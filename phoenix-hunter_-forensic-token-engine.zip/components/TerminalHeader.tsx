
import React, { useState, useEffect } from 'react';
import { Terminal, ShieldAlert, Cpu, Activity, Zap, Flame, Cloud, Target } from 'lucide-react';
import { storageService } from '../services/storageService';

interface Props {
  status: string;
  uptime: number;
}

const TerminalHeader: React.FC<Props> = ({ status, uptime }) => {
  const [syncInfo, setSyncInfo] = useState(storageService.getSyncStatus());

  useEffect(() => {
    const interval = setInterval(() => {
      setSyncInfo(storageService.getSyncStatus());
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const hours = Math.floor(uptime / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  const seconds = uptime % 60;

  const sessionId = React.useMemo(
    () => Math.random().toString(16).slice(2, 12).toUpperCase(),
    []
  );

  return (
    <div className="glass-panel rounded-xl border-l-4 border-orange-500 overflow-hidden flex flex-col lg:flex-row items-stretch shadow-2xl relative">
      {/* Decorative Wing Element */}
      <div className="absolute top-0 right-0 w-32 h-full opacity-[0.03] pointer-events-none">
        <Flame size={120} className="rotate-45" />
      </div>

      {/* Brand ID */}
      <div className="p-6 bg-white/[0.02] flex items-center gap-6 border-b lg:border-b-0 lg:border-r border-zinc-800/50 wing-tip">
        <div className="p-4 bg-orange-500/10 rounded-xl border border-orange-500/30 shadow-[0_0_30px_rgba(249,115,22,0.15)] relative group overflow-hidden">
          <Flame className="text-orange-500 relative z-10" size={32} />
          <div className="absolute inset-0 bg-gradient-to-t from-orange-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-orange-500 rounded-full animate-ping opacity-75" />
        </div>
        <div>
          <h1 className="text-2xl font-black text-white tracking-tighter flex items-center gap-2">
            PHOENIX<span className="text-orange-500">NEURAL</span>
            <span className="text-[10px] bg-orange-500/20 px-2 py-0.5 rounded font-mono text-orange-400 font-normal border border-orange-500/20">v1.0.REBORN</span>
          </h1>
          <div className="flex items-center gap-2 mt-1">
            <p className="text-[9px] text-zinc-500 uppercase tracking-[0.3em] font-bold">Ashen-Input Forensic Core</p>
            {syncInfo.isConfigured && (
              <div className={`flex items-center gap-1 bg-orange-500/10 border border-orange-500/20 px-1.5 py-0.5 rounded`}>
                <Cloud size={8} className="text-orange-400" />
                <span className="text-[7px] text-orange-400 font-black uppercase">Ledger Active</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Stats Center */}
      <div className="flex-1 grid grid-cols-2 md:grid-cols-4 divide-x divide-zinc-800/50">
        <HUDStat icon={<Activity size={14}/>} label="Thermal Core" value={status} color="text-orange-400" />
        <HUDStat 
          icon={<Zap size={14}/>}
          label="Incineration Clock" 
          value={`${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`} 
        />
        <HUDStat icon={<Target size={14}/>} label="Forensic Focus" value="HIGH-FI" color="text-amber-500" />
        <HUDStat icon={<Cpu size={14}/>} label="Neural Node" value="SOL-PHX" color="text-red-400" />
      </div>

      {/* Connection Hash */}
      <div className="hidden lg:flex flex-col justify-center px-8 bg-black/40 border-l border-zinc-800/50 min-w-[200px]">
        <div className="flex items-center gap-2 text-[9px] text-zinc-600 uppercase font-black tracking-widest mb-1">
          <Flame size={10} className="text-orange-500" /> Sync Hash
        </div>
        <div className="text-sm font-mono font-bold text-zinc-300 tracking-[0.1em]">
          {sessionId}
        </div>
      </div>
    </div>
  );
};

const HUDStat = React.memo(
  ({ icon, label, value, color = 'text-white' }: { icon: React.ReactNode, label: string, value: string, color?: string }) => (
    <div className="p-5 flex flex-col justify-center gap-1 group hover:bg-orange-500/[0.03] transition-colors cursor-default">
      <div className="flex items-center gap-2 text-[10px] text-zinc-600 uppercase font-black tracking-widest">
        {icon} {label}
      </div>
      <div className={`text-sm font-black tracking-widest uppercase ${color}`}>
        {value}
      </div>
    </div>
  )
);

HUDStat.displayName = 'HUDStat';

export default TerminalHeader;
