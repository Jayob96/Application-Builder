
import React, { useState, useEffect } from 'react';
import { SystemLog } from '../types';
import { Terminal, Activity, ShieldCheck, Cloud, Zap, Database, AlertCircle } from 'lucide-react';
import { storageService } from '../services/storageService';

interface Props {
  logs: SystemLog[];
}

const SystemLogs: React.FC<Props> = ({ logs }) => {
  const scrollRef = React.useRef<HTMLDivElement>(null);
  const [syncStatus, setSyncStatus] = useState(storageService.getSyncStatus());
  
  // Safe access to environment variables
  const env = (import.meta as any).env || {};
  const hasBackpackKey = !!env.VITE_BACKPACK_API_KEY;

  useEffect(() => {
    const timer = setInterval(() => {
      setSyncStatus(storageService.getSyncStatus());
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  React.useEffect(() => {
    const scrollTimer = requestAnimationFrame(() => {
      if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
      }
    });
    return () => cancelAnimationFrame(scrollTimer);
  }, [logs]);

  const getLogColor = (type: string, severity: number = 0) => {
    if (severity >= 4) return 'text-red-500 font-bold uppercase underline';
    switch (type) {
      case 'error': return 'text-red-500 font-bold';
      case 'warning': return 'text-yellow-500/80 italic';
      case 'success': return 'text-green-500 font-bold';
      case 'audit': return 'text-blue-400 italic opacity-80';
      case 'trade': return 'text-white bg-green-500/20 px-1 rounded font-bold';
      default: return 'text-zinc-500';
    }
  };

  return (
    <div className="space-y-4">
      {/* Kernel Diagnostics Panel */}
      <div className="grid grid-cols-2 gap-2">
        <DiagnosticNode 
          label="Cloud Ledger" 
          active={syncStatus.isConfigured} 
          icon={<Cloud size={10}/>} 
          status={syncStatus.isConfigured ? "LINKED" : "MISSING ID"}
        />
        <DiagnosticNode 
          label="Execution Node" 
          active={hasBackpackKey} 
          icon={<Zap size={10}/>} 
          status={hasBackpackKey ? "READY" : "DEFERRED"}
        />
      </div>

      <div className="glass-panel rounded-xl border border-zinc-800/50 flex flex-col h-[320px] shadow-2xl overflow-hidden" role="log" aria-live="polite">
        <div className="px-5 py-3 border-b border-zinc-800/50 flex justify-between items-center bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <Terminal size={12} className="text-zinc-600" />
            <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">System Kernel Journal</span>
          </div>
          <div className="flex gap-1">
            <div className={`w-1.5 h-1.5 rounded-full ${logs.length > 0 ? 'bg-green-500 animate-pulse' : 'bg-zinc-800'}`} />
            <div className="w-1.5 h-1.5 rounded-full bg-zinc-800" />
          </div>
        </div>
        
        <div 
          ref={scrollRef} 
          className="flex-1 overflow-y-auto p-5 font-mono text-[10px] space-y-2.5 scroll-smooth scrollbar-hide bg-black/40"
        >
          {logs.map((log) => (
            <div 
              key={`${log.id}-${log.timestamp}`} 
              className="flex gap-4 group hover:bg-white/[0.02] transition-colors rounded -mx-2 px-2 py-0.5"
            >
              <span className="text-zinc-700 shrink-0 select-none font-bold">
                {new Date(log.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </span>
              <div className="flex-1 leading-relaxed">
                <span className="text-[8px] text-zinc-800 uppercase font-black mr-2">[{log.actor || 'sys'}]</span>
                <span className={getLogColor(log.type, log.severity)}>
                  {log.message}
                </span>
              </div>
            </div>
          ))}
          
          {logs.length === 0 && (
            <div 
              className="h-full flex flex-col items-center justify-center gap-3 opacity-20"
              role="status"
              aria-label="System is establishing connection to logging feed"
            >
              <div className="w-8 h-8 rounded border-2 border-dashed border-zinc-600 animate-spin" />
              <span className="text-[9px] uppercase font-bold tracking-[0.4em]">Establishing Feed...</span>
            </div>
          )}
        </div>

        <div className="px-5 py-2 border-t border-zinc-800/50 bg-white/[0.02] flex justify-between items-center text-[9px] font-mono text-zinc-700 uppercase tracking-widest font-bold">
          <span>Signals Cached: {logs.length}</span>
          <span className="text-green-500 animate-pulse">█ SYSTEM ACTIVE</span>
        </div>
      </div>
    </div>
  );
};

const DiagnosticNode = ({ label, active, status, icon }: { label: string, active: boolean, status: string, icon: any }) => (
  <div className={`p-2 rounded-lg border glass-panel flex items-center justify-between ${active ? 'border-green-500/20 bg-green-500/5' : 'border-red-500/20 bg-red-500/5'}`}>
    <div className="flex items-center gap-2">
      <div className={active ? 'text-green-500' : 'text-red-500 opacity-50'}>{icon}</div>
      <span className="text-[8px] font-black uppercase text-zinc-400">{label}</span>
    </div>
    <span className={`text-[8px] font-black uppercase ${active ? 'text-green-500' : 'text-red-500'}`}>{status}</span>
  </div>
);

export default SystemLogs;
