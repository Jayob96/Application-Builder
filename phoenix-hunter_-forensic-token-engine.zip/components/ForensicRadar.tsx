
import React from 'react';
import { ScoringWeights } from '../types';

interface Props {
  weights: ScoringWeights;
  title?: string;
}

const ForensicRadar: React.FC<Props> = ({ weights, title = "Neural Calibration" }) => {
  const entries = Object.entries(weights);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-[10px] font-black text-white uppercase tracking-[0.2em] flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
          {title}
        </h3>
      </div>
      <div className="grid grid-cols-1 gap-4">
        {entries.map(([key, val]) => (
          <div key={key} className="space-y-1.5">
            <div className="flex justify-between text-[9px] uppercase font-black tracking-widest">
              <span className="text-zinc-500">{key.replace(/([A-Z])/g, ' $1')}</span>
              <span className="text-orange-400 font-bold">{(Number(val) * 100).toFixed(1)}%</span>
            </div>
            <div className="h-1.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
              <div 
                className="h-full bg-gradient-to-r from-red-600 via-orange-500 to-amber-400 transition-all duration-1000 shadow-[0_0_15px_rgba(249,115,22,0.3)]" 
                style={{ width: `${Number(val) * 100}%` }} 
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ForensicRadar;
