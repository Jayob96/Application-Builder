
import React from 'react';
import { ActiveToken, TokenRisk, LifecycleStage } from '../types';
import { TrendingUp, TrendingDown, Activity, Loader2, Eye, ShoppingCart, LogOut, Crosshair, Zap } from 'lucide-react';

interface Props {
  tokens: ActiveToken[];
  limit?: number;
  onSnipe?: (id: string) => void;
  onExit?: (id: string) => void;
  onViewAudit?: (token: ActiveToken) => void;
}

const TokenTable: React.FC<Props> = ({ tokens, limit = 10, onSnipe, onExit, onViewAudit }) => {
  const displayTokens = tokens.slice(0, limit);

  return (
    <div className="glass-panel rounded-xl overflow-hidden border-zinc-800/50 shadow-2xl">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[900px]">
          <thead>
            <tr className="bg-white/[0.02] border-b border-zinc-800/50">
              <th className="px-6 py-4 text-[10px] font-black text-zinc-600 uppercase tracking-widest">Asset Signal</th>
              <th className="px-6 py-4 text-[10px] font-black text-zinc-600 uppercase tracking-widest text-center">Neural Phase</th>
              <th className="px-6 py-4 text-[10px] font-black text-zinc-600 uppercase tracking-widest">Forensic Gauge</th>
              <th className="px-6 py-4 text-[10px] font-black text-zinc-600 uppercase tracking-widest text-right">Thermal ROI</th>
              <th className="px-6 py-4 text-[10px] font-black text-zinc-600 uppercase tracking-widest text-center">Commands</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800/30">
            {displayTokens.map((token) => (
              <tr key={token.id} className="group hover:bg-orange-500/[0.02] transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center font-black italic text-zinc-100 group-hover:border-orange-500/50 transition-colors">
                      {token.symbol[0]}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-black text-white group-hover:text-orange-400 transition-colors">{token.symbol}</span>
                        <span className="text-[7px] font-black bg-orange-500/10 text-orange-500 px-1.5 py-0.5 rounded border border-orange-500/20 uppercase">{token.discoverySource}</span>
                      </div>
                      <div className="text-[10px] text-zinc-700 font-mono mt-0.5">{token.mint.slice(0, 10)}...</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 text-center">
                  <span className={`px-3 py-1 rounded-full text-[8px] font-black border uppercase tracking-widest inline-flex items-center gap-2 ${token.stage === 'TRACKING' ? 'bg-orange-500/10 text-orange-500 border-orange-500/20' : 'bg-zinc-800/50 text-zinc-500 border-zinc-800/50'}`}>
                    {token.stage === 'AUDITING' ? <Loader2 size={10} className="animate-spin" /> : <div className="w-1 h-1 rounded-full bg-current" />}
                    {token.stage}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="max-w-[120px] space-y-1.5">
                    <div className="flex justify-between text-[8px] font-black text-orange-500/50 uppercase">
                      <span>{token.analysis?.riskLevel || 'EVAL'}</span>
                      <span>{token.analysis?.forensicScore?.toFixed(0) || 0}%</span>
                    </div>
                    <div className="h-1 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                      <div className="h-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.5)]" style={{ width: `${token.analysis?.forensicScore || 0}%` }} />
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className={`flex flex-col items-end gap-1 ${token.currentRoi >= 1 ? 'text-orange-400' : 'text-red-500'}`}>
                    <div className="text-base font-black italic tabular-nums flex items-center gap-1">
                      {token.currentRoi >= 1 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                      {((token.currentRoi - 1) * 100).toFixed(1)}%
                    </div>
                    <div className="text-[8px] text-zinc-700 font-black uppercase tracking-widest">MC: ${(token.marketCap / 1000).toFixed(1)}k</div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center justify-center gap-2">
                    <button onClick={() => onViewAudit?.(token)} className="p-2 bg-white/5 hover:bg-orange-500/10 rounded-lg text-zinc-500 hover:text-orange-400 transition-all"><Eye size={14} /></button>
                    {token.stage === 'TRACKING' ? (
                      <button onClick={() => onExit?.(token.id)} className="p-2 bg-red-500/10 hover:bg-red-500/20 rounded-lg text-red-500"><LogOut size={14} /></button>
                    ) : (
                      <button onClick={() => onSnipe?.(token.id)} className="p-2 bg-orange-500/10 hover:bg-orange-500/20 rounded-lg text-orange-500"><Crosshair size={14} /></button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TokenTable;
