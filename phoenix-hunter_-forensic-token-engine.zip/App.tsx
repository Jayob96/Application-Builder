
import React, { useState, useEffect, useRef } from 'react';
import { ActiveToken, ScoringWeights, SystemLog, EvolutionReport, TokenRisk } from './types';
import { INITIAL_WEIGHTS } from './constants';
import { GeminiQuotaService } from './services/geminiQuotaService';
import { ForensicEngine } from './services/geminiService';
import { DecisionEngine } from './services/decisionEngine';
import { IngestionService } from './services/ingestionService';
import { logger } from './services/observabilityService';
import { storageService } from './services/storageService';
import TerminalHeader from './components/TerminalHeader';
import TokenTable from './components/TokenTable';
import SystemLogs from './components/SystemLogs';
import ForensicRadar from './components/ForensicRadar';
import { 
  Activity, Zap, Search, Flame, TrendingUp, Sparkles, AlertTriangle, 
  X, Fingerprint, ShieldCheck, BarChart3, Cpu, RefreshCw, Layers, 
  LayoutDashboard, Target, Bird, Lock, ShieldAlert, Wifi, PieChart, 
  Terminal as TerminalIcon, FileText, ExternalLink, Brain, Database,
  Copy, Check
} from 'lucide-react';

type NavNode = 'dashboard' | 'trading' | 'evolution' | 'reports' | 'logs';

const App: React.FC = () => {
  const [tokens, setTokens] = useState<ActiveToken[]>([]);
  const [weights, setWeights] = useState<ScoringWeights>(INITIAL_WEIGHTS);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [uptime, setUptime] = useState(0);
  const [isEvolving, setIsEvolving] = useState(false);
  const [isIngesting, setIsIngesting] = useState(false);
  const [activeTab, setActiveTab] = useState<'tracking' | 'recent' | 'trending' | 'organic'>('tracking');
  const [activeNav, setActiveNav] = useState<NavNode>('dashboard');
  const [selectedToken, setSelectedToken] = useState<ActiveToken | null>(null);
  const [testMint, setTestMint] = useState("");
  const [bootError, setBootError] = useState<string | null>(null);
  const [isBooted, setIsBooted] = useState(false);

  const engineRef = useRef<DecisionEngine | null>(null);
  const forensicRef = useRef<ForensicEngine | null>(null);
  const quotaRef = useRef<GeminiQuotaService | null>(null); 
  const ingestionRef = useRef<IngestionService | null>(null);
  const initJupiterRetries = useRef(0);

  useEffect(() => {
    const unsubscribe = logger.subscribe((log: SystemLog) => {
      setLogs(prev => [log, ...prev].slice(0, 100));
    });

    const bootSystem = async () => {
      try {
        forensicRef.current = new ForensicEngine();
        quotaRef.current = new GeminiQuotaService();
        ingestionRef.current = new IngestionService();
        
        engineRef.current = new DecisionEngine(quotaRef.current!, (updatedTokens: ActiveToken[]) => {
          setTokens([...updatedTokens].sort((a, b) => b.first_seen - a.first_seen));
        });
        
        await engineRef.current.start(weights);
        setIsBooted(true);
        logger.log("Phoenix Synapse online. Core ignited.", "success");
      } catch (err: any) {
        setBootError(err.message || "Neural Boot Failure");
      }
    };

    bootSystem();
    const timer = setInterval(() => setUptime(u => u + 1), 1000);
    initJupiter();
    return () => {
      unsubscribe();
      clearInterval(timer);
    };
  }, []);

  const initJupiter = (mint?: string) => {
    if ((window as any).Jupiter) {
      try {
        (window as any).Jupiter.init({
          displayMode: "integrated",
          integratedTargetId: "jupiter-terminal-container",
          endpoint: "https://api.mainnet-beta.solana.com",
          strictTokenList: false,
          formProps: {
            fixedOutputMint: false,
            initialOutputMint: mint,
          },
        });
        initJupiterRetries.current = 0; 
      } catch (err: any) {
        logger.log(`Jupiter Error: ${err.message}`, "error");
      }
    } else if (initJupiterRetries.current < 15) {
      initJupiterRetries.current++;
      setTimeout(() => initJupiter(mint), 1000);
    }
  };

  const handleJupiterSync = async (type: 'recent' | 'trending' | 'organic') => {
    if (!ingestionRef.current || !isBooted) return;
    setIsIngesting(true);
    setActiveTab(type);
    try {
      const events = await ingestionRef.current.fetchJupiterFeed(type);
      for (const event of events) {
        if (engineRef.current) await engineRef.current.ingestToken(event);
      }
    } finally {
      setIsIngesting(false);
    }
  };

  const handleSearch = async () => {
    if (!testMint || isIngesting || !ingestionRef.current) return;
    setIsIngesting(true);
    try {
      const event = await ingestionRef.current.fetchJupiterByMint(testMint);
      if (event && engineRef.current) await engineRef.current.ingestToken(event);
    } finally {
      setIsIngesting(false);
    }
  };

  if (bootError) return <BootError message={bootError} />;
  if (!isBooted) return <BootingScreen />;

  const activeTracking = tokens.filter(t => t.stage === 'TRACKING');
  const candidates = tokens.filter(t => t.status === 'active' && t.stage !== 'TRACKING').slice(0, 15);

  return (
    <div className="flex min-h-screen bg-[#050505] text-white font-mono overflow-hidden">
      {/* Sidebar */}
      <aside className="w-20 lg:w-64 border-r border-orange-500/10 glass-panel flex flex-col z-50">
        <div className="p-6 border-b border-orange-500/10 flex items-center gap-3 bg-gradient-to-r from-orange-500/5 to-transparent wing-tip">
          <div className="w-8 h-8 bg-orange-500 rounded flex items-center justify-center shadow-[0_0_20px_rgba(249,115,22,0.4)]">
            <Bird size={20} className="text-black" />
          </div>
          <span className="hidden lg:block text-lg font-black tracking-tighter italic">PHOENIX<span className="text-orange-500">HUNTER</span></span>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 mt-4 overflow-y-auto scrollbar-hide">
          <NavButton active={activeNav === 'dashboard'} icon={<LayoutDashboard size={20}/>} label="Thermal Hub" onClick={() => setActiveNav('dashboard')} />
          <NavButton active={activeNav === 'trading'} icon={<Target size={20}/>} label="Intercept" onClick={() => setActiveNav('trading')} />
          <NavButton active={activeNav === 'evolution'} icon={<Flame size={20}/>} label="Neural Lab" onClick={() => setActiveNav('evolution')} />
          <NavButton active={activeNav === 'reports'} icon={<FileText size={20}/>} label="Visual Ledger" onClick={() => setActiveNav('reports')} />
          <NavButton active={activeNav === 'logs'} icon={<TerminalIcon size={20}/>} label="Kernel Log" onClick={() => setActiveNav('logs')} />
        </nav>
      </aside>

      {/* Main */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <div className="p-6 overflow-y-auto scrollbar-hide">
          <TerminalHeader status={isEvolving ? "EVOLVING" : "STABLE"} uptime={uptime} />
          
          <div className="mt-6">
            {activeNav === 'dashboard' && (
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
                <div className="xl:col-span-8 space-y-6">
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <DashboardStat icon={<Activity size={18}/>} label="Ignited Nodes" value={activeTracking.length} color="orange" />
                      <DashboardStat icon={<Database size={18}/>} label="Ashen Records" value={tokens.length} color="amber" />
                      <DashboardStat icon={<TrendingUp size={18}/>} label="Neural Purity" value="91.4%" color="red" />
                   </div>
                   <TokenTable tokens={candidates} limit={10} onViewAudit={setSelectedToken} />
                </div>
                <div className="xl:col-span-4 space-y-4">
                   <div className="glass-panel p-6 rounded-xl border border-orange-500/10 bg-black/40">
                      <ForensicRadar weights={weights} title="Global Weight Distribution" />
                   </div>
                   <SystemLogs logs={logs.slice(0, 50)} />
                </div>
              </div>
            )}

            {activeNav === 'trading' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-8 space-y-6">
                  <div className="glass-panel p-4 rounded-xl flex gap-3 border-orange-500/10">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={16} />
                      <input 
                        type="text" 
                        placeholder="Interrogate Mint Address..." 
                        className="w-full bg-black/60 border border-zinc-800/50 rounded-lg pl-10 pr-4 py-3 text-sm font-mono text-zinc-300 focus:border-orange-500 focus:outline-none transition-all" 
                        value={testMint} 
                        onChange={(e) => setTestMint(e.target.value)} 
                      />
                    </div>
                    <button onClick={handleSearch} disabled={isIngesting} className="px-8 py-3 btn-fire rounded-lg flex items-center gap-2 disabled:opacity-50">
                      <Zap size={14} className="text-black" /> Intercept
                    </button>
                  </div>
                  <div className="flex items-center gap-4 mb-4">
                    <FeedTab icon={<Flame size={12}/>} label="Scorching" active={activeTab === 'trending'} onClick={() => handleJupiterSync('trending')} />
                    <FeedTab icon={<Sparkles size={12}/>} label="Fresh Embers" active={activeTab === 'recent'} onClick={() => handleJupiterSync('recent')} />
                    <FeedTab icon={<Activity size={12}/>} label="Locked On" active={activeTab === 'tracking'} onClick={() => setActiveTab('tracking')} />
                  </div>
                  <TokenTable 
                    tokens={activeTab === 'tracking' ? (activeTracking.length > 0 ? activeTracking : candidates) : candidates} 
                    onSnipe={(id) => engineRef.current?.manualSnipe(id)}
                    onViewAudit={setSelectedToken} 
                  />
                </div>
                <div className="lg:col-span-4 h-[700px]">
                  <div className="glass-panel h-full rounded-xl overflow-hidden border border-zinc-800/50">
                    <div id="jupiter-terminal-container" className="w-full h-full"></div>
                  </div>
                </div>
              </div>
            )}
            
            {activeNav === 'evolution' && (
              <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
                <div className="xl:col-span-1">
                  <div className="glass-panel p-6 rounded-2xl border-orange-500/20">
                    <h3 className="text-[10px] font-black uppercase tracking-widest mb-6 text-orange-500">Thermal Calibration</h3>
                    <ForensicRadar weights={weights} />
                  </div>
                </div>
                <div className="xl:col-span-3">
                  <div className="glass-panel p-16 rounded-2xl border-dashed border-zinc-800 flex flex-col items-center justify-center text-center opacity-40">
                    <Flame size={48} className="mb-4 text-zinc-600 animate-pulse" />
                    <h3 className="text-lg font-black uppercase tracking-tighter">Neural Lab Offline</h3>
                    <p className="text-xs text-zinc-500 max-w-sm">Gather more thermal data to re-ignite the evolution core.</p>
                  </div>
                </div>
              </div>
            )}
            
            {activeNav === 'reports' && (
              <div className="glass-panel p-8 rounded-2xl border-zinc-800/50 flex flex-col items-center justify-center h-64 opacity-50">
                 <FileText size={32} className="mb-2 text-zinc-700" />
                 <span className="text-[10px] font-black uppercase tracking-[0.4em]">Visual Ledger Synching...</span>
              </div>
            )}

            {activeNav === 'logs' && <SystemLogs logs={logs} />}
          </div>
        </div>
      </main>

      {/* Audit Modal */}
      {selectedToken && (
        <AuditModal token={selectedToken} weights={weights} onClose={() => setSelectedToken(null)} onSwap={initJupiter} />
      )}
    </div>
  );
};

const NavButton = ({ active, icon, label, onClick }: { active: boolean, icon: any, label: string, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all relative overflow-hidden group ${active ? 'bg-orange-500/10 text-orange-500 border border-orange-500/20' : 'text-zinc-600 hover:text-orange-400 hover:bg-white/5'}`}
  >
    {active && <div className="absolute left-0 top-0 w-1 h-full bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.5)]" />}
    {icon}
    <span className="hidden lg:block text-[10px] font-black uppercase tracking-widest">{label}</span>
  </button>
);

const DashboardStat = ({ icon, label, value, color }: { icon: any, label: string, value: string | number, color: string }) => {
  const colors: any = { 
    orange: 'text-orange-500 bg-orange-500/5 border-orange-500/10', 
    amber: 'text-amber-500 bg-amber-500/5 border-amber-500/10', 
    red: 'text-red-500 bg-red-500/5 border-red-500/10' 
  };
  return (
    <div className={`p-6 rounded-xl border glass-panel ${colors[color]} flex flex-col gap-2`}>
      <div className="flex items-center gap-2 opacity-60">
        {icon} <span className="text-[10px] font-black uppercase tracking-widest">{label}</span>
      </div>
      <div className="text-3xl font-black tracking-tighter">{value}</div>
    </div>
  );
};

const FeedTab = ({ icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) => (
  <button 
    onClick={onClick} 
    className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${active ? 'bg-orange-500 text-black shadow-xl' : 'text-zinc-600 hover:bg-white/5 hover:text-orange-400'}`}
  >
    {icon} {label}
  </button>
);

const AuditModal = ({ token, weights, onClose, onSwap }: { token: ActiveToken, weights: ScoringWeights, onClose: () => void, onSwap: (mint: string) => void }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setActiveStep(s => s < 9 ? s + 1 : s), 80);
    return () => clearInterval(timer);
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(token.mint);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const securityGates = [
    { label: "Liq. Depth", status: token.liquidity > 25000 ? 'SECURE' : 'THIN', icon: <Layers size={12}/> },
    { label: "LP Lock", status: token.liquidity > 10000 ? 'DETECTED' : 'UNCONFIRMED', icon: <Lock size={12}/> },
    { label: "Mint Auth", status: token.contractVerified ? 'RENUNCIATED' : 'ACTIVE', icon: <ShieldCheck size={12}/> },
    { label: "Freeze Auth", status: 'DISABLED', icon: <ShieldAlert size={12}/> },
    { label: "Top Holders", status: token.holders > 500 ? 'DISTRIBUTED' : 'CONCENTRATED', icon: <PieChart size={12}/> },
    { label: "Dev Rep", status: token.platformQuality > 60 ? 'ELITE' : 'UNKNOWN', icon: <Brain size={12}/> },
    { label: "Organic Vol", status: token.socialScore > 50 ? 'AUTHENTIC' : 'SUSPICIOUS', icon: <Activity size={12}/> },
    { label: "Tax Forensic", status: 'CLEAN', icon: <TrendingUp size={12}/> },
    { label: "Verification", status: token.contractVerified ? 'PASSED' : 'MANUAL', icon: <ShieldCheck size={12}/> },
  ];

  const score = token.analysis?.forensicScore || 50;

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-black/98 backdrop-blur-xl">
      <div className="glass-panel max-w-5xl w-full rounded-2xl overflow-hidden border-orange-500/30 relative shadow-[0_0_150px_rgba(249,115,22,0.1)]">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-orange-500 to-transparent animate-[scan-line_3.5s_linear_infinite] opacity-40 pointer-events-none" />
        
        {/* Header */}
        <div className="p-8 border-b border-zinc-800/50 flex justify-between items-start bg-gradient-to-b from-white/[0.03] to-transparent">
          <div className="flex items-center gap-8">
            <div className="w-24 h-24 rounded-2xl bg-zinc-900 border-2 border-orange-500/20 flex items-center justify-center text-5xl font-black italic text-orange-500 shadow-inner relative group">
              <div className="absolute inset-0 bg-orange-500/5 animate-pulse rounded-2xl" />
              {token.symbol[0]}
            </div>
            <div>
              <div className="flex items-center gap-4">
                <h3 className="text-4xl font-black text-white tracking-tighter">{token.name}</h3>
                <span className="text-zinc-600 font-mono text-xl font-bold">[{token.symbol}]</span>
                <div className={`px-3 py-1 rounded text-[10px] font-black uppercase tracking-[0.2em] ${score > 70 ? 'bg-orange-500/20 text-orange-500 border border-orange-500/30' : 'bg-red-500/20 text-red-500 border border-red-500/30'}`}>
                  {score > 70 ? 'SENTINEL_APPROVED' : 'RISK_DETECTED'}
                </div>
              </div>
              <div className="flex items-center gap-3 mt-3">
                <p className="text-[10px] text-zinc-500 font-mono tracking-widest flex items-center gap-2">
                  <Wifi size={10} className="text-orange-500 animate-pulse" /> {token.mint}
                </p>
                <button onClick={handleCopy} className="p-1.5 hover:bg-white/5 rounded transition-all text-zinc-600 hover:text-orange-500">
                  {copied ? <Check size={12} /> : <Copy size={12} />}
                </button>
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-3 hover:bg-orange-500/10 rounded-full text-zinc-600 hover:text-orange-500 transition-all">
            <X size={32} />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 h-[600px]">
          {/* Main Diagnostic Body */}
          <div className="lg:col-span-8 p-10 border-r border-zinc-800/50 overflow-y-auto scrollbar-hide space-y-12 bg-black/40 relative">
            
            {/* Phase 1: Security Matrix */}
            <section>
              <h4 className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.4em] mb-6 flex items-center gap-2">
                <ShieldCheck size={14} className="text-orange-500" /> Forensic Security Matrix
              </h4>
              <div className="grid grid-cols-3 gap-4">
                {securityGates.map((gate, idx) => (
                  <div key={idx} className={`p-5 rounded-xl border transition-all duration-300 ${idx < activeStep ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'} ${gate.status.includes('SECURE') || gate.status.includes('RENUNCIATED') || gate.status.includes('PASSED') ? 'bg-orange-500/[0.03] border-orange-500/10' : 'bg-zinc-900/40 border-zinc-800/50'}`}>
                    <div className="flex items-center gap-2 text-[8px] font-black text-zinc-600 uppercase tracking-widest mb-3">{gate.icon} {gate.label}</div>
                    <div className={`text-xs font-black tracking-widest ${gate.status.includes('SECURE') || gate.status.includes('RENUNCIATED') || gate.status.includes('PASSED') ? 'text-orange-400' : 'text-zinc-500'}`}>
                      {gate.status}
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Phase 2: Neural Reasoning */}
            <section>
              <h4 className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.4em] mb-6 flex items-center gap-2">
                <Fingerprint size={14} className="text-orange-500" /> Neural Interrogation Signal
              </h4>
              <div className="bg-orange-500/[0.02] border border-orange-500/10 p-8 rounded-2xl relative overflow-hidden group hover:border-orange-500/30 transition-all">
                <div className="absolute top-0 right-0 p-8 opacity-[0.03] pointer-events-none group-hover:opacity-10 transition-opacity">
                   <Brain size={120}/>
                </div>
                <h4 className="text-[9px] font-black text-orange-600 uppercase tracking-[0.5em] mb-3 flex items-center gap-2">
                   <Wifi size={10} className="animate-pulse"/> Gemini 3 Inference Trace
                </h4>
                <p className="text-lg text-zinc-200 leading-relaxed italic font-medium">
                  "{token.analysis?.reasoning || 'Decrypting neural ash metadata from cluster nodes...'}"
                </p>
              </div>
            </section>
          </div>

          {/* Right Panel: Scoring & Actions */}
          <div className="lg:col-span-4 p-10 space-y-10 bg-zinc-900/20 flex flex-col justify-between">
            <div className="space-y-10">
              <div className="text-center space-y-3">
                <div className="text-[11px] font-black text-zinc-600 uppercase tracking-[0.5em]">Forensic Score</div>
                <div className={`text-7xl font-black tracking-tighter ${score > 70 ? 'text-orange-500' : 'text-red-500'} drop-shadow-[0_0_20px_rgba(249,115,22,0.1)]`}>
                  {score.toFixed(0)}
                </div>
                <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden border border-zinc-800/50">
                  <div className={`h-full transition-all duration-1000 ${score > 70 ? 'bg-orange-500' : 'bg-red-500'}`} style={{ width: `${score}%` }} />
                </div>
              </div>

              <div className="space-y-4">
                 <AuditRow label="Risk Profile" value={token.analysis?.riskLevel || 'EVAL'} color={token.analysis?.riskLevel === 'LOW' ? 'text-orange-400' : 'text-red-500'} />
                 <AuditRow label="Rug Probability" value={`${((token.analysis?.rugProbability || 0) * 100).toFixed(1)}%`} color={token.analysis?.rugProbability < 0.2 ? 'text-orange-500' : 'text-red-500'} />
                 <AuditRow label="Liquidity Base" value={`$${(token.liquidity / 1000).toFixed(1)}k`} />
                 <AuditRow label="Social Depth" value={token.socialScore > 70 ? 'HIGH' : 'LOW'} color="text-amber-500" />
              </div>

              <div className="pt-4 opacity-70">
                 <ForensicRadar weights={weights} title="Weight Impact Analysis" />
              </div>
            </div>

            <div className="pt-10">
              <button 
                onClick={() => { onSwap(token.mint); onClose(); }} 
                className="w-full py-5 btn-fire rounded-xl flex items-center justify-center gap-4 shadow-[0_20px_60px_rgba(0,0,0,0.5)] active:scale-[0.98] transition-all group"
              >
                <Zap size={24} className="text-black group-hover:scale-125 transition-transform" /> 
                <span className="text-black text-sm font-black">EXECUTE THERMAL SWAP</span>
              </button>
              <div className="text-[8px] text-zinc-700 text-center mt-4 uppercase tracking-[0.5em] font-black italic">
                Secure Swap Protocol v1.4 // Slippage: Auto
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const AuditRow = ({ label, value, color = 'text-white' }: { label: string, value: string, color?: string }) => (
  <div className="flex justify-between items-center text-[10px] border-b border-zinc-800/50 pb-3">
    <span className="text-zinc-600 font-black uppercase tracking-[0.2em]">{label}</span>
    <span className={`font-mono font-bold ${color} tracking-tight`}>{value}</span>
  </div>
);

const BootingScreen = () => (
  <div className="min-h-screen bg-[#050505] flex flex-col items-center justify-center font-mono gap-6 relative overflow-hidden">
    <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_0%,_#050505_100%)] opacity-80" />
    <div className="relative">
      <div className="w-24 h-24 border-2 border-orange-500/10 border-t-orange-500 rounded-full animate-spin shadow-[0_0_50px_rgba(249,115,22,0.2)]" />
      <Bird className="absolute inset-0 m-auto text-orange-500 animate-pulse" size={40} />
    </div>
    <div className="flex flex-col items-center gap-1 z-10">
      <div className="text-[12px] text-orange-500 font-black uppercase tracking-[0.8em] animate-pulse">Initializing Phoenix Neural</div>
      <div className="text-[8px] text-zinc-700 uppercase tracking-widest mt-2 font-black">Decrypting Secure Channels...</div>
    </div>
  </div>
);

const BootError = ({ message }: { message: string }) => (
  <div className="min-h-screen bg-[#050505] flex items-center justify-center p-6 font-mono">
    <div className="max-w-xl w-full glass-panel border-red-500/50 p-12 rounded-3xl text-center shadow-[0_0_100px_rgba(239,68,68,0.1)]">
      <AlertTriangle className="text-red-500 mb-8 mx-auto" size={80} />
      <h1 className="text-3xl font-black uppercase tracking-tighter mb-4">Neural Kernel Ash</h1>
      <div className="bg-red-500/5 border border-red-500/10 p-6 rounded-xl mb-10">
        <p className="text-xs text-red-400 font-mono italic leading-relaxed">{message}</p>
      </div>
      <button onClick={() => window.location.reload()} className="w-full py-4 bg-red-500 text-black text-[11px] font-black uppercase tracking-[0.4em] rounded-xl hover:bg-red-400 transition-all shadow-xl">
        Hard Rebirth Loop
      </button>
    </div>
  </div>
);

export default App;
