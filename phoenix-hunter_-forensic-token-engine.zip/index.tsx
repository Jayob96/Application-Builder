
import React, { ErrorInfo, ReactNode } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { AlertOctagon } from 'lucide-react';

interface ErrorBoundaryProps {
  children?: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

// Global Error Boundary to catch neural kernel panics
class GlobalErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  // Fix: Explicitly declare state and props to fix "Property does not exist" errors
  public state: ErrorBoundaryState;
  public props: ErrorBoundaryProps;

  // Explicit constructor helps TypeScript infer props property correctly
  constructor(props: ErrorBoundaryProps) {
    super(props);
    // Fix: Initializing state within constructor after explicit declaration
    this.state = {
      hasError: false,
      error: null
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("PHX_KERNEL_PANIC:", error, errorInfo);
  }

  render() {
    // Fix: Accessing explicitly declared state property
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#050505] flex items-center justify-center p-6 font-mono text-white">
          <div className="max-w-2xl w-full glass-panel border-red-500/50 p-8 rounded-2xl shadow-2xl bg-black/80">
            <div className="flex items-center gap-4 text-red-500 mb-6">
              <AlertOctagon size={48} />
              <div>
                <h1 className="text-2xl font-black uppercase tracking-tighter italic">Neural Ash Detected</h1>
                <p className="text-xs opacity-60 uppercase font-bold tracking-[0.2em]">Execution Loop Halted</p>
              </div>
            </div>
            <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-lg mb-6">
              <pre className="text-xs text-red-300 whitespace-pre-wrap overflow-x-auto">
                {this.state.error?.message || "SYNAPSE_FAILURE"}
              </pre>
            </div>
            <button 
              onClick={() => window.location.reload()}
              className="w-full py-3 bg-red-500/20 hover:bg-red-500/40 text-red-500 text-[10px] font-black uppercase tracking-[0.4em] rounded-lg border border-red-500/30 transition-all"
            >
              Re-Ignite Core (Reload)
            </button>
          </div>
        </div>
      );
    }
    // Fix: Accessing explicitly declared props property
    return this.props.children;
  }
}

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <GlobalErrorBoundary>
      <App />
    </GlobalErrorBoundary>
  );
}