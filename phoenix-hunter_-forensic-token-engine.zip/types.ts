
export enum TokenRisk {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

export enum TokenOutcome {
  MOON_100X = 'MOON_100X',
  MOON_10X = 'MOON_10X',
  GAIN_2X = 'GAIN_2X',
  LOSS = 'LOSS',
  RUG = 'RUG'
}

export type TokenSource = 'LAUNCHPACT' | 'BIRDEYE' | 'APESAFE' | 'SOLANAFM' | 'DEXSCREENER' | 'TELEGRAM' | 'PUMP_FUN' | 'RAYDIUM';
export type LifecycleStage = 'IDENTIFIED' | 'AUDITING' | 'CANDIDATE' | 'SNIPED' | 'TRACKING' | 'EXITED';
export type DecisionVerdict = 'SNIPE' | 'WATCH' | 'IGNORE' | 'REJECT' | 'ENTER' | 'EXIT' | 'FLIP';

export interface DevHistory {
  launches: number;
  rugs: number;
  avgRoi: number;
}

export interface TokenMetadata {
  id: string;
  name: string;
  symbol: string;
  mint: string;
  liquidity: number;
  marketCap: number;
  devHistory: DevHistory;
  socialScore: number;
  holders: number;
  launchedAt: number;
  contractVerified: boolean;
  source: TokenSource;
  discoverySource?: string;
  platformQuality?: number;
  decimals?: number;
}

export interface ScoringWeights {
  liquidityDepth: number;
  liquidityLock: number;
  devReputation: number;
  holderConcentration: number;
  mintAuthority: number;
  freezeAuthority: number;
  socialMomentum: number;
  taxForensics: number;
  verificationStatus: number;
}

export interface ScoreBreakdown extends ScoringWeights {}

export interface HeuristicResult {
  total_score: number;
  confidence_score: number;
  score_breakdown: ScoreBreakdown;
}

export interface LaunchEvent extends TokenMetadata {
  first_seen: number;
  entry_price: number;
  stage: LifecycleStage;
}

export interface TokenCandidate extends LaunchEvent {
  status: 'pending' | 'active' | 'archived';
  heuristic?: HeuristicResult;
  verdict?: DecisionVerdict;
}

export interface PerformanceDelta {
  timestamp: number;
  price: number;
  roi: number;
  volume: number;
  lp: number;
  holders: number;
  spread?: number;
  topHolderPct?: number;
  liquidityChange?: number;
}

export interface AnalysisResult {
  forensicScore: number;
  confidence: number;
  riskLevel: TokenRisk;
  predictedHoldTime: number;
  reasoning: string;
  rugProbability: number;
}

export interface ActiveToken extends TokenCandidate {
  analysis?: AnalysisResult;
  history: PerformanceDelta[];
  currentRoi: number;
  outcome?: TokenOutcome;
  exitPrice?: number;
  entryTx?: string;
  exitTx?: string;
}

export interface Position {
  id: string;
  mint: string;
  symbol: string;
  decimals: number;
  amountTokens: number;
  costBasis: number;
  entryPrice: number;
  entryTime: number;
  entryTxn: string;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  status: 'ACTIVE' | 'CLOSED';
  exitReason?: string;
  exitTxn?: string;
  exitPrice?: number;
  exitTime?: number;
}

export interface FilterAttribution {
  filterName: keyof ScoringWeights;
  precision: number;
  recall: number;
  roiDelta: number;
}

export interface EvolutionReport {
  timestamp: number;
  attribution: FilterAttribution[];
  adjustmentReasoning: string;
  previousWeights: ScoringWeights;
  newWeights: ScoringWeights;
}

export interface SystemLog {
  id: string;
  timestamp: number;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error' | 'audit' | 'trade';
  context?: Record<string, any>;
  severity?: number;
  actor?: string;
}
