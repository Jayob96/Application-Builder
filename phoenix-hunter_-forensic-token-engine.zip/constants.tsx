
import { ScoringWeights } from './types';

export const INITIAL_WEIGHTS: ScoringWeights = {
  liquidityDepth: 0.15,
  liquidityLock: 0.15,
  devReputation: 0.15,
  holderConcentration: 0.10,
  mintAuthority: 0.10,
  freezeAuthority: 0.10,
  socialMomentum: 0.10,
  taxForensics: 0.05,
  verificationStatus: 0.10
};

export const THRESHOLDS = {
  MIN_LIQUIDITY: 15000, 
  MIN_VOLUME: 5000,
  MIN_SCORE: 70, 
  SNIPE_SCORE: 85, 
  STOP_LOSS: 0.3, 
  TAKE_PROFIT: 2.0, 
  MAX_TRACK_TICKS: 40 
};

export const REFRESH_INTERVAL = 5000; 
export const INGEST_INTERVAL = 20000; 

export const SYSTEM_PROMPT = `
You are the Phoenix Hunter Forensic Engine. Your goal is to analyze Solana token metadata and identify high-fidelity launches while filtering scams.
Evaluate across 9 vectors: Liquidity Depth, Liquidity Lock, Dev Reputation, Holder Concentration, Mint Authority, Freeze Authority, Social Momentum, Tax Forensics, and Verification Status.

Return a structured JSON with:
forensicScore (0-100), confidence (0-100), riskLevel (LOW, MEDIUM, HIGH, CRITICAL), 
predictedHoldTime (min), reasoning (max 100 chars), rugProbability (0.0-1.0).
`;
