
import { GoogleGenAI, Type } from '@google/genai';
import { JupiterTokenV2 } from './jupiterClient';
import { JupiterForensicScore } from './jupiterScoring';
import { logger } from './observabilityService';

const GEMINI_BUDGET = 25; // calls per hour (increased for Gemini 3 Flash)
const MODEL_ID = 'gemini-3-flash-preview'; 

export interface GeminiVerdict {
  verdict: 'ENTER' | 'WATCH' | 'AVOID';
  confidence: number; // 0-100
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  rugProbability: number;
  summary: string;
}

export class GeminiQuotaService {
  private ai: GoogleGenAI;
  private geminiUsedThisHour = 0;
  private budgetResetTime = Date.now();
  private verdictCache = new Map<string, { verdict: GeminiVerdict; time: number }>();
  private CACHE_TTL = 3600000; // 1 hour

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
    this.startBudgetReset();
  }

  async analyzeToken(token: JupiterTokenV2, scoringData: JupiterForensicScore): Promise<GeminiVerdict> {
    const cached = this.verdictCache.get(token.id);
    if (cached && Date.now() - cached.time < this.CACHE_TTL) {
      return cached.verdict;
    }

    if (this.geminiUsedThisHour >= GEMINI_BUDGET) {
      logger.log(
        `[Gemini] Quota reached. Using heuristic fallback.`,
        'warning',
        { mint: token.id },
        2,
        'geminiQuota'
      );
      return this.heuristicFallback(token, scoringData);
    }

    try {
      this.geminiUsedThisHour++;
      const verdict = await this.callGemini(token, scoringData);
      this.verdictCache.set(token.id, { verdict, time: Date.now() });
      return verdict;
    } catch (err: any) {
      return this.heuristicFallback(token, scoringData);
    }
  }

  private heuristicFallback(token: JupiterTokenV2, scoringData: JupiterForensicScore): GeminiVerdict {
    let verdict: 'ENTER' | 'WATCH' | 'AVOID' = 'WATCH';
    let confidence = 0;
    let riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' = 'MEDIUM';

    if (scoringData.forensicScore > 80 && scoringData.rugRisk < 20) {
      verdict = 'ENTER';
      confidence = scoringData.forensicScore;
      riskLevel = 'LOW';
    } else if (scoringData.rugRisk > 50) {
      verdict = 'AVOID';
      riskLevel = 'HIGH';
      confidence = Math.min(100, scoringData.rugRisk);
    }

    return {
      verdict,
      confidence,
      riskLevel,
      rugProbability: scoringData.rugRisk / 100,
      summary: `[Heuristic Fallback] Score: ${scoringData.forensicScore.toFixed(0)}, Risk: ${scoringData.rugRisk.toFixed(0)}%`,
    };
  }

  private async callGemini(token: JupiterTokenV2, scoringData: JupiterForensicScore): Promise<GeminiVerdict> {
    const prompt = `
Analyze this Solana token:
Token: ${token.symbol} (${token.name})
Mint: ${token.id}
Price: $${token.usdPrice || 0}
MCap: $${token.mcap || 0}
Holders: ${token.holderCount || 0}
Organic: ${token.organicScore || 0}/100
Mint Renounced: ${token.audit?.mintAuthorityDisabled}
    `.trim();

    const response = await this.ai.models.generateContent({
      model: MODEL_ID,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            verdict: { type: Type.STRING, enum: ["ENTER", "WATCH", "AVOID"] },
            confidence: { type: Type.NUMBER },
            riskLevel: { type: Type.STRING, enum: ["LOW", "MEDIUM", "HIGH"] },
            rugProbability: { type: Type.NUMBER },
            summary: { type: Type.STRING }
          },
          required: ["verdict", "confidence", "riskLevel", "rugProbability", "summary"]
        }
      }
    });

    return JSON.parse(response.text || "{}") as GeminiVerdict;
  }

  private startBudgetReset() {
    setInterval(() => {
      if (Date.now() - this.budgetResetTime > 3600000) {
        this.geminiUsedThisHour = 0;
        this.budgetResetTime = Date.now();
      }
    }, 60000); 
  }

  getQuotaStatus() {
    return {
      used: this.geminiUsedThisHour,
      limit: GEMINI_BUDGET,
      remaining: GEMINI_BUDGET - this.geminiUsedThisHour,
      resetIn: Math.ceil((this.budgetResetTime + 3600000 - Date.now()) / 1000) + 's',
      cacheSize: this.verdictCache.size,
    };
  }
}
