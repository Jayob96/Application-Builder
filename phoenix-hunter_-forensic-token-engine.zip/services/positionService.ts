
import { Position } from '../types';

class PositionService {
  private positions: Map<string, Position> = new Map();

  add(pos: Position) {
    this.positions.set(pos.id, pos);
  }

  get(id: string) {
    return this.positions.get(id);
  }

  getActive(): Position[] {
    return Array.from(this.positions.values()).filter(p => p.status === 'ACTIVE');
  }

  update(id: string, data: Partial<Position>) {
    const pos = this.positions.get(id);
    if (pos) {
      Object.assign(pos, data);
      this.positions.set(id, pos);
    }
  }

  close(id: string, exitData: { exitReason: string; exitPrice: number; exitTime: number; exitTxn: string }) {
    this.update(id, {
        status: 'CLOSED',
        ...exitData
    });
  }
}

export const positionService = new PositionService();
