
import { Keypair } from "@solana/web3.js";
import nacl from "tweetnacl";
import { logger } from "./observabilityService";
import type {
  BackpackMarket,
  BackpackTicker,
  BackpackAccount,
  BackpackCapital,
  ExecuteOrderParams,
  BackpackOrder,
  BackpackDepth,
  BackpackKLine,
  BackpackFill,
} from "./backpackTypes";

const BACKPACK_API_BASE = "https://api.backpack.exchange";
const DEFAULT_RECV_WINDOW = 5000;
const USER_AGENT = "Solana-Sentinel-Bot/1.0";

const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
const ALPHABET_MAP: Record<string, number> = ALPHABET.split("").reduce(
  (acc, char, index) => ({ ...acc, [char]: index }),
  {}
);

function decodeBase58(str: string): Uint8Array {
  const result = [0];
  for (const char of str) {
    const value = ALPHABET_MAP[char];
    if (value === undefined) throw new Error("Invalid Base58 character");
    let carry = value;
    for (let i = 0; i < result.length; i++) {
      carry += result[i] * 58;
      result[i] = carry & 0xff;
      carry >>= 8;
    }
    while (carry > 0) {
      result.push(carry & 0xff);
      carry >>= 8;
    }
  }
  for (let i = 0; str[i] === "1" && i < str.length - 1; i++) result.push(0);
  return new Uint8Array(result.reverse());
}

export class BackpackClient {
  private apiKey: string;
  private secretKey: Uint8Array | null = null;
  private marketsCache: Map<string, BackpackMarket> = new Map();
  private tickerCache: Map<string, { data: BackpackTicker; timestamp: number }> = new Map();
  private CACHE_TTL = 5000;
  private lastRequestTime = 0;
  private rateLimitDelay = 100;

  constructor(apiKey: string, privateKeyInput: string) {
    this.apiKey = apiKey;

    if (!apiKey || !privateKeyInput) {
      console.warn("[Backpack] Initialization deferred: API credentials missing.");
      return;
    }

    try {
      let decoded: Uint8Array;
      const isBase58 = /^[1-9A-HJ-NP-Za-km-z]+$/.test(privateKeyInput);
      
      if (isBase58 && privateKeyInput.length >= 43 && privateKeyInput.length <= 90) {
        decoded = decodeBase58(privateKeyInput);
      } else if (privateKeyInput.startsWith("[") && privateKeyInput.endsWith("]")) {
        const parsed = JSON.parse(privateKeyInput);
        decoded = new Uint8Array(parsed);
      } else {
        const binaryString = atob(privateKeyInput);
        decoded = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          decoded[i] = binaryString.charCodeAt(i);
        }
      }

      if (decoded.length === 64) {
        this.secretKey = decoded;
      } else if (decoded.length === 32) {
        const kp = Keypair.fromSeed(decoded);
        this.secretKey = kp.secretKey;
      } else {
        throw new Error(`Invalid key length: ${decoded.length}`);
      }
      
      logger.log("[Backpack] Keypair initialized.", "success", {}, 1, "backpackClient");
    } catch (e: any) {
      this.secretKey = null;
      console.error("[Backpack] Key error:", e.message);
    }
  }

  async getMarkets(): Promise<BackpackMarket[]> {
    if (this.marketsCache.size > 0) return Array.from(this.marketsCache.values());
    const markets = await this.publicRequest<BackpackMarket[]>("/api/v1/markets");
    markets.forEach((m) => this.marketsCache.set(m.symbol, m));
    return markets;
  }

  async getTicker(symbol: string): Promise<BackpackTicker> {
    const cached = this.tickerCache.get(symbol);
    if (cached && Date.now() - cached.timestamp < this.CACHE_TTL) return cached.data;
    const ticker = await this.publicRequest<BackpackTicker>(`/api/v1/ticker?symbol=${symbol}`);
    this.tickerCache.set(symbol, { data: ticker, timestamp: Date.now() });
    return ticker;
  }

  async getDepth(symbol: string): Promise<BackpackDepth> {
    return this.publicRequest<BackpackDepth>(`/api/v1/depth?symbol=${symbol}`);
  }

  async getKlines(symbol: string, interval: string, limit = 100): Promise<BackpackKLine[]> {
    return this.publicRequest<BackpackKLine[]>(`/api/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
  }

  async getAccount(): Promise<BackpackAccount> {
    this.ensureAuth();
    return this.authRequest<BackpackAccount>("GET", "/api/v1/account", undefined, "accountQuery");
  }

  async updateAccountSettings(params: any): Promise<any> {
    this.ensureAuth();
    return this.authRequest<any>("PATCH", "/api/v1/account", params, "accountUpdate");
  }

  async getCapital(): Promise<BackpackCapital> {
    this.ensureAuth();
    return this.authRequest<BackpackCapital>("GET", "/api/v1/capital", undefined, "capitalQuery");
  }

  async executeOrder(params: ExecuteOrderParams): Promise<BackpackOrder> {
    this.ensureAuth();
    return this.authRequest<BackpackOrder>("POST", "/api/v1/order", params, "orderExecute");
  }

  async executeBatchOrders(orders: ExecuteOrderParams[]): Promise<BackpackOrder[]> {
    this.ensureAuth();
    return this.authRequest<BackpackOrder[]>("POST", "/api/v1/orders", orders, "orderExecute");
  }

  async getOpenOrders(symbol?: string): Promise<BackpackOrder[]> {
    this.ensureAuth();
    const query = symbol ? `?symbol=${symbol}` : "";
    return this.authRequest<BackpackOrder[]>("GET", `/api/v1/orders${query}`, undefined, "orderQuery");
  }

  async cancelOrder(orderId: string, symbol: string): Promise<BackpackOrder> {
    this.ensureAuth();
    return this.authRequest<BackpackOrder>("DELETE", "/api/v1/order", { orderId, symbol }, "orderCancel");
  }

  async cancelAllOrders(symbol: string): Promise<BackpackOrder[]> {
    this.ensureAuth();
    return this.authRequest<BackpackOrder[]>("DELETE", "/api/v1/orders", { symbol }, "orderCancel");
  }

  async getOrderHistory(symbol?: string, limit = 100): Promise<BackpackOrder[]> {
    this.ensureAuth();
    const q = symbol ? `?symbol=${symbol}&limit=${limit}` : `?limit=${limit}`;
    return this.authRequest<BackpackOrder[]>("GET", `/wapi/v1/history/orders${q}`, undefined, "orderHistoryQuery");
  }

  async getFillHistory(symbol?: string, limit = 100): Promise<BackpackFill[]> {
    this.ensureAuth();
    const q = symbol ? `?symbol=${symbol}&limit=${limit}` : `?limit=${limit}`;
    return this.authRequest<BackpackFill[]>("GET", `/wapi/v1/history/fills${q}`, undefined, "fillHistoryQuery");
  }

  async pollOrder(orderId: string, symbol: string, maxAttempts = 20): Promise<BackpackOrder> {
    this.ensureAuth();
    let attempt = 0;
    while (attempt < maxAttempts) {
      try {
        const order = await this.authRequest<BackpackOrder>("GET", `/api/v1/order?symbol=${symbol}&orderId=${orderId}`, undefined, "orderQuery");
        if (["Filled", "Canceled", "Expired"].includes(order.status)) return order;
      } catch { }
      await new Promise((r) => setTimeout(r, Math.min(1000 * Math.pow(1.5, attempt), 5000)));
      attempt++;
    }
    throw new Error(`Polling timeout for order ${orderId}`);
  }

  private async publicRequest<T>(endpoint: string): Promise<T> {
    await this.rateLimit();
    const res = await fetch(`${BACKPACK_API_BASE}${endpoint}`, { headers: { "User-Agent": USER_AGENT } });
    if (!res.ok) throw new Error(`Backpack Public Error ${res.status}`);
    return res.json();
  }

  private ensureAuth() {
    if (!this.apiKey || !this.secretKey) throw new Error("Backpack: Missing Auth");
  }

  private async authRequest<T>(method: string, endpoint: string, body: any, instruction: string): Promise<T> {
    await this.rateLimit();
    const timestamp = Date.now();
    const window = DEFAULT_RECV_WINDOW;
    let serializedBody = (body && method !== "GET") ? JSON.stringify(body) : "";
    let queryParams = endpoint.includes("?") ? endpoint.split("?")[1] : "";

    const signData = `instruction=${instruction}&timestamp=${timestamp}&window=${window}` +
      (serializedBody ? `&body=${serializedBody}` : "") +
      (queryParams ? `&${queryParams}` : "");

    const messageBytes = new TextEncoder().encode(signData);
    const signatureBytes = nacl.sign.detached(messageBytes, this.secretKey!);
    const signature = btoa(String.fromCharCode.apply(null, Array.from(signatureBytes)));

    const headers: Record<string, string> = {
      "X-API-Key": this.apiKey,
      "X-Timestamp": timestamp.toString(),
      "X-Window": window.toString(),
      "X-Signature": signature,
      "Content-Type": "application/json",
      "User-Agent": USER_AGENT,
    };

    const config: RequestInit = { method, headers };
    if (serializedBody) config.body = serializedBody;

    const res = await fetch(`${BACKPACK_API_BASE}${endpoint}`, config);
    if (!res.ok) throw new Error(`Backpack Auth Error: ${res.status}`);
    return res.json();
  }

  private async rateLimit() {
    const now = Date.now();
    const timeSinceLast = now - this.lastRequestTime;
    if (timeSinceLast < this.rateLimitDelay) {
      await new Promise((r) => setTimeout(r, this.rateLimitDelay - timeSinceLast));
    }
    this.lastRequestTime = Date.now();
  }
}
