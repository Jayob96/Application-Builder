
import { ActiveToken, PerformanceDelta } from "../types";

export class MarketService {
  getLatestSnapshot(token: ActiveToken): PerformanceDelta {
    const lastEntry = token.history[token.history.length - 1];
    
    // Inlined simple volatility logic for simulation
    const volatility = 0.2;
    const trend = Math.random() > 0.5 ? 0.05 : -0.05;
    const change = (Math.random() - 0.5) * volatility + trend;
    const nextRoi = token.currentRoi * (1 + change);
    
    const newPrice = token.entry_price * nextRoi;
    const newLp = lastEntry.lp * (0.97 + Math.random() * 0.05);
    const liquidityChange = newLp - lastEntry.lp;
    
    return {
      timestamp: Date.now(),
      price: newPrice,
      roi: nextRoi,
      volume: lastEntry.volume * (0.85 + Math.random() * 0.4),
      lp: newLp,
      liquidityChange,
      holders: Math.floor(lastEntry.holders + (Math.random() * 12)),
      spread: 0.01 + Math.random() * 0.03,
      topHolderPct: lastEntry.topHolderPct ? lastEntry.topHolderPct * (0.99 + Math.random() * 0.02) : 0.1
    };
  }
}
