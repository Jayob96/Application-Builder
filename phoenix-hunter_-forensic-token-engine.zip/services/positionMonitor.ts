import { positionService } from './positionService';
// Fixed: Relative path for ExecutionService module
import { ExecutionService } from './executionService';
import { TradeExecutor } from './tradeExecutor';
import { logger } from './observabilityService';
import { Position } from '../types';
import { Keypair } from '@solana/web3.js';

export class PositionMonitor {
    private isRunning = false;
    private intervalId: any;
    private readonly STOP_LOSS_PERCENT = -30;
    private readonly TAKE_PROFIT_PERCENT = 100;
    private readonly MAX_HOLD_HOURS = 24;
    private readonly SOL_MINT = "So11111111111111111111111111111111111111112";

    constructor(
        private executionService: ExecutionService,
        private tradeExecutor: TradeExecutor,
        private wallet: Keypair
    ) {}

    start() {
        if (this.isRunning) return;
        this.isRunning = true;
        this.intervalId = setInterval(() => this.monitor(), 10000); // Check every 10s
        logger.log("Position Monitor initialized", "info", {}, 1, "positionMonitor");
    }

    stop() {
        this.isRunning = false;
        clearInterval(this.intervalId);
    }

    private async monitor() {
        const positions = positionService.getActive();
        for (const pos of positions) {
            try {
                // Check if decimals are valid, otherwise default to 6 (USDC-like) or 9 (SOL) - risky but needed if metadata missing
                const decimals = pos.decimals || 6;
                const rawAmount = Math.floor(pos.amountTokens * Math.pow(10, decimals));
                
                // Get Quote for selling whole position to SOL to determine current value
                // Fixed: Corrected estimateSwap signature call from (from, placeholder, to, amount) to (from, to, amount)
                const quote = await this.executionService.estimateSwap(
                    pos.mint, 
                    this.SOL_MINT, 
                    rawAmount
                );

                if (!quote || !quote.outputAmount) {
                     // Could not fetch price, skip this tick
                     continue; 
                }

                // outputAmount is in Lamports (SOL decimals = 9)
                const currentValueSol = parseInt(quote.outputAmount) / 1e9; 
                const currentPriceSol = currentValueSol / pos.amountTokens;
                
                const pnl = currentValueSol - pos.costBasis;
                const pnlPercent = (pnl / pos.costBasis) * 100;

                // Update Position State
                positionService.update(pos.id, {
                    currentPrice: currentPriceSol,
                    pnl,
                    pnlPercent
                });

                // Check Exits
                const holdHours = (Date.now() - pos.entryTime) / 3600000;
                
                if (pnlPercent <= this.STOP_LOSS_PERCENT) {
                    await this.triggerExit(pos, 'STOP_LOSS', pnlPercent);
                } else if (pnlPercent >= this.TAKE_PROFIT_PERCENT) {
                    await this.triggerExit(pos, 'TAKE_PROFIT', pnlPercent);
                } else if (holdHours >= this.MAX_HOLD_HOURS) {
                    await this.triggerExit(pos, 'TIME_EXPIRED', pnlPercent);
                }

            } catch (err: any) {
                // Suppress errors per position to avoid flooding logs for single failure
            }
        }
    }

    private async triggerExit(pos: Position, reason: string, pnl: number) {
        logger.log(`Exit Signal for ${pos.symbol}: ${reason} (${pnl.toFixed(2)}%)`, "warning", {}, 2, "positionMonitor");
        
        const result = await this.tradeExecutor.closePosition(pos, reason, this.wallet);
        
        if (result.status === 'SUCCESS') {
             positionService.close(pos.id, {
                 exitReason: reason,
                 exitPrice: result.price,
                 exitTime: Date.now(),
                 exitTxn: result.signature || result.orderId || 'unknown'
             });
             logger.log(`Position Closed: ${pos.symbol}`, 'success', { roi: pnl }, 2, "positionMonitor");
        } else {
             logger.log(`Failed to close ${pos.symbol}: ${result.error}`, 'error', {}, 3, "positionMonitor");
        }
    }

    // Overloaded estimateSwap helper for typescript alignment with executionService
    private async estimateSwapWrapper(from: string, to: string, amount: number) {
        return this.executionService.estimateSwap(from, to, amount);
    }
}