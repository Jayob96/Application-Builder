
import { LaunchEvent } from "../types";
import { getLatestSolanaTokens, fetchDexscreenerData } from "./dexscreenerClient";
import { getRecent as getRecentJupiter, JupiterTokenV2 } from "./jupiterClient";
import { logger } from "./observabilityService";

const POLL_INTERVAL_DEX = 10000; 
const POLL_INTERVAL_JUP = 6500;
const CLEANUP_INTERVAL = 60 * 60 * 1000;

export class IngestionService {
  private seen = new Map<string, number>();
  private isRunning = false;
  
  async start(onEvent: (event: LaunchEvent) => void) {
    if (this.isRunning) return;
    this.isRunning = true;
    logger.log("Ingestion Engines: ONLINE (Primary: JUP, Secondary: DEX)", "info", {}, 1, "ingestionService");

    // Initialize parallel polling streams
    this.pollJupiter(onEvent);
    this.pollDexscreener(onEvent);
    this.startCleanup();
  }

  stop() {
    this.isRunning = false;
    logger.log("Ingestion Engines: OFFLINE", "warning", {}, 1, "ingestionService");
  }

  async fetchDexscreenerByMint(mint: string): Promise<LaunchEvent | null> {
    try {
      const pair = await fetchDexscreenerData(mint);
      if (!pair) return null;
      return this.normalizeDexscreener(pair, mint, 'DEX_MANUAL');
    } catch (e: any) {
      logger.log(`Manual Dex Ingest Failed: ${e.message}`, "error", { mint }, 2, "ingestionService");
      return null;
    }
  }

  async fetchJupiterFeed(category: 'recent' | 'trending' | 'organic'): Promise<LaunchEvent[]> {
    const JUPITER_TOKENS_BASE = "https://api.jup.ag/tokens/v2";
    try {
      let url = `${JUPITER_TOKENS_BASE}/recent`;
      if (category === 'trending') url = `${JUPITER_TOKENS_BASE}/toptrending/5m?limit=20`;
      if (category === 'organic') url = `${JUPITER_TOKENS_BASE}/toporganicscore/5m?limit=20`;

      const res = await fetch(url, { 
        headers: { 'User-Agent': 'Solana-Sentinel-Bot/1.0' },
        cache: 'no-store'
      });
      
      if (!res.ok) {
        logger.log(`Jupiter Feed Error (${category}): HTTP ${res.status}`, "error", {}, 2, "ingestionService");
        return [];
      }
      
      const data = await res.json();
      if (!Array.isArray(data)) {
        logger.log(`Jupiter Feed Parse Error [${category}]: Expected array payload`, "error", {}, 2, "ingestionService");
        return [];
      }

      return data
        .map(item => this.normalizeJupiter(item))
        .filter((item): item is LaunchEvent => item !== null);
    } catch (e: any) {
      logger.log(`Jupiter Feed Parse Exception [${category}]: ${e.message}`, "error", {}, 2, "ingestionService");
      return [];
    }
  }

  async fetchJupiterByMint(mint: string): Promise<LaunchEvent | null> {
    const JUPITER_TOKENS_BASE = "https://api.jup.ag/tokens/v2";
    try {
      const res = await fetch(`${JUPITER_TOKENS_BASE}/search?query=${encodeURIComponent(mint)}`, { 
        headers: { 'User-Agent': 'Solana-Sentinel-Bot/1.0' } 
      });
      if (!res.ok) {
        logger.log(`Jupiter Search Error: HTTP ${res.status}`, "error", { mint }, 2, "ingestionService");
        return null;
      }
      const data = await res.json();
      return data?.[0] ? this.normalizeJupiter(data[0]) : null;
    } catch (e: any) {
      logger.log(`Jupiter Mint Lookup Exception: ${e.message}`, "error", { mint }, 2, "ingestionService");
      return null;
    }
  }

  private async pollDexscreener(onEvent: (event: LaunchEvent) => void) {
    while (this.isRunning) {
      try {
        const profiles = await getLatestSolanaTokens();
        if (!profiles || profiles.length === 0) {
          await new Promise(r => setTimeout(r, POLL_INTERVAL_DEX));
          continue;
        }

        for (const profile of profiles) {
          if (!this.isRunning) break;
          const mint = profile.tokenAddress;
          if (!this.seen.has(mint)) {
            this.seen.set(mint, Date.now());
            const pairData = await fetchDexscreenerData(mint);
            if (pairData) onEvent(this.normalizeDexscreener(pairData, mint, 'DEX_LATEST'));
          }
        }
      } catch (err: any) {
        logger.log(`Dexscreener Polling Error: ${err.message || 'Unknown network error'}`, "error", {}, 2, "ingestionService");
      }
      await new Promise(r => setTimeout(r, POLL_INTERVAL_DEX));
    }
  }

  private async pollJupiter(onEvent: (event: LaunchEvent) => void) {
    while (this.isRunning) {
      try {
        const tokens: JupiterTokenV2[] = await getRecentJupiter();
        if (!tokens || tokens.length === 0) {
          await new Promise(r => setTimeout(r, POLL_INTERVAL_JUP));
          continue;
        }

        for (const token of tokens) {
          if (!this.isRunning) break;
          if (!this.seen.has(token.id)) {
            this.seen.set(token.id, Date.now());
            const event = this.normalizeJupiter(token);
            if (event) onEvent(event);
          }
        }
      } catch (err: any) {
        logger.log(`Jupiter Polling Error: ${err.message || 'Unknown network error'}`, "error", {}, 2, "ingestionService");
      }
      await new Promise(r => setTimeout(r, POLL_INTERVAL_JUP));
    }
  }

  private startCleanup() {
    setInterval(() => {
      const now = Date.now();
      const cutoff = 24 * 60 * 60 * 1000;
      let cleaned = 0;
      for (const [key, time] of this.seen.entries()) {
        if (now - time > cutoff) {
          this.seen.delete(key);
          cleaned++;
        }
      }
      if (cleaned > 0) {
        logger.log(`Ingestion Cache Purged: ${cleaned} stale entries.`, "info", {}, 1, "ingestionService");
      }
    }, CLEANUP_INTERVAL);
  }

  private normalizeJupiter(item: any): LaunchEvent | null {
    if (!item?.id) return null;
    return {
      id: item.id,
      name: item.name || "Unknown",
      symbol: (item.symbol || "UNK").toUpperCase(),
      mint: item.id,
      liquidity: item.liquidity || 0,
      marketCap: item.mcap || item.fdv || 0,
      devHistory: { launches: item.isVerified ? 5 : 1, rugs: 0, avgRoi: 1.0 },
      socialScore: item.organicScore || 50,
      holders: item.holderCount || 0,
      launchedAt: item.firstPool?.createdAt ? new Date(item.firstPool.createdAt).getTime() : Date.now(),
      contractVerified: !!item.isVerified,
      source: 'RAYDIUM',
      discoverySource: 'JUP_V2',
      first_seen: Date.now(),
      entry_price: item.usdPrice || 0,
      stage: 'IDENTIFIED',
      platformQuality: item.organicScore || 0
    };
  }

  private normalizeDexscreener(pair: any, mint: string, source: string): LaunchEvent {
    return {
      id: pair.pairAddress || mint,
      name: pair.baseToken?.name || "Unknown",
      symbol: (pair.baseToken?.symbol || "UNK").toUpperCase(),
      mint: pair.baseToken?.address || mint,
      liquidity: pair.liquidity?.usd ?? 0,
      marketCap: pair.fdv ?? pair.marketCap ?? 0,
      devHistory: { launches: 1, rugs: 0, avgRoi: 1.0 },
      socialScore: 50,
      holders: pair.makers?.h24 ?? 0,
      launchedAt: pair.pairCreatedAt || Date.now(),
      contractVerified: true,
      source: 'DEXSCREENER',
      discoverySource: source,
      first_seen: Date.now(),
      entry_price: parseFloat(pair.priceUsd) || 0,
      stage: 'IDENTIFIED'
    };
  }
}
