import { searchByMint } from './jupiterClient';
import { scoreJupiterToken } from './jupiterScoring';
import { fetchDexscreenerData, scoreDexscreenerData } from './dexscreenerClient';
import { GeminiQuotaService } from './geminiQuotaService';
import { logger } from './observabilityService';

/**
 * Perform forensic audit for a new token.
 * Now requires the quotaService to be passed in to ensure singleton consistency and safe boot.
 */
export async function analyzeNewToken(mint: string, quotaService: GeminiQuotaService) {
  try {
    logger.log(`Starting forensic audit for ${mint.slice(0, 8)}...`, 'info', { mint }, 1, 'forensicNode');

    const [dexData, jupiterToken] = await Promise.all([
      fetchDexscreenerData(mint),
      searchByMint(mint)
    ]);

    if (!jupiterToken) {
      logger.log(`Audit aborted: Token missing from Jupiter V2.`, 'warning', { mint });
      return null;
    }

    const jupiterScore = scoreJupiterToken(jupiterToken);
    const dexScoreValue = scoreDexscreenerData(dexData);
    const combinedScore = (dexScoreValue * 0.4) + (jupiterScore.forensicScore * 0.6);

    if (combinedScore > 70) {
      // Use the injected service instance
      const verdict = await quotaService.analyzeToken(jupiterToken, jupiterScore);
      return {
        mint,
        heuristicScore: combinedScore,
        jupiterScore,
        dexScore: dexScoreValue,
        aiVerdict: verdict
      };
    }

    return {
      mint,
      heuristicScore: combinedScore,
      jupiterScore,
      dexScore: dexScoreValue,
      aiVerdict: null
    };
  } catch (error: any) {
    logger.log(`Forensic Pipeline Failure: ${error.message}`, 'error', { error }, 4, 'forensicNode');
    throw error;
  }
}