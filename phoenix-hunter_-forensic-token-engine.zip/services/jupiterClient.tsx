
export interface JupiterTokenV2 {
  id: string;
  name: string;
  symbol: string;
  icon: string;
  decimals: number;
  circSupply: number;
  totalSupply: number;
  tokenProgram: string;
  firstPool: { id: string; createdAt: string };
  holderCount: number;
  audit: {
    mintAuthorityDisabled: boolean;
    freezeAuthorityDisabled: boolean;
    topHoldersPercentage: number;
  };
  organicScore: number;
  organicScoreLabel: 'low' | 'medium' | 'high' | 'very high';
  isVerified: boolean;
  cexes: string[];
  tags: string[];
  fdv: number;
  mcap: number;
  usdPrice: number;
  liquidity: number;
  stats5m: TokenStats;
  stats1h: TokenStats;
  stats6h: TokenStats;
  stats24h: TokenStats;
  updatedAt: string;
}

export interface TokenStats {
  priceChange: number;
  liquidityChange: number;
  volumeChange: number;
  buyVolume: number;
  sellVolume: number;
  buyOrganicVolume: number;
  sellOrganicVolume: number;
  numBuys: number;
  numSells: number;
  numTraders: number;
  numOrganicBuyers: number;
  numNetBuyers: number;
}

const BASE = 'https://api.jup.ag/tokens/v2';

export async function searchByMint(mint: string, apiKey?: string): Promise<JupiterTokenV2 | null> {
  const url = `${BASE}/search?query=${encodeURIComponent(mint)}`;
  const res = await fetch(url, {
    headers: apiKey ? { 'x-api-key': apiKey } : {},
  });
  if (!res.ok) throw new Error(`Jupiter search HTTP ${res.status}`);
  const data: JupiterTokenV2[] = await res.json();
  return data[0] ?? null;
}

export async function getRecent(limit = 30, apiKey?: string) {
  const res = await fetch(`${BASE}/recent?limit=${limit}`, {
    headers: apiKey ? { 'x-api-key': apiKey } : {},
  });
  if (!res.ok) throw new Error(`Jupiter recent HTTP ${res.status}`);
  return (await res.json()) as JupiterTokenV2[];
}
