
import { Connection, PublicKey, VersionedTransaction, Keypair } from '@solana/web3.js';
import { logger } from './observabilityService';

export interface SwapParams {
  inputMint: string;
  outputMint: string;
  amountLamports: number;
  slippageBps: number;
  userPublicKey: PublicKey;
  userKeypair: Keypair;
}

export interface SwapResult {
  success: boolean;
  signature?: string;
  error?: string;
  amountOut?: number;
  estimatedPrice?: number;
}

export class ExecutionService {
  private connection: Connection;
  private readonly HEADERS = {
    'Content-Type': 'application/json',
    'User-Agent': 'Solana-Sentinel-Bot/1.0'
  };

  constructor(rpcUrl: string = "https://api.mainnet-beta.solana.com") {
    this.connection = new Connection(rpcUrl, 'confirmed');
  }

  /**
   * Estimates a swap without executing it. Used for monitoring ROI.
   */
  async estimateSwap(inputMint: string, outputMint: string, amount: number) {
    try {
      const url = `https://quote-api.jup.ag/v6/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amount}&slippageBps=50`;
      const res = await fetch(url, { headers: { 'User-Agent': 'Solana-Sentinel-Bot/1.0' } });
      if (!res.ok) return null;
      return await res.json();
    } catch (e) {
      return null;
    }
  }

  /**
   * Executes a real swap on Solana via Jupiter V6
   */
  async executeBuySwap(params: SwapParams): Promise<SwapResult> {
    try {
      // Ensure Buffer is available (Polyfilled in index.html)
      if (typeof window !== 'undefined' && !(window as any).Buffer) {
        throw new Error("System Error: Buffer polyfill missing. Transaction aborted.");
      }

      logger.log(`Executing Swap: ${params.amountLamports} lamports -> ${params.outputMint.slice(0, 8)}`, 'info', {}, 2, 'executionService');

      // 1. Get Quote
      const quoteUrl = `https://quote-api.jup.ag/v6/quote?inputMint=${params.inputMint}&outputMint=${params.outputMint}&amount=${params.amountLamports}&slippageBps=${params.slippageBps}`;
      const quoteRes = await fetch(quoteUrl, { headers: { 'User-Agent': 'Solana-Sentinel-Bot/1.0' } });
      const quoteResponse = await quoteRes.json();

      if (!quoteResponse.outAmount) {
        throw new Error(quoteResponse.error || "No route found on Jupiter");
      }

      // 2. Get Swap Transaction
      const swapRes = await fetch('https://quote-api.jup.ag/v6/swap', {
        method: 'POST',
        headers: this.HEADERS,
        body: JSON.stringify({
          quoteResponse,
          userPublicKey: params.userPublicKey.toBase58(),
          wrapAndUnwrapSol: true,
          prioritizationFeeLamports: 50000 
        })
      });

      const swapData = await swapRes.json();
      if (!swapData.swapTransaction) {
        throw new Error("Jupiter Swap API failed to return a transaction.");
      }

      // 3. Sign and Send
      // Fixed: Accessing Buffer via window to satisfy TypeScript and utilize browser polyfill
      const swapTransactionBuf = (window as any).Buffer.from(swapData.swapTransaction, 'base64');
      const transaction = VersionedTransaction.deserialize(swapTransactionBuf);
      
      transaction.sign([params.userKeypair]);

      const rawTransaction = transaction.serialize();
      const txid = await this.connection.sendRawTransaction(rawTransaction, {
        skipPreflight: true,
        maxRetries: 2
      });

      // 4. Confirm
      const confirmation = await this.connection.confirmTransaction(txid, 'confirmed');
      
      if (confirmation.value.err) {
        throw new Error(`Transaction failed: ${JSON.stringify(confirmation.value.err)}`);
      }

      return {
        success: true,
        signature: txid,
        amountOut: parseInt(quoteResponse.outAmount),
        estimatedPrice: parseFloat(quoteResponse.outAmount) / params.amountLamports
      };

    } catch (err: any) {
      logger.log(`Swap Execution Failure: ${err.message}`, 'error', { err }, 4, 'executionService');
      return { success: false, error: err.message };
    }
  }
}
