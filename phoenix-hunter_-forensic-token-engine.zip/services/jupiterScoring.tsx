
import type { JupiterTokenV2 } from './jupiterClient';

export interface JupiterForensicScore {
  forensicScore: number;
  rugRisk: number;
  reasons: string[];
}

export function scoreJupiterToken(token: JupiterTokenV2): JupiterForensicScore {
  const reasons: string[] = [];
  let score = 50;
  let rugRisk = 0;

  if (token.audit.mintAuthorityDisabled) {
    score += 20;
    reasons.push('Mint authority renounced (+20)');
  } else {
    rugRisk += 25;
    reasons.push('Mint authority active (+25 risk)');
  }

  if (token.audit.freezeAuthorityDisabled) {
    score += 15;
    reasons.push('Freeze authority renounced (+15)');
  } else {
    rugRisk += 20;
    reasons.push('Freeze authority active (+20 risk)');
  }

  if (token.audit.topHoldersPercentage < 30) {
    score += 15;
    reasons.push(`Holder concentration < 30% (+15)`);
  } else if (token.audit.topHoldersPercentage > 50) {
    rugRisk += 30;
    reasons.push(`Holder concentration > 50% (+30 risk)`);
  }

  if (token.holderCount > 1000) {
    score += 10;
    reasons.push(`Holder count > 1,000 (+10)`);
  }

  if (token.organicScore > 70) {
    score += 15;
    reasons.push(`Organic score > 70 (+15)`);
  } else if (token.organicScore < 30) {
    rugRisk += 20;
    reasons.push(`Organic score < 30 (+20 risk)`);
  }

  if (token.isVerified) {
    score += 10;
    reasons.push('Jupiter verified (+10)');
  }

  const forensicScore = Math.min(100, Math.max(0, score));
  const finalRisk = Math.min(100, Math.max(0, rugRisk));

  return { forensicScore, rugRisk: finalRisk, reasons };
}
