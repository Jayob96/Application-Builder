
export interface DexPair {
  chainId: string;
  dexId: string;
  url: string;
  pairAddress: string;
  baseToken: {
    address: string;
    name: string;
    symbol: string;
  };
  priceUsd: string;
  fdv?: number;
  marketCap?: number;
  liquidity?: {
    usd: number;
    base: number;
    quote: number;
  };
  volume?: {
    h24: number;
    h6: number;
    h1: number;
    m5: number;
  };
  priceChange?: {
    m5: number;
    h1: number;
    h6: number;
    h24: number;
  };
}

/**
 * NOTE: Dexscreener API often blocks direct browser fetches via CORS.
 * We implement a silent fallback to prevent UI crashes.
 */
export async function fetchDexscreenerData(mint: string): Promise<DexPair | null> {
  try {
    // Attempting fetch with a short timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);

    const res = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, {
      signal: controller.signal,
      headers: { 'User-Agent': 'Solana-Sentinel-Bot/1.0' }
    });
    
    clearTimeout(timeoutId);
    
    if (!res.ok) return null;
    const data = await res.json();
    return data.pairs?.sort((a: any, b: any) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0))[0] ?? null;
  } catch (error: any) {
    // Silent failure for CORS/Network issues - IngestionService will fall back to Jupiter
    if (error.name !== 'AbortError') {
       // Only log serious unexpected errors, not standard browser CORS blocks
       console.debug(`[Dexscreener] Data unreachable (likely CORS). Falling back to Jupiter feed.`);
    }
    return null;
  }
}

export async function getLatestSolanaTokens(): Promise<any[]> {
  try {
    const res = await fetch("https://api.dexscreener.com/token-profiles/latest/v1", {
      headers: { 'User-Agent': 'Solana-Sentinel-Bot/1.0' }
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.filter((item: any) => item.chainId === 'solana');
  } catch (e) {
    // Silent fail - system relies on Jupiter recent feed if Dexscreener is blocked by CORS
    return [];
  }
}

export function scoreDexscreenerData(pair: DexPair | null): number {
  if (!pair) return 0;
  let score = 50;
  const liq = pair.liquidity?.usd || 0;
  if (liq > 100000) score += 25;
  else if (liq > 25000) score += 15;
  else if (liq < 5000) score -= 20;

  const vol24h = pair.volume?.h24 || 0;
  if (vol24h > 500000) score += 20;
  else if (vol24h > 50000) score += 10;

  return Math.min(100, Math.max(0, score));
}
