
import type {
  UltraSearchResponse,
  ShieldResponse,
  HoldingsResponse,
  OrderResponse,
  ExecuteResponse,
  OrderRequest,
  ExecuteRequest,
} from './ultraSwapTypes';

const ULTRA_BASE = 'https://api.jup.ag/ultra/v1';
const RATE_LIMIT_WINDOW = 10000;

export class UltraSwapClient {
  private apiKey: string;
  private requestsThisWindow = 0;
  private windowResetTime = Date.now();
  private baseQuota = 50;
  private addedQuota = 0;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async searchToken(query: string): Promise<UltraSearchResponse> {
    await this.checkRateLimit();
    const url = `${ULTRA_BASE}/search?query=${encodeURIComponent(query)}`;
    const response = await fetch(url, { headers: { 'x-api-key': this.apiKey } });
    if (!response.ok) throw new Error(`Ultra search error: ${response.status}`);
    return await response.json();
  }

  async getShield(mints: string[]): Promise<ShieldResponse> {
    await this.checkRateLimit();
    const url = `${ULTRA_BASE}/shield?mints=${mints.join(',')}`;
    const response = await fetch(url, { headers: { 'x-api-key': this.apiKey } });
    if (!response.ok) throw new Error(`Ultra shield error: ${response.status}`);
    return await response.json();
  }

  async getHoldings(walletAddress: string): Promise<HoldingsResponse> {
    await this.checkRateLimit();
    const url = `${ULTRA_BASE}/holdings/${walletAddress}`;
    const response = await fetch(url, { headers: { 'x-api-key': this.apiKey } });
    if (!response.ok) throw new Error(`Ultra holdings error: ${response.status}`);
    return await response.json();
  }

  async getOrder(params: OrderRequest): Promise<OrderResponse> {
    await this.checkRateLimit();
    const url = new URL(`${ULTRA_BASE}/order`);
    url.searchParams.append('inputMint', params.inputMint);
    url.searchParams.append('outputMint', params.outputMint);
    url.searchParams.append('amount', params.amount.toString());
    url.searchParams.append('taker', params.taker);
    
    const response = await fetch(url.toString(), { headers: { 'x-api-key': this.apiKey } });
    if (!response.ok) throw new Error(`Ultra order error: ${response.status}`);
    return await response.json();
  }

  async executeOrder(params: ExecuteRequest): Promise<ExecuteResponse> {
    await this.checkRateLimit();
    const response = await fetch(`${ULTRA_BASE}/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': this.apiKey },
      body: JSON.stringify(params),
    });
    if (!response.ok) throw new Error(`Ultra execute error: ${response.status}`);
    return await response.json();
  }

  async pollExecutionStatus(signedTransaction: string, requestId: string): Promise<ExecuteResponse> {
    const maxAttempts = 120;
    for (let i = 0; i < maxAttempts; i++) {
      const response = await this.executeOrder({ signedTransaction, requestId });
      if (response.status === 'Success' || response.status === 'Failed') return response;
      await new Promise(r => setTimeout(r, 1000));
    }
    throw new Error('Transaction timeout');
  }

  private async checkRateLimit() {
    const now = Date.now();
    if (now - this.windowResetTime >= RATE_LIMIT_WINDOW) {
      this.requestsThisWindow = 0;
      this.windowResetTime = now;
    }
    const quotaLimit = this.baseQuota + this.addedQuota;
    if (this.requestsThisWindow >= quotaLimit) {
      const waitTime = this.windowResetTime + RATE_LIMIT_WINDOW - now;
      await new Promise(r => setTimeout(r, Math.max(waitTime, 100)));
      return this.checkRateLimit();
    }
    this.requestsThisWindow++;
  }

  updateQuotaFromVolume(volumeUsd: number) {
    this.addedQuota = Math.floor(volumeUsd / 10000);
  }

  getQuotaStatus() {
    return {
      totalLimit: this.baseQuota + this.addedQuota,
      currentWindow: this.requestsThisWindow,
      windowResetIn: this.windowResetTime + RATE_LIMIT_WINDOW - Date.now(),
    };
  }
}
