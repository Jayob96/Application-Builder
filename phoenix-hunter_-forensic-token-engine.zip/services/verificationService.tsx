
import { LaunchEvent } from "../types";
import { logger as sysLogger } from "./observabilityService";

export class VerificationService {
  async verifyContract(token: any): Promise<{ isVerified: boolean; riskFlags: string[] }> {
    sysLogger.audit(token.symbol, "Initializing high-fidelity contract audit...");
    
    await new Promise(r => setTimeout(r, 1000));
    
    const riskFlags: string[] = [];
    
    if (token.audit) {
      if (!token.audit.mintAuthorityDisabled) riskFlags.push("Mint Authority Active");
      if (!token.audit.freezeAuthorityDisabled) riskFlags.push("Freeze Authority Active");
      if (token.audit.topHoldersPercentage > 30) riskFlags.push("High Holder Concentration");
    }

    if (!token.contractVerified && riskFlags.length === 0) {
      if (Math.random() > 0.8) riskFlags.push("Ownership Not Renounced");
    }
    
    const isVerified = riskFlags.length === 0;
    
    if (isVerified) {
      sysLogger.audit(token.symbol, "Audit status: SECURE (All safety gates passed)");
    } else {
      sysLogger.audit(token.symbol, `Safety Warning: ${riskFlags.join(', ')}`);
    }

    return { isVerified, riskFlags };
  }

  async verifyLiquidity(token: LaunchEvent): Promise<boolean> {
    sysLogger.audit(token.symbol, "Verifying Liquidity depth and pool status...");
    await new Promise(r => setTimeout(r, 800));
    
    const locked = token.liquidity > 5000; 
    if (locked) sysLogger.audit(token.symbol, `LP Check: Active (${(token.liquidity/1000).toFixed(1)}k depth)`);
    else sysLogger.audit(token.symbol, "CRITICAL: Insufficient liquidity depth detected.");
    
    return locked;
  }
}
