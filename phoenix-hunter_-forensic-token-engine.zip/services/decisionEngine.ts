
import { GeminiQuotaService } from "./geminiQuotaService";
import { IngestionService } from "./ingestionService";
import { VerificationService } from "./verificationService";
import { ExecutionService } from "./executionService";
import { MarketService } from "./marketService";
import { analyzeNewToken } from "./analyzeToken";
import { ActiveToken, LaunchEvent, ScoringWeights, TokenRisk } from "../types";
import { logger as sysLogger } from "./observabilityService";
// Fixed: Added INITIAL_WEIGHTS to imports to ensure type-safe initialization
import { THRESHOLDS, INITIAL_WEIGHTS } from "../constants";
import { Keypair } from "@solana/web3.js";
import { BackpackClient } from "./backpackClient";
import { OrderRouter } from "./orderRouter";
import { TradeExecutor } from "./tradeExecutor";
import { TradeHistoryService } from "./tradeHistoryService";
import { PositionMonitor } from "./positionMonitor";
import { positionService } from "./positionService";
import { searchByMint } from "./jupiterClient";
import { storageService } from "./storageService";

export class DecisionEngine {
  private forensicService: GeminiQuotaService;
  private ingestion: IngestionService = new IngestionService();
  private v: VerificationService = new VerificationService();
  private execution: ExecutionService;
  private backpack: BackpackClient;
  private router: OrderRouter;
  private tradeExecutor: TradeExecutor;
  private positionMonitor: PositionMonitor;
  private market: MarketService = new MarketService();
  
  private tokens: Map<string, ActiveToken> = new Map();
  private onUpdate: (tokens: ActiveToken[]) => void;
  private currentWeights: ScoringWeights;
  private sessionKeypair: Keypair;

  constructor(forensicService: GeminiQuotaService, onUpdate: (tokens: ActiveToken[]) => void) {
    this.forensicService = forensicService;
    this.onUpdate = onUpdate;
    
    // Fixed: Used INITIAL_WEIGHTS to correctly initialize ScoringWeights with valid properties
    this.currentWeights = { ...INITIAL_WEIGHTS };
    
    // Safety check for Buffer before generating keypair
    // Fixed: Cast 'window' to 'any' to resolve TypeScript error for missing 'Buffer' property
    if (typeof window !== 'undefined' && !(window as any).Buffer) {
      throw new Error("Neural Link Failure: Required crypto polyfills (Buffer) missing.");
    }

    try {
      this.sessionKeypair = Keypair.generate();
    } catch (e) {
      console.warn("Keypair generation failed, using mock keypair for UI stability.");
      // Fallback to a zero-filled keypair just to prevent null errors in UI
      this.sessionKeypair = Keypair.fromSeed(new Uint8Array(32).fill(1));
    }

    this.execution = new ExecutionService("https://api.mainnet-beta.solana.com");

    const env = (import.meta as any).env || {};
    const bpApiKey = env.VITE_BACKPACK_API_KEY || "";
    const bpSecret = env.VITE_BACKPACK_PRIVATE_KEY || "";

    // Initialize these with safety guards
    this.backpack = new BackpackClient(bpApiKey, bpSecret);
    this.router = new OrderRouter(this.backpack, this.execution);
    this.tradeExecutor = new TradeExecutor(this.router, this.backpack, this.execution, TradeHistoryService.getInstance());
    this.positionMonitor = new PositionMonitor(this.execution, this.tradeExecutor, this.sessionKeypair);

    sysLogger.log("Engine Online: Neural Execution Router mapped.", "success", { pubkey: this.sessionKeypair.publicKey.toBase58() }, 1, "decisionEngine");
  }

  async start(weights: ScoringWeights) {
    this.currentWeights = { ...weights };
    this.positionMonitor.start();
    this.ingestion.start(async (event) => {
      await this.processLaunch(event, this.currentWeights);
    });
    setInterval(() => this.heartbeat(), 2000);
  }

  public async ingestToken(event: LaunchEvent) {
    await this.processLaunch(event, this.currentWeights);
  }

  public updateWeights(newWeights: ScoringWeights) {
    this.currentWeights = { ...newWeights };
    sysLogger.log("Neural topology weights updated in engine.", "info");
  }

  public async manualSnipe(tokenId: string) {
    const token = this.tokens.get(tokenId);
    if (token && token.stage !== 'TRACKING' && token.stage !== 'EXITED') {
      sysLogger.log(`Manual override: Sniping ${token.symbol}`, "warning");
      await this.executeEntryStrategy(token);
      this.broadcast();
    }
  }

  public async manualExit(tokenId: string) {
    const activePositions = positionService.getActive();
    const token = this.tokens.get(tokenId);
    if (!token) return;

    const pos = activePositions.find(p => p.mint === token.mint);
    if (pos) {
       sysLogger.log(`Manual override: Exiting ${token.symbol}`, "warning");
       await this.tradeExecutor.closePosition(pos, 'MANUAL_EXIT', this.sessionKeypair);
       positionService.close(pos.id, {
           exitReason: 'MANUAL',
           exitPrice: 0,
           exitTime: Date.now(),
           exitTxn: 'manual_override'
       });
    }
  }

  private async executeEntryStrategy(token: ActiveToken) {
     const SOL_MINT = "So11111111111111111111111111111111111111112";
     try {
       const result = await this.tradeExecutor.executeTrade({
          inputMint: SOL_MINT,
          outputMint: token.mint,
          amountLamports: 10000000, 
          maxSlippageBps: 50,
          wallet: this.sessionKeypair,
          symbol: token.symbol
       });

       if (result.status !== 'SUCCESS') {
          sysLogger.log(`Entry failed for ${token.symbol}: ${result.error || 'unknown error'}`, "error", { tokenId: token.id }, 3, "decisionEngine");
          return;
       }

       token.stage = 'TRACKING';
       token.entryTx = result.signature || result.orderId;
       token.entry_price = result.price || token.entry_price;
       
       let decimals = 6; 
       try {
           const info = await searchByMint(token.mint);
           if (info) decimals = info.decimals;
       } catch(e) {}

       positionService.add({
           id: token.id,
           mint: token.mint,
           symbol: token.symbol,
           decimals,
           amountTokens: result.outputAmount,
           costBasis: 0.01,
           entryPrice: result.price,
           entryTime: Date.now(),
           entryTxn: result.signature || result.orderId || 'unknown',
           currentPrice: result.price,
           pnl: 0,
           pnlPercent: 0,
           status: 'ACTIVE'
       });
       
     } catch (err: any) {
       sysLogger.log(`Entry strategy crashed for ${token.symbol}: ${err.message}`, "error");
     }
  }

  private async processLaunch(event: LaunchEvent, weights: ScoringWeights) {
    if (this.tokens.has(event.id)) return;

    const active: ActiveToken = {
      ...event,
      status: 'active',
      stage: 'AUDITING',
      history: [{ 
        timestamp: Date.now(), price: event.entry_price, roi: 1, volume: event.liquidity * 0.4, 
        lp: event.liquidity, holders: event.holders, spread: 0.02, topHolderPct: 0.1, liquidityChange: 0
      }],
      currentRoi: 1
    };

    this.tokens.set(active.id, active);
    this.broadcast();

    try {
      const fullAudit = await analyzeNewToken(active.mint, this.forensicService);
      
      if (!fullAudit || fullAudit.heuristicScore < THRESHOLDS.MIN_SCORE) {
        active.stage = 'EXITED';
        active.status = 'archived';
        this.broadcast();
        return;
      }

      if (fullAudit.aiVerdict) {
        const v = fullAudit.aiVerdict;
        active.analysis = {
          forensicScore: v.confidence,
          confidence: v.confidence,
          riskLevel: v.riskLevel as TokenRisk,
          predictedHoldTime: 10,
          reasoning: v.summary,
          rugProbability: v.rugProbability
        };
        active.verdict = v.verdict === 'ENTER' ? 'ENTER' : 'WATCH';
      }

      if (storageService.isConfigured()) {
        storageService.syncTokenAudit(active);
      }

      if (active.verdict === 'ENTER') {
        await this.executeEntryStrategy(active);
      } else {
        active.stage = 'CANDIDATE';
      }
      
      this.broadcast();
    } catch (err) {
      this.broadcast();
    }
  }

  private heartbeat() {
    let changed = false;
    const activePositions = positionService.getActive();
    
    this.tokens.forEach(token => {
      const pos = activePositions.find(p => p.mint === token.mint);
      if (pos) {
          token.currentRoi = 1 + (pos.pnlPercent / 100);
          changed = true;
      } else if (token.stage === 'TRACKING') {
          const next = this.market.getLatestSnapshot(token);
          if (next) {
            token.history.push(next);
            token.currentRoi = next.roi;
            changed = true;
          }
      }
    });
    
    if (changed) this.broadcast();
  }

  private broadcast() {
    this.onUpdate(Array.from(this.tokens.values()));
  }
}
