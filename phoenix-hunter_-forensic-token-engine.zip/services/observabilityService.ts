
import { SystemLog } from "../types";

type LogCallback = (log: SystemLog) => void;

export class ObservabilityService {
  private static instance: ObservabilityService;
  private listeners: LogCallback[] = [];

  private constructor() {}

  static getInstance() {
    if (!this.instance) this.instance = new ObservabilityService();
    return this.instance;
  }

  subscribe(callback: LogCallback) {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  log(message: string, type: SystemLog['type'] = 'info', context?: Record<string, any>, severity: number = 1, actor: string = 'system') {
    const log: SystemLog = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      message,
      type,
      context,
      severity,
      actor
    };
    this.listeners.forEach(l => l(log));
  }

  audit(token: string, detail: string, severity: number = 2) {
    this.log(`[AUDIT] ${token}: ${detail}`, 'audit', { token }, severity, 'forensicNode');
  }

  trade(token: string, action: string, price: number, severity: number = 3) {
    this.log(`[TRADE] ${token} ${action} @ $${price.toFixed(6)}`, 'trade', { token, action, price }, severity, 'executionService');
  }
}

export const logger = ObservabilityService.getInstance();
