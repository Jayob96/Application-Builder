
import { BackpackFill, PnLMetrics } from './backpackTypes';
import { logger } from './observabilityService';

export interface LoggedTrade {
  id: string;
  symbol: string;
  side: 'Buy' | 'Sell';
  price: number;
  quantity: number;
  fee: number;
  timestamp: number;
  venue: 'Backpack' | 'Jupiter';
}

export class TradeHistoryService {
  private static instance: TradeHistoryService;
  private trades: LoggedTrade[] = [];
  private readonly STORAGE_KEY = 'solana_sentinel_trades';

  private constructor() {
    this.load();
  }

  static getInstance(): TradeHistoryService {
    if (!this.instance) this.instance = new TradeHistoryService();
    return this.instance;
  }

  logBackpackFill(fill: BackpackFill) {
    const trade: LoggedTrade = {
      id: fill.id,
      symbol: fill.symbol,
      side: fill.side === 'Bid' ? 'Buy' : 'Sell',
      price: parseFloat(fill.price),
      quantity: parseFloat(fill.quantity),
      fee: parseFloat(fill.fee),
      timestamp: fill.timestamp,
      venue: 'Backpack'
    };
    this.addTrade(trade);
  }

  logManualTrade(trade: LoggedTrade) {
    this.addTrade(trade);
  }

  private addTrade(trade: LoggedTrade) {
    this.trades.push(trade);
    this.save();
    logger.log(`Trade Logged: ${trade.side} ${trade.symbol}`, 'success', { price: trade.price }, 2, 'tradeHistory');
  }

  getTrades(symbol?: string): LoggedTrade[] {
    if (!symbol) return this.trades;
    return this.trades.filter(t => t.symbol === symbol);
  }

  calculatePnL(symbol: string): PnLMetrics {
    const trades = this.getTrades(symbol).sort((a, b) => a.timestamp - b.timestamp);
    const buys: LoggedTrade[] = [];
    
    let realizedPnL = 0;
    let volume = 0;
    let winCount = 0;
    let tradeCount = 0;

    for (const trade of trades) {
      volume += trade.price * trade.quantity;
      
      if (trade.side === 'Buy') {
        buys.push({ ...trade });
      } else {
        let quantityToSell = trade.quantity;
        tradeCount++;
        let tradePnL = 0;

        while (quantityToSell > 0 && buys.length > 0) {
          const buy = buys[0];
          const matchedQty = Math.min(buy.quantity, quantityToSell);
          const profit = (trade.price - buy.price) * matchedQty;
          realizedPnL += profit;
          tradePnL += profit;
          buy.quantity -= matchedQty;
          quantityToSell -= matchedQty;
          if (buy.quantity <= 0.00000001) buys.shift();
        }
        
        realizedPnL -= trade.fee; 
        if (tradePnL > 0) winCount++;
      }
    }

    return {
      realizedPnL,
      unrealizedPnL: 0, 
      volume,
      trades: tradeCount,
      winRate: tradeCount > 0 ? winCount / tradeCount : 0
    };
  }

  private save() {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.trades));
      }
    } catch (e) {
      console.error('Failed to save trades', e);
    }
  }

  private load() {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const data = localStorage.getItem(this.STORAGE_KEY);
        if (data) this.trades = JSON.parse(data);
      }
    } catch (e) {
      this.trades = [];
    }
  }
}
