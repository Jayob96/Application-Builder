
export interface SystemSpecs {
  cpu: string;
  ram: string;
  os: string;
  storageType: 'HDD' | 'SSD' | 'NVMe';
  storageSpace: string;
  gpu?: string;
  architecture?: string;
  cores?: number;
  display?: string;
  network?: string;
  battery?: string;
  logicalProcessors?: number;
}

export interface AppUpdate {
  version: string;
  releaseDate: string;
  criticality: 'Low' | 'Medium' | 'High' | 'Critical';
  changelog: string[];
  binaryHash: string;
  deltaSize: string;
}

export interface LogicEvolution {
  version: string;
  complexity: number;
  lastMutation: number;
  evolutionPath: string[];
  stabilityIndex: number;
}

export interface ThreatPattern {
  id: string;
  name: string;
  vector: string;
  complexity: number;
  description: string;
  signature: string;
}

export interface OperationPattern {
  id: string;
  name: string;
  category: 'I/O' | 'CPU_SCHEDULING' | 'MEMORY_PAGING' | 'INTERRUPT_HANDLING';
  description: string;
  instructionEntropy: number;
  baselineEfficiency: number;
}

export interface TrainingProgress {
  epoch: number;
  accuracy: number;
  loss: number;
  entropyDivergence: number;
  activeThreatId: string | null;
  activeOpId?: string | null;
}

export interface DriverInfo {
  component: string;
  detectedModel: string;
  currentStatus: 'Up to Date' | 'Update Available' | 'Legacy' | 'Stability Risk';
  latestVersion?: string;
  releaseDate?: string;
  downloadUrl?: string;
  impact: string;
  stabilityRisk?: number;
  rollbackVersion?: string;
}

// Added missing interface: DriverStability
export interface DriverStability {
  verdict: string;
  riskScore: number;
  performanceImpact: string;
  compatibilityIssues: string[];
  recommendation: string;
  neuralScore: number;
  rollbackVersion?: string;
}

// Added missing interface: ResearchResult
export interface ResearchResult {
  title: string;
  type: string;
  description: string;
  automationSummary: string;
  url: string;
  source: string;
}

// Added missing interface: BreachInfo
export interface BreachInfo {
  source: string;
  date: string;
  details: string;
  uri: string;
}

// Added missing interface: SecurityAudit
export interface SecurityAudit {
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical' | string;
  vulnerabilities: string[];
  hardeningSteps: string[];
}

// Added missing interface: ChatMessage
export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

// Added missing interface: MutationMatrixState
export interface MutationMatrixState {
  grid: string[][];
  stability: number;
  mutationDepth: number;
}

// Added missing interface: NeuralWeightMap
export interface NeuralWeightMap {
  synapses: {
    id: string;
    weight: number;
    bias: number;
    signal: 'excitatory' | 'inhibitory';
  }[];
  globalBias: number;
  layerDensity: number;
}

export interface OptimizationReport {
  summary: string;
  bottlenecks: string[];
  softwareSteps: string[];
  hardwareSuggestions: string[];
  osTweaks: string[];
  expectedGain: string;
  securityAudit: SecurityAudit;
  researchFindings?: ResearchResult[];
}

export interface StorageMetric {
  used: number;
  quota: number;
  indexDbSize: number;
  vfsCount: number;
}

export interface PerformanceSnapshot {
  timestamp: number;
  cpu: number;
  ram: number;
  temp: number;
  efficiency: number;
}

export interface TuningManifest {
  version: string;
  tuningType: string;
  explanation: string;
  scripts: { file: string; content: string }[];
}

// Added missing interface: LiveTelemetry
export interface LiveTelemetry {
  cpuUsage: number;
  ramUsed: number;
  ramTotal: number;
  networkDown: number;
  networkUp: number;
  thermalIndex: number;
  neuralLoad: number;
  jitter: number;
  pageFaults: number;
  instructionRetirement: number;
  diskIo?: number;
  gpuUsage?: number;
  timestamp: number;
}

// Added missing interface: CognitiveEvent
export interface CognitiveEvent {
  timestamp: Date;
  source: string;
  type: string;
  confidence?: number;
  metadata?: Record<string, any>;
  requestId?: string;
}

// Added missing interface: CorpusEntry
export interface CorpusEntry {
  id: string;
  source: string;
  raw: string;
  timestamp: number;
  metadata: Record<string, any>;
}

// Added missing interface: TelemetryChunk
export interface TelemetryChunk {
  chunkId: string;
  corpusId: string;
  text: string;
  entropy: number;
  timestamp: number;
  metadata: Record<string, any>;
}

// Firewall related exports
export type FirewallAction = 'ALLOW' | 'BLOCK' | 'QUARANTINE' | 'THROTTLE' | 'ALERT';
export type ThreatCategory = 'MALWARE' | 'EXFILTRATION' | 'BRUTEFORCE' | 'ANOMALY';

export interface NetworkPacket {
  id: string;
  sourceIp: string;
  destinationIp: string;
  port: number;
  protocol: 'TCP' | 'UDP' | 'ICMP' | string;
  payloadSize: number;
  entropy: number;
  timestamp: number;
}

export interface ThreatIndicator {
  category: ThreatCategory;
  score: number;
  evidence: string;
  source: string;
}

export interface FirewallVerdict {
  action: FirewallAction;
  threatLevel: number;
  reasoning: string;
  confidence: number;
  threats: ThreatIndicator[];
  recommendations: string[];
  analyzedAt: number;
}

export interface FirewallPolicy {
  trustedIps: string[];
  blockedIps: string[];
  allowedPorts: number[];
  maxEntropyThreshold: number;
  maxPacketRatePerSecond: number;
  humanReviewThreshold: number;
}

export interface TrafficProfile {
  sourceIp: string;
  packetCount: number;
  avgPacketSize: number;
  avgEntropy: number;
  uniqueDestinations: Set<string>;
  uniquePorts: Set<number>;
  protocolDistribution: Record<string, number>;
}

export interface FirewallAuditEntry {
  packetId: string;
  verdict: FirewallVerdict;
  signature: string;
  timestamp: number;
  actor: string;
}

export enum DashboardTab {
  COMMAND_CENTER = 'command_center',
  AI_OPTIMIZER = 'ai_optimizer',
  NEURAL_SECURITY = 'neural_security',
  DEVOPS_KERNEL = 'devops_kernel',
  SYSTEM_UTILS = 'system_utils',
  AI_FIREWALL = 'ai_firewall'
}
