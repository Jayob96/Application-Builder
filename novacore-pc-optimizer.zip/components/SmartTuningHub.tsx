
import React, { useState, useEffect, useRef } from 'react';
import { SystemSpecs, PerformanceSnapshot } from '../types';
import { tuningEngine, OPS_DATASET } from '../services/smartTuningService';

interface SmartTuningHubProps {
  specs: SystemSpecs | null;
}

export const SmartTuningHub: React.FC<SmartTuningHubProps> = ({ specs }) => {
  const [weights, setWeights] = useState(tuningEngine.getWeights());
  const [progress, setProgress] = useState(tuningEngine.getProgress());
  const [isLearning, setIsLearning] = useState(false);
  const [history, setHistory] = useState<PerformanceSnapshot[]>([]);
  const [logs, setLogs] = useState<{ id: number, msg: string, type: 'info' | 'success' }[]>([]);
  
  const logRef = useRef<HTMLDivElement>(null);

  const addLog = (msg: string, type: 'info' | 'success') => {
    setLogs(prev => [...prev.slice(-12), { id: Date.now(), msg: msg.toUpperCase(), type }]);
  };

  const executeDeepLearn = async () => {
    if (isLearning) return;
    setIsLearning(true);
    addLog("Initializing Neural Synapse Recalibration...", 'info');
    
    try {
      const res = await tuningEngine.runTuningCycle(specs, history);
      if (res) {
        addLog(`OP_TARGET: ${res.op.name}`, 'info');
        addLog(`INSTRUCTION_MUTATION: Committing logic node...`, 'info');
        addLog(`EFFICIENCY_GAIN: +${res.result.efficiencyGain.toFixed(2)}%`, 'success');
        setWeights({ ...tuningEngine.getWeights() });
        setProgress({ ...tuningEngine.getProgress() });
      }
    } catch (e) {
      addLog("DEEP_LEARN_FAILED: Neural link timeout.", 'info');
    } finally {
      setIsLearning(false);
    }
  };

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [logs]);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 select-none">
      <header className="flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
             <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_12px_rgba(16,185,129,0.8)]" />
             <span className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.4em] mb-0.5">Autonomous Instruction Tuning</span>
          </div>
          <h2 className="text-6xl font-black text-white tracking-tighter uppercase italic leading-none">Smart Tuning Hub</h2>
          <p className="text-slate-500 font-medium italic text-sm">Neural Synapse Mapping active for <span className="text-slate-300">{specs?.cpu || 'Generic Architecture'}</span></p>
        </div>
        <button 
           onClick={executeDeepLearn}
           disabled={isLearning}
           className="px-12 py-5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-[24px] font-black text-xs uppercase tracking-[0.3em] shadow-2xl transition-all disabled:opacity-50 active:scale-95 group overflow-hidden relative"
        >
          <span className="relative z-10">{isLearning ? 'Deep Learning...' : 'Trigger Deep Learn'}</span>
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Synapse Weight Visualization */}
        <div className="lg:col-span-8 bg-slate-900/40 backdrop-blur-3xl border border-slate-800 rounded-[48px] p-10 relative overflow-hidden group shadow-3xl">
           <div className="flex items-center justify-between mb-12">
              <h3 className="font-black text-3xl text-white uppercase tracking-tighter italic">Instruction Weight Matrix</h3>
              <div className="flex gap-6">
                 <div className="text-right">
                    <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Accuracy</p>
                    <p className="text-lg font-black text-emerald-500">{progress.accuracy.toFixed(1)}%</p>
                 </div>
                 <div className="text-right border-l border-slate-800 pl-4">
                    <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Density</p>
                    <p className="text-lg font-black text-blue-400">{weights.layerDensity.toFixed(1)}%</p>
                 </div>
              </div>
           </div>

           <div className="grid grid-cols-2 md:grid-cols-3 gap-6 relative z-10">
              {weights.synapses.map((syn, i) => (
                <div key={syn.id} className="bg-slate-950/60 p-6 rounded-[32px] border border-slate-800 hover:border-emerald-500/30 transition-all group/card">
                   <div className="flex justify-between items-center mb-6">
                      <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">{syn.id}</span>
                      <div className={`w-1.5 h-1.5 rounded-full ${syn.signal === 'excitatory' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.5)]'}`} />
                   </div>
                   <div className="space-y-4">
                      <div className="flex justify-between items-end">
                         <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Weight</span>
                         <span className={`text-xl font-black italic ${syn.weight > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>{syn.weight.toFixed(3)}</span>
                      </div>
                      <div className="h-1 w-full bg-slate-900 rounded-full overflow-hidden">
                         <div 
                           className={`h-full transition-all duration-1000 ${syn.weight > 0 ? 'bg-emerald-500' : 'bg-rose-500'}`} 
                           style={{ width: `${Math.abs(syn.weight) * 100}%` }} 
                         />
                      </div>
                   </div>
                </div>
              ))}
           </div>

           <div className="mt-12 p-8 bg-black/40 rounded-[32px] border border-slate-800/50">
              <div className="flex items-center justify-between mb-4">
                 <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Active Recalibration Operation</p>
                 <span className="text-[9px] font-mono text-emerald-500 animate-pulse">NEURAL_SYNC_READY</span>
              </div>
              <p className="text-sm text-slate-300 font-medium italic leading-relaxed">
                {progress.activeOpId ? 
                  `"Currently analyzing ${OPS_DATASET.find(o => o.id === progress.activeOpId)?.description}"` : 
                  "Neural link established. Awaiting Deep Learn command."}
              </p>
           </div>
        </div>

        <div className="lg:col-span-4 flex flex-col gap-8">
           <div className="bg-slate-900/40 border border-slate-800 rounded-[48px] p-10 h-[480px] shadow-3xl flex flex-col overflow-hidden group">
              <div className="flex items-center justify-between mb-8">
                <h3 className="font-black text-[11px] uppercase tracking-[0.4em] text-slate-500 italic">Neural Log Stream</h3>
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
              </div>
              <div ref={logRef} className="flex-1 overflow-y-auto space-y-4 font-mono text-[10px] custom-scrollbar pr-2">
                 {logs.length === 0 && <p className="text-slate-800 italic">Awaiting instruction ingestion...</p>}
                 {logs.map(log => (
                   <div key={log.id} className="flex gap-4 animate-in slide-in-from-right-4">
                      <span className="text-slate-800 shrink-0 font-bold">[{new Date(log.id).toLocaleTimeString([], {second:'2-digit'})}]</span>
                      <span className={`font-black tracking-tight leading-relaxed ${
                        log.type === 'success' ? 'text-emerald-400' : 'text-blue-400'
                      }`}>
                        {log.msg}
                      </span>
                   </div>
                 ))}
                 {isLearning && <div className="w-1.5 h-3 bg-emerald-500 animate-pulse inline-block" />}
              </div>
           </div>

           <div className="bg-gradient-to-br from-indigo-600 to-blue-700 border border-blue-500/20 rounded-[48px] p-10 shadow-3xl flex-1 flex flex-col justify-between group overflow-hidden relative">
              <div className="relative z-10">
                <p className="text-[10px] font-black uppercase text-blue-100 tracking-widest mb-2 opacity-80">Architecture Awareness</p>
                <h4 className="text-2xl font-black text-white italic tracking-tighter leading-none mb-6">Smart Tuning Protocol</h4>
                <p className="text-[11px] text-blue-50/70 font-medium leading-relaxed italic">
                   "The Smart Tuning Hub utilizes Gemini 3 Pro to perform deep learning on specific system operation patterns. By mutating core instruction weights locally, we can revitalization older PC hardware beyond factory specifications."
                </p>
              </div>
              <div className="absolute bottom-0 right-0 p-8 opacity-20 pointer-events-none group-hover:translate-x-4 transition-transform duration-1000">
                 <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71L12 2z"/></svg>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
