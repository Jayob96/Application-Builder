
import React, { useState, useRef, useEffect } from 'react';
import { SystemSpecs, DashboardTab } from '../types';
import { processTerminalCommand, getOptimizationReport, getSentinelSelfUpgrade, synthesizeMutationProtocol } from '../services/geminiService';
import { autodiscoverSpecs } from '../services/hardwareScanner';
import { vault } from '../services/memoryVault';

interface VSCodeTerminalProps {
  specs: SystemSpecs | null;
}

interface LogEntry {
  type: 'input' | 'output' | 'error' | 'system' | 'success' | 'ai';
  content: string;
}

export const VSCodeTerminal: React.FC<VSCodeTerminalProps> = ({ specs }) => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentPath, setCurrentPath] = useState('C:/NovaCore/System');
  const [vfs, setVfs] = useState<{ [key: string]: string }>({});

  const terminalEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync VFS from Vault on mount and intervals
  const syncVFS = async () => {
    const files = await vault.getAllFiles();
    // Default files if vault is empty
    if (Object.keys(files).length === 0) {
        await vault.saveFile('core_logic.sys', 'VERSION=1.4.2\nMODE=NEURAL_ADAPTIVE');
        await vault.saveFile('C:/Windows/System32/kernel32.dll', '[BINARY_DATA_BLOB]');
        const refreshed = await vault.getAllFiles();
        setVfs(refreshed);
    } else {
        setVfs(files);
    }
  };

  useEffect(() => {
    syncVFS();
    if (logs.length === 0) {
      setLogs([
        { type: 'system', content: 'NovaCore Terminal Interface [Version 1.4.2]' },
        { type: 'system', content: `Host: ${specs?.os || 'Windows NT'} | Arch: ${specs?.architecture || 'x86_64'}` },
        { type: 'system', content: 'MemoryVault connection: ESTABLISHED' }
      ]);
    }
  }, []);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const addLog = (type: LogEntry['type'], content: string) => {
    setLogs(prev => [...prev, { type, content }]);
  };

  const executeCommand = async (fullCommand: string) => {
    const parts = fullCommand.trim().split(/\s+/);
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1);

    switch (cmd) {
      case 'help':
        addLog('output', `
Available Commands:
  ls [path]       List virtual files from Vault
  cat <file>      Read virtual file from Vault
  rm <file>       Delete file from Vault
  nova scan       Trigger hardware discovery
  nova optimize   Run performance interrogation
  nova evolve     Trigger core self-upgrade
  clear           Flush buffer
  ai <prompt>     Interrogate logic bridge
        `);
        break;

      case 'ls': {
        await syncVFS();
        const targetRaw = args[0] || currentPath;
        const targetNormalized = targetRaw.replace(/\\/g, '/').replace(/\/$/, '');
        
        const filtered = Object.keys(vfs).filter(key => {
          const keyNormalized = key.replace(/\\/g, '/');
          return keyNormalized.startsWith(targetNormalized) || keyNormalized === targetNormalized;
        });

        const displayItems = filtered.map(f => f.split('/').pop() || f);
        addLog('output', displayItems.join('    ') || `Directory "${targetRaw}" is unmapped.`);
        break;
      }

      case 'cat':
        await syncVFS();
        const fileContent = vfs[args[0]];
        if (fileContent) {
          addLog('output', fileContent);
        } else {
          addLog('error', `ERR: Node not found: ${args[0]}`);
        }
        break;

      case 'rm':
        if (!args[0]) {
          addLog('error', 'Usage: rm <filename>');
        } else {
          await vault.deleteFile(args[0]);
          await syncVFS();
          addLog('success', `Node unlinked: ${args[0]}`);
        }
        break;

      case 'nova':
        const sub = args[0]?.toLowerCase();
        if (sub === 'scan') {
          addLog('system', 'Initializing silicon scan...');
          const newSpecs = await autodiscoverSpecs();
          addLog('success', `Scan finalized: ${newSpecs.cpu} detected.`);
        } else if (sub === 'optimize') {
          if (!specs) { addLog('error', 'ERR: Specs unmapped.'); }
          else {
            addLog('system', 'Synthesizing roadmap...');
            const report = await getOptimizationReport(specs);
            addLog('ai', report.summary);
          }
        } else {
          addLog('error', 'Usage: nova [scan|optimize|evolve]');
        }
        break;

      case 'clear':
        setLogs([]);
        break;

      case 'ai':
        const prompt = args.join(' ');
        if (!prompt) {
          addLog('error', 'Usage: ai <query>');
        } else {
          setIsProcessing(true);
          const response = await processTerminalCommand(prompt, specs);
          addLog('ai', response);
          setIsProcessing(false);
        }
        break;

      default:
        setIsProcessing(true);
        const aiResponse = await processTerminalCommand(`Unknown command: "${fullCommand}". Provide a technical system error.`, specs);
        addLog('ai', aiResponse);
        setIsProcessing(false);
        break;
    }
  };

  const handleCommandSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isProcessing) return;
    const cmd = input.trim();
    setLogs(prev => [...prev, { type: 'input', content: cmd }]);
    setInput('');
    await executeCommand(cmd);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 h-full flex flex-col">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-black text-white uppercase italic tracking-tighter">Functional Terminal</h2>
          <p className="text-slate-500 font-medium italic">Direct I/O to MemoryVault nodes.</p>
        </div>
      </header>

      <div className="flex-1 flex flex-col bg-[#0c0c0c] border border-slate-800 rounded-[40px] shadow-3xl overflow-hidden min-h-[500px]">
         <div className="bg-[#1e1e1e] px-6 py-4 flex items-center gap-6 border-b border-white/5">
            <div className="flex gap-2">
               <div className="w-3 h-3 rounded-full bg-rose-500/40" />
               <div className="w-3 h-3 rounded-full bg-amber-500/40" />
               <div className="w-3 h-3 rounded-full bg-emerald-500/40" />
            </div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">nova-kernel — root@vault</span>
         </div>

         <div className="flex-1 overflow-y-auto p-10 font-mono text-[13px] custom-scrollbar">
            <div className="space-y-4">
               {logs.map((log, i) => (
                  <div key={i} className={
                    log.type === 'error' ? 'text-rose-400' : 
                    log.type === 'system' ? 'text-slate-500 italic' : 
                    log.type === 'success' ? 'text-emerald-400' : 
                    log.type === 'ai' ? 'text-blue-300' : 
                    log.type === 'input' ? 'text-white' : 'text-slate-300'
                  }>
                     {log.type === 'input' && <span className="text-blue-500 mr-3">{currentPath}&gt;</span>}
                     {log.type === 'ai' && <div className="mt-2 pl-4 border-l-2 border-blue-500/40 bg-blue-500/5 py-4 rounded-r-2xl whitespace-pre-wrap">{log.content}</div>}
                     {log.type === 'output' && <div className="mt-2 pl-4 border-l border-slate-800 whitespace-pre-wrap text-slate-400">{log.content}</div>}
                     {log.type !== 'ai' && log.type !== 'output' && log.content}
                  </div>
               ))}
               {isProcessing && <div className="text-blue-500 animate-pulse italic">PROCESSING_IO...</div>}
               <div ref={terminalEndRef} />
            </div>
         </div>

         <form onSubmit={handleCommandSubmit} className="bg-[#050505] px-10 py-6 border-t border-white/5 flex items-center">
            <span className="text-blue-500 font-mono text-[13px] mr-4">{currentPath}&gt;</span>
            <input 
               ref={inputRef}
               className="flex-1 bg-transparent border-none outline-none font-mono text-[13px] text-white caret-blue-500"
               placeholder="Enter functional command..."
               value={input}
               onChange={e => setInput(e.target.value)}
               autoFocus
               disabled={isProcessing}
            />
         </form>

         <div className="bg-[#007acc] px-6 py-2 flex justify-between text-white text-[10px] font-medium">
            <span>Functional-Shell*</span>
            <span>VAULT_SYNC: OK</span>
         </div>
      </div>
    </div>
  );
};
