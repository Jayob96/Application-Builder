
import React, { useState, useEffect, useRef } from 'react';
import { analyzeSuspiciousFile } from '../services/geminiService';

const SCAN_DIRECTORIES = [
  "C:/Windows/System32/drivers",
  "C:/Windows/SysWOW64",
  "C:/Program Files/Common Files",
  "C:/Program Files (x86)/Internet Explorer",
  "C:/Users/Default/AppData/Local/Temp",
  "C:/Users/Admin/Downloads",
  "C:/Boot/BCD",
  "C:/Windows/Prefetch"
];

const MOCK_THREATS = [
  { path: "C:/Users/Default/AppData/Local/Temp", name: "Suspicious Script Engine (js.tmp)" },
  { path: "C:/Windows/System32/drivers", name: "Unsigned Kernel Driver (vxt_drv.sys)" },
  { path: "C:/Users/Admin/Downloads", name: "PUP.Optional.Adware.Bundler" }
];

export const ThreatCenter: React.FC = () => {
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [foundItems, setFoundItems] = useState<{name: string, path: string}[]>([]);
  const [currentScanningPath, setCurrentScanningPath] = useState('');
  const [scanStats, setScanStats] = useState({ files: 0, folders: 0 });
  
  // Heuristic Engine States
  const [suspiciousFile, setSuspiciousFile] = useState('');
  const [observedBehavior, setObservedBehavior] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [analysisLogs, setAnalysisLogs] = useState<string[]>([]);
  
  const scanIntervalRef = useRef<number | null>(null);

  const startScan = () => {
    setIsScanning(true);
    setScanProgress(0);
    setFoundItems([]);
    setScanStats({ files: 0, folders: 0 });
    
    let currentDirIndex = 0;
    let localProgress = 0;
    let localFiles = 0;

    scanIntervalRef.current = window.setInterval(() => {
      localProgress += Math.random() * 1.5;
      setScanProgress(Math.min(localProgress, 100));

      localFiles += Math.floor(Math.random() * 25) + 10;
      setScanStats({ files: localFiles, folders: Math.floor(localFiles / 15) });

      const dirIndex = Math.floor((localProgress / 100) * SCAN_DIRECTORIES.length);
      if (dirIndex !== currentDirIndex && dirIndex < SCAN_DIRECTORIES.length) {
        currentDirIndex = dirIndex;
        const newPath = SCAN_DIRECTORIES[currentDirIndex];
        setCurrentScanningPath(newPath);

        const threat = MOCK_THREATS.find(t => t.path === newPath);
        if (threat) {
          setFoundItems(prev => [...prev, threat]);
        }
      }

      if (localProgress >= 100) {
        if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
        setIsScanning(false);
        setCurrentScanningPath('System Integrity Verified');
      }
    }, 120);
  };

  const handleAnalyzeBehavior = async () => {
    if (!observedBehavior && !suspiciousFile) return;
    setIsAnalyzing(true);
    setAnalysisLogs([]);
    setAnalysisResult(null);

    const logSteps = [
      "Initializing Heuristic Interrogator...",
      "Mapping behavioral pattern to ATT&CK matrix...",
      "Simulating execution in isolated VM sandbox...",
      "Analyzing instruction set variance...",
      "Cross-referencing kernel call hooks...",
      "Synthesizing neural verdict..."
    ];

    for (const log of logSteps) {
      setAnalysisLogs(prev => [...prev, `[LOG] ${log}`]);
      await new Promise(r => setTimeout(r, 400 + Math.random() * 400));
    }

    try {
      const res = await analyzeSuspiciousFile(
        suspiciousFile || "Observed System Behavior", 
        observedBehavior || "No behavior description provided."
      );
      setAnalysisResult(res);
    } catch (e) {
      setAnalysisResult("AI Analysis engine encountered a synchronization error. Please retry.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  useEffect(() => {
    return () => {
      if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
    };
  }, []);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter uppercase italic">Threat Center</h2>
          <p className="text-slate-500 mt-1 font-medium">Real-time antivirus, heuristic behavior analysis, and AI sandboxing.</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="hidden md:flex flex-col items-end">
            <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Heuristic Engine Status</span>
            <span className="text-xs font-bold text-emerald-500">NOMINAL & ACTIVE</span>
          </div>
          <button 
            onClick={startScan}
            disabled={isScanning}
            className="px-10 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-blue-900/40 transition-all active:scale-95 disabled:opacity-50"
          >
            {isScanning ? 'Lockdown Scanning...' : 'Full System Scan'}
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Real-time Status & Scan */}
        <div className="lg:col-span-7 space-y-8">
          <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-[40px] p-10 relative overflow-hidden group shadow-3xl">
             <div className="flex items-center justify-between mb-10">
                <div className="flex items-center gap-4">
                   <div className={`w-3 h-3 rounded-full ${isScanning ? 'bg-blue-500 animate-ping' : 'bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.5)]'}`} />
                   <h3 className="font-black text-xl text-white">Kernel Watchdog</h3>
                </div>
                <div className="flex gap-4">
                   <div className="text-right">
                      <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Files Scanned</p>
                      <p className="text-sm font-black text-slate-300">{scanStats.files.toLocaleString()}</p>
                   </div>
                   <div className="text-right border-l border-slate-800 pl-4">
                      <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Folders Mapped</p>
                      <p className="text-sm font-black text-slate-300">{scanStats.folders.toLocaleString()}</p>
                   </div>
                </div>
             </div>

             {isScanning ? (
               <div className="space-y-8 py-4">
                  <div className="flex justify-between items-end">
                    <div className="overflow-hidden flex-1">
                      <p className="text-[10px] uppercase font-black text-blue-500 tracking-[0.3em] mb-2">Interrogating File System</p>
                      <p className="text-xs font-mono text-slate-400 truncate max-w-md bg-black/40 p-3 rounded-xl border border-slate-800">{currentScanningPath || 'Initializing environment diagnostics...'}</p>
                    </div>
                    <div className="text-right ml-6">
                       <p className="text-4xl font-black text-white tracking-tighter">{Math.round(scanProgress)}%</p>
                    </div>
                  </div>
                  <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800 shadow-inner">
                    <div className="h-full bg-gradient-to-r from-blue-600 via-indigo-500 to-blue-600 transition-all duration-300 shadow-[0_0_20px_rgba(59,130,246,0.5)]" style={{ width: `${scanProgress}%` }} />
                  </div>
                  
                  {foundItems.length > 0 && (
                    <div className="mt-10 animate-in fade-in slide-in-from-top-6 duration-700">
                       <div className="flex items-center gap-3 mb-4">
                          <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                          <p className="text-[10px] font-black text-rose-500 uppercase tracking-[0.3em]">Potential Anomalies Identified ({foundItems.length})</p>
                       </div>
                       <div className="space-y-3">
                          {foundItems.map((item, i) => (
                            <div key={i} className="flex items-center justify-between bg-rose-500/5 border border-rose-500/20 p-4 rounded-2xl group hover:bg-rose-500/10 transition-all">
                               <div className="flex items-center gap-4">
                                  <div className="w-8 h-8 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-500">
                                     <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                                  </div>
                                  <div>
                                     <p className="text-xs font-black text-white">{item.name}</p>
                                     <p className="text-[9px] font-mono text-slate-500 mt-0.5">{item.path}</p>
                                  </div>
                               </div>
                               <button className="px-3 py-1.5 bg-rose-600/10 border border-rose-600/20 rounded-lg text-[9px] font-black text-rose-500 uppercase tracking-widest hover:bg-rose-600 hover:text-white transition-all">Isolate</button>
                            </div>
                          ))}
                       </div>
                    </div>
                  )}
               </div>
             ) : (
               <div className="grid grid-cols-1 gap-4">
                  {foundItems.length > 0 ? (
                    <div className="space-y-6">
                       <div className="p-6 bg-rose-500/5 border border-rose-500/20 rounded-[32px] flex items-center justify-between gap-6">
                          <div>
                             <h4 className="text-sm font-black text-rose-500 uppercase tracking-widest mb-1">Threats Detected</h4>
                             <p className="text-xs font-medium text-slate-400">The scan identified {foundItems.length} potential threats. Immediate action is recommended.</p>
                          </div>
                          <button className="px-8 py-3 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all shadow-xl shadow-rose-950/40 whitespace-nowrap">Quarantine Assets</button>
                       </div>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {foundItems.map((item, i) => (
                          <div key={i} className="flex flex-col gap-3 bg-slate-950/60 border border-slate-800 p-6 rounded-[32px] group hover:border-rose-500/30 transition-all cursor-pointer">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-xl bg-rose-500/10 flex items-center justify-center text-rose-500 group-hover:scale-110 transition-transform">
                                 <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                              </div>
                              <span className="text-sm font-black text-white">{item.name}</span>
                            </div>
                            <p className="text-[10px] font-mono text-slate-500 truncate bg-black/40 p-2 rounded-lg border border-slate-800">{item.path}</p>
                          </div>
                        ))}
                       </div>
                    </div>
                  ) : (
                    <div className="py-24 flex flex-col items-center justify-center text-center">
                      <div className="w-24 h-24 bg-slate-950 rounded-[32px] border border-slate-800 flex items-center justify-center mb-8 text-slate-700 shadow-2xl">
                        <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
                      </div>
                      <h4 className="text-2xl font-black text-white italic">System Status: Shielded</h4>
                      <p className="text-sm font-medium text-slate-500 mt-3 max-w-xs">No active threats discovered. Initialize a deep scan to verify kernel-level integrity.</p>
                    </div>
                  )}
               </div>
             )}
          </div>

          {/* Adaptive Heuristic Interrogator */}
          <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-[40px] p-10 shadow-3xl overflow-hidden relative group">
             <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-110 transition-transform duration-700">
                <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71L12 2z"/></svg>
             </div>
             <h3 className="font-black text-xl flex items-center gap-3 mb-8 relative z-10">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0012 18.75c-1.03 0-1.9-.4-2.593-1.003l-.547-.547z" /></svg>
                </div>
                Behavioral Pattern Interrogator
             </h3>
             <p className="text-xs text-slate-500 mb-8 leading-relaxed max-w-2xl relative z-10 font-medium italic">Describe suspicious system activity, weird process names, or paste event logs. The AI will sandbox the behavior to provide a neural verdict.</p>
             
             <div className="space-y-4 relative z-10">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                   <div className="md:col-span-1">
                      <label className="text-[10px] font-black text-slate-600 uppercase tracking-widest block mb-2">Subject Source</label>
                      <input 
                        className="w-full bg-slate-950/80 border border-slate-800 rounded-2xl px-5 py-4 text-sm text-white focus:border-indigo-500 outline-none transition-all placeholder:text-slate-800"
                        placeholder="e.g. svchost.exe"
                        value={suspiciousFile}
                        onChange={e => setSuspiciousFile(e.target.value)}
                      />
                   </div>
                   <div className="md:col-span-2">
                      <label className="text-[10px] font-black text-slate-600 uppercase tracking-widest block mb-2">Observed Behavioral Logic</label>
                      <textarea 
                        className="w-full bg-slate-950/80 border border-slate-800 rounded-2xl px-5 py-4 text-sm text-white focus:border-indigo-500 outline-none transition-all placeholder:text-slate-800 min-h-[56px] resize-none"
                        placeholder="e.g. Frequent unencrypted port 443 calls during idle..."
                        value={observedBehavior}
                        onChange={e => setObservedBehavior(e.target.value)}
                      />
                   </div>
                </div>
                
                <button 
                  onClick={handleAnalyzeBehavior}
                  disabled={isAnalyzing || (!observedBehavior && !suspiciousFile)}
                  className="w-full py-5 bg-indigo-600 rounded-2xl font-black text-[10px] uppercase tracking-[0.3em] hover:bg-indigo-500 transition-all disabled:opacity-30 shadow-2xl shadow-indigo-900/40 active:scale-95 text-white"
                >
                  {isAnalyzing ? 'Initializing AI Sandbox...' : 'Synthesize Behavioral Verdict'}
                </button>
             </div>

             {isAnalyzing && (
               <div className="mt-8 p-6 bg-slate-950 border border-indigo-500/20 rounded-3xl animate-in zoom-in-95 duration-500">
                  <div className="flex items-center gap-3 mb-4">
                     <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping" />
                     <p className="text-[10px] font-black uppercase text-indigo-400 tracking-widest">Interrogator Log Stream</p>
                  </div>
                  <div className="space-y-1.5 font-mono text-[10px] text-slate-500">
                     {analysisLogs.map((log, i) => (
                       <div key={i} className="animate-in slide-in-from-left-2 flex gap-3">
                          <span className="text-slate-800">[{i}]</span>
                          <span>{log}</span>
                       </div>
                     ))}
                     <div className="w-1 h-3 bg-indigo-500 animate-pulse inline-block" />
                  </div>
               </div>
             )}

             {analysisResult && !isAnalyzing && (
               <div className="mt-8 bg-slate-950 rounded-[32px] border border-indigo-500/30 overflow-hidden animate-in fade-in slide-in-from-top-4 duration-700 shadow-3xl">
                  <header className="px-8 py-4 bg-indigo-500/10 border-b border-indigo-500/20 flex justify-between items-center">
                    <span className="text-[10px] font-black uppercase text-indigo-400 tracking-[0.3em]">AI Sandbox Verdict</span>
                    <div className="flex gap-1.5">
                       <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                       <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                       <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                    </div>
                  </header>
                  <div className="p-8">
                     <p className="text-sm text-slate-300 leading-relaxed font-medium whitespace-pre-wrap">{analysisResult}</p>
                     <div className="mt-8 flex justify-end gap-3">
                        <button onClick={() => setAnalysisResult(null)} className="px-6 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest text-slate-500 hover:text-white transition-colors">Dismiss</button>
                        <button className="px-6 py-2 bg-indigo-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg shadow-indigo-900/40">Apply Mitigation</button>
                     </div>
                  </div>
               </div>
             )}
          </div>
        </div>

        {/* Intelligence Sidebar */}
        <div className="lg:col-span-5 space-y-8">
           <div className="bg-slate-900/40 backdrop-blur-xl border border-slate-800 rounded-[40px] p-10 shadow-3xl group overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
              <h4 className="font-black text-xl mb-8 text-white flex items-center gap-3">
                 <svg className="w-6 h-6 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                 Heuristic Vitality
              </h4>
              <div className="space-y-5 relative z-10">
                 <InsightItem label="Cloud Reputation" value="TRUSTED" color="emerald" />
                 <InsightItem label="Zero-Day Shield" value="ACTIVE" color="blue" />
                 <InsightItem label="Kernel Interceptor" value="MONITORING" color="blue" />
                 <InsightItem label="Code Signing Logic" value="HARDENED" color="emerald" />
                 <InsightItem label="Process Isolation" value="ISOLATED" color="emerald" />
                 <InsightItem label="Neural Response" value="SYNCHRONIZED" color="indigo" />
              </div>
           </div>

           <div className="bg-slate-900/40 border border-slate-800 rounded-[40px] p-10 shadow-2xl">
              <h4 className="font-black text-xl mb-6 flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-500 border border-emerald-500/20">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 00-2 2z" /></svg>
                </div>
                Hardware Guard
              </h4>
              <div className="bg-slate-950/80 p-6 rounded-3xl border border-slate-800 mb-8 flex items-center gap-6 group hover:border-emerald-500/30 transition-all">
                 <div className="w-14 h-14 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500 border border-emerald-500/20 group-hover:scale-110 transition-transform">
                    <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 00-2 2z" /></svg>
                 </div>
                 <div>
                    <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">Status</p>
                    <p className="text-base font-black text-emerald-400 tracking-tighter italic">CRYPTO-HARDENED</p>
                 </div>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed font-medium italic">"NovaCore intercepts kernel-level requests to hardware peripherals. Unauthorized attempts to activate imaging or audio devices are neutralized before the call executes."</p>
           </div>

           <div className="p-10 bg-indigo-600/5 border border-indigo-500/20 rounded-[40px] shadow-3xl">
              <div className="flex gap-6 items-start">
                 <div className="text-indigo-500 shrink-0 w-10 h-10 bg-indigo-500/10 rounded-xl flex items-center justify-center border border-indigo-500/20">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                 </div>
                 <div>
                    <p className="text-xs font-black text-indigo-400 mb-2 uppercase tracking-widest">Heuristic Code Logic</p>
                    <p className="text-[11px] text-slate-500 leading-relaxed font-medium">Deep behavioral scans utilize the Gemini 3 Flash model to analyze instruction sets without the overhead of massive virus signature databases. This is specifically optimized for older PC architectures with limited CPU cycles.</p>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

const InsightItem: React.FC<{ label: string, value: string, color: string }> = ({ label, value, color }) => (
  <div className="flex justify-between items-center bg-slate-950/40 p-4 rounded-2xl border border-slate-800/50 hover:border-slate-700 transition-all group">
     <span className="text-xs text-slate-400 font-bold group-hover:text-slate-200 transition-colors">{label}</span>
     <span className={`text-[9px] font-black px-3 py-1.5 rounded-xl bg-${color}-500/10 text-${color}-400 border border-${color}-500/20 uppercase tracking-widest shadow-[0_0_15px_rgba(0,0,0,0.2)]`}>{value}</span>
  </div>
);
