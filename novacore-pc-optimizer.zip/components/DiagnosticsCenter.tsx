
import React, { useState, useEffect } from 'react';
import { vault } from '../services/memoryVault';
import { GoogleGenAI } from '@google/genai';

interface TestResult {
  id: string;
  name: string;
  status: 'pending' | 'success' | 'warning' | 'fail';
  message: string;
  category: 'AI' | 'Storage' | 'Hardware' | 'Permissions';
}

export const DiagnosticsCenter: React.FC = () => {
  const [tests, setTests] = useState<TestResult[]>([
    { id: 'api', name: 'Neural Bridge Protocol', status: 'pending', message: 'Checking API Key signature...', category: 'AI' },
    { id: 'db', name: 'Memory Vault Stability', status: 'pending', message: 'Probing IndexedDB connectivity...', category: 'Storage' },
    { id: 'vfs', name: 'Virtual FS Consistency', status: 'pending', message: 'Verifying file node integrity...', category: 'Storage' },
    { id: 'mic', name: 'Audio Ingestion Layer', status: 'pending', message: 'Checking microphone permissions...', category: 'Permissions' },
    { id: 'ua', name: 'Hardware Signature Map', status: 'pending', message: 'Validating High Entropy detection...', category: 'Hardware' },
    { id: 'gemini', name: 'Flash Logic Performance', status: 'pending', message: 'Benchmarking AI response latency...', category: 'AI' }
  ]);
  const [isTesting, setIsTesting] = useState(false);

  const updateTest = (id: string, updates: Partial<TestResult>) => {
    setTests(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  const runDiagnostics = async () => {
    setIsTesting(true);
    
    // 1. API Key Check
    updateTest('api', { message: 'Verifying environment encryption...' });
    await new Promise(r => setTimeout(r, 800));
    if (process.env.API_KEY) {
      updateTest('api', { status: 'success', message: 'API_KEY verified and active.' });
    } else {
      updateTest('api', { status: 'fail', message: 'CRITICAL: AI Key missing from environment.' });
    }

    // 2. Database Check
    updateTest('db', { message: 'Attempting transaction commit...' });
    try {
      await vault.init();
      const metrics = await vault.getMetrics();
      updateTest('db', { status: 'success', message: `MemoryVault active. Usage: ${(metrics.used / 1024).toFixed(2)}KB` });
    } catch (e) {
      updateTest('db', { status: 'fail', message: 'IndexedDB Access Denied or Browser Restricted.' });
    }

    // 3. VFS Consistency
    updateTest('vfs', { message: 'Scanning virtual clusters...' });
    const files = await vault.getAllFiles();
    const count = Object.keys(files).length;
    updateTest('vfs', { status: count > 0 ? 'success' : 'warning', message: `${count} nodes mapped in virtual root.` });

    // 4. Microphone Check
    updateTest('mic', { message: 'Requesting device handle...' });
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(t => t.stop());
      updateTest('mic', { status: 'success', message: 'Audio stream handle granted.' });
    } catch (e) {
      updateTest('mic', { status: 'fail', message: 'Microphone permission blocked or unavailable.' });
    }

    // 5. Hardware Signature
    updateTest('ua', { message: 'Ingesting entropy data...' });
    if ('userAgentData' in navigator) {
      updateTest('ua', { status: 'success', message: 'High Entropy Platform values accessible.' });
    } else {
      updateTest('ua', { status: 'warning', message: 'Legacy Browser: Using limited fallback detection.' });
    }

    // 6. Gemini Performance
    updateTest('gemini', { message: 'Synthesizing test request...' });
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const start = Date.now();
      await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: 'Ping',
      });
      const latency = Date.now() - start;
      updateTest('gemini', { status: 'success', message: `Cloud logic synchronized. Latency: ${latency}ms` });
    } catch (e) {
      updateTest('gemini', { status: 'fail', message: 'AI Cloud Relay timeout or restricted.' });
    }

    setIsTesting(false);
    // Fix: changed 'system' to 'info' as 'system' is not a valid log level
    await vault.addLog("Omni-Diagnostics completed.", "info");
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <header className="flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter uppercase italic">Omni-Diagnostics</h2>
          <p className="text-slate-500 mt-1 font-medium">Feature health interrogation and application troubleshooting.</p>
        </div>
        <button 
          onClick={runDiagnostics}
          disabled={isTesting}
          className="px-10 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-black text-xs uppercase tracking-[0.25em] shadow-2xl shadow-indigo-900/40 transition-all active:scale-95 disabled:opacity-50"
        >
          {isTesting ? 'Interrogating Systems...' : 'Initialize Omni-Test'}
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tests.map(test => (
          <div key={test.id} className="bg-slate-900/40 backdrop-blur-xl border border-slate-800 rounded-[32px] p-8 shadow-2xl relative overflow-hidden group">
            <div className={`absolute top-0 right-0 px-4 py-1.5 rounded-bl-2xl text-[8px] font-black uppercase tracking-widest ${
              test.category === 'AI' ? 'bg-blue-600/10 text-blue-400' :
              test.category === 'Storage' ? 'bg-indigo-600/10 text-indigo-400' :
              'bg-slate-800 text-slate-500'
            }`}>
              {test.category}
            </div>
            
            <div className="flex items-center gap-4 mb-6">
              <div className={`w-3 h-3 rounded-full ${
                test.status === 'success' ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]' :
                test.status === 'warning' ? 'bg-amber-500 animate-pulse' :
                test.status === 'fail' ? 'bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.5)]' :
                'bg-slate-800 animate-pulse'
              }`} />
              <h4 className="font-black text-white uppercase tracking-tighter text-sm italic">{test.name}</h4>
            </div>

            <p className="text-xs text-slate-400 font-medium leading-relaxed min-h-[40px] italic">"{test.message}"</p>
            
            <div className="mt-6 pt-6 border-t border-slate-800 flex justify-between items-center">
              <span className={`text-[9px] font-black uppercase tracking-[0.2em] ${
                test.status === 'success' ? 'text-emerald-500' :
                test.status === 'warning' ? 'text-amber-500' :
                test.status === 'fail' ? 'text-rose-500' :
                'text-slate-600'
              }`}>
                {test.status.toUpperCase()}
              </span>
              <div className="flex gap-1">
                 <div className="w-1 h-1 rounded-full bg-slate-800" />
                 <div className="w-1 h-1 rounded-full bg-slate-800" />
                 <div className={`w-1 h-1 rounded-full ${test.status === 'success' ? 'bg-emerald-500' : 'bg-slate-800'}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-slate-950 border border-slate-800 rounded-[40px] p-10 flex gap-8 items-start relative overflow-hidden group">
         <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-110 transition-transform">
            <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
         </div>
         <div className="w-14 h-14 bg-indigo-600/10 rounded-3xl flex items-center justify-center text-indigo-400 shrink-0 border border-indigo-500/20">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
         </div>
         <div>
            <h5 className="text-[10px] font-black uppercase text-indigo-500 mb-3 tracking-[0.2em]">Diagnostic Intelligence Protocol</h5>
            <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
               Omni-Diagnostics performs a comprehensive layer-by-layer verification of NovaCore. It ensures that the **Neural Bridge** is authenticated, the **MemoryVault** is non-volatile and accessible, and that hardware interrogation APIs are not being suppressed by host restrictions. Running these tests helps calibrate AI response models for your specific environment.
            </p>
         </div>
      </div>
    </div>
  );
};
