
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { SystemSpecs, OptimizationReport, ResearchResult, StorageMetric } from '../types';
import { getOptimizationReport, generateAuditIntelligence, researchAutomatedTweaks } from '../services/geminiService';
import { autodiscoverSpecs } from '../services/hardwareScanner';
import { vault } from '../services/memoryVault';

interface AnalysisToolProps {
  specs: SystemSpecs | null;
  report: OptimizationReport | null;
  onSpecsChange: (specs: SystemSpecs) => void;
  onReportGenerated: (report: OptimizationReport) => void;
}

const AUDIT_PHASES = [
  { id: 'L1', name: 'Silicon Layer Interrogation', icon: 'CPU' },
  { id: 'L2', name: 'Memory Topology Mapping', icon: 'RAM' },
  { id: 'L3', name: 'Graphics Pipeline Audit', icon: 'GPU' },
  { id: 'L4', name: 'Disk Page Integrity', icon: 'Disk' },
  { id: 'L5', name: 'Network Stack Verification', icon: 'Net' },
  { id: 'L6', name: 'Kernel & Architecture Sig', icon: 'Arch' }
];

export const AnalysisTool: React.FC<AnalysisToolProps> = ({ specs, report, onSpecsChange, onReportGenerated }) => {
  const [loading, setLoading] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [researching, setResearching] = useState(false);
  const [currentPhase, setCurrentPhase] = useState(0);
  const [auditLogs, setAuditLogs] = useState<string[]>([]);
  const [neuralInsights, setNeuralInsights] = useState<string[]>([]);
  const [storageMetrics, setStorageMetrics] = useState<StorageMetric | null>(null);
  const [implementing, setImplementing] = useState<string | null>(null);
  const [showCommandModal, setShowCommandModal] = useState<{title: string, cmd: string} | null>(null);
  
  const [formData, setFormData] = useState<SystemSpecs>(specs || {
    cpu: '',
    ram: '',
    os: '',
    storageType: 'SSD',
    storageSpace: '',
    gpu: '',
    architecture: '',
    display: '',
    network: '',
    battery: ''
  });

  useEffect(() => {
    vault.getMetrics().then(setStorageMetrics);
    const interval = setInterval(() => {
       vault.getMetrics().then(setStorageMetrics);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleAutodiscover = async () => {
    setScanning(true);
    setAuditLogs([]);
    setNeuralInsights([]);
    setCurrentPhase(0);
    
    const addLog = (msg: string) => setAuditLogs(prev => [...prev.slice(-10), `[${new Date().toLocaleTimeString()}] ${msg}`]);

    try {
      addLog("Initializing Silicon Interrogation...");
      await new Promise(r => setTimeout(r, 800));
      const specsPart = await autodiscoverSpecs();
      const insight1 = await generateAuditIntelligence("Silicon Layer", specsPart.cpu);
      setNeuralInsights(prev => [...prev, insight1]);
      setCurrentPhase(1);

      addLog("Mapping Memory Topology...");
      await new Promise(r => setTimeout(r, 1000));
      const insight2 = await generateAuditIntelligence("Memory Topology", specsPart.ram);
      setNeuralInsights(prev => [...prev, insight2]);
      setCurrentPhase(2);

      addLog("Probing Graphics Pipeline...");
      await new Promise(r => setTimeout(r, 1200));
      const insight3 = await generateAuditIntelligence("Graphics Pipeline", specsPart.gpu);
      setNeuralInsights(prev => [...prev, insight3]);
      setCurrentPhase(3);

      addLog("Verifying Disk Page Integrity...");
      await new Promise(r => setTimeout(r, 1000));
      setCurrentPhase(4);
      
      addLog("Interrogating Network Stack...");
      await new Promise(r => setTimeout(r, 1000));
      setCurrentPhase(5);

      addLog("Audit Complete. Finalizing Environmental Signature.");
      await new Promise(r => setTimeout(r, 800));
      setCurrentPhase(6);

      setFormData(prev => ({ ...prev, ...specsPart as any }));
      onSpecsChange({ ...formData, ...specsPart as any });
      
    } catch (error) {
      addLog("CRITICAL: Audit Interrupted by Host Constraint.");
    } finally {
      setTimeout(() => setScanning(false), 1500);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      onSpecsChange(formData);
      const result = await getOptimizationReport(formData);
      onReportGenerated(result);
    } catch (error) {
      console.error("Analysis failed:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeployRemedy = async (title: string, content: string) => {
    setImplementing(title);
    await new Promise(r => setTimeout(r, 1500));
    
    // Create virtual implementation in VFS
    const fileName = `C:/NovaCore/Deploy/${title.toLowerCase().replace(/\s+/g, '_')}.ps1`;
    await vault.saveFile(fileName, `# NovaCore Synthesized Fix\n# Title: ${title}\n# Context: ${specs?.cpu}\n\nExecute-Optimization -Target "${content}"`);
    // Fix: changed 'success' to 'info' as 'success' is not a valid log level in MemoryVault
    await vault.addLog(`Deployed active logic node: ${title}`, 'info');
    
    setImplementing(null);
    vault.getMetrics().then(setStorageMetrics);
  };

  const runDiscoverySearch = async () => {
    if (!specs) return;
    setResearching(true);
    try {
       const findings = await researchAutomatedTweaks(specs);
       if (report) {
         onReportGenerated({ ...report, researchFindings: findings });
       }
    } catch (err) {
       console.error("Research failed:", err);
    } finally {
       setResearching(false);
    }
  };

  const fragLevel = useMemo(() => {
    if (!storageMetrics) return 0;
    return Math.min(100, Math.floor((storageMetrics.vfsCount / 100) * 15 + (storageMetrics.used / 1024 / 1024)));
  }, [storageMetrics]);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 relative">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter uppercase italic">AI Optimization Engine</h2>
          <p className="text-slate-400 mt-1 font-medium italic">Deep hardware interrogation and active implementation roadmap.</p>
        </div>
        <div className="flex gap-4">
          <button 
            onClick={handleAutodiscover}
            disabled={scanning}
            className="flex items-center gap-3 px-8 py-3.5 bg-slate-800 hover:bg-slate-700 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] transition-all group active:scale-95 disabled:opacity-50 border border-slate-700"
          >
            {scanning ? 'Audit Active...' : 'Hardware Audit'}
          </button>
          <button 
            onClick={handleSubmit}
            disabled={loading || !formData.cpu}
            className="flex items-center gap-3 px-8 py-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-blue-600/40 transition-all group active:scale-95 disabled:opacity-50"
          >
            {loading ? 'Synthesizing...' : 'Generate Roadmap'}
          </button>
        </div>
      </header>

      {scanning && (
        <div className="fixed inset-0 z-[100] bg-slate-950/95 backdrop-blur-2xl flex items-center justify-center p-6 animate-in fade-in duration-500">
           <div className="w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-[40px] shadow-3xl overflow-hidden flex flex-col md:flex-row h-[80vh] relative">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-indigo-600 to-blue-500 animate-shimmer bg-[length:200%_auto]" />
              <div className="flex-1 p-12 flex flex-col border-r border-slate-800/50">
                 <div className="flex items-center gap-4 mb-10">
                    <div className="w-3 h-3 rounded-full bg-blue-500 animate-ping" />
                    <h3 className="text-2xl font-black text-white uppercase tracking-tighter italic">Neural Interrogation HUB</h3>
                 </div>
                 <div className="flex-1 space-y-12">
                    <div className="space-y-4">
                       <p className="text-[10px] font-black uppercase text-slate-500 tracking-[0.3em]">Interrogation Phase</p>
                       <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                          {AUDIT_PHASES.map((phase, i) => (
                             <div key={phase.id} className={`p-4 rounded-2xl border transition-all duration-700 ${i < currentPhase ? 'bg-emerald-500/10 border-emerald-500/30' : i === currentPhase ? 'bg-blue-600/10 border-blue-500/50 scale-105' : 'bg-slate-950/40 border-slate-800 opacity-20'}`}>
                                <p className="text-[9px] font-black text-slate-600 mb-1">{phase.id}</p>
                                <p className={`text-[10px] font-bold ${i === currentPhase ? 'text-blue-400' : i < currentPhase ? 'text-emerald-400' : 'text-slate-500'}`}>{phase.name}</p>
                             </div>
                          ))}
                       </div>
                    </div>
                    <div className="space-y-4">
                       <p className="text-[10px] font-black uppercase text-slate-500 tracking-[0.3em]">AI Observation Engine</p>
                       <div className="bg-black/40 rounded-3xl p-6 border border-slate-800 min-h-[140px] flex flex-col justify-center">
                          {neuralInsights.length > 0 ? (
                            <p className="text-sm text-blue-100 font-medium leading-relaxed italic animate-in slide-in-from-left-4">
                               "{neuralInsights[neuralInsights.length - 1]}"
                            </p>
                          ) : (
                            <p className="text-xs text-slate-700 italic">Waiting for telemetry ingestion...</p>
                          )}
                       </div>
                    </div>
                 </div>
              </div>
              <div className="w-full md:w-80 bg-slate-950 p-10 flex flex-col font-mono text-[10px] space-y-6">
                 <div className="flex-1 overflow-y-auto custom-scrollbar space-y-2">
                    {auditLogs.map((log, i) => (
                       <div key={i} className="text-slate-500 flex gap-3 animate-in slide-in-from-right-2">
                          <span className="text-blue-900 shrink-0">[{i}]</span>
                          <span>{log}</span>
                       </div>
                    ))}
                    <div className="w-1.5 h-3 bg-blue-500 animate-pulse inline-block" />
                 </div>
              </div>
           </div>
        </div>
      )}

      {implementing && (
        <div className="fixed inset-0 z-[110] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-6">
           <div className="bg-slate-900 border border-blue-500/30 p-10 rounded-[32px] shadow-3xl flex flex-col items-center gap-6 max-w-sm text-center">
              <div className="w-16 h-16 border-4 border-blue-500/10 border-t-blue-500 rounded-full animate-spin" />
              <div>
                <h4 className="text-lg font-black text-white uppercase italic">Neural Write Cycle</h4>
                <p className="text-xs text-slate-500 mt-2 italic">Committing logic node for "{implementing}" to MemoryVault...</p>
              </div>
           </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-4 space-y-6 h-fit sticky top-0">
          <div className="bg-slate-900/40 backdrop-blur-md border border-slate-800 rounded-3xl p-8 relative overflow-hidden shadow-2xl">
            <h3 className="font-bold text-xl mb-8 flex items-center gap-3 uppercase tracking-tighter italic text-white">
              Hardware Map
            </h3>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 gap-4">
                <InputField label="Processor" value={formData.cpu} onChange={v => setFormData({...formData, cpu: v})} icon="CPU" />
                <InputField label="Memory" value={formData.ram} onChange={v => setFormData({...formData, ram: v})} icon="RAM" />
                <InputField label="GPU" value={formData.gpu || ''} onChange={v => setFormData({...formData, gpu: v})} icon="GPU" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <InputField label="OS" value={formData.os} onChange={v => setFormData({...formData, os: v})} icon="OS" />
                 <InputField label="Capacity" value={formData.storageSpace} onChange={v => setFormData({...formData, storageSpace: v})} icon="Disk" />
              </div>
            </form>
          </div>

          <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-8 shadow-2xl overflow-hidden relative group">
             <div className="flex items-center justify-between mb-6">
                <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-400">Memory Vault Health</h4>
                <div className={`w-2 h-2 rounded-full ${fragLevel > 50 ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]'}`} />
             </div>
             <div className="space-y-6">
                <div className="flex justify-between items-end">
                   <div>
                      <p className="text-2xl font-black text-white italic">{fragLevel}%</p>
                      <p className="text-[9px] font-black uppercase text-slate-500 tracking-widest mt-1">Fragmentation</p>
                   </div>
                   <div className="text-right">
                      <p className="text-sm font-black text-slate-300 italic">{storageMetrics ? `${storageMetrics.vfsCount}` : '0'}</p>
                      <p className="text-[9px] font-black uppercase text-slate-500 tracking-widest mt-1">VFS Nodes</p>
                   </div>
                </div>
                <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                   <div className="h-full bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.4)] transition-all duration-1000" style={{ width: `${fragLevel}%` }} />
                </div>
             </div>
          </div>
        </div>

        <div className="lg:col-span-8 space-y-6">
          {report && (
            <div className="animate-in fade-in slide-in-from-right-8 duration-700 space-y-8">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-[40px] p-10 text-white shadow-2xl relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="font-black text-3xl mb-4 italic tracking-tighter uppercase">AI Optimization Roadmap</h3>
                  <p className="text-blue-50 text-sm opacity-90 leading-relaxed max-w-xl mb-6">{report.summary}</p>
                  <div className="flex items-end gap-3">
                    <span className="text-6xl font-black tracking-tighter">{report.expectedGain}</span>
                    <span className="text-xs font-bold uppercase tracking-[0.2em] mb-3 text-blue-200">Gain Potential</span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900/60 border border-slate-800 rounded-[40px] p-10 shadow-3xl overflow-hidden relative group">
                 <div className="flex items-center justify-between mb-8">
                    <div>
                       <h3 className="text-2xl font-black text-white italic tracking-tighter uppercase">Neural Discovery Hub</h3>
                       <p className="text-xs text-slate-500 mt-1 font-medium italic">Google Search grounding identified specific community optimizations.</p>
                    </div>
                    <button 
                      onClick={runDiscoverySearch}
                      disabled={researching}
                      className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-xl shadow-blue-900/40 disabled:opacity-50"
                    >
                      {researching ? 'Interrogating Web...' : 'Research Automated Tweaks'}
                    </button>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {report.researchFindings?.map((finding, i) => (
                       <div key={i} className="bg-slate-950/60 p-6 rounded-3xl border border-slate-800 hover:border-blue-500/30 transition-all flex flex-col group/card">
                          <div className="flex justify-between items-start mb-4">
                             <div className="flex flex-col">
                                <span className={`text-[9px] font-black uppercase tracking-widest mb-1 ${finding.type === 'Script' ? 'text-emerald-500' : 'text-amber-500'}`}>{finding.type}</span>
                                <h4 className="text-sm font-black text-white leading-snug">{finding.title}</h4>
                             </div>
                             <button 
                                onClick={() => setShowCommandModal({title: finding.title, cmd: finding.automationSummary})}
                                className="w-8 h-8 rounded-xl bg-slate-900 flex items-center justify-center text-blue-500 hover:bg-blue-600 hover:text-white transition-all"
                             >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                             </button>
                          </div>
                          <p className="text-xs text-slate-400 mb-6 flex-1 italic">"{finding.description}"</p>
                          <div className="space-y-4">
                             <div className="p-4 bg-black/40 rounded-2xl border border-slate-800">
                                <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2">Automation Signature</p>
                                <p className="text-[10px] text-slate-400 font-medium leading-relaxed truncate">{finding.automationSummary}</p>
                             </div>
                             <div className="flex items-center justify-between mt-4">
                                <a href={finding.url} target="_blank" rel="noreferrer" className="text-[10px] font-black text-blue-500 hover:text-white transition-colors flex items-center gap-2">
                                   SOURCE: {finding.source.toUpperCase()}
                                   <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                                </a>
                             </div>
                          </div>
                       </div>
                    ))}
                 </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-20">
                <ReportCard title="Critical Bottlenecks" items={report.bottlenecks} color="rose" hideAction />
                <ReportCard title="Software Remedies" items={report.softwareSteps} color="blue" onDeploy={handleDeployRemedy} />
                <ReportCard title="OS Performance Tweaks" items={report.osTweaks} color="cyan" onDeploy={handleDeployRemedy} />
                <ReportCard title="Hardware Upgrades" items={report.hardwareSuggestions} color="emerald" onDeploy={(t) => setShowCommandModal({title: t, cmd: "User Action Required: Purchase and install hardware component."})} deployLabel="Buy Guide" />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Command Handover Modal */}
      {showCommandModal && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-300">
           <div className="bg-slate-900 border border-slate-800 rounded-[40px] w-full max-w-xl shadow-3xl overflow-hidden relative">
              <header className="p-10 pb-4 flex justify-between items-start">
                 <div>
                    <p className="text-[10px] uppercase font-black text-blue-500 tracking-[0.3em] mb-2">Real-world Handover</p>
                    <h3 className="text-2xl font-black text-white italic">{showCommandModal.title}</h3>
                 </div>
                 <button onClick={() => setShowCommandModal(null)} className="p-3 bg-slate-800 hover:bg-slate-700 rounded-2xl text-slate-400 hover:text-white transition-all">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                 </button>
              </header>
              <div className="p-10 pt-0 space-y-6">
                 <p className="text-sm text-slate-400 font-medium italic leading-relaxed">Browser environments cannot modify OS-level registry keys directly. To implement this optimization, execute the following command in an Administrator PowerShell console:</p>
                 <div className="bg-black/60 p-6 rounded-3xl border border-slate-800 font-mono text-xs text-blue-400 relative group">
                    <div className="break-all">{showCommandModal.cmd}</div>
                    <button 
                       onClick={() => {
                          navigator.clipboard.writeText(showCommandModal.cmd);
                          alert("Command copied to silicon clipboard.");
                       }}
                       className="absolute right-4 top-4 p-2 bg-slate-800 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity text-white"
                    >
                       <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" /></svg>
                    </button>
                 </div>
              </div>
              <footer className="p-8 bg-slate-950 border-t border-slate-800 flex justify-end">
                 <button onClick={() => setShowCommandModal(null)} className="px-10 py-3 bg-blue-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-500 shadow-xl shadow-blue-950/40">Synchronized</button>
              </footer>
           </div>
        </div>
      )}
    </div>
  );
};

const InputField: React.FC<{ label: string; value: string; onChange: (v: string) => void; icon: string }> = ({ label, value, onChange, icon }) => (
  <div className="flex-1 min-w-0">
    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-2">{label}</label>
    <div className="relative">
      <input 
        required
        className="w-full bg-slate-950/50 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-100 focus:outline-none focus:border-blue-500 transition-all placeholder:text-slate-800"
        placeholder={`Enter ${label}...`}
        value={value}
        onChange={e => onChange(e.target.value)}
      />
      <div className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-black text-slate-700 tracking-tighter uppercase">{icon}</div>
    </div>
  </div>
);

const ReportCard: React.FC<{ title: string; items: string[]; color: string; onDeploy?: (title: string, content: string) => void; hideAction?: boolean; deployLabel?: string }> = ({ title, items, color, onDeploy, hideAction, deployLabel }) => (
  <div className="bg-slate-900/40 backdrop-blur-md border border-slate-800 rounded-[32px] p-8 shadow-xl hover:border-slate-700 transition-all flex flex-col group">
    <h4 className={`text-xs font-black uppercase tracking-[0.3em] mb-8 flex items-center gap-3 text-${color}-400`}>
      <div className={`w-2 h-2 rounded-full bg-${color}-500 shadow-[0_0_10px_rgba(var(--color-${color}-500),0.5)]`} />
      {title}
    </h4>
    <ul className="space-y-5 flex-1 mb-8">
      {items.map((item, i) => (
        <li key={i} className="flex gap-4 text-xs text-slate-300 leading-snug group/item items-start">
          <span className="text-slate-600 font-mono text-[9px] mt-0.5 shrink-0">0{i + 1}</span>
          <div className="flex-1">
             <span className="group-hover/item:text-white transition-colors">{item}</span>
             {!hideAction && onDeploy && (
               <button 
                  onClick={() => onDeploy(item, item)}
                  className={`mt-3 flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-${color}-500 hover:text-white transition-colors group/btn`}
               >
                  {deployLabel || 'Deploy Fix'}
                  <svg className="w-3 h-3 group-hover/btn:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
               </button>
             )}
          </div>
        </li>
      ))}
    </ul>
  </div>
);
