
import React from 'react';
import { DashboardTab } from '../types';

interface SidebarProps {
  activeTab: DashboardTab;
  onTabChange: (tab: DashboardTab) => void;
  lockdownMode: boolean;
  toggleLockdown: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onTabChange, lockdownMode, toggleLockdown }) => {
  const items = [
    { id: DashboardTab.COMMAND_CENTER, label: 'Command Hub', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { id: DashboardTab.AI_OPTIMIZER, label: 'AI Optimizer', icon: 'M13 10V3L4 14h7v7l9-11h-7z' },
    { id: DashboardTab.NEURAL_SECURITY, label: 'Security Fortress', icon: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z' },
    { id: DashboardTab.DEVOPS_KERNEL, label: 'DevOps Kernel', icon: 'M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4' },
    { id: DashboardTab.SYSTEM_UTILS, label: 'System Utils', icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z' },
  ];

  return (
    <nav className="w-72 bg-slate-950/90 backdrop-blur-3xl border-r border-slate-900 flex flex-col h-full shrink-0 z-50 shadow-2xl">
      <div className="p-10">
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 transition-all duration-700 rounded-2xl flex items-center justify-center shadow-2xl ${lockdownMode ? 'bg-rose-600 shadow-rose-500/40 animate-pulse' : 'bg-gradient-to-br from-blue-600 to-indigo-700 shadow-blue-500/30'}`}>
            <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <div>
            <h1 className="font-black text-xl tracking-tighter text-white italic uppercase leading-none">NovaCore</h1>
            <p className={`text-[9px] font-black tracking-[0.3em] uppercase mt-1 ${lockdownMode ? 'text-rose-500' : 'text-blue-500'}`}>
              {lockdownMode ? 'LOCKED' : 'ENTERPRISE'}
            </p>
          </div>
        </div>
      </div>

      <div className="flex-1 px-6 py-4 space-y-2 overflow-y-auto custom-scrollbar">
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all duration-300 group relative overflow-hidden ${
              activeTab === item.id 
                ? (lockdownMode ? 'bg-rose-600/10 text-rose-400 border border-rose-500/20' : 'bg-blue-600/10 text-blue-400 border border-blue-500/20 shadow-[0_0_25px_rgba(59,130,246,0.1)]') 
                : 'text-slate-500 hover:text-slate-200 hover:bg-slate-900/50'
            }`}
          >
            {activeTab === item.id && (
              <div className={`absolute left-0 top-0 bottom-0 w-1 rounded-r-full ${lockdownMode ? 'bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.8)]' : 'bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.8)]'}`} />
            )}
            <svg className={`w-5 h-5 transition-all duration-500 ${activeTab === item.id ? 'scale-110 drop-shadow-[0_0_8px_currentColor]' : 'group-hover:scale-110'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
            </svg>
            <span className="font-black text-[10px] uppercase tracking-[0.2em]">{item.label}</span>
          </button>
        ))}
      </div>

      <div className="p-8 border-t border-slate-900 bg-black/20 space-y-6">
        <button 
          onClick={toggleLockdown}
          className={`w-full py-4 rounded-2xl flex items-center justify-center gap-4 text-[10px] font-black uppercase tracking-[0.3em] transition-all border ${
            lockdownMode 
              ? 'bg-rose-600 text-white border-rose-500 shadow-2xl shadow-rose-950/60' 
              : 'bg-slate-900 text-slate-500 border-slate-800 hover:text-rose-500 hover:border-rose-500/40 shadow-inner'
          }`}
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
          {lockdownMode ? 'Exit Lockdown' : 'Lockdown'}
        </button>

        <div className="bg-slate-950/60 rounded-3xl p-5 border border-slate-900 shadow-inner group">
          <div className="flex items-center justify-between mb-4">
             <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest group-hover:text-slate-400 transition-colors">Neural Stream</span>
             <div className={`w-2 h-2 rounded-full ${lockdownMode ? 'bg-rose-500 animate-ping shadow-[0_0_10px_rgba(244,63,94,0.8)]' : 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.8)]'}`} />
          </div>
          <div className="space-y-2">
             <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                <div className={`h-full transition-all duration-1000 ${lockdownMode ? 'bg-rose-500 w-full animate-pulse' : 'bg-blue-600 w-3/4 shadow-[0_0_10px_rgba(59,130,246,0.6)]'}`} />
             </div>
             <p className="text-[8px] text-slate-700 font-mono font-black uppercase tracking-tighter">
                {lockdownMode ? 'SECURE_TUNNEL:OMEGA' : 'ENCRYPTED_DATA_PULSE:OK'}
             </p>
          </div>
        </div>
      </div>
    </nav>
  );
};
