
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { chatWithAssistant, connectLiveAssistant } from '../services/geminiService';
import { SystemSpecs, ChatMessage, OptimizationReport } from '../types';
import { LiveServerMessage } from '@google/genai';

interface AIChatProps {
  specs: SystemSpecs | null;
  report: OptimizationReport | null;
}

type LoginStep = 'idle' | 'input' | 'authenticating' | 'syncing' | 'success';

// Manual base64 decoding for raw bytes.
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Manual base64 encoding for raw bytes.
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

// Helper to decode PCM bytes into AudioBuffer.
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const AIChat: React.FC<AIChatProps> = ({ specs, report }) => {
  const [activeSubTab, setActiveSubTab] = useState<'chat' | 'convergence'>('chat');
  const [isLiveMode, setIsLiveMode] = useState(false);
  
  // Chat State
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Live Audio Refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef(new Set<AudioBufferSourceNode>());
  const sessionRef = useRef<any>(null);

  // Convergence Hub State
  const [isLoggedIntoGemini, setIsLoggedIntoGemini] = useState(() => localStorage.getItem('nova_gemini_login') === 'true');
  const [isLoggedIntoCopilot, setIsLoggedIntoCopilot] = useState(() => localStorage.getItem('nova_copilot_login') === 'true');
  const [portalTarget, setPortalTarget] = useState<'gemini' | 'copilot' | null>(null);
  const [loginStep, setLoginStep] = useState<LoginStep>('idle');
  const [portalEmail, setPortalEmail] = useState('');

  useEffect(() => {
    localStorage.setItem('nova_gemini_login', String(isLoggedIntoGemini));
    localStorage.setItem('nova_copilot_login', String(isLoggedIntoCopilot));
  }, [isLoggedIntoGemini, isLoggedIntoCopilot]);

  useEffect(() => {
    if (scrollRef.current && activeSubTab === 'chat') {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, activeSubTab]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping) return;

    const userMsg: ChatMessage = { role: 'user', content: input, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    const currentInput = input;
    setInput('');
    setIsTyping(true);

    try {
      const history = messages.map(m => ({ role: m.role, content: m.content }));
      
      const perfKeywords = ['speed', 'slow', 'lag', 'boost', 'optimization', 'fps', 'ram', 'cpu', 'perform'];
      const secKeywords = ['security', 'virus', 'threat', 'malware', 'hack', 'privacy', 'safe'];
      const isRelated = [...perfKeywords, ...secKeywords].some(kw => currentInput.toLowerCase().includes(kw));

      let context = '';
      if (isRelated) {
        const sysContext = specs ? `System: CPU: ${specs.cpu}, RAM: ${specs.ram}, OS: ${specs.os}. ` : '';
        const reportContext = report ? `\n[SYSTEM_DIAGNOSTICS_ACTIVE]\nSummary: ${report.summary}\nBottlenecks: ${report.bottlenecks.join(', ')}\nRisk Level: ${report.securityAudit.riskLevel}\n[/SYSTEM_DIAGNOSTICS_ACTIVE]` : '';
        context = `[ENVIRONMENTAL_CONTEXT]\n${sysContext}${reportContext}\n\n`;
      }

      const response = await chatWithAssistant(history, context + currentInput);
      const assistantMsg: ChatMessage = { role: 'assistant', content: response, timestamp: Date.now() };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (error) {
      console.error("Chat error:", error);
    } finally {
      setIsTyping(false);
    }
  };

  const toggleLiveMode = async () => {
    if (isLiveMode) {
      if (sessionRef.current) sessionRef.current.close();
      for (const src of sourcesRef.current) {
        try { src.stop(); } catch(e) {}
      }
      sourcesRef.current.clear();
      setIsLiveMode(false);
      return;
    }

    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      
      if (audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      }
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      
      const sessionPromise = connectLiveAssistant({
        onopen: () => {
          setIsLiveMode(true);
          const source = inputCtx.createMediaStreamSource(stream);
          const processor = inputCtx.createScriptProcessor(4096, 1, 1);
          processor.onaudioprocess = (e: AudioProcessingEvent) => {
            if (!isLiveMode) return;
            const inputData = e.inputBuffer.getChannelData(0);
            const int16 = new Int16Array(inputData.length);
            for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
            const base64Data = encode(new Uint8Array(int16.buffer));
            sessionPromise.then(s => s.sendRealtimeInput({ media: { data: base64Data, mimeType: 'audio/pcm;rate=16000' } }));
          };
          source.connect(processor);
          processor.connect(inputCtx.destination);
        },
        onmessage: async (message: LiveServerMessage) => {
          // Handle Model Turn
          const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
          if (audioData && audioContextRef.current) {
            const ctx = audioContextRef.current;
            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
            const buffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
            const source = ctx.createBufferSource();
            source.buffer = buffer;
            source.connect(ctx.destination);
            source.start(nextStartTimeRef.current);
            nextStartTimeRef.current += buffer.duration;
            sourcesRef.current.add(source);
            source.onended = () => sourcesRef.current.delete(source);
          }

          // Handle Interruption
          if (message.serverContent?.interrupted) {
            for (const src of sourcesRef.current) {
              try { src.stop(); } catch(e) {}
            }
            sourcesRef.current.clear();
            nextStartTimeRef.current = 0;
          }
        },
        onclose: () => setIsLiveMode(false),
        onerror: () => setIsLiveMode(false)
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error("Failed to start Live API:", err);
    }
  };

  const startLoginFlow = (platform: 'gemini' | 'copilot') => {
    setPortalTarget(platform);
    setLoginStep('input');
    setPortalEmail('');
  };

  const executeLogin = async () => {
    setLoginStep('authenticating');
    await new Promise(r => setTimeout(r, 1500));
    setLoginStep('syncing');
    await new Promise(r => setTimeout(r, 1500));
    setLoginStep('success');
    await new Promise(r => setTimeout(r, 1000));
    
    if (portalTarget === 'gemini') setIsLoggedIntoGemini(true);
    else setIsLoggedIntoCopilot(true);
    
    setPortalTarget(null);
    setLoginStep('idle');
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] animate-in fade-in slide-in-from-bottom-4 duration-500 relative">
      {/* Portals & Overlays */}
      {portalTarget && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/90 backdrop-blur-2xl animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-[40px] p-10 shadow-3xl text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-600 to-indigo-600" />
            {loginStep === 'input' && (
              <div className="space-y-8">
                <div className={`w-20 h-20 mx-auto rounded-3xl flex items-center justify-center text-3xl font-black text-white ${portalTarget === 'gemini' ? 'bg-gradient-to-br from-blue-600 to-blue-800' : 'bg-gradient-to-br from-indigo-600 to-indigo-800'}`}>
                   {portalTarget === 'gemini' ? 'G' : 'M'}
                </div>
                <div>
                  <h3 className="text-3xl font-black">Link {portalTarget === 'gemini' ? 'Google' : 'Microsoft'}</h3>
                  <p className="text-slate-500 text-sm mt-2">Enterprise-level environment sync required.</p>
                </div>
                <input 
                  className="w-full bg-slate-950 border border-slate-700 rounded-2xl p-5 text-white focus:border-blue-500 outline-none transition-all placeholder:text-slate-800"
                  placeholder="Enterprise Credential (Email)"
                  value={portalEmail}
                  onChange={e => setPortalEmail(e.target.value)}
                />
                <div className="flex justify-end gap-4">
                  <button onClick={() => setPortalTarget(null)} className="px-6 py-3 text-slate-500 font-black uppercase text-xs tracking-widest hover:text-white transition-colors">Abort</button>
                  <button onClick={executeLogin} className="px-10 py-3 bg-blue-600 hover:bg-blue-500 rounded-2xl font-black uppercase text-xs tracking-[0.2em] shadow-xl shadow-blue-600/30 transition-all">Authorize</button>
                </div>
              </div>
            )}
            {loginStep !== 'input' && loginStep !== 'idle' && (
               <div className="py-20 flex flex-col items-center gap-10">
                  <div className="w-24 h-24 relative">
                    <div className="absolute inset-0 border-4 border-blue-500/10 rounded-full" />
                    <div className="absolute inset-0 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-xl font-black text-white">{loginStep === 'authenticating' ? 'Verifying Identity' : loginStep === 'syncing' ? 'Ingesting Telemetry' : 'Convergence Verified'}</h4>
                    <p className="text-slate-500 text-sm max-w-xs mx-auto">NovaCore is establishing an encrypted bridge with your {portalTarget} cloud profile.</p>
                  </div>
               </div>
            )}
          </div>
        </div>
      )}

      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-black text-white tracking-tighter flex items-center gap-4">
            Nova AI Suite
            {isLiveMode && (
              <div className="flex items-center gap-2 bg-rose-600/10 border border-rose-600/20 px-3 py-1 rounded-full">
                <div className="w-1.5 h-1.5 bg-rose-600 rounded-full animate-ping" />
                <span className="text-rose-600 text-[9px] font-black uppercase tracking-widest">Live Voice Active</span>
              </div>
            )}
          </h2>
          <p className="text-slate-400 mt-1 font-medium">Hyper-personalized system intelligence suite.</p>
        </div>
        <div className="flex bg-slate-900/60 p-1 rounded-2xl border border-slate-800">
          <button onClick={() => setActiveSubTab('chat')} className={`px-8 py-2.5 rounded-xl text-xs font-black uppercase tracking-[0.15em] transition-all ${activeSubTab === 'chat' ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/20' : 'text-slate-500 hover:text-slate-300'}`}>Nova Assistant</button>
          <button onClick={() => setActiveSubTab('convergence')} className={`px-8 py-2.5 rounded-xl text-xs font-black uppercase tracking-[0.15em] transition-all ${activeSubTab === 'convergence' ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/20' : 'text-slate-500 hover:text-slate-300'}`}>LLM Convergence</button>
        </div>
      </header>

      {activeSubTab === 'chat' ? (
        <div className="flex-1 bg-slate-900/40 backdrop-blur-md border border-slate-800 rounded-[32px] flex flex-col overflow-hidden shadow-3xl">
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-10 space-y-8 custom-scrollbar">
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-center opacity-40 py-20 animate-pulse">
                <div className="w-24 h-24 bg-blue-600/10 rounded-[32px] flex items-center justify-center text-blue-500 mb-8 border border-blue-500/10">
                  <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
                </div>
                <h3 className="text-2xl font-black">NovaCore AI Systems Online</h3>
                <p className="max-w-xs text-sm mt-3 font-medium leading-relaxed text-slate-400">Environment telemetry ingested. Ready for maintenance commands or voice interrogation.</p>
                <div className="flex flex-wrap justify-center gap-3 mt-10">
                   {['Optimize kernel cache', 'Locate bloatware', 'Secure system integrity'].map(q => (
                     <button key={q} onClick={() => setInput(q)} className="px-5 py-2.5 bg-slate-800/50 border border-slate-700 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-500 hover:text-white hover:border-blue-500/40 transition-all">{q}</button>
                   ))}
                </div>
              </div>
            )}
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-3 duration-500`}>
                <div className={`max-w-[75%] px-7 py-5 rounded-[28px] shadow-2xl ${msg.role === 'user' ? 'bg-blue-600 text-white rounded-tr-none shadow-blue-600/10 border border-blue-500/50' : 'bg-slate-800 text-slate-100 rounded-tl-none border border-slate-700 backdrop-blur-md'}`}>
                  <p className="text-sm font-medium leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex items-center gap-2 text-blue-400 font-black text-[9px] uppercase tracking-[0.3em] animate-pulse">
                <div className="w-1 h-1 bg-blue-500 rounded-full" />
                Nova AI Thinking...
              </div>
            )}
          </div>
          <form onSubmit={handleSend} className="p-8 border-t border-slate-800 bg-slate-950/40 flex items-center gap-5">
             <button 
                type="button" 
                onClick={toggleLiveMode} 
                className={`p-5 rounded-2xl transition-all shadow-xl group ${isLiveMode ? 'bg-rose-600 animate-pulse text-white shadow-rose-600/20' : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'}`}
                title="Voice Assistant Mode"
              >
                <svg className={`w-6 h-6 ${isLiveMode ? 'scale-110' : 'group-hover:scale-110'} transition-transform`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
             </button>
             <input 
                className="flex-1 bg-slate-900 border border-slate-800 rounded-2xl px-8 py-5 text-sm text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all placeholder:text-slate-700" 
                placeholder="Analyze system state or give command..." 
                value={input} 
                onChange={e => setInput(e.target.value)} 
              />
             <button 
                type="submit" 
                disabled={!input.trim() || isTyping} 
                className="p-5 bg-blue-600 text-white rounded-2xl hover:bg-blue-500 disabled:opacity-50 shadow-2xl shadow-blue-600/30 transition-all active:scale-90"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
             </button>
          </form>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 overflow-y-auto pb-20 custom-scrollbar pr-2">
           <ConvergenceCard 
             name="Google Gemini" 
             isLoggedIn={isLoggedIntoGemini} 
             onLogin={() => isLoggedIntoGemini ? setIsLoggedIntoGemini(false) : startLoginFlow('gemini')}
             color="blue"
             description="Enterprise context bridge for Gemini 1.5 Pro. Ingests local hardware profile for pinpoint diagnostic precision."
           />
           <ConvergenceCard 
             name="Microsoft Copilot" 
             isLoggedIn={isLoggedIntoCopilot} 
             onLogin={() => isLoggedIntoCopilot ? setIsLoggedIntoCopilot(false) : startLoginFlow('copilot')}
             color="indigo"
             description="Windows kernel aware bridge for Microsoft Copilot. Synchronizes local optimization roadmap with cloud intelligence."
           />
           <div className="lg:col-span-2 bg-slate-900/40 p-10 rounded-[40px] border border-slate-800 relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-10 opacity-5">
                 <svg className="w-48 h-48" fill="currentColor" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              </div>
              <h3 className="font-black text-xl mb-8 flex items-center gap-4 relative z-10">
                 <div className="w-3 h-3 rounded-full bg-blue-500 animate-pulse" />
                 Environmental Telemetry Matrix
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 relative z-10">
                 <SyncPill label="Processor ID" active={!!specs} />
                 <SyncPill label="VRAM Topology" active={!!specs} />
                 <SyncPill label="Hardening Log" active={!!report} />
                 <SyncPill label="Kernel Hooks" active={true} />
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

const ConvergenceCard = ({ name, isLoggedIn, onLogin, color, description }: any) => (
  <div className="bg-slate-900/40 border border-slate-800 rounded-[40px] p-10 hover:border-blue-500/30 transition-all flex flex-col h-full group relative overflow-hidden shadow-2xl">
    <div className={`absolute inset-0 bg-gradient-to-br ${color === 'blue' ? 'from-blue-600' : 'from-indigo-600'} to-transparent opacity-0 group-hover:opacity-5 transition-opacity duration-700`} />
    <div className="flex justify-between items-start mb-10 relative z-10">
      <div className={`w-16 h-16 rounded-3xl bg-gradient-to-br ${color === 'blue' ? 'from-blue-600 to-blue-800' : 'from-indigo-600 to-indigo-800'} flex items-center justify-center font-black text-2xl text-white shadow-xl`}>{name[0]}</div>
      <button 
        onClick={onLogin} 
        className={`px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all ${isLoggedIn ? 'bg-slate-800 text-slate-500 hover:text-rose-500 border border-slate-700' : 'bg-white text-black hover:scale-105 shadow-xl shadow-white/10'}`}
      >
        {isLoggedIn ? 'Terminate Sync' : 'Initialize Portal'}
      </button>
    </div>
    <h3 className="text-2xl font-black mb-3 relative z-10">{name}</h3>
    <p className="text-slate-500 text-sm mb-10 flex-1 leading-relaxed relative z-10 font-medium">{description}</p>
    <div className="flex items-center gap-3 text-[10px] font-black uppercase text-slate-600 tracking-[0.25em] relative z-10">
       <div className={`w-2.5 h-2.5 rounded-full ${isLoggedIn ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)] animate-pulse' : 'bg-slate-800 border border-slate-700'}`} />
       {isLoggedIn ? 'Convergence Ready' : 'Portal Offline'}
    </div>
  </div>
);

const SyncPill = ({ label, active }: any) => (
  <div className={`p-6 rounded-3xl border transition-all duration-700 ${active ? 'bg-blue-500/5 border-blue-500/20 shadow-xl' : 'bg-slate-950 border-slate-800 opacity-30 scale-95'}`}>
     <p className="text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">{label}</p>
     <div className="flex items-center justify-between">
        <p className={`text-sm font-black ${active ? 'text-blue-400' : 'text-slate-700'}`}>{active ? 'Verified' : 'Unmapped'}</p>
        {active && <div className="w-1.5 h-1.5 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.6)]" />}
     </div>
  </div>
);
