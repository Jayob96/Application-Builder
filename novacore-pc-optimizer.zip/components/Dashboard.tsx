
import React, { useMemo, useState, useEffect, useRef } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { SystemSpecs, OptimizationReport, TuningManifest } from '../types';
import { getLiveTelemetry, LiveTelemetry } from '../services/hardwareScanner';
import { neuralLoop } from '../services/learningService';
import { nativeBridge } from '../services/adapters/nativeBridge';

interface DashboardProps {
  specs: SystemSpecs | null;
  report: OptimizationReport | null;
  onAnalyze: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ specs, report, onAnalyze }) => {
  const [profile, setProfile] = useState<'Eco' | 'Balanced' | 'Turbo'>('Balanced');
  const [telemetry, setTelemetry] = useState<LiveTelemetry>(getLiveTelemetry('Balanced'));
  const [history, setHistory] = useState<{ time: number, displayTime: string, cpu: number, ram: number, net: number }[]>([]);
  const [systemLogs, setSystemLogs] = useState<{ id: number, msg: string, type: 'info' | 'warn' | 'crit' | 'ai' | 'telemetry' }[]>([]);
  const [activeTuning, setActiveTuning] = useState<TuningManifest | null>(null);
  const [osInfo, setOsInfo] = useState<any>(null);
  
  const logContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    nativeBridge.getOSInfo().then(setOsInfo);
    
    // Subscribe to AI Tuning events
    neuralLoop.subscribe((manifest) => {
      setActiveTuning(manifest);
      setSystemLogs(prev => [...prev.slice(-25), { 
        id: Date.now(), 
        msg: `AI TUNING: ${manifest.tuningType} OPTIMIZATION COMMITTED`, 
        type: 'ai' 
      }]);
      
      nativeBridge.notify("Neural Loop Optimization", `System recalibrated for ${manifest.tuningType}`);
    });

    const timer = setInterval(() => {
      const data = getLiveTelemetry(profile);
      const now = new Date();
      setTelemetry(data);

      const snapshot = {
        time: now.getTime(),
        displayTime: `${now.getSeconds()}s`,
        cpu: data.cpuUsage,
        ram: (data.ramUsed / data.ramTotal) * 100,
        net: Math.min(100, (data.networkDown / 200) * 100)
      };

      setHistory(prev => [...prev, snapshot].slice(-20));

      // Feed Neural Loop
      neuralLoop.ingest({
        timestamp: snapshot.time,
        cpu: snapshot.cpu,
        ram: snapshot.ram,
        temp: data.thermalIndex,
        efficiency: 100 - (snapshot.cpu * 0.5 + (100 - snapshot.ram) * 0.2)
      }, specs);

      if (Math.random() > 0.95) {
        const msgs = [
          { msg: "Native Kernel buffer scrubbed", type: 'info' },
          { msg: "IO scheduling optimized for host environment", type: 'info' },
          { msg: "Silicon bus handshake verified: NATIVE_LINK_OK", type: 'info' }
        ] as const;
        const selected = msgs[Math.floor(Math.random() * msgs.length)];
        setSystemLogs(prev => [...prev.slice(-25), { id: Date.now(), ...selected }]);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [profile, specs]);

  useEffect(() => {
    if (logContainerRef.current) logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
  }, [systemLogs]);

  const efficiencyTrend = neuralLoop.getEfficiencyTrend();

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
             <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse shadow-[0_0_12px_rgba(59,130,246,0.8)]" />
             <span className="text-[10px] font-black uppercase text-blue-500 tracking-[0.4em] mb-0.5">Desktop Node: {osInfo?.platform || 'Detecting...'}</span>
          </div>
          <h2 className="text-6xl font-black text-white tracking-tighter uppercase italic leading-none">
            Command Hub
          </h2>
          <p className="text-slate-500 font-medium italic text-sm">
            Silicon Status: <span className="text-slate-300">{specs?.cpu || 'Detecting...'}</span> | Efficiency: <span className={efficiencyTrend >= 0 ? 'text-emerald-400' : 'text-rose-400'}>{efficiencyTrend >= 0 ? '+' : ''}{efficiencyTrend.toFixed(1)}%</span>
          </p>
        </div>
        <div className="flex bg-slate-900/40 p-1.5 rounded-2xl border border-slate-800 backdrop-blur-3xl shadow-2xl">
          {(['Eco', 'Balanced', 'Turbo'] as const).map(p => (
            <button
              key={p}
              onClick={() => setProfile(p)}
              className={`px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all relative overflow-hidden group ${
                profile === p ? 'bg-blue-600 text-white shadow-2xl shadow-blue-600/40' : 'text-slate-500 hover:text-slate-200'
              }`}
            >
              <span className="relative z-10">{p}</span>
            </button>
          ))}
        </div>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
        <LiveStatCard title="CPU Load" value={`${Math.round(telemetry.cpuUsage)}%`} sub="Native Flux" color="blue" percent={telemetry.cpuUsage} />
        <LiveStatCard title="RAM Pressure" value={`${Math.round((telemetry.ramUsed / telemetry.ramTotal) * 100)}%`} sub="Host Topology" color="indigo" percent={(telemetry.ramUsed / telemetry.ramTotal) * 100} />
        <LiveStatCard title="Net Pulse" value={`${telemetry.networkDown.toFixed(1)}`} sub="Mbps IO" color="emerald" percent={(telemetry.networkDown / 200) * 100} />
        <LiveStatCard title="Core Temp" value={`${Math.round(telemetry.thermalIndex)}°C`} sub="Junction" color={telemetry.thermalIndex > 70 ? "rose" : "amber"} percent={telemetry.thermalIndex} />
        <LiveStatCard title="Convergence" value={osInfo?.isDesktop ? 'DESKTOP' : 'WEB'} sub="Deployment Mode" color="violet" percent={100} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8 bg-slate-900/40 backdrop-blur-3xl border border-slate-800 rounded-[48px] p-10 relative overflow-hidden group shadow-3xl">
          <div className="flex items-center justify-between mb-12 relative z-10">
            <div>
              <h3 className="font-black text-3xl text-white uppercase tracking-tighter italic">Resource Topology</h3>
              <p className="text-[10px] text-slate-500 mt-1 uppercase tracking-[0.4em] font-black">AI Guided Scaling • Desktop Context</p>
            </div>
            <div className="flex gap-6">
               <LegendItem color="#3b82f6" label="CPU" />
               <LegendItem color="#818cf8" label="RAM" />
            </div>
          </div>

          <div className="h-[450px] w-full relative z-10 px-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={history}>
                <defs>
                  <linearGradient id="fluxCpu" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" opacity={0.15} />
                <XAxis dataKey="displayTime" axisLine={{ stroke: '#1e293b' }} tickLine={false} tick={{ fill: '#475569', fontSize: 10 }} />
                <YAxis domain={[0, 100]} axisLine={{ stroke: '#1e293b' }} tickLine={false} tick={{ fill: '#475569', fontSize: 10 }} unit="%" />
                <Tooltip contentStyle={{ backgroundColor: 'rgba(2, 6, 23, 0.9)', border: '1px solid rgba(51, 65, 85, 0.4)', borderRadius: '24px' }} />
                <Area type="monotone" dataKey="cpu" stroke="#3b82f6" strokeWidth={4} fill="url(#fluxCpu)" isAnimationActive={false} />
                <Line type="monotone" dataKey="ram" stroke="#818cf8" strokeWidth={2} dot={false} isAnimationActive={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-4 flex flex-col gap-8">
          <div className="bg-slate-900/40 backdrop-blur-3xl border border-slate-800 rounded-[48px] p-10 shadow-3xl relative overflow-hidden flex flex-col h-full group">
             <div className="flex items-center justify-between mb-8">
                <h3 className="font-black text-[11px] uppercase tracking-[0.4em] text-slate-500 italic">Native Kernel Log</h3>
                <div className={`w-1.5 h-1.5 rounded-full ${activeTuning ? 'bg-violet-500 animate-ping' : 'bg-blue-500 animate-pulse'}`} />
             </div>
             
             <div ref={logContainerRef} className="flex-1 overflow-y-auto space-y-5 font-mono text-[10px] custom-scrollbar pr-3">
                {systemLogs.map(log => (
                  <div key={log.id} className="flex gap-4 animate-in slide-in-from-right-4">
                    <span className="text-slate-800 shrink-0 font-bold">[{new Date(log.id).toLocaleTimeString()}]</span>
                    <span className={`font-black tracking-tight ${
                      log.type === 'ai' ? 'text-violet-400' : 'text-blue-400/80'
                    }`}>
                      {log.msg.toUpperCase()}
                    </span>
                  </div>
                ))}
             </div>
          </div>

          <div className="bg-gradient-to-br from-indigo-600 to-blue-700 rounded-[48px] p-10 text-white shadow-3xl relative overflow-hidden group">
             <div className="relative z-10 flex flex-col h-full justify-between">
                <div>
                  <h4 className="font-black text-xs uppercase tracking-[0.4em] text-blue-100 mb-2 opacity-70">Native Link</h4>
                  <p className="text-4xl font-black italic tracking-tighter">
                     SYNCHRONIZED
                  </p>
                </div>
                <div className="mt-12">
                   <button onClick={onAnalyze} className="w-full py-5 bg-white text-blue-700 rounded-[24px] font-black text-[11px] uppercase tracking-[0.3em] shadow-3xl hover:bg-blue-50 transition-all">
                     Full Hardware Scan
                   </button>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const LiveStatCard = ({ title, value, sub, color, percent }: { title: string, value: string, sub: string, color: string, percent: number }) => (
  <div className="bg-slate-900/40 backdrop-blur-3xl border border-slate-800 rounded-[40px] p-8 shadow-2xl group transition-all relative overflow-hidden flex flex-col">
    <div className={`absolute top-0 left-0 w-1 h-full bg-${color === 'violet' ? 'fuchsia' : color}-500/20 group-hover:bg-${color === 'violet' ? 'fuchsia' : color}-500 transition-all duration-500`} />
    <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.3em] mb-4 opacity-70">{title}</p>
    <h4 className="text-4xl font-black text-white italic tracking-tighter mb-1.5">{value}</h4>
    <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">{sub}</p>
    <div className="mt-8 h-1.5 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800/50">
       <div className={`h-full bg-${color === 'violet' ? 'fuchsia' : color}-500 transition-all duration-1000`} style={{ width: `${Math.min(100, percent)}%` }} />
    </div>
  </div>
);

const LegendItem = ({ color, label }: { color: string, label: string }) => (
  <div className="flex items-center gap-2.5 px-3 py-1.5 bg-slate-950/40 rounded-full border border-slate-800/40">
    <div className="w-2 h-2 rounded-full shadow-[0_0_8px_currentColor]" style={{ backgroundColor: color }} />
    <span className="text-[9px] font-black text-slate-400 tracking-[0.2em] uppercase">{label}</span>
  </div>
);
