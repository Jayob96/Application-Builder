
import React, { useState, useRef, useEffect } from 'react';
import { vault } from '../services/memoryVault';
import { optimizeNeuralStorage } from '../services/geminiService';
import { StorageMetric } from '../types';

export const MaintenanceTools: React.FC = () => {
  const [activeAction, setActiveAction] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [metrics, setMetrics] = useState<StorageMetric | null>(null);
  const logContainerRef = useRef<HTMLDivElement>(null);

  const addLog = (msg: string) => {
    setLogs(prev => [...prev.slice(-15), `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  useEffect(() => {
    vault.getMetrics().then(setMetrics);
  }, []);

  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  const runAction = async (id: string, title: string) => {
    setActiveAction(id);
    setProgress(0);
    setLogs([]);
    addLog(`Initializing ${title}...`);
    
    if (id === 'defrag') {
      try {
        addLog("Interrogating Neural Memory topology...");
        const vfs = await vault.getAllFiles();
        const currentMetrics = await vault.getMetrics();
        
        addLog("Requesting AI optimization protocol...");
        const result = await optimizeNeuralStorage(currentMetrics, vfs);
        
        addLog(`Protocol Received: ${result.protocol}`);
        for (const step of result.defragSteps) {
          addLog(`EXECUTING: ${step}`);
          await new Promise(r => setTimeout(r, 800));
          setProgress(prev => Math.min(prev + (100 / result.defragSteps.length), 95));
        }
        
        addLog("Committing storage architecture enhancements...");
        await new Promise(r => setTimeout(r, 1000));
        setProgress(100);
        addLog(`Optimization Successful. Expected space recovery: ${result.expectedReduction}`);
        
        // Refresh metrics
        const updated = await vault.getMetrics();
        setMetrics(updated);
      } catch (err) {
        addLog("CRITICAL: Optimization logic link interrupted.");
      } finally {
        setTimeout(() => setActiveAction(null), 1500);
      }
      return;
    }

    // Generic mock tool logic
    const messages = [
      "Interrogating kernel handlers...",
      "Mapping disk page files...",
      "Analyzing registry clusters...",
      "Clearing transient data traps...",
      "Optimizing instruction pipe...",
      "Operation verifying...",
      "Maintenance complete."
    ];

    let msgIndex = 0;
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          setTimeout(() => setActiveAction(null), 1500);
          return 100;
        }
        
        if (p > (msgIndex + 1) * (100 / messages.length) && msgIndex < messages.length) {
          addLog(messages[msgIndex]);
          msgIndex++;
        }
        
        return p + Math.random() * 8;
      });
    }, 150);
  };

  const tools = [
    { id: 'defrag', title: 'Neural Memory Defrag', desc: 'AI-driven analysis and optimization of NovaCore internal storage architecture.', icon: 'M13 10V3L4 14h7v7l9-11h-7z' },
    { id: 'cleanup', title: 'Deep Disk Purge', desc: 'Identify and eliminate recursive cache chains and outdated temp clusters.', icon: 'M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16' },
    { id: 'network', title: 'Network Optimizer', desc: 'Recalibrate TCP/IP stack and DNS resolvers for high-frequency data relay.', icon: 'M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0' },
    { id: 'registry', title: 'Registry Forge', desc: 'Neural scan for orphan keys and broken installer link corruption.', icon: 'M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z' },
    { id: 'startup', title: 'Boot Sequencer', desc: 'Analyze and suppress non-critical background startup agents.', icon: 'M13 10V3L4 14h7v7l9-11h-7z' },
    { id: 'privacy', title: 'Privacy Shredder', desc: 'Surgical removal of browser metadata and persistent tracking cookies.', icon: 'M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-white tracking-tighter uppercase italic">Maintenance Suite</h2>
          <p className="text-slate-400 mt-1 font-medium italic">Precision utilities for system restoration and memory optimization.</p>
        </div>
        <div className="flex gap-4">
          <div className="flex items-center gap-3 bg-slate-900/40 p-1.5 rounded-2xl border border-slate-800">
             <div className="w-10 h-10 bg-blue-600/10 rounded-xl flex items-center justify-center text-blue-500">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
             </div>
             <div className="pr-4">
                <p className="text-[10px] font-black uppercase text-slate-500 tracking-widest leading-none">Internal Quota</p>
                <p className="text-xs font-bold text-slate-200 mt-1">{metrics ? `${(metrics.used / 1024 / 1024).toFixed(2)} MB / ${(metrics.quota / 1024 / 1024 / 1024).toFixed(1)} GB` : 'Syncing...'}</p>
             </div>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tools.map(tool => (
          <div key={tool.id} className={`bg-slate-900/40 backdrop-blur-md border border-slate-800 rounded-3xl p-8 transition-all hover:bg-slate-900/60 group relative overflow-hidden flex flex-col shadow-2xl ${tool.id === 'defrag' ? 'ring-1 ring-blue-500/20' : ''}`}>
            <div className="flex items-start justify-between mb-8">
              <div className={`w-14 h-14 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-center text-blue-500 group-hover:scale-110 group-hover:border-blue-500/30 transition-all ${tool.id === 'defrag' ? 'text-indigo-400 shadow-[0_0_15px_rgba(129,140,248,0.2)]' : ''}`}>
                <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={tool.icon} />
                </svg>
              </div>
              <button 
                onClick={() => runAction(tool.id, tool.title)}
                disabled={!!activeAction}
                className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                   activeAction === tool.id ? 'bg-blue-600/20 text-blue-400' : 'bg-blue-600 text-white hover:bg-blue-500 shadow-xl shadow-blue-600/20'
                } disabled:opacity-50 active:scale-95`}
              >
                {activeAction === tool.id ? 'Active' : 'Deploy'}
              </button>
            </div>
            <h3 className="font-black text-xl mb-2 flex items-center gap-2">
              {tool.title}
              {tool.id === 'defrag' && <span className="bg-indigo-500/20 text-indigo-400 text-[8px] px-2 py-0.5 rounded-full uppercase tracking-tighter">Neural</span>}
            </h3>
            <p className="text-sm text-slate-500 mb-8 flex-1 leading-relaxed font-medium italic">"{tool.desc}"</p>
            
            <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800 shadow-inner">
               {activeAction === tool.id && (
                 <div className="h-full bg-blue-600 transition-all duration-300 shadow-[0_0_10px_rgba(37,99,235,0.5)]" style={{ width: `${progress}%` }} />
               )}
            </div>
          </div>
        ))}
      </div>

      {activeAction && (
        <div className="bg-slate-950 border border-slate-800 rounded-3xl p-8 animate-in zoom-in-95 duration-500 shadow-3xl">
           <div className="flex items-center justify-between mb-6">
              <h4 className="text-sm font-black uppercase tracking-widest text-slate-400">Real-time Maintenance Log</h4>
              <div className="flex gap-1">
                 <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                 <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse [animation-delay:200ms]" />
                 <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse [animation-delay:400ms]" />
              </div>
           </div>
           <div ref={logContainerRef} className="bg-black/50 rounded-2xl p-6 font-mono text-xs text-blue-400/80 h-48 overflow-y-auto space-y-2 custom-scrollbar border border-white/5">
              {logs.map((log, i) => (
                <div key={i} className="animate-in slide-in-from-left-2 duration-300">
                  <span className="text-slate-600 mr-3">>>></span>
                  {log}
                </div>
              ))}
              {logs.length === 0 && <p className="text-slate-800 italic">Initializing console...</p>}
           </div>
        </div>
      )}

      <div className="bg-gradient-to-r from-indigo-600/10 to-blue-600/10 border border-blue-500/20 rounded-3xl p-8 flex gap-6 items-start relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-110 transition-transform">
           <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 24 24"><path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
        </div>
        <div className="text-indigo-500 shrink-0 w-12 h-12 bg-indigo-600/10 rounded-2xl flex items-center justify-center border border-indigo-500/20">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
          </svg>
        </div>
        <div className="relative z-10">
          <h4 className="font-black text-indigo-500 uppercase tracking-widest text-xs mb-2">Neural Storage Safety Protocol</h4>
          <p className="text-sm text-blue-200/60 leading-relaxed max-w-4xl">
            NovaCore now utilizes a <span className="text-white font-bold italic">MemoryVault</span> backend powered by IndexedDB. Self-optimization cycles use Gemini to reorganize internal data structures for maximum retrieval speed on legacy hardware. This process is non-destructive but may temporarily increase CPU utilization during the neural defragmentation pass.
          </p>
        </div>
      </div>
    </div>
  );
};
