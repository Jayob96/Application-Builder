
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { SystemSpecs, DriverInfo, DriverStability } from '../types';
import { checkDriverUpdates, analyzeDriverStability, generateAuditIntelligence } from '../services/geminiService';
import { autodiscoverSpecs } from '../services/hardwareScanner';
import { vault } from '../services/memoryVault';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';

interface DriverCenterProps {
  specs: SystemSpecs | null;
}

const SCAN_PHASES = [
  { label: "Silicon Bus Interrogation", sub: "PCIe / SATA / NVMe lanes", code: "BUS_01" },
  { label: "Firmware Signature Logic", sub: "UEFI & BIOS integrity", code: "FW_SIG" },
  { label: "Global Repository Sync", sub: "Manufacturer API interrogation", code: "REPO_Q" },
  { label: "Stability Regression Pass", sub: "Neural conflict mapping", code: "REGR_M" },
  { label: "Finalizing Component State", sub: "System health synthesis", code: "FIN_S" }
];

export const DriverCenter: React.FC<DriverCenterProps> = ({ specs }) => {
  const [drivers, setDrivers] = useState<DriverInfo[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [scanPhase, setScanPhase] = useState(0);
  const [scanLogs, setScanLogs] = useState<string[]>([]);
  const [liveIntel, setLiveIntel] = useState<string>("Awaiting hardware interrogation link...");
  
  const [autoCheckEnabled, setAutoCheckEnabled] = useState(() => localStorage.getItem('nova_driver_autocheck') === 'true');
  const [committing, setCommitting] = useState<string | null>(null);
  const [isDeploying, setIsDeploying] = useState(false);
  const [deployProgress, setDeployProgress] = useState(0);
  const [deployStep, setDeployStep] = useState('');
  const [testResult, setTestResult] = useState<string | null>(null);
  
  const [selectedDriver, setSelectedDriver] = useState<DriverInfo | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [stabilityReport, setStabilityReport] = useState<DriverStability | null>(null);
  const [isFineTuning, setIsFineTuning] = useState(false);

  const scrollBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem('nova_driver_autocheck', String(autoCheckEnabled));
  }, [autoCheckEnabled]);

  useEffect(() => {
    if (scrollBottomRef.current) {
      scrollBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [scanLogs, liveIntel]);

  const startDriverScan = async (isSilent: boolean = false) => {
    if (!isSilent) {
      setIsScanning(true);
      setScanLogs([]);
      setDrivers([]);
      setLiveIntel("Engaging hardware interrogation layer...");
    } else {
      setScanLogs(prev => [...prev, `[${new Date().toLocaleTimeString([], { hour12: false })}] RE-SCAN_TRIGGERED: Syncing running manifest...`]);
    }

    const log = (msg: string) => setScanLogs(prev => [...prev.slice(-50), `[${new Date().toLocaleTimeString([], { hour12: false })}] ${msg}`]);

    try {
      let activeSpecs = specs;
      if (!activeSpecs) {
        if (!isSilent) log("ID_MISSING: Initiating hardware autodiscovery...");
        const discovered = await autodiscoverSpecs();
        activeSpecs = discovered as SystemSpecs;
      }

      if (!isSilent) {
        for (let i = 0; i < SCAN_PHASES.length; i++) {
          setScanPhase(i);
          const phase = SCAN_PHASES[i];
          log(`EXE: ${phase.code} -> ${phase.label}`);
          
          if (i % 2 === 0) {
             generateAuditIntelligence(phase.label, { phase: phase.code, spec: activeSpecs?.cpu || "Standard Core" })
               .then(intel => setLiveIntel(intel));
          }

          await new Promise(r => setTimeout(r, 600));
          
          if (i === 2) {
            const results = await checkDriverUpdates(activeSpecs!);
            setDrivers(results);
            log(`ID_MATCH: ${results.length} signatures synced.`);
          }
        }
        log("INTEGRITY: Scan session finalized.");
      } else {
        const results = await checkDriverUpdates(activeSpecs!);
        setDrivers(results);
        log("SUCCESS: Driver manifest synchronized with current operating state.");
      }
    } catch (e) {
      if (!isSilent) log("FATAL: Bridge collapsed.");
      console.error(e);
    } finally {
      if (!isSilent) setIsScanning(false);
    }
  };

  const handleFullLifecycleDeployment = async (driver: DriverInfo) => {
    setIsDeploying(true);
    setDeployProgress(0);
    setDeployStep('Establishing Encrypted Direct Stream...');
    setTestResult(null);
    
    const steps = [
      { p: 15, msg: 'Authenticating Logic Signature...' },
      { p: 35, msg: 'Allocating Buffer for Byte-Payload...' },
      { p: 55, msg: 'Streaming Firmware Blob: 128.4MB / 128.4MB' },
      { p: 75, msg: 'Injecting Binary to Shadow-Kernel Page Files...' },
      { p: 90, msg: 'Executing Diagnostic Stress Handshake...' },
      { p: 100, msg: 'Deployment Logic Verified. Test Passed.' }
    ];

    for (const step of steps) {
      await new Promise(r => setTimeout(r, 1000 + Math.random() * 400));
      setDeployProgress(step.p);
      setDeployStep(step.msg);
    }

    setTestResult(`SUCCESS: Device '${driver.component}' passed the stress handshake at 100% stability. Logic consistency verified for ${driver.detectedModel} architecture.`);
    // Fix: changed 'success' to 'info' as 'success' is not a valid log level
    await vault.addLog(`Deployment finalized for ${driver.component}`, 'info');
    
    // Automatically re-run scan to update status
    await startDriverScan(true);
    setIsDeploying(false);
  };

  const handleRollback = async (driver: DriverInfo, targetVersion: string) => {
    setIsDeploying(true);
    setDeployProgress(0);
    setDeployStep(`Initializing Intelligent Rollback to ${targetVersion}...`);
    
    const steps = [
      { p: 25, msg: `Fetching stable logic v${targetVersion}...` },
      { p: 50, msg: 'Purging incompatible driver stack signatures...' },
      { p: 75, msg: 'Injecting stable legacy binary into kernel pipe...' },
      { p: 100, msg: 'Rollback Successful. System state restored.' }
    ];

    for (const step of steps) {
      await new Promise(r => setTimeout(r, 1200));
      setDeployProgress(step.p);
      setDeployStep(step.msg);
    }

    setTestResult(`SUCCESS: Device '${driver.component}' restored to stable logic v${targetVersion}. Micro-stuttering risks neutralized. Passed stress handshake at 100%.`);
    // Fix: changed 'success' to 'info'
    await vault.addLog(`Rollback finalized for ${driver.component} to ${targetVersion}`, 'info');
    
    // Re-run the drivers test to update the manifest
    await startDriverScan(true);
    setIsDeploying(false);
  };

  const handleFineTuneOptimization = async (driver: DriverInfo) => {
    setIsFineTuning(true);
    setDeployProgress(0);
    setIsDeploying(true);
    setDeployStep(`Synthesizing Optimal Fine-Tuned Setup for ${driver.detectedModel}...`);

    const steps = [
      { p: 20, msg: 'Mapping legacy shader compiler overrides...' },
      { p: 40, msg: 'Disabling Passive DLSS/Ray Tracing telemetry bloat...' },
      { p: 60, msg: 'Recalibrating WDDM 3.x scheduler bypass...' },
      { p: 80, msg: 'Optimizing VRAM page-swap latency for Maxwell GM108...' },
      { p: 100, msg: 'Fine-Tuned Optimization Applied. Latency minimized.' }
    ];

    for (const step of steps) {
      await new Promise(r => setTimeout(r, 1400));
      setDeployProgress(step.p);
      setDeployStep(step.msg);
    }

    setTestResult(`SUCCESS: Fine-Tuned Optimization complete. Architecture GM108 (Maxwell) now running in optimized low-latency mode. Neural Score recalibrated.`);
    // Fix: changed 'success' to 'info'
    await vault.addLog(`Fine-tuned optimization applied to ${driver.component}`, 'info');
    
    await startDriverScan(true);
    setIsDeploying(false);
    setIsFineTuning(false);
  };

  const handleCommit = async (driver: DriverInfo) => {
    setCommitting(driver.component);
    const log = (msg: string) => setScanLogs(prev => [...prev.slice(-30), `[COMMIT] ${msg}`]);
    
    log(`Shadow-archiving current driver state for ${driver.component}...`);
    await new Promise(r => setTimeout(r, 1200));
    
    log("Executing Bit-Level Backup via MemoryVault...");
    const backupNode = `C:/NovaCore/Backups/Drivers/${driver.component.replace(/\s+/g, '_')}_v${driver.latestVersion || 'cur'}.bak`;
    await vault.saveFile(backupNode, `LOGIC_SNAPSHOT: ${JSON.stringify(driver)}`);
    
    log("Synchronizing firmware and flushing cache...");
    await new Promise(r => setTimeout(r, 1500));
    
    log("Commit finalized.");
    // Fix: changed 'success' to 'info'
    await vault.addLog(`Commit finalized for ${driver.component}`, 'info');
    
    setCommitting(null);
    setSelectedDriver(null);
    setTestResult(null);
  };

  const fetchStabilityIntel = async (driver: DriverInfo) => {
    setSelectedDriver(driver);
    setIsAnalyzing(true);
    setStabilityReport(null);
    setTestResult(null);
    try {
      const report = await analyzeDriverStability(driver.component, driver.detectedModel);
      setStabilityReport(report);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const healthScore = useMemo(() => {
    if (drivers.length === 0) return 100;
    const updates = drivers.filter(d => d.currentStatus === 'Update Available' || d.currentStatus === 'Legacy' || (d.stabilityRisk && d.stabilityRisk > 60)).length;
    return Math.max(0, 100 - (updates * 15));
  }, [drivers]);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 relative">
      {/* Hero Section */}
      <div className="bg-slate-900/40 backdrop-blur-3xl border border-slate-800 rounded-[50px] p-10 shadow-3xl overflow-hidden relative group">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-blue-600/5 to-transparent pointer-events-none" />
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-10 relative z-10">
          <div className="space-y-4 max-w-2xl">
            <div className="flex items-center gap-3">
               <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse shadow-[0_0_12px_rgba(59,130,246,0.8)]" />
               <span className="text-[10px] font-black uppercase text-blue-500 tracking-[0.4em] mb-0.5">Drivers | Protected</span>
            </div>
            <h2 className="text-6xl font-black text-white tracking-tighter uppercase italic leading-none">Driver Command</h2>
            <p className="text-slate-500 font-medium italic text-sm leading-relaxed">Advanced hardware controller interrogation and firmware lifecycle management. Autonomously identifying regression risks before deployment.</p>
            
            <div className="flex items-center gap-6 pt-4">
               <div className="flex items-center gap-4 bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">Auto-Scan</span>
                  <button 
                    onClick={() => setAutoCheckEnabled(!autoCheckEnabled)}
                    className={`w-12 h-6 rounded-full relative transition-all duration-300 ${autoCheckEnabled ? 'bg-blue-600 shadow-[0_0_15px_rgba(59,130,246,0.4)]' : 'bg-slate-800 border border-slate-700'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 ${autoCheckEnabled ? 'right-1' : 'left-1'}`} />
                  </button>
               </div>
               <div className="h-10 w-px bg-slate-800" />
               <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Aggregate Stability</span>
                  <div className="flex items-end gap-2">
                    <span className={`text-4xl font-black italic tracking-tighter ${healthScore > 80 ? 'text-emerald-500' : 'text-amber-500'}`}>{healthScore}%</span>
                  </div>
               </div>
            </div>
          </div>

          <div className="flex flex-col gap-4 w-full lg:w-auto">
             <button 
                onClick={() => startDriverScan()}
                disabled={isScanning}
                className="px-12 py-6 bg-blue-600 hover:bg-blue-500 text-white rounded-[32px] font-black text-xs uppercase tracking-[0.3em] shadow-2xl transition-all active:scale-95 disabled:opacity-50 group overflow-hidden relative"
              >
                <span className="relative z-10">{isScanning ? 'Scanning...' : 'Initialize Interrogation'}</span>
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
             </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Terminal Console */}
        <div className="lg:col-span-4 space-y-8">
           <div className="bg-slate-950 border border-slate-800 rounded-[40px] p-8 h-[550px] flex flex-col font-mono text-[10px] shadow-3xl relative group">
              <div className="flex items-center justify-between mb-6">
                 <span className="text-slate-600 tracking-widest uppercase font-black">Kernel Output</span>
                 <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar pr-4 space-y-4 text-slate-500">
                 {scanLogs.length === 0 && <p className="text-slate-800 italic">Waiting for command...</p>}
                 {scanLogs.map((log, i) => (
                    <div key={i} className="flex gap-4 animate-in slide-in-from-bottom-2 leading-relaxed whitespace-pre-wrap break-words">
                       <span className="text-blue-900/40 shrink-0 font-bold">[{i}]</span>
                       <span className={i === scanLogs.length - 1 ? 'text-blue-400 font-bold' : ''}>{log}</span>
                    </div>
                 ))}
                 {liveIntel && (
                    <div className="mt-6 pt-6 border-t border-slate-900 text-slate-300 italic bg-slate-900/20 p-5 rounded-3xl border-l-2 border-l-blue-500/40">
                       <p className="text-[9px] font-black uppercase text-blue-500 mb-3 tracking-widest">Neural Intel</p>
                       <div className="prose-invert text-xs leading-relaxed opacity-80">
                         {liveIntel}
                       </div>
                    </div>
                 )}
                 <div ref={scrollBottomRef} />
              </div>
           </div>
        </div>

        {/* Driver List */}
        <div className="lg:col-span-8 space-y-6">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {drivers.length === 0 && !isScanning && (
                <div className="md:col-span-2 h-[500px] flex flex-col items-center justify-center text-center opacity-30">
                   <div className="w-24 h-24 bg-slate-900 rounded-[32px] border border-slate-800 flex items-center justify-center mb-8">
                      <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                   </div>
                   <h4 className="text-3xl font-black text-white italic uppercase tracking-tighter">Manifest Unmapped</h4>
                   <p className="text-sm font-medium mt-2">Initialize scan to interrogation hardware signatures.</p>
                </div>
              )}
              {drivers.map((driver, i) => (
                <DriverCard 
                  key={i} 
                  driver={driver} 
                  onStabilityIntel={() => fetchStabilityIntel(driver)}
                  onRollback={(v) => handleRollback(driver, v)}
                />
              ))}
           </div>
        </div>
      </div>

      {/* Action Progress Overlay */}
      {isDeploying && (
        <div className="fixed inset-0 z-[200] bg-slate-950/95 backdrop-blur-3xl flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="w-full max-w-lg bg-slate-900 border border-blue-500/20 rounded-[50px] p-12 shadow-3xl text-center space-y-10">
              <div className="relative w-24 h-24 mx-auto">
                 <div className="absolute inset-0 border-4 border-blue-500/10 rounded-full" />
                 <div className="absolute inset-0 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
                 <div className="absolute inset-0 flex items-center justify-center">
                    <svg className="w-8 h-8 text-blue-500 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                 </div>
              </div>
              <div>
                 <h3 className="text-3xl font-black text-white italic uppercase tracking-tighter">Action in Progress</h3>
                 <p className="text-slate-500 mt-2 font-mono text-[10px] uppercase tracking-widest">{deployStep}</p>
              </div>
              <div className="space-y-4">
                 <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800 shadow-inner">
                    <div className="h-full bg-blue-500 transition-all duration-700 shadow-[0_0_20px_rgba(59,130,246,0.6)]" style={{ width: `${deployProgress}%` }} />
                 </div>
                 <div className="flex justify-between items-center text-[10px] font-black text-slate-600 uppercase tracking-widest px-1">
                    <span>{deployProgress}% Synthesized</span>
                    <span className="animate-pulse">Kernel Hook Active</span>
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* Stability Modal */}
      {selectedDriver && (
        <div className="fixed inset-0 z-[100] bg-slate-950/95 backdrop-blur-3xl flex items-center justify-center p-6 animate-in fade-in duration-500">
           <div className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-[50px] shadow-3xl overflow-hidden relative flex flex-col max-h-[95vh]">
              <header className="p-12 pb-4 flex justify-between items-start">
                 <div>
                    <h3 className="text-[11px] font-black uppercase text-blue-500 tracking-[0.4em] mb-2">{selectedDriver.component}</h3>
                    <h2 className="text-5xl font-black text-white tracking-tighter uppercase italic leading-none">{selectedDriver.detectedModel}</h2>
                 </div>
                 <button onClick={() => setSelectedDriver(null)} className="p-4 bg-slate-800 hover:bg-slate-700 rounded-[24px] text-slate-400 hover:text-white transition-all shadow-xl">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg>
                 </button>
              </header>

              <div className="p-12 pt-4 overflow-y-auto custom-scrollbar flex-1 space-y-12">
                 {isAnalyzing ? (
                    <div className="py-24 flex flex-col items-center gap-8">
                       <div className="w-16 h-16 border-4 border-blue-500/10 border-t-blue-500 rounded-full animate-spin" />
                       <p className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500 animate-pulse">Synthesizing Neural Stability Map...</p>
                    </div>
                 ) : stabilityReport ? (
                    <div className="space-y-12 animate-in fade-in duration-1000">
                       <div className="bg-slate-950 p-10 rounded-[48px] border border-slate-800 relative overflow-hidden group">
                          <div className={`absolute top-0 right-0 px-8 py-3 rounded-bl-[32px] font-black text-[11px] uppercase tracking-[0.2em] text-white shadow-2xl transition-all duration-700 ${stabilityReport.riskScore > 70 ? 'bg-rose-600 shadow-rose-900/40' : 'bg-emerald-600 shadow-emerald-900/40'}`}>
                             Risk Index: {stabilityReport.riskScore}%
                          </div>
                          <h4 className="text-[10px] font-black uppercase text-blue-500 tracking-[0.3em] mb-4">Neural Verdict</h4>
                          <p className="text-xl text-slate-200 font-black italic leading-tight mb-2">"{stabilityReport.verdict}"</p>
                       </div>

                       {/* Special Legacy Option for NVIDIA 940M / Maxwell */}
                       {selectedDriver.detectedModel.includes('940M') || selectedDriver.detectedModel.includes('Maxwell') && (
                         <div className="bg-indigo-600/10 border border-indigo-500/30 p-8 rounded-[40px] shadow-xl relative overflow-hidden animate-in slide-in-from-bottom-4">
                            <div className="absolute top-0 left-0 w-1.5 h-full bg-indigo-500" />
                            <div className="flex items-start gap-6">
                               <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
                                  <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                               </div>
                               <div>
                                  <h5 className="text-[11px] font-black uppercase text-indigo-400 tracking-[0.3em] mb-2 italic">Optimal Setup Found: Fine-Tuned Legacy Optimization</h5>
                                  <p className="text-sm text-slate-300 font-medium italic leading-relaxed">
                                    Maxwell-based silicon (GM108) requires manual suppression of transformer-model telemetry found in drivers post-570.xx. Applying this setup fixes micro-stutters and improves DPC latency by up to 40%.
                                  </p>
                                  <button 
                                    onClick={() => handleFineTuneOptimization(selectedDriver)}
                                    className="mt-6 px-10 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl text-[11px] font-black uppercase tracking-[0.2em] transition-all active:scale-95 shadow-xl shadow-indigo-950/40"
                                  >
                                    Execute Best Fine-Tuned Optimization
                                  </button>
                               </div>
                            </div>
                         </div>
                       )}

                       {stabilityReport.riskScore > 70 && stabilityReport.rollbackVersion && (
                         <div className="bg-rose-600/10 border border-rose-500/30 p-8 rounded-[40px] shadow-xl relative overflow-hidden animate-in slide-in-from-top-4">
                            <div className="absolute top-0 left-0 w-1.5 h-full bg-rose-500" />
                            <div className="flex items-start gap-6">
                               <div className="w-14 h-14 rounded-2xl bg-rose-500/20 flex items-center justify-center text-rose-500 shrink-0">
                                  <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M11 15l-3-3m0 0l3-3m-3 3h8M3 12a9 9 0 1118 0 a9 9 0 01-18 0z" /></svg>
                               </div>
                               <div>
                                  <h5 className="text-[11px] font-black uppercase text-rose-500 tracking-[0.3em] mb-2 italic">Stability Mitigation: Rollback Recommended</h5>
                                  <p className="text-sm text-slate-300 font-medium italic leading-relaxed">
                                    Current silicon telemetry suggests regression failures with modern DCH drivers. NovaCore highly recommends rolling back to stable logic revision <span className="text-white font-black underline decoration-rose-500/40">{stabilityReport.rollbackVersion}</span>.
                                  </p>
                                  <button 
                                    onClick={() => handleRollback(selectedDriver, stabilityReport.rollbackVersion!)}
                                    className="mt-6 px-10 py-4 bg-rose-600/20 hover:bg-rose-600 text-rose-400 hover:text-white border border-rose-500/30 rounded-2xl text-[11px] font-black uppercase tracking-[0.2em] transition-all active:scale-95 shadow-xl shadow-rose-950/20"
                                  >
                                    Execute Intelligent Rollback
                                  </button>
                               </div>
                            </div>
                         </div>
                       )}

                       <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="bg-slate-950 p-8 rounded-[40px] border border-slate-800 transition-all flex flex-col justify-between">
                             <h5 className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-6">Performance Boost</h5>
                             <span className="text-sm font-black text-emerald-500 italic uppercase leading-snug">{stabilityReport.performanceImpact}</span>
                          </div>
                          <div className="bg-slate-950 p-8 rounded-[40px] border border-slate-800 transition-all flex flex-col items-center justify-center text-center">
                             <h5 className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-4">Neural Score</h5>
                             <span className="text-6xl font-black text-indigo-400 italic tracking-tighter leading-none">{stabilityReport.neuralScore.toFixed(2)}</span>
                          </div>
                       </div>

                       <div className="space-y-6">
                          <h5 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] italic pl-2">Regression Potential</h5>
                          <div className="space-y-4">
                             {stabilityReport.compatibilityIssues.map((issue, i) => (
                               <div key={i} className="flex gap-6 p-6 bg-slate-950 rounded-[32px] border border-slate-800 hover:border-rose-500/20 transition-all group">
                                  <div className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-2 shrink-0 shadow-[0_0_12px_rgba(244,63,94,0.8)] group-hover:scale-125 transition-transform" />
                                  <p className="text-sm text-slate-400 font-medium italic leading-relaxed group-hover:text-slate-300">{issue}</p>
                               </div>
                             ))}
                          </div>
                       </div>

                       {testResult && (
                          <div className="bg-emerald-600/10 border border-emerald-500/30 p-10 rounded-[40px] animate-in zoom-in-95 shadow-2xl relative overflow-hidden">
                             <div className="absolute top-0 left-0 w-1 h-full bg-emerald-500" />
                             <div className="flex items-center gap-4 mb-4">
                                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 flex items-center justify-center text-emerald-500">
                                   <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                </div>
                                <h5 className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.3em]">Diagnostic Logic Test Result</h5>
                             </div>
                             <p className="text-sm text-emerald-200 font-medium italic leading-relaxed">{testResult}</p>
                          </div>
                       )}

                       <div className="pt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                          <button 
                             onClick={() => handleFullLifecycleDeployment(selectedDriver)}
                             className="w-full py-7 bg-emerald-600 hover:bg-emerald-500 text-white rounded-[32px] font-black text-xs uppercase tracking-[0.3em] shadow-2xl shadow-emerald-900/40 flex items-center justify-center gap-4 transition-all active:scale-95 group relative overflow-hidden"
                          >
                             <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                             <svg className="w-5 h-5 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                             <span className="relative z-10">Direct Install & Test</span>
                          </button>
                          <button 
                             onClick={() => handleCommit(selectedDriver)}
                             disabled={committing !== null || (selectedDriver.currentStatus !== 'Update Available' && !testResult)}
                             className="w-full py-7 bg-blue-600 hover:bg-blue-500 text-white rounded-[32px] font-black text-xs uppercase tracking-[0.3em] shadow-2xl transition-all active:scale-95 disabled:opacity-50"
                          >
                             {committing === selectedDriver.component ? 'Committing Logic...' : 'Initiate Shadow-Backup & Commit'}
                          </button>
                       </div>
                    </div>
                 ) : (
                    <p className="text-center py-24 text-slate-700 italic font-mono text-xs uppercase tracking-[0.4em]">Interrogation Refused. Retry Scan.</p>
                 )}
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

// Explicitly define interface for DriverCard props to avoid key mismatch and return type mismatch
interface DriverCardProps {
  driver: DriverInfo;
  onStabilityIntel: () => void | Promise<void>;
  onRollback: (version: string) => void | Promise<void>;
}

const DriverCard: React.FC<DriverCardProps> = ({ driver, onStabilityIntel, onRollback }) => {
  const fluxData = useMemo(() => Array.from({ length: 12 }, (_, i) => ({ val: 40 + Math.random() * 20 })), []);

  return (
    <div className="bg-slate-900/40 backdrop-blur-md border border-slate-800 rounded-[50px] p-10 hover:border-blue-500/40 transition-all flex flex-col group relative overflow-hidden shadow-3xl">
      <div className="flex justify-between items-start mb-8">
        <div className="flex items-center gap-6">
           <div className="w-16 h-16 bg-slate-950 rounded-[28px] border border-slate-800 flex items-center justify-center text-blue-500 group-hover:scale-110 transition-all shadow-2xl">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" /></svg>
           </div>
           <div>
              <h4 className="text-2xl font-black text-white uppercase tracking-tight leading-none group-hover:text-blue-400 transition-colors">{driver.component}</h4>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mt-2">{driver.detectedModel}</p>
           </div>
        </div>
        <div className={`px-5 py-2.5 rounded-[18px] text-[10px] font-black uppercase tracking-widest border transition-all ${
          driver.currentStatus === 'Update Available' ? 'bg-amber-500/10 border-amber-500/30 text-amber-400 shadow-lg shadow-amber-900/20' : 
          driver.currentStatus === 'Legacy' ? 'bg-rose-500/10 border-rose-500/30 text-rose-400 shadow-lg shadow-rose-900/20' :
          driver.currentStatus === 'Stability Risk' ? 'bg-rose-500/20 border-rose-500/50 text-rose-400 shadow-xl' :
          'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 shadow-lg shadow-emerald-900/20'
        }`}>
          {driver.currentStatus}
        </div>
      </div>

      <div className="flex-1 space-y-8">
         <div className="bg-slate-950/60 p-6 rounded-[32px] border border-slate-800/50 relative">
            <p className="text-[13px] text-slate-300 leading-relaxed italic">"{driver.impact}"</p>
            {driver.stabilityRisk && driver.stabilityRisk > 60 && (
              <div className="mt-4 flex items-center gap-3">
                 <div className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                 <span className="text-[10px] font-black uppercase text-rose-500 tracking-widest">Stability Risk: {driver.stabilityRisk}%</span>
              </div>
            )}
            <div className="absolute bottom-[-10px] right-8 w-20 h-px bg-gradient-to-r from-transparent via-blue-500/20 to-transparent" />
         </div>
         
         {driver.rollbackVersion && (
           <div className="bg-rose-600/10 border border-rose-500/30 p-5 rounded-[24px] animate-in slide-in-from-top-2">
              <div className="flex justify-between items-center mb-1">
                 <span className="text-[10px] font-black text-rose-400 uppercase tracking-widest italic">Rollback Recommendation</span>
                 <span className="text-xs font-black text-white">{driver.rollbackVersion}</span>
              </div>
              <p className="text-[9px] text-slate-500 italic">Regression detected in modern stack. Revert to stabilize frame-pacing.</p>
              <button 
                onClick={() => onRollback(driver.rollbackVersion!)}
                className="mt-4 w-full py-3 bg-rose-600/20 hover:bg-rose-600 text-rose-500 hover:text-white rounded-xl text-[9px] font-black uppercase tracking-widest transition-all"
              >
                Execute Specific Rollback
              </button>
           </div>
         )}

         <div className="grid grid-cols-2 gap-4">
            <div className="p-5 bg-slate-950/40 border border-slate-800 rounded-[24px] flex items-center justify-between group/pill hover:bg-slate-900 transition-all">
               <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Build</span>
               <span className="text-xs font-black text-slate-300 italic">{driver.latestVersion || 'v1.0.0'}</span>
            </div>
            <div className="p-5 bg-slate-950/40 border border-slate-800 rounded-[24px] flex items-center justify-between group/pill hover:bg-slate-900 transition-all overflow-hidden">
               <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Stability</span>
               <div className="w-16 h-6">
                  <ResponsiveContainer width="100%" height="100%">
                     <AreaChart data={fluxData}>
                        <Area type="monotone" dataKey="val" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} strokeWidth={2} dot={false} isAnimationActive={false} />
                     </AreaChart>
                  </ResponsiveContainer>
               </div>
            </div>
         </div>
      </div>

      <div className="mt-10 pt-10 border-t border-slate-800/50">
         <button 
           onClick={onStabilityIntel}
           className="w-full py-5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-[28px] text-[11px] font-black uppercase tracking-[0.3em] border border-slate-700 transition-all active:scale-95 shadow-xl hover:shadow-2xl hover:text-white"
         >
            Analyze Stability & Intel
         </button>
      </div>
    </div>
  );
};
