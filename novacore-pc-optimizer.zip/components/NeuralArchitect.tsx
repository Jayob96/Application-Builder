
import React, { useState, useRef, useEffect } from 'react';
import { SystemSpecs, ChatMessage } from '../types';
import { proposeArchitectChanges, ArchitectProposal } from '../services/geminiService';
import { vault } from '../services/memoryVault';

interface NeuralArchitectProps {
  specs: SystemSpecs | null;
}

export const NeuralArchitect: React.FC<NeuralArchitectProps> = ({ specs }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [proposal, setProposal] = useState<ArchitectProposal | null>(null);
  const [vfs, setVfs] = useState<{ [key: string]: string }>({});

  const chatScrollRef = useRef<HTMLDivElement>(null);

  const syncVFS = async () => {
    const files = await vault.getAllFiles();
    setVfs(files);
  };

  useEffect(() => {
    syncVFS();
    if (chatScrollRef.current) chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
  }, [messages]);

  const handleArchitectRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping) return;

    const userMsg: ChatMessage = { role: 'user', content: input, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    const currentInput = input;
    setInput('');
    setIsTyping(true);
    setProposal(null);

    try {
      const result = await proposeArchitectChanges(currentInput, vfs, specs);
      setProposal(result);
      setMessages(prev => [...prev, { role: 'assistant', content: result.explanation, timestamp: Date.now() }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', content: "ERR: Logic bridge collapsed.", timestamp: Date.now() }]);
    } finally {
      setIsTyping(false);
    }
  };

  const applyChanges = async () => {
    if (!proposal) return;
    for (const change of proposal.changes) {
      await vault.saveFile(change.file, change.content);
    }
    await syncVFS();
    // Fix: changed 'system' to 'info' as 'system' is not a valid log level
    await vault.addLog(`Applied architectural patch: ${proposal.changes.length} nodes updated.`, 'info');
    setProposal(null);
    setMessages(prev => [...prev, { role: 'assistant', content: "System synchronized. Changes committed to MemoryVault.", timestamp: Date.now() }]);
  };

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col gap-8 animate-in fade-in duration-500">
      <header>
          <h2 className="text-4xl font-black text-white uppercase italic tracking-tighter">Neural Architect</h2>
          <p className="text-slate-500 font-medium italic">Logic construction via Gemini 3 Pro.</p>
      </header>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-8 overflow-hidden">
        <div className="lg:col-span-5 flex flex-col bg-slate-900/40 backdrop-blur-xl border border-slate-800 rounded-[40px] shadow-3xl overflow-hidden relative">
           <div ref={chatScrollRef} className="flex-1 overflow-y-auto p-8 space-y-6 custom-scrollbar">
              {messages.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center opacity-30 text-center px-10">
                   <h3 className="text-xl font-black uppercase tracking-tighter">Architect Mode</h3>
                   <p className="text-xs font-medium mt-3">Synthesize system patches and logic nodes.</p>
                </div>
              )}
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
                   <div className={`max-w-[85%] px-6 py-4 rounded-[24px] ${msg.role === 'user' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' : 'bg-slate-800 text-slate-200 border border-slate-700'}`}>
                      <p className="text-xs font-medium leading-relaxed">{msg.content}</p>
                   </div>
                </div>
              ))}
              {isTyping && <div className="text-indigo-500 animate-pulse font-black text-[9px] uppercase tracking-[0.3em]">SYNTHESIZING_PROPOSAL...</div>}
           </div>

           {proposal && (
              <div className="mx-8 mb-4 p-6 bg-emerald-600/10 border border-emerald-500/30 rounded-3xl animate-in zoom-in-95">
                 <div className="flex justify-between items-center mb-4">
                    <span className="text-[10px] font-black uppercase text-emerald-500">Patch Detected</span>
                    <span className="text-[9px] font-mono text-slate-500">{proposal.changes.length} files</span>
                 </div>
                 <button onClick={applyChanges} className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl">Commit to Vault</button>
              </div>
           )}

           <form onSubmit={handleArchitectRequest} className="p-8 border-t border-slate-800 bg-slate-950/40 flex gap-4">
              <input className="flex-1 bg-slate-900 border border-slate-800 rounded-2xl px-6 py-4 text-xs text-white focus:border-indigo-500 outline-none" placeholder="Propose a system modification..." value={input} onChange={e => setInput(e.target.value)} disabled={isTyping} />
              <button className="p-4 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-500 shadow-xl shadow-indigo-900/40">
                 <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
              </button>
           </form>
        </div>

        <div className="lg:col-span-7 flex flex-col bg-[#050505] border border-slate-800 rounded-[40px] shadow-3xl overflow-hidden relative">
           <div className="bg-[#1e1e1e] px-6 py-4 border-b border-white/5 flex items-center justify-between">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">VAULT_EXPLORER</span>
           </div>
           <div className="flex-1 flex overflow-hidden">
              <div className="w-48 border-r border-white/5 bg-[#181818] p-6 space-y-3 overflow-y-auto custom-scrollbar">
                 {Object.keys(vfs).map(file => (
                    <div key={file} className="flex items-center gap-3 text-[10px] font-mono text-slate-500 hover:text-white cursor-pointer group">
                       <svg className="w-3 v-3 group-hover:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                       <span className="truncate">{file}</span>
                    </div>
                 ))}
              </div>
              <div className="flex-1 p-10 font-mono text-[11px] text-slate-600 bg-black/20">
                 <p>// Workspace initialized. Waiting for proposal or file selection...</p>
                 <p className="mt-4">NODE_SYNC: {Object.keys(vfs).length} entries.</p>
              </div>
           </div>
           <div className="bg-[#007acc] px-6 py-2 text-white text-[10px] font-bold">ARCHITECT-CORE-ACTIVE</div>
        </div>
      </div>
    </div>
  );
};
