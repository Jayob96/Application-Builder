
import React, { useState } from 'react';
import { SystemSpecs, OptimizationReport } from '../types';

interface ExternalAIHubProps {
  specs: SystemSpecs | null;
  report: OptimizationReport | null;
}

export const ExternalAIHub: React.FC<ExternalAIHubProps> = ({ specs, report }) => {
  const [activePortal, setActivePortal] = useState<'gemini' | 'copilot' | null>(null);
  const [isLoggedIntoGemini, setIsLoggedIntoGemini] = useState(false);
  const [isLoggedIntoCopilot, setIsLoggedIntoCopilot] = useState(false);
  const [contextSync, setContextSync] = useState(true);

  const toggleLogin = (platform: 'gemini' | 'copilot') => {
    if (platform === 'gemini') setIsLoggedIntoGemini(!isLoggedIntoGemini);
    else setIsLoggedIntoCopilot(!isLoggedIntoCopilot);
  };

  const syncStats = [
    { label: 'CPU Profile', status: specs ? 'Synced' : 'Waiting', active: !!specs },
    { label: 'Memory Topology', status: specs ? 'Mapped' : 'Waiting', active: !!specs },
    { label: 'Security Audit', status: report ? 'Ingested' : 'Waiting', active: !!report },
    { label: 'Kernel Logs', status: 'Real-time', active: true },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white tracking-tight">AI Convergence Hub</h2>
          <p className="text-slate-400 mt-1 font-medium">Link enterprise LLMs to your local system environment.</p>
        </div>
        <div className="flex items-center gap-3 bg-slate-900/40 p-3 rounded-2xl border border-slate-800">
           <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${contextSync ? 'bg-emerald-500 animate-pulse' : 'bg-slate-600'}`} />
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Environmental Sync</span>
           </div>
           <button 
             onClick={() => setContextSync(!contextSync)}
             className={`w-9 h-5 rounded-full relative transition-all duration-300 ${contextSync ? 'bg-emerald-600 shadow-[0_0_10px_rgba(16,185,129,0.3)]' : 'bg-slate-700'}`}
           >
             <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all duration-300 ${contextSync ? 'right-1' : 'left-1'}`} />
           </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Google Gemini Card */}
        <AICard 
          name="Google Gemini"
          brandColor="from-blue-500 via-red-500 to-yellow-500"
          icon={<svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>}
          isLoggedIn={isLoggedIntoGemini}
          onLogin={() => toggleLogin('gemini')}
          description="Direct access to Gemini 1.5 Pro with native Google Search grounding and Workspace sync."
          environmentalAwareness={contextSync}
        />

        {/* Microsoft Copilot Card */}
        <AICard 
          name="Microsoft Copilot"
          brandColor="from-blue-600 to-indigo-700"
          icon={<svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>}
          isLoggedIn={isLoggedIntoCopilot}
          onLogin={() => toggleLogin('copilot')}
          description="Enterprise-grade GPT-4o integration with full Windows kernel awareness and M365 context."
          environmentalAwareness={contextSync}
        />
      </div>

      {/* Sync Status Board */}
      <div className="bg-slate-900/40 backdrop-blur-xl border border-slate-800 rounded-3xl p-8">
         <div className="flex items-center justify-between mb-8">
            <h3 className="font-bold text-xl flex items-center gap-3">
               <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
               </div>
               Environment Telemetry Map
            </h3>
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Global Sync Status: {contextSync ? 'Active' : 'Paused'}</span>
         </div>

         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {syncStats.map((stat, i) => (
               <div key={i} className={`p-4 rounded-2xl border transition-all ${
                 stat.active && contextSync ? 'bg-blue-500/5 border-blue-500/20' : 'bg-slate-950/40 border-slate-800 opacity-50'
               }`}>
                  <p className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-1">{stat.label}</p>
                  <div className="flex items-center justify-between">
                     <span className={`text-sm font-bold ${stat.active && contextSync ? 'text-blue-400' : 'text-slate-600'}`}>{stat.status}</span>
                     {stat.active && contextSync && <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />}
                  </div>
               </div>
            ))}
         </div>
      </div>

      {/* Context Preview */}
      <div className="p-6 bg-slate-950/50 border border-slate-800 rounded-3xl">
         <div className="flex gap-6 items-start">
            <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-slate-600 shrink-0 border border-slate-800">
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </div>
            <div>
               <h4 className="text-sm font-bold text-slate-200 mb-2 uppercase tracking-tight">How environmental awareness works</h4>
               <p className="text-xs text-slate-500 leading-relaxed max-w-3xl">
                 When enabled, NovaCore injects a hidden system prompt into your LLM sessions. This prompt contains your hardware profile (CPU/GPU/RAM), active security risks, and optimization roadmap. This allows Gemini and Copilot to provide advice specifically tailored to your machine's unique state instead of general generic answers.
               </p>
            </div>
         </div>
      </div>
    </div>
  );
};

const AICard: React.FC<{ 
  name: string; 
  brandColor: string; 
  icon: React.ReactNode; 
  isLoggedIn: boolean; 
  onLogin: () => void;
  description: string;
  environmentalAwareness: boolean;
}> = ({ name, brandColor, icon, isLoggedIn, onLogin, description, environmentalAwareness }) => (
  <div className="bg-slate-900/40 backdrop-blur-md border border-slate-800 rounded-3xl p-8 flex flex-col h-full relative group overflow-hidden">
    {/* Animated background gradient on hover */}
    <div className={`absolute inset-0 bg-gradient-to-br ${brandColor} opacity-0 group-hover:opacity-5 transition-opacity duration-700`} />
    
    <div className="flex items-center justify-between mb-8 relative z-10">
      <div className="flex items-center gap-4">
        <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${brandColor} p-[1px]`}>
          <div className="w-full h-full bg-slate-950 rounded-[15px] flex items-center justify-center text-white">
            {icon}
          </div>
        </div>
        <div>
          <h3 className="text-xl font-black text-white">{name}</h3>
          <div className="flex items-center gap-2 mt-1">
             <div className={`w-1.5 h-1.5 rounded-full ${isLoggedIn ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-slate-700'}`} />
             <span className="text-[10px] font-black uppercase text-slate-500 tracking-widest">{isLoggedIn ? 'Authenticated' : 'Offline'}</span>
          </div>
        </div>
      </div>
      
      <button 
        onClick={onLogin}
        className={`px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
          isLoggedIn 
            ? 'bg-slate-800 text-slate-400 hover:bg-rose-500/10 hover:text-rose-500 border border-slate-700' 
            : 'bg-white text-black hover:scale-105'
        }`}
      >
        {isLoggedIn ? 'Disconnect' : 'Log In'}
      </button>
    </div>

    <p className="text-slate-400 text-sm leading-relaxed mb-8 flex-1 relative z-10">{description}</p>

    <div className="space-y-4 relative z-10">
      <div className="flex items-center justify-between p-4 bg-slate-950/50 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-3">
           <svg className={`w-4 h-4 ${environmentalAwareness ? 'text-emerald-500' : 'text-slate-600'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
           <span className="text-xs font-bold text-slate-300">Contextual Ingestion</span>
        </div>
        <span className={`text-[10px] font-black uppercase ${environmentalAwareness ? 'text-emerald-500' : 'text-slate-600'}`}>{environmentalAwareness ? 'Enabled' : 'Blocked'}</span>
      </div>

      <button 
        disabled={!isLoggedIn}
        className={`w-full py-4 rounded-xl font-black text-sm uppercase tracking-widest transition-all ${
          isLoggedIn 
            ? 'bg-gradient-to-r from-slate-800 to-slate-900 border border-slate-700 text-white hover:border-blue-500/30' 
            : 'bg-slate-900/40 text-slate-600 border border-slate-800 cursor-not-allowed'
        }`}
      >
        {isLoggedIn ? `Launch ${name.split(' ')[1]} Console` : 'Authentication Required'}
      </button>
    </div>
  </div>
);
