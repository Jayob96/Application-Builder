
import React, { useState, useMemo } from 'react';
import { OptimizationReport, SystemSpecs, SecurityAudit } from '../types';
import { getVulnerabilityDetails, checkSystemIntegrity, IntegrityResult, runDeepSecurityAudit } from '../services/geminiService';
import { autodiscoverSpecs } from '../services/hardwareScanner';

interface SecurityHubProps {
  report: OptimizationReport | null;
  specs: SystemSpecs | null;
  onReportGenerated: (report: OptimizationReport) => void;
  onSpecsChange: (specs: SystemSpecs) => void;
}

export const SecurityHub: React.FC<SecurityHubProps> = ({ report, specs, onReportGenerated, onSpecsChange }) => {
  const [protections, setProtections] = useState({
    firewall: true,
    realTime: true,
    cloudGuard: true,
    appControl: false,
    memoryIntegrity: true
  });
  
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditLog, setAuditLog] = useState<string[]>([]);
  const [selectedVulnerability, setSelectedVulnerability] = useState<string | null>(null);
  const [details, setDetails] = useState<string | null>(null);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);

  // System Integrity States
  const [integrityResult, setIntegrityResult] = useState<IntegrityResult | null>(null);
  const [isCheckingIntegrity, setIsCheckingIntegrity] = useState(false);

  const handleToggle = (key: keyof typeof protections) => {
    setProtections(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const addAuditLog = (msg: string) => {
    setAuditLog(prev => [...prev.slice(-8), `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  const executeAudit = async (mode: 'baseline' | 'deep') => {
    setIsAuditing(true);
    setAuditLog([]);
    try {
      addAuditLog(`Initializing ${mode === 'deep' ? 'Deep Interrogation' : 'Baseline Sweep'}...`);
      
      let currentSpecs = specs;
      if (!currentSpecs) {
        addAuditLog("Hardware signature unmapped. Discovery triggered...");
        const discovered = await autodiscoverSpecs();
        currentSpecs = discovered as SystemSpecs;
        onSpecsChange(currentSpecs);
        addAuditLog("Hardware profile ingestion complete.");
      }

      addAuditLog("Probing kernel-level hooks for unauthorized persistence...");
      await new Promise(r => setTimeout(r, 600));
      
      addAuditLog(`Mapping vulnerabilities using ${mode === 'deep' ? 'Gemini 3 Pro' : 'Gemini 3 Flash'}...`);
      const securityResult = await runDeepSecurityAudit(currentSpecs);
      
      addAuditLog("Audit analysis complete. Synthesizing security posture...");
      await new Promise(r => setTimeout(r, 800));

      // Construct a full report if we only ran a security audit
      if (report) {
        onReportGenerated({ ...report, securityAudit: securityResult });
      } else {
        onReportGenerated({
          summary: "Security-only audit completed.",
          bottlenecks: [],
          softwareSteps: [],
          hardwareSuggestions: [],
          osTweaks: [],
          expectedGain: "N/A",
          securityAudit: securityResult
        });
      }
    } catch (error) {
      console.error("Audit failed:", error);
      addAuditLog("CRITICAL: Interrogation session interrupted by AI timeout.");
    } finally {
      setIsAuditing(false);
    }
  };

  const handleLearnMore = async (vulnerability: string) => {
    setSelectedVulnerability(vulnerability);
    setDetails(null);
    setIsLoadingDetails(true);
    try {
      const result = await getVulnerabilityDetails(vulnerability, specs);
      setDetails(result);
    } catch (error) {
      setDetails("Failed to load vulnerability details. Check connection.");
    } finally {
      setIsLoadingDetails(false);
    }
  };

  const handleIntegrityCheck = async () => {
    setIsCheckingIntegrity(true);
    setIntegrityResult(null);
    addAuditLog("Starting Deep System Integrity Audit...");
    try {
      const result = await checkSystemIntegrity(specs);
      setIntegrityResult(result);
      addAuditLog(`Integrity Audit Complete: Status ${result.overallStatus.toUpperCase()}`);
    } catch (error) {
      console.error("Integrity check failed", error);
      addAuditLog("Integrity check session collapsed.");
    } finally {
      setIsCheckingIntegrity(false);
    }
  };

  const securityScore = useMemo(() => {
    if (!report) return 0;
    const rl = report.securityAudit.riskLevel;
    return rl === 'Low' ? 95 : rl === 'Medium' ? 70 : rl === 'High' ? 40 : 15;
  }, [report]);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 relative">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter uppercase italic">Security Command Hub</h2>
          <p className="text-slate-500 mt-1 font-medium">Enterprise-grade interrogation & kernel-level hardening.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] border transition-all ${
            securityScore >= 70 ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 
            securityScore >= 40 ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' : 
            'bg-rose-500/10 border-rose-500/20 text-rose-400 shadow-[0_0_20px_rgba(244,63,94,0.1)]'
          }`}>
            POSTURE: {report ? report.securityAudit.riskLevel : 'UNMAPPED'}
          </div>
        </div>
      </header>

      {/* Main Scanner Console */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-[40px] p-10 flex flex-col items-center justify-center text-center relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-b from-indigo-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
          
          <div className="relative w-48 h-48 flex items-center justify-center mb-10">
             <div className={`absolute inset-0 rounded-full border-4 border-slate-800 transition-all duration-700 ${isAuditing || isCheckingIntegrity ? 'scale-110 opacity-20' : ''}`} />
             <div className={`absolute inset-0 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin ${isAuditing || isCheckingIntegrity ? 'opacity-100' : 'opacity-0'}`} />
             
             {/* Security Pulse Ring */}
             <div className={`absolute inset-4 border-2 rounded-full transition-all duration-500 ${
               report ? (securityScore >= 70 ? 'border-emerald-500/30' : 'border-rose-500/30') : 'border-slate-800'
             } ${isAuditing || isCheckingIntegrity ? 'animate-ping' : ''}`} />

             <div className="relative z-10 flex flex-col items-center">
                <svg className={`w-16 h-16 transition-all duration-700 ${isAuditing || isCheckingIntegrity ? 'text-indigo-500 scale-90' : (report ? (securityScore >= 70 ? 'text-emerald-500' : 'text-rose-500') : 'text-slate-600')}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
                {(report || integrityResult) && !isAuditing && !isCheckingIntegrity && (
                  <span className="text-3xl font-black text-white mt-3 tracking-tighter">{securityScore}%</span>
                )}
             </div>
          </div>

          <div className="space-y-4 w-full relative z-10">
            <h3 className="text-xl font-black text-white">Security Interrogator</h3>
            <p className="text-xs text-slate-500 mb-8 leading-relaxed max-w-[200px] mx-auto">Analyze hardware-level vulnerabilities and kernel integrity.</p>
            
            <div className="flex flex-col gap-3">
              <button 
                onClick={() => executeAudit('deep')}
                disabled={isAuditing || isCheckingIntegrity}
                className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.25em] shadow-xl shadow-indigo-900/40 transition-all active:scale-95 disabled:opacity-50"
              >
                {isAuditing ? 'Analyzing Architecture...' : 'Initialize Deep Audit'}
              </button>
              <button 
                onClick={handleIntegrityCheck}
                disabled={isAuditing || isCheckingIntegrity}
                className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-xl font-black text-[9px] uppercase tracking-[0.2em] transition-all disabled:opacity-30 border border-slate-700 hover:border-blue-500/40"
              >
                {isCheckingIntegrity ? 'Verifying Files...' : 'Verify System Integrity'}
              </button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-8 space-y-6">
           {/* Audit Log Terminal */}
           <div className="bg-slate-950 border border-slate-800 rounded-[32px] p-8 shadow-2xl relative overflow-hidden group">
              <div className="flex items-center justify-between mb-6">
                 <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-500">Live Interrogation Console</h4>
                 <div className="flex gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-slate-800" />
                    <div className="w-2 h-2 rounded-full bg-slate-800" />
                    <div className="w-2 h-2 rounded-full bg-slate-800" />
                 </div>
              </div>
              <div className="h-48 overflow-y-auto font-mono text-[11px] text-slate-400 space-y-2 custom-scrollbar">
                 {auditLog.length === 0 && (
                   <p className="text-slate-800 italic">Console idling. Waiting for audit trigger...</p>
                 )}
                 {auditLog.map((log, i) => (
                   <div key={i} className="flex gap-4 animate-in slide-in-from-left-2">
                      <span className="text-indigo-900 shrink-0">[{i}]</span>
                      <span className={i === auditLog.length - 1 ? 'text-indigo-400 font-bold' : ''}>{log}</span>
                   </div>
                 ))}
                 {(isAuditing || isCheckingIntegrity) && <div className="w-1.5 h-3 bg-indigo-500 animate-pulse inline-block" />}
              </div>
           </div>

           {/* Results Grid */}
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Vulnerabilities Section */}
              <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-8 relative group overflow-hidden h-full">
                 <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:scale-110 transition-transform">
                    <svg className="w-16 h-16" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L1 21h22L12 2zm0 15h-1v-1h1v1zm0-3h-1v-4h1v4z"/></svg>
                 </div>
                 <h4 className="font-bold text-lg mb-6 flex items-center gap-3">
                    Detected Threats
                    {report && report.securityAudit.vulnerabilities.length > 0 && (
                      <span className="bg-rose-500/20 text-rose-500 text-[10px] px-2 py-0.5 rounded-full">{report.securityAudit.vulnerabilities.length}</span>
                    )}
                 </h4>
                 <div className="space-y-3">
                    {report?.securityAudit.vulnerabilities.map((v, i) => (
                      <div key={i} onClick={() => handleLearnMore(v)} className="bg-slate-950/50 p-3 rounded-xl border border-slate-800 hover:border-rose-500/30 transition-all cursor-pointer group flex justify-between items-center">
                         <span className="text-xs font-bold text-slate-300 group-hover:text-white transition-colors truncate pr-4">{v}</span>
                         <svg className="w-4 h-4 text-slate-700 group-hover:text-rose-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7"/></svg>
                      </div>
                    ))}
                    {!report && <p className="text-xs text-slate-600 italic">No vulnerability data available.</p>}
                 </div>
              </div>

              {/* Integrity Section */}
              <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-8 relative group overflow-hidden h-full">
                 <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:scale-110 transition-transform">
                    <svg className="w-16 h-16" fill="currentColor" viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-3-3 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z"/></svg>
                 </div>
                 <h4 className="font-bold text-lg mb-6 flex items-center gap-3">
                    Integrity Watchdog
                    {integrityResult && (
                      <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                        integrityResult.overallStatus === 'Secure' ? 'bg-emerald-500/20 text-emerald-500' : 
                        integrityResult.overallStatus === 'Warning' ? 'bg-amber-500/20 text-amber-500' : 'bg-rose-500/20 text-rose-500'
                      }`}>
                        {integrityResult.overallStatus}
                      </span>
                    )}
                 </h4>
                 <div className="space-y-3">
                    {integrityResult ? (
                      integrityResult.checks.map((check, i) => (
                        <div key={i} className="flex flex-col p-3 bg-slate-950/40 rounded-xl border border-slate-800 hover:border-indigo-500/20 transition-all group">
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-[11px] font-mono text-slate-300 truncate pr-2">{check.file}</span>
                            <span className={`text-[9px] font-black uppercase ${
                              check.status === 'Valid' ? 'text-emerald-500' : check.status === 'Modified' ? 'text-amber-500' : 'text-rose-500'
                            }`}>{check.status}</span>
                          </div>
                          <p className="text-[10px] text-slate-500 italic truncate group-hover:text-slate-400 transition-colors">{check.detail}</p>
                        </div>
                      ))
                    ) : (
                      <div className="flex flex-col items-center justify-center py-10 opacity-40">
                         <svg className="w-10 h-10 mb-2 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                         <p className="text-[10px] font-black uppercase tracking-widest">Awaiting Verification</p>
                      </div>
                    )}
                 </div>
              </div>
           </div>

           {/* Hardening Steps (Expanded) */}
           <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-8 relative group overflow-hidden">
              <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:scale-110 transition-transform">
                 <svg className="w-16 h-16" fill="currentColor" viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.5h7c-.47 4.34-3.1 8.22-7 9.49V11.5H5V6.3l7-3.11v8.31z"/></svg>
              </div>
              <h4 className="font-bold text-lg mb-6">AI Hardening Roadmap</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 {report?.securityAudit.hardeningSteps.map((step, i) => (
                   <div key={i} className="flex gap-4 p-4 bg-emerald-500/5 rounded-2xl border border-emerald-500/10 hover:border-emerald-500/30 transition-all group">
                     <div className="w-8 h-8 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500 group-hover:scale-110 transition-transform shrink-0">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"/></svg>
                     </div>
                     <span className="text-[11px] font-medium text-slate-300 leading-relaxed group-hover:text-white transition-colors">{step}</span>
                   </div>
                 ))}
                 {!report && <p className="text-xs text-slate-600 italic px-4">Hardening steps synthesized after audit completion.</p>}
              </div>
           </div>
        </div>
      </div>

      {/* Detail View Modal */}
      {selectedVulnerability && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-2xl animate-in fade-in duration-300">
          <div className="bg-slate-900 border border-slate-800 rounded-[40px] w-full max-w-2xl shadow-3xl overflow-hidden flex flex-col max-h-[90vh] relative">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-rose-500 to-transparent" />
            <header className="p-10 flex justify-between items-start">
              <div>
                <p className="text-[10px] uppercase font-black text-rose-500 tracking-[0.3em] mb-3">Intelligence Archive</p>
                <h3 className="text-3xl font-black text-white leading-tight">{selectedVulnerability}</h3>
              </div>
              <button onClick={() => setSelectedVulnerability(null)} className="p-3 bg-slate-800 hover:bg-slate-700 rounded-2xl text-slate-400 hover:text-white transition-all">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </header>
            
            <div className="p-10 pt-0 overflow-y-auto custom-scrollbar flex-1">
              {isLoadingDetails ? (
                <div className="flex flex-col items-center justify-center py-20 space-y-6">
                  <div className="w-16 h-16 border-4 border-rose-500/10 border-t-rose-500 rounded-full animate-spin" />
                  <p className="text-slate-400 font-black text-[10px] uppercase tracking-widest animate-pulse">Decrypting vulnerability data...</p>
                </div>
              ) : (
                <div className="prose prose-invert prose-rose max-w-none">
                  <div className="bg-slate-950/50 p-8 rounded-3xl border border-slate-800">
                    {details ? details.split('\n').map((line, i) => (
                      <p key={i} className="text-sm text-slate-400 leading-relaxed mb-4 last:mb-0">{line}</p>
                    )) : "No archive data available."}
                  </div>
                </div>
              )}
            </div>
            
            <footer className="p-8 border-t border-slate-800 bg-slate-900/50 flex justify-end gap-4">
               <button onClick={() => setSelectedVulnerability(null)} className="px-8 py-3 bg-slate-800 text-slate-400 rounded-xl text-xs font-black uppercase tracking-widest">Close</button>
               <button className="px-8 py-3 bg-rose-600 text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-xl shadow-rose-900/30">Deploy Patch</button>
            </footer>
          </div>
        </div>
      )}
    </div>
  );
};
