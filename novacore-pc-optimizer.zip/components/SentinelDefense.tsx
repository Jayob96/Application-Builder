
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { SystemSpecs, OptimizationReport, ThreatPattern, TrainingProgress, MutationMatrixState, LogicEvolution } from '../types';
import { trainingLab } from '../services/securityTrainingService';

interface SentinelDefenseProps {
  specs: SystemSpecs | null;
  report: OptimizationReport | null;
}

export const SentinelDefense: React.FC<SentinelDefenseProps> = ({ specs, report }) => {
  const [matrix, setMatrix] = useState<MutationMatrixState>(trainingLab.getMatrix());
  const [progress, setProgress] = useState<TrainingProgress>(trainingLab.getProgress());
  const [evolution, setEvolution] = useState<LogicEvolution>(trainingLab.getEvolution());
  const [isTraining, setIsTraining] = useState(false);
  const [logs, setLogs] = useState<{ id: number, msg: string, type: 'info' | 'threat' | 'success' }[]>([]);
  const logRef = useRef<HTMLDivElement>(null);

  // USER-DRIVEN ENTROPY: Seed the matrix with mouse movements
  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (Math.random() > 0.95) {
      trainingLab.seedEntropy(e.clientX, e.clientY);
    }
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      trainingLab.shiftMatrix();
      setMatrix({ ...trainingLab.getMatrix() });
      setEvolution({ ...trainingLab.getEvolution() });
      setProgress({ ...trainingLab.getProgress() });
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  const runEpoch = async () => {
    if (isTraining) return;
    setIsTraining(true);
    addLog("Initializing Neural Convergence Epoch...", 'info');
    
    try {
      const res = await trainingLab.runEpoch(specs);
      if (res) {
        // Cast result to access mutation and verdict
        const mutationResult = res.result as { mutation: string; verdict: string };
        addLog(`TARGET_ACQUIRED: ${res.threat.name}`, 'threat');
        addLog(`MUTATION_COMMIT: ${mutationResult.mutation.slice(0, 30)}...`, 'success');
        addLog(`VERDICT: ${mutationResult.verdict}`, 'info');
      }
    } catch (e) {
      addLog("EPOCH_FAILED: Logic bridge collapse.", 'info');
    } finally {
      setIsTraining(false);
    }
  };

  const addLog = (msg: string, type: 'info' | 'threat' | 'success') => {
    setLogs(prev => [...prev.slice(-12), { id: Date.now(), msg: msg.toUpperCase(), type }]);
  };

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [logs]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20 select-none">
      <header className="flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
             <div className="w-2 h-2 rounded-full bg-teal-500 animate-pulse shadow-[0_0_12px_rgba(20,184,166,0.8)]" />
             <span className="text-[10px] font-black uppercase text-teal-500 tracking-[0.4em] mb-0.5">Zero-Trust Neural Security Lab</span>
          </div>
          <h2 className="text-6xl font-black text-white tracking-tighter uppercase italic leading-none">Sentinel Core</h2>
          <p className="text-slate-500 font-medium italic text-sm">Active Version: <span className="text-slate-300">v{evolution.version}</span> | Stability: <span className="text-teal-400">{evolution.stabilityIndex}%</span></p>
        </div>
        <div className="flex gap-4">
           <button 
            onClick={runEpoch} 
            disabled={isTraining}
            className="px-12 py-5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-[24px] font-black text-xs uppercase tracking-[0.3em] shadow-2xl transition-all disabled:opacity-50 active:scale-95 group overflow-hidden relative"
          >
            <span className="relative z-10">{isTraining ? 'Training Model...' : 'Trigger Mutation Cycle'}</span>
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div 
          onMouseMove={handleMouseMove}
          className="lg:col-span-8 bg-slate-900/40 backdrop-blur-3xl border border-slate-800 rounded-[48px] p-10 relative overflow-hidden group shadow-3xl cursor-crosshair"
        >
           <div className="flex items-center justify-between mb-10">
              <h3 className="font-black text-3xl text-white uppercase tracking-tighter italic">Polymorphic Mutation Matrix</h3>
              <div className="flex gap-4">
                 <div className="text-right">
                    <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Mutation Depth</p>
                    <p className="text-lg font-black text-teal-500">{matrix.mutationDepth.toFixed(1)}%</p>
                 </div>
                 <div className="text-right border-l border-slate-800 pl-4">
                    <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Neural Accuracy</p>
                    <p className="text-lg font-black text-indigo-400">{progress.accuracy.toFixed(1)}%</p>
                 </div>
              </div>
           </div>

           <div className="grid grid-cols-10 gap-1.5 relative z-10">
              {matrix.grid.map((row, r) => row.map((cell, c) => (
                 <div 
                  key={`${r}-${c}`} 
                  className={`aspect-square rounded-lg flex items-center justify-center font-mono text-[9px] font-black transition-all duration-1000 border ${
                    Math.random() > 0.98 ? 'bg-indigo-600/30 text-white scale-110 shadow-[0_0_15px_rgba(99,102,241,0.4)]' : 
                    Math.random() > 0.9 ? 'bg-teal-600/10 text-teal-400 border-teal-500/20' : 
                    'bg-slate-950/40 text-slate-800 border-slate-900 opacity-40'
                  }`}
                 >
                    {cell}
                 </div>
              )))}
           </div>

           <div className="mt-12 p-8 bg-black/40 rounded-[32px] border border-slate-800/50">
              <div className="flex items-center justify-between mb-4">
                 <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Logic Evolution Path</p>
                 <span className="text-[9px] font-mono text-slate-700">KERNEL_SNAPSHOT: OK</span>
              </div>
              <div className="flex gap-3 overflow-x-auto pb-2 custom-scrollbar no-scrollbar">
                {evolution.evolutionPath.map((evo, i) => (
                  <div key={i} className={`px-4 py-2 rounded-xl text-[9px] font-black shrink-0 border transition-all ${
                    i === evolution.evolutionPath.length - 1 ? 'bg-indigo-600 text-white border-indigo-500 shadow-xl' : 'bg-slate-900 text-slate-500 border-slate-800'
                  }`}>
                    {evo}
                  </div>
                ))}
              </div>
           </div>
           
           <div className="absolute top-0 right-0 p-10 opacity-5 group-hover:scale-125 transition-transform duration-[3s] pointer-events-none">
              <svg className="w-64 h-64" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
           </div>
        </div>

        <div className="lg:col-span-4 flex flex-col gap-8">
           <div className="bg-slate-900/40 border border-slate-800 rounded-[48px] p-10 h-[480px] shadow-3xl flex flex-col overflow-hidden group">
              <div className="flex items-center justify-between mb-8">
                <h3 className="font-black text-[11px] uppercase tracking-[0.4em] text-slate-500 italic">Evolution Stream</h3>
                <div className="flex gap-1.5">
                   <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping" />
                </div>
              </div>
              <div ref={logRef} className="flex-1 overflow-y-auto space-y-4 font-mono text-[10px] custom-scrollbar pr-2">
                 {logs.length === 0 && <p className="text-slate-800 italic">Initializing telemetry ingestion...</p>}
                 {logs.map(log => (
                   <div key={log.id} className="flex gap-4 animate-in slide-in-from-right-4 group/log">
                      <span className="text-slate-800 shrink-0 font-bold">[{new Date(log.id).toLocaleTimeString([], {second:'2-digit'})}]</span>
                      <span className={`font-black tracking-tight leading-relaxed ${
                        log.type === 'success' ? 'text-teal-400' : 
                        log.type === 'threat' ? 'text-rose-500' : 
                        'text-indigo-400'
                      }`}>
                        {log.msg}
                      </span>
                   </div>
                 ))}
                 {isTraining && <div className="w-1.5 h-3 bg-indigo-500 animate-pulse inline-block" />}
              </div>
           </div>

           <div className="bg-gradient-to-br from-teal-600 to-emerald-700 border border-emerald-500/20 rounded-[48px] p-10 shadow-3xl flex-1 flex flex-col justify-between group overflow-hidden relative">
              <div className="relative z-10">
                <div className="w-14 h-14 bg-white/10 rounded-3xl flex items-center justify-center text-white mb-6 backdrop-blur-md border border-white/10 group-hover:scale-110 transition-transform">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" /></svg>
                </div>
                <p className="text-[10px] font-black uppercase text-teal-100 tracking-widest mb-2 opacity-80">HIPAA Governance Engine</p>
                <h4 className="text-2xl font-black text-white italic tracking-tighter leading-none mb-6">Zero-Knowledge Guard</h4>
                <p className="text-[11px] text-teal-50/70 font-medium leading-relaxed italic">
                   "All system telemetry is scrubbed and masked locally. The AI models only ingest high-entropy logic signatures, ensuring 100% user-as-trusted privacy."
                </p>
              </div>
              <div className="absolute bottom-0 right-0 p-8 opacity-20 pointer-events-none group-hover:translate-x-4 transition-transform duration-1000">
                 <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-3-3 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z"/></svg>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};