
import React, { useState } from 'react';
import { checkDataBreaches } from '../services/geminiService';
import { BreachInfo } from '../types';

export const IdentityHub: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState<{ breaches: BreachInfo[], summary: string } | null>(null);

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setIsSearching(true);
    try {
      const data = await checkDataBreaches(email);
      setResults(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header>
        <h2 className="text-3xl font-bold text-white tracking-tight">Identity Vault</h2>
        <p className="text-slate-400 mt-1 font-medium">Protect your personal data from leaks and dark web exposures.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Scanner Form */}
        <div className="lg:col-span-5">
           <div className="bg-slate-900/40 backdrop-blur-xl border border-slate-800 rounded-3xl p-8 sticky top-8">
              <h3 className="font-bold text-xl mb-4 flex items-center gap-2">
                 <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                 Dark Web Scanner
              </h3>
              <p className="text-sm text-slate-500 mb-8 leading-relaxed">Enter an email, username, or company to scan for recent data breaches using AI-powered search grounding.</p>
              
              <form onSubmit={handleScan} className="space-y-4">
                 <div>
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-2">Target Identifier</label>
                    <input 
                      className="w-full bg-slate-950/50 border border-slate-700 rounded-xl px-4 py-4 text-sm focus:border-blue-500 outline-none transition-all placeholder:text-slate-700"
                      placeholder="e.g. myname@email.com or Adobe"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                    />
                 </div>
                 <button 
                   type="submit"
                   disabled={isSearching || !email}
                   className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-xl shadow-blue-600/20 transition-all disabled:opacity-50"
                 >
                    {isSearching ? 'Deep Web Query...' : 'Initialize Scan'}
                 </button>
              </form>

              <div className="mt-8 pt-8 border-t border-slate-800">
                 <div className="flex items-center gap-4 p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-2xl">
                    <div className="text-emerald-500"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg></div>
                    <p className="text-xs font-medium text-emerald-200">Zero credentials found in active browser memory.</p>
                 </div>
              </div>
           </div>
        </div>

        {/* Scan Results */}
        <div className="lg:col-span-7 space-y-6">
           {isSearching ? (
             <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-12 flex flex-col items-center justify-center text-center">
                <div className="w-16 h-16 relative mb-6">
                   <div className="absolute inset-0 border-4 border-blue-500/10 rounded-full" />
                   <div className="absolute inset-0 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
                </div>
                <h4 className="text-xl font-bold mb-2">Analyzing Dark Repositories</h4>
                <p className="text-slate-500 text-sm max-w-sm">We are cross-referencing global breach datasets and intelligence feeds.</p>
             </div>
           ) : results ? (
             <div className="animate-in fade-in duration-700 space-y-6">
                <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-8">
                   <h3 className="font-bold text-lg mb-4 text-blue-400">Intelligence Summary</h3>
                   <p className="text-sm text-slate-300 leading-relaxed italic border-l-2 border-blue-500 pl-4 bg-blue-500/5 py-3 rounded-r-xl">"{results.summary}"</p>
                </div>

                <div className="space-y-4">
                   <h4 className="text-xs font-black text-slate-500 uppercase tracking-[0.2em]">Suspected Sources ({results.breaches.length})</h4>
                   {results.breaches.map((breach, i) => (
                      <a 
                        key={i} 
                        href={breach.uri} 
                        target="_blank" 
                        rel="noreferrer"
                        className="block bg-slate-900/40 border border-slate-800 p-6 rounded-2xl hover:border-blue-500/40 transition-all group"
                      >
                         <div className="flex justify-between items-start mb-2">
                            <h5 className="font-bold text-slate-100 group-hover:text-blue-400 transition-colors">{breach.source}</h5>
                            <span className="text-[10px] font-mono text-slate-500">{breach.date}</span>
                         </div>
                         <p className="text-xs text-slate-400 mb-4">{breach.details}</p>
                         <div className="flex items-center gap-2 text-[10px] font-bold text-blue-500">
                            VIEW DETAILS <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
                         </div>
                      </a>
                   ))}
                   {results.breaches.length === 0 && (
                      <div className="py-20 text-center bg-slate-900/20 border border-dashed border-slate-800 rounded-3xl">
                         <p className="text-slate-600 font-medium">No direct external matches found for this query.</p>
                      </div>
                   )}
                </div>
             </div>
           ) : (
             <div className="h-full bg-slate-900/20 border border-dashed border-slate-800 rounded-3xl p-12 flex flex-col items-center justify-center text-center">
                <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center text-slate-700 mb-6">
                   <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A10.003 10.003 0 0012 3c1.223 0 2.38.22 3.446.621m4.414 4.414a10.003 10.003 0 011.537 12.07l-.054.09" /></svg>
                </div>
                <h4 className="text-lg font-bold text-slate-500">Awaiting Search Input</h4>
                <p className="text-xs text-slate-600 max-w-xs mt-2">Initialize a Dark Web scan to see results here.</p>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};
