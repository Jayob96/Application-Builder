
import React, { useState, useEffect, useRef } from 'react';
import { checkAppUpdates } from '../services/geminiService';
import { AppUpdate } from '../types';
import { vault } from '../services/memoryVault';

interface UpdateCenterProps {
  onUpdateApplied: () => void;
}

export const UpdateCenter: React.FC<UpdateCenterProps> = ({ onUpdateApplied }) => {
  const [currentVersion, setCurrentVersion] = useState(() => localStorage.getItem('nova_app_version') || '1.4.3');
  const [availableUpdate, setAvailableUpdate] = useState<AppUpdate | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);
  const [installProgress, setInstallProgress] = useState(0);
  const [installLogs, setInstallLogs] = useState<string[]>([]);
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [installLogs]);

  const checkForUpdates = async () => {
    setIsChecking(true);
    setAvailableUpdate(null);
    try {
      const rollout = await checkAppUpdates(currentVersion);
      // Simulate discovering a newer build in the global rollout repository
      if (rollout.version !== currentVersion) {
        setAvailableUpdate(rollout);
      } else {
        alert("NovaCore Desktop Client is synchronized with the latest kernel build (v" + currentVersion + ").");
      }
    } catch (e) {
      console.error("Update link collapsed", e);
    } finally {
      setIsChecking(false);
    }
  };

  const handleInstall = async () => {
    if (!availableUpdate) return;
    setIsInstalling(true);
    setInstallProgress(0);
    setInstallLogs([]);

    const addLog = (msg: string) => setInstallLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg.toUpperCase()}`]);

    const steps = [
      { p: 5, msg: "Connecting to NovaCore Global Rollout Service..." },
      { p: 15, msg: "Allocating storage for Delta Patch (App.exe metadata)..." },
      { p: 30, msg: `Downloading Portable Binary: Build_${availableUpdate.version}_x64.exe` },
      { p: 50, msg: `Applying logic patches to local environment...` },
      { p: 65, msg: "Verifying binary signature against Neural Ledger..." },
      { p: 80, msg: "Restarting local maintenance bridges..." },
      { p: 90, msg: "Syncing MemoryVault to new version schema..." },
      { p: 100, msg: "Executable Logic Finalized. Rollout Complete." }
    ];

    for (const step of steps) {
      addLog(step.msg);
      await new Promise(r => setTimeout(r, 1000 + Math.random() * 600));
      setInstallProgress(step.p);
    }

    // Persist new version
    localStorage.setItem('nova_app_version', availableUpdate.version);
    setCurrentVersion(availableUpdate.version);
    
    // Virtual binary commit to vault
    await vault.saveFile(`C:/NovaCore/Rollouts/Build_${availableUpdate.version}.bin`, `RELEASE_SIG: ${availableUpdate.binaryHash}`);
    // Fix: changed 'success' to 'info' as 'success' is not a valid log level
    await vault.addLog(`System updated to rollout version ${availableUpdate.version}`, 'info');

    setTimeout(() => {
      setIsInstalling(false);
      onUpdateApplied();
    }, 1500);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter uppercase italic leading-none">Desktop Rollout Hub</h2>
          <p className="text-slate-500 mt-2 font-medium italic">Packaging manifest management and .exe logic synchronization.</p>
        </div>
        <div className="flex gap-4">
           <div className="hidden lg:flex items-center gap-3 px-6 py-2 border border-slate-800 rounded-2xl bg-slate-900/40">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Build Status: RELEASED</span>
           </div>
           <button 
              onClick={checkForUpdates}
              disabled={isChecking || isInstalling}
              className="px-10 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-black text-xs uppercase tracking-[0.25em] shadow-2xl transition-all disabled:opacity-50 active:scale-95 group relative overflow-hidden"
           >
             <span className="relative z-10">{isChecking ? 'Syncing...' : 'Check for Updates'}</span>
             <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
           </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 space-y-8">
           <div className="bg-slate-900/40 backdrop-blur-xl border border-slate-800 rounded-[40px] p-10 relative overflow-hidden shadow-3xl group">
              <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-blue-600/5 to-transparent pointer-events-none" />
              <div className="relative z-10">
                 <div className="flex items-center justify-between mb-10">
                    <div className="flex items-center gap-4">
                       <div className="w-12 h-12 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-center text-blue-500 shadow-2xl group-hover:scale-110 transition-transform">
                          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                       </div>
                       <div>
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-none">Running Version</p>
                          <p className="text-3xl font-black text-white tracking-tighter italic mt-1">v{currentVersion}-stable</p>
                       </div>
                    </div>
                    <div className="text-right">
                       <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Platform</p>
                       <p className="text-sm font-black text-blue-400">Windows-x64-Native</p>
                    </div>
                 </div>

                 {availableUpdate ? (
                    <div className="space-y-8 animate-in zoom-in-95 duration-500">
                       <div className="bg-blue-600/10 border border-blue-500/30 rounded-[32px] p-8 relative overflow-hidden">
                          <div className="absolute top-0 right-0 px-6 py-2 bg-blue-600 text-white text-[9px] font-black uppercase tracking-widest rounded-bl-2xl">
                             Rollout Pending
                          </div>
                          <h3 className="text-xl font-black text-white mb-2">Build v{availableUpdate.version} Available</h3>
                          <p className="text-sm text-slate-400 font-medium italic mb-6">Dispatching from Global CDN • {availableUpdate.deltaSize} payload</p>
                          
                          <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800 mb-8">
                             <p className="text-[10px] font-black text-blue-400 uppercase tracking-[0.3em] mb-4">Rollout Improvements</p>
                             <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {availableUpdate.changelog.map((log, i) => (
                                   <li key={i} className="flex gap-3 text-xs text-slate-300 font-medium italic items-start">
                                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                                      {log}
                                   </li>
                                ))}
                             </ul>
                          </div>

                          <button 
                             onClick={handleInstall}
                             disabled={isInstalling}
                             className="w-full py-5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-black text-xs uppercase tracking-[0.3em] shadow-2xl transition-all active:scale-95"
                          >
                             Apply Desktop Update & Relaunch
                          </button>
                       </div>
                    </div>
                 ) : (
                    <div className="py-20 flex flex-col items-center justify-center text-center opacity-40">
                       <div className="w-20 h-20 bg-slate-950 rounded-full border border-slate-800 flex items-center justify-center mb-8">
                          <svg className="w-10 h-10 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                       </div>
                       <p className="text-xl font-black text-white italic uppercase tracking-tighter">Native Client Synchronized</p>
                       <p className="text-sm font-medium text-slate-500 mt-2 max-w-xs mx-auto">NovaCore is checking for global rollouts in the background. Your local binary is verified.</p>
                    </div>
                 )}
              </div>
           </div>

           <div className="bg-slate-900/20 border border-dashed border-slate-800 rounded-[40px] p-10 flex items-center justify-between group">
              <div className="max-w-md">
                 <h4 className="text-lg font-black text-slate-300 italic uppercase">Package Manifest</h4>
                 <p className="text-xs text-slate-500 mt-1 font-medium">Binary identity and packaging configurations for the desktop executable.</p>
              </div>
              <div className="flex gap-2">
                 <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 font-mono text-[9px] text-slate-500">arch: x64</div>
                 <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 font-mono text-[9px] text-slate-500">target: .exe</div>
              </div>
           </div>
        </div>

        <div className="lg:col-span-5 flex flex-col gap-8">
           <div className="bg-slate-950 border border-slate-800 rounded-[40px] p-8 h-[550px] flex flex-col font-mono text-[10px] shadow-3xl overflow-hidden group">
              <div className="flex items-center justify-between mb-8">
                <h3 className="font-black text-slate-600 uppercase tracking-widest">Rollout Console</h3>
                <div className={`w-2 h-2 rounded-full ${isInstalling ? 'bg-blue-500 animate-pulse shadow-[0_0_10px_rgba(59,130,246,0.6)]' : 'bg-slate-800'}`} />
              </div>
              <div ref={logRef} className="flex-1 overflow-y-auto space-y-3 custom-scrollbar text-slate-500">
                 {installLogs.length === 0 && <p className="text-slate-800 italic">Standing by for rollout packet ingestion...</p>}
                 {installLogs.map((log, i) => (
                    <div key={i} className="flex gap-4 animate-in slide-in-from-right-4">
                       <span className="text-slate-800 shrink-0 font-bold">[{i}]</span>
                       <span className={i === installLogs.length - 1 ? 'text-blue-400 font-bold' : ''}>{log}</span>
                    </div>
                 ))}
                 {isInstalling && <div className="w-1.5 h-3 bg-blue-500 animate-pulse inline-block" />}
              </div>
              {isInstalling && (
                 <div className="mt-8 pt-8 border-t border-slate-900 space-y-3">
                    <div className="flex justify-between items-center text-[9px] font-black uppercase text-slate-600 tracking-widest">
                       <span>Patch Progress</span>
                       <span>{installProgress}%</span>
                    </div>
                    <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800 shadow-inner">
                       <div className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-700 shadow-[0_0_15px_rgba(59,130,246,0.4)]" style={{ width: `${installProgress}%` }} />
                    </div>
                 </div>
              )}
           </div>

           <div className="bg-gradient-to-br from-blue-600 to-indigo-700 border border-blue-500/20 rounded-[40px] p-10 flex-1 flex flex-col justify-between group overflow-hidden relative shadow-3xl">
              <div className="relative z-10">
                <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center text-white mb-8 border border-white/10 group-hover:scale-110 transition-transform backdrop-blur-sm shadow-xl">
                   <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
                </div>
                <h4 className="text-2xl font-black text-white italic tracking-tighter uppercase leading-none mb-4">Native Integrity</h4>
                <p className="text-xs text-blue-50/70 font-medium leading-relaxed italic">
                   "NovaCore is packaged as a standalone portable .exe to minimize system footprint. Each rollout is signed with a unique neural hash that is verified by the local kernel before logic injection."
                </p>
              </div>
              <div className="absolute bottom-[-20px] right-[-20px] opacity-10 group-hover:scale-110 transition-transform duration-1000">
                 <svg className="w-48 h-48" fill="currentColor" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
