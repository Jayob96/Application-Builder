// main.ts (Electron main process)

import { app, BrowserWindow, ipcMain, shell, Tray, Menu } from "electron";
import * as path from "path";
import { autoUpdater } from "electron-updater";

let mainWindow: BrowserWindow | null = null;
let tray: Tray | null = null;

function createWindow(): void {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 768,
    frame: true, // Native window frame for OS accessibility
    titleBarStyle: "hiddenInset", // Modern macOS look
    backgroundColor: "#020617",
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true,
      webSecurity: true,
    },
    icon: path.join(__dirname, "assets", "icon.png"),
  });

  // Load the web app
  mainWindow.loadFile("index.html");

  // Open external links in default browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("https:")) {
      shell.openExternal(url);
    }
    return { action: "deny" };
  });

  mainWindow.on("closed", () => {
    mainWindow = null;
  });

  // Initialize Auto-Updater
  if (app.isPackaged) {
    autoUpdater.checkForUpdatesAndNotify();
  }
}

app.whenReady().then(() => {
  createWindow();

  // Initialize Tray Icon
  const trayIconPath = path.join(__dirname, "assets", "tray_icon.png");
  tray = new Tray(trayIconPath);

  const contextMenu = Menu.buildFromTemplate([
    {
      label: "Show NovaCore",
      click: () => {
        if (mainWindow) {
          if (mainWindow.isMinimized()) mainWindow.restore();
          mainWindow.show();
          mainWindow.focus();
        }
      },
    },
    {
      label: "Run Fast Sweep",
      click: () => {
        if (mainWindow) {
          mainWindow.webContents.send("trigger-sweep");
        }
      },
    },
    { type: "separator" },
    {
      label: "Quit",
      click: () => app.quit(),
    },
  ]);

  tray.setToolTip("NovaCore Neural Optimizer");
  tray.setContextMenu(contextMenu);
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// IPC communication for native system calls
ipcMain.handle("get-os-info", () => {
  return {
    platform: process.platform,
    arch: process.arch,
    version: app.getVersion(),
    isPackaged: app.isPackaged,
  };
});
