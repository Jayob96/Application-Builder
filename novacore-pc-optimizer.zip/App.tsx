
import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { AnalysisTool } from './components/AnalysisTool';
import { MaintenanceTools } from './components/MaintenanceTools';
import { AIChat } from './components/AIChat';
import { SecurityHub } from './components/SecurityHub';
import { SentinelDefense } from './components/SentinelDefense';
import { ThreatCenter } from './components/ThreatCenter';
import { IdentityHub } from './components/IdentityHub';
import { DriverCenter } from './components/DriverCenter';
import { VSCodeTerminal } from './components/VSCodeTerminal';
import { NeuralArchitect } from './components/NeuralArchitect';
import { DiagnosticsCenter } from './components/DiagnosticsCenter';
import { SmartTuningHub } from './components/SmartTuningHub';
import { UpdateCenter } from './components/UpdateCenter';
import { DashboardTab, SystemSpecs, OptimizationReport } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<DashboardTab>(DashboardTab.COMMAND_CENTER);
  const [specs, setSpecs] = useState<SystemSpecs | null>(null);
  const [report, setReport] = useState<OptimizationReport | null>(null);
  const [lockdownMode, setLockdownMode] = useState(false);

  // Sub-navigation states
  const [optimizerSubTab, setOptimizerSubTab] = useState<'roadmap' | 'drivers' | 'smart-tuning' | 'chat'>('roadmap');
  const [securitySubTab, setSecuritySubTab] = useState<'hub' | 'sentinel' | 'av' | 'identity'>('hub');
  const [devOpsSubTab, setDevOpsSubTab] = useState<'architect' | 'terminal'>('architect');
  const [utilsSubTab, setUtilsSubTab] = useState<'tools' | 'diagnostics' | 'updates'>('tools');

  useEffect(() => {
    const savedSpecs = localStorage.getItem('nova_specs');
    const savedReport = localStorage.getItem('nova_report');
    if (savedSpecs) setSpecs(JSON.parse(savedSpecs));
    if (savedReport) setReport(JSON.parse(savedReport));
  }, []);

  const handleUpdateSpecs = (newSpecs: SystemSpecs) => {
    setSpecs(newSpecs);
    localStorage.setItem('nova_specs', JSON.stringify(newSpecs));
  };

  const handleSetReport = (newReport: OptimizationReport) => {
    setReport(newReport);
    localStorage.setItem('nova_report', JSON.stringify(newReport));
  };

  const bgGradientNormal = "bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-900/10 via-slate-950 to-slate-950";
  const bgGradientLockdown = "bg-rose-950/20";
  const mainWrapperClasses = `flex-1 overflow-y-auto relative transition-all duration-700 custom-scrollbar ${lockdownMode ? bgGradientLockdown : bgGradientNormal}`;
  
  const topBgAccent = lockdownMode ? "bg-gradient-to-b from-rose-600/10" : "bg-gradient-to-b from-blue-600/5";
  const circleBgAccent = lockdownMode ? "bg-rose-500/10" : "bg-blue-500/10";

  return (
    <div className={`flex h-screen text-slate-100 overflow-hidden font-sans transition-colors duration-700 ${lockdownMode ? 'bg-rose-950' : 'bg-[#020617]'}`}>
      <Sidebar 
        activeTab={activeTab} 
        onTabChange={setActiveTab} 
        lockdownMode={lockdownMode} 
        toggleLockdown={() => setLockdownMode(!lockdownMode)} 
      />
      
      <main className={mainWrapperClasses}>
        <div className="max-w-[1600px] mx-auto p-6 md:p-10 lg:p-14 pb-32">
          {lockdownMode && (
            <div className="mb-10 bg-rose-600/10 border border-rose-600/30 p-5 rounded-[32px] flex items-center justify-between animate-in slide-in-from-top duration-500 shadow-2xl">
               <div className="flex items-center gap-5 text-rose-500">
                 <div className="w-10 h-10 rounded-2xl bg-rose-600/10 flex items-center justify-center border border-rose-600/20">
                   <svg className="w-5 h-5 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                 </div>
                 <span className="text-[11px] font-black uppercase tracking-[0.4em] italic">Lockdown Protocol Active: External Bridges Interrupted</span>
               </div>
               <div className="w-2 h-2 rounded-full bg-rose-500 shadow-[0_0_12px_rgba(244,63,94,1)] animate-pulse" />
            </div>
          )}

          {/* Sub-navigation Header */}
          {activeTab !== DashboardTab.COMMAND_CENTER && (
            <div className="mb-12 flex gap-2 bg-slate-900/40 p-1.5 rounded-[24px] border border-slate-800 w-fit backdrop-blur-xl shadow-2xl overflow-x-auto no-scrollbar">
              {activeTab === DashboardTab.AI_OPTIMIZER && (
                <>
                  <SubTabButton label="Roadmap" active={optimizerSubTab === 'roadmap'} onClick={() => setOptimizerSubTab('roadmap')} />
                  <SubTabButton label="Drivers" active={optimizerSubTab === 'drivers'} onClick={() => setOptimizerSubTab('drivers')} />
                  <SubTabButton label="Smart Tuning" active={optimizerSubTab === 'smart-tuning'} onClick={() => setOptimizerSubTab('smart-tuning')} />
                  <SubTabButton label="AI Chat" active={optimizerSubTab === 'chat'} onClick={() => setOptimizerSubTab('chat')} />
                </>
              )}
              {activeTab === DashboardTab.NEURAL_SECURITY && (
                <>
                  <SubTabButton label="Security Hub" active={securitySubTab === 'hub'} onClick={() => setSecuritySubTab('hub')} />
                  <SubTabButton label="Sentinel" active={securitySubTab === 'sentinel'} onClick={() => setSecuritySubTab('sentinel')} />
                  <SubTabButton label="Threat Scan" active={securitySubTab === 'av'} onClick={() => setSecuritySubTab('av')} />
                  <SubTabButton label="Dark Web" active={securitySubTab === 'identity'} onClick={() => setSecuritySubTab('identity')} />
                </>
              )}
              {activeTab === DashboardTab.DEVOPS_KERNEL && (
                <>
                  <SubTabButton label="Neural Architect" active={devOpsSubTab === 'architect'} onClick={() => setDevOpsSubTab('architect')} />
                  <SubTabButton label="Kernel Terminal" active={devOpsSubTab === 'terminal'} onClick={() => setDevOpsSubTab('terminal')} />
                </>
              )}
              {activeTab === DashboardTab.SYSTEM_UTILS && (
                <>
                  <SubTabButton label="Maintenance" active={utilsSubTab === 'tools'} onClick={() => setUtilsSubTab('tools')} />
                  <SubTabButton label="Diagnostics" active={utilsSubTab === 'diagnostics'} onClick={() => setUtilsSubTab('diagnostics')} />
                  <SubTabButton label="Updates" active={utilsSubTab === 'updates'} onClick={() => setUtilsSubTab('updates')} />
                </>
              )}
            </div>
          )}

          <div className="min-h-full">
            {activeTab === DashboardTab.COMMAND_CENTER && (
              <Dashboard specs={specs} report={report} onAnalyze={() => {
                setActiveTab(DashboardTab.AI_OPTIMIZER);
                setOptimizerSubTab('roadmap');
              }} />
            )}
            
            {activeTab === DashboardTab.AI_OPTIMIZER && (
              <>
                {optimizerSubTab === 'roadmap' && (
                  <AnalysisTool 
                    specs={specs} 
                    onSpecsChange={handleUpdateSpecs} 
                    onReportGenerated={handleSetReport}
                    report={report}
                  />
                )}
                {optimizerSubTab === 'drivers' && <DriverCenter specs={specs} />}
                {optimizerSubTab === 'smart-tuning' && <SmartTuningHub specs={specs} />}
                {optimizerSubTab === 'chat' && <AIChat specs={specs} report={report} />}
              </>
            )}

            {activeTab === DashboardTab.NEURAL_SECURITY && (
              <>
                {securitySubTab === 'hub' && (
                  <SecurityHub 
                    report={report} 
                    specs={specs} 
                    onReportGenerated={handleSetReport}
                    onSpecsChange={handleUpdateSpecs}
                  />
                )}
                {securitySubTab === 'sentinel' && <SentinelDefense specs={specs} report={report} />}
                {securitySubTab === 'av' && <ThreatCenter />}
                {securitySubTab === 'identity' && <IdentityHub />}
              </>
            )}

            {activeTab === DashboardTab.DEVOPS_KERNEL && (
              <>
                {devOpsSubTab === 'architect' && <NeuralArchitect specs={specs} />}
                {devOpsSubTab === 'terminal' && <VSCodeTerminal specs={specs} />}
              </>
            )}

            {activeTab === DashboardTab.SYSTEM_UTILS && (
              <>
                {utilsSubTab === 'tools' && <MaintenanceTools />}
                {utilsSubTab === 'diagnostics' && <DiagnosticsCenter />}
                {utilsSubTab === 'updates' && <UpdateCenter onUpdateApplied={() => setUtilsSubTab('diagnostics')} />}
              </>
            )}
          </div>
        </div>
        
        <div className={`fixed top-0 right-0 w-full h-[600px] transition-all duration-1000 -z-10 pointer-events-none ${topBgAccent} to-transparent opacity-60`} />
        <div className={`fixed top-[-15%] right-[-10%] w-[50%] h-[70%] blur-[180px] rounded-full -z-10 pointer-events-none transition-all duration-1000 ${circleBgAccent} opacity-40`} />
      </main>
    </div>
  );
};

const SubTabButton = ({ label, active, onClick }: { label: string, active: boolean, onClick: () => void }) => (
  <button
    onClick={onClick}
    className={`px-8 py-2.5 rounded-[18px] text-[10px] font-black uppercase tracking-[0.25em] transition-all italic shrink-0 ${
      active ? 'bg-blue-600 text-white shadow-2xl shadow-blue-600/40 scale-[1.02]' : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/40'
    }`}
  >
    {label}
  </button>
);

export default App;
