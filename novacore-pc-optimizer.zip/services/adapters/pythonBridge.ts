
// services/adapters/pythonBridge.ts
// PhoenixBird Phase 2/4 Integration: Python Execution Bridge

import { vault } from "../memoryVault";
import { cryptoEngine } from "../core/cryptoEngine";
import * as strategyValidator from "../phase2/strategyValidator";
import { CognitiveEvent } from "../../types";

/**
 * Python script interfaces for type safety and Phase 4 training integration
 */
export interface PythonScript {
  filename: string;
  code: string;
  dependencies: string[];
  entryPoint?: string;
  runtime?: 'python3.11' | 'python3.13' | 'conda';
  timeoutSeconds?: number;
  expectedOutputType: 'json' | 'text' | 'image' | 'model';
}

export interface PythonExecutionResult {
  scriptId: string;
  success: boolean;
  output: any;
  stderr?: string;
  executionTime: number; // ms
  cpuUsage: number;
  memoryUsage: number;
  timestamp: Date;
  dependenciesInstalled: boolean;
}

export interface PythonTaskIntent {
  task: string;
  context?: Record<string, any>;
  forceInstall?: boolean;
  virtualEnv?: string;
}

/**
 * PythonBridge - Secure bridge to Python execution environment
 * 
 * Phase 2: Task mapping and validation
 * Phase 3: Trust boundaries and signing
 * Phase 4: Training pipeline integration
 * 
 * Supports data analysis, ML training, and system automation
 */
class PythonBridge {
  private readonly scriptBasePath = "C:/NovaCore/Bridges/Python/";
  private readonly allowedScripts: Record<string, PythonScript> = {
    // System Analysis & Monitoring
    "SYSTEM_ANALYSIS": {
      filename: "system_analyzer.py",
      code: `
import os
import sys
import json
import psutil
import platform
from datetime import datetime


def analyze_system():
    """Comprehensive system analysis for PhoenixBird"""
    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    
    info = {
        "timestamp": datetime.now().isoformat(),
        "platform": platform.platform(),
        "cpu_count": psutil.cpu_count(),
        "cpu_usage": cpu_percent,
        "memory": {
            "total_gb": round(memory.total / (1024**3), 2),
            "used_percent": memory.percent,
            "available_gb": round(memory.available / (1024**3), 2)
        },
        "disk": {
            "total_gb": round(disk.total / (1024**3), 2),
            "used_percent": round((disk.used / disk.total) * 100, 2)
        },
        "boot_time": datetime.fromtimestamp(psutil.boot_time()).isoformat()
    }
    
    print(json.dumps(info))
    return info


if __name__ == "__main__":
    analyze_system()
      `,
      dependencies: ["psutil"],
      expectedOutputType: 'json',
      timeoutSeconds: 10
    },

    // ML/Embedding Generation
    "GENERATE_EMBEDDINGS": {
      filename: "embedding_generator.py",
      code: `
import numpy as np
import json
from sentence_transformers import SentenceTransformer


def generate_embeddings(texts):
    """Generate embeddings for RAG integration"""
    model = SentenceTransformer('all-MiniLM-L6-v2')
    embeddings = model.encode(texts)
    
    result = {
        "texts": texts,
        "embeddings": embeddings.tolist(),
        "shape": embeddings.shape
    }
    
    print(json.dumps(result))
    return result


if __name__ == "__main__":
    texts = sys.argv[1:] if len(sys.argv) > 1 else ["sample text"]
    generate_embeddings(texts)
      `,
      dependencies: ["sentence-transformers", "numpy", "torch"],
      expectedOutputType: 'json',
      timeoutSeconds: 30
    },

    // Training Data Preparation (Phase 4)
    "PREPARE_TRAINING_DATA": {
      filename: "training_data_prep.py",
      code: `
import json
import pandas as pd
from sklearn.model_selection import train_test_split


def prepare_training_data(input_file):
    """Prepare training data for Phase 4 fine-tuning"""
    with open(input_file, 'r') as f:
        data = json.load(f)
    
    df = pd.DataFrame(data)
    train, test = train_test_split(df, test_size=0.2, random_state=42)
    
    result = {
        "train_samples": len(train),
        "test_samples": len(test),
        "features": list(train.columns)
    }
    
    print(json.dumps(result))
    return result


if __name__ == "__main__":
    if len(sys.argv) > 1:
        prepare_training_data(sys.argv[1])
    else:
        print(json.dumps({"error": "No input file provided"}))
      `,
      dependencies: ["pandas", "scikit-learn"],
      expectedOutputType: 'json',
      timeoutSeconds: 60
    },

    // DeepSpeed Training Orchestration (Phase 4)
    "DEEPSPEED_SETUP": {
      filename: "deepspeed_launcher.py",
      code: `
import subprocess
import sys
import json


def launch_deepspeed(config_path):
    """Launch DeepSpeed training with PhoenixBird config"""
    cmd = [
        "deepspeed",
        "--num_gpus=1",
        "train.py",
        "--config", config_path
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
    
    output = {
        "success": result.returncode == 0,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "duration": "simulated"
    }
    
    print(json.dumps(output))
    return output


if __name__ == "__main__":
    if len(sys.argv) > 1:
        launch_deepspeed(sys.argv[1])
    else:
        print(json.dumps({"error": "No DeepSpeed config provided"}))
      `,
      dependencies: ["deepspeed"],
      expectedOutputType: 'json',
      timeoutSeconds: 300
    }
  };

  /**
   * Main entry point: Convert task intent to executable Python script
   * 
   * Phase 2: Strategy mapping + validation
   * Phase 3: Trust boundaries and signing
   * Phase 4: Training pipeline preparation
   */
  public async generatePythonBridge(intent: PythonTaskIntent): Promise<PythonScript> {
    const startTime = performance.now();
    const requestId = this.generateRequestId();

    try {
      // Phase 2: Validate Python task intent
      const isValidTask = await (strategyValidator as any).validatePythonTask(intent.task);
      if (!isValidTask) {
        throw new Error(`Invalid Python task: ${intent.task}`);
      }

      // Map to predefined script or create generic
      const script = this.mapTaskToScript(intent.task) || this.createGenericScript(intent.task);

      // Phase 3: Trust boundary verification
      const isTrusted = await cryptoEngine.verifyTrustBoundary(script.code);
      if (!isTrusted) {
        throw new Error(`Trust boundary violation for Python script ${script.filename}`);
      }

      // Persist script with signature (Phase 3 audit trail)
      await this.persistScript(script, requestId);

      // Log cognitive event for Phase 4 monitoring
      // Fix: task must be in metadata to match CognitiveEvent type
      await this.logCognitiveEvent({
        type: 'python_task_generation',
        metadata: {
          task: intent.task,
          dependencies: script.dependencies
        },
        requestId
      });

      const duration = performance.now() - startTime;
      await vault.addLog(
        `PythonBridge [${requestId}]: Script ${script.filename} generated in ${duration.toFixed(0)}ms`,
        'info'
      );

      return script;

    } catch (error) {
      const duration = performance.now() - startTime;
      await vault.addLog(
        `PythonBridge [${requestId}]: Task processing failed (${duration.toFixed(0)}ms): ${error}`,
        'error'
      );
      throw error;
    }
  }

  /**
   * Execute the generated Python script
   * 
   * Simulates Python execution with proper isolation and monitoring
   */
  public async executeScript(script: PythonScript): Promise<PythonExecutionResult> {
    const startTime = performance.now();

    try {
      // Simulate Python execution (in production: spawn isolated process)
      const simulatedResult = this.simulatePythonExecution(script);

      const result: PythonExecutionResult = {
        scriptId: script.filename,
        success: true,
        output: simulatedResult,
        executionTime: performance.now() - startTime,
        cpuUsage: Math.random() * 50 + 10, // Simulated
        memoryUsage: Math.random() * 30 + 5, // Simulated
        dependenciesInstalled: true,
        timestamp: new Date()
      };

      await vault.addLog(
        `PythonBridge: Executed ${script.filename} successfully (${result.executionTime.toFixed(0)}ms)`,
        'info'
      );

      return result;

    } catch (error) {
      const result: PythonExecutionResult = {
        scriptId: script.filename,
        success: false,
        output: null,
        stderr: error instanceof Error ? error.message : String(error),
        executionTime: performance.now() - startTime,
        cpuUsage: 0,
        memoryUsage: 0,
        dependenciesInstalled: false,
        timestamp: new Date()
      };

      await vault.addLog(
        `PythonBridge: Execution failed ${script.filename}: ${result.stderr}`,
        'error'
      );

      return result;
    }
  }

  /**
   * List available Python scripts by category or capability
   */
  public getAvailableScripts(): PythonScript[] {
    return Object.values(this.allowedScripts);
  }

  /**
   * Private: Map task intent to predefined Python script
   */
  private mapTaskToScript(task: string): PythonScript | null {
    const upperTask = task.toUpperCase().replace(/[^A-Z]/g, '_');
    return this.allowedScripts[upperTask] || null;
  }

  /**
   * Private: Create safe generic Python script
   */
  private createGenericScript(task: string): PythonScript {
    return {
      filename: `nova_generic_${Date.now()}.py`,
      code: `
import sys
import json
from datetime import datetime

print(json.dumps({
    "timestamp": datetime.now().isoformat(),
    "task": "${task}",
    "status": "completed",
    "message": "Generic task executed successfully"
}))
      `,
      dependencies: [],
      expectedOutputType: 'json',
      timeoutSeconds: 5
    };
  }

  /**
   * Private: Persist script with cryptographic signature
   */
  private async persistScript(script: PythonScript, requestId: string): Promise<void> {
    const filePath = `${this.scriptBasePath}${script.filename}`;
    await vault.saveFile(filePath, script.code);
    
    // Sign the script content
    const signature = await cryptoEngine.signData(script.code);
    await vault.saveFile(`${filePath}.sig`, signature);
  }

  /**
   * Private: Simulate Python execution for development
   */
  private simulatePythonExecution(script: PythonScript): any {
    const outputs = {
      "system_analyzer.py": {
        "cpu_usage": 12.5,
        "memory_used": 45.2,
        "disk_used": 78.3
      },
      "embedding_generator.py": {
        "embeddings": [[0.1, 0.2, 0.3]],
        "shape": [1, 384]
      }
    };

    return outputs[script.filename as keyof typeof outputs] || 
           { status: "completed", task: script.filename };
  }

  /**
   * Private: Log cognitive event for Phase 4
   */
  private async logCognitiveEvent(event: Partial<CognitiveEvent>): Promise<void> {
    try {
      const fullEvent: CognitiveEvent = {
        timestamp: new Date(),
        source: 'python_bridge',
        ...event
      } as CognitiveEvent;
      
      await vault.addLog(`Cognitive Event: ${JSON.stringify(fullEvent)}`, 'debug');
    } catch (error) {
      console.warn("PythonBridge: Failed to log cognitive event:", error);
    }
  }

  /**
   * Private: Generate unique request ID
   */
  private generateRequestId(): string {
    return `pybridge-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Export singleton instance
export const pythonBridge = new PythonBridge();
