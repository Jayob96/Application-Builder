
// services/adapters/powershellBridge.ts
// PhoenixBird Phase 2/3 Integration: PowerShell Execution Bridge

import { vault } from "../memoryVault";
import { cryptoEngine } from "../core/cryptoEngine";
import * as strategyValidator from "../phase2/strategyValidator";

/**
 * PowerShell command interfaces for type safety
 */
export interface PowerShellCommand {
  id: string;
  script: string;
  description: string;
  requiresAdmin: boolean;
  category: 'optimization' | 'maintenance' | 'security' | 'monitoring';
  estimatedDuration: number; // seconds
  riskLevel: 'low' | 'medium' | 'high';
}

export interface ExecutionResult {
  commandId: string;
  success: boolean;
  output: string;
  error?: string;
  executionTime: number; // ms
  requiresAdmin: boolean;
  timestamp: Date;
}

export interface PowerShellIntent {
  intent: string;
  context?: Record<string, any>;
  force?: boolean;
}

/**
 * PowerShellBridge - Secure bridge to Windows PowerShell execution
 * 
 * Implements Phase 2 (strategy mapping) and Phase 3 (trust boundaries)
 * Provides safe, auditable execution of system commands
 * 
 * Integrates with Gemini/Ollama for natural language command generation
 */
class PowerShellBridge {
  private readonly commandBasePath = "C:/NovaCore/Bridges/PS_";
  private readonly allowedCommands: Record<string, PowerShellCommand> = {
    // Optimization Commands (Low-Medium Risk)
    "PURGE_TEMP": {
      id: "PS_001",
      script: "Remove-Item -Path $env:TEMP\\* -Recurse -Force -ErrorAction SilentlyContinue; Write-Output 'Temp cleanup complete'",
      description: "Clears current user temporary directory and logs result.",
      requiresAdmin: false,
      category: 'optimization',
      estimatedDuration: 2,
      riskLevel: 'low'
    },
    "OPTIMIZE_DRIVE": {
      id: "PS_002",
      script: "Optimize-Volume -DriveLetter C -ReTrim -Verbose -ErrorAction Stop; Write-Output 'Drive optimization complete'",
      description: "Triggers SSD ReTrim/Optimization with verbose output.",
      requiresAdmin: true,
      category: 'optimization',
      estimatedDuration: 30,
      riskLevel: 'medium'
    },
    "FLUSH_DNS": {
      id: "PS_003",
      script: "Clear-DnsClientCache; ipconfig /flushdns; Write-Output 'DNS cache cleared'",
      description: "Flushes both PowerShell DNS cache and Windows DNS resolver.",
      requiresAdmin: true,
      category: 'optimization',
      estimatedDuration: 1,
      riskLevel: 'low'
    },
    "DEBLOAT_APPS": {
      id: "PS_004",
      script: `
$apps = Get-AppxPackage | Where-Object {$_.Name -notlike '*Store*' -and $_.Name -notlike '*Calculator*' -and $_.Name -notlike '*Photos*'}
$apps | Remove-AppxPackage -ErrorAction SilentlyContinue
Write-Output "Debloat complete. Removed $($apps.Count) packages"
      `,
      description: "Removes non-essential pre-installed Windows apps (safe list).",
      requiresAdmin: true,
      category: 'optimization',
      estimatedDuration: 15,
      riskLevel: 'medium'
    },

    // Maintenance Commands
    "SYSTEM_INFO": {
      id: "PS_005",
      script: "Get-ComputerInfo | Select-Object WindowsProductName, TotalPhysicalMemory, CsProcessors; Get-WmiObject Win32_OperatingSystem | Select-Object LastBootUpTime",
      description: "Gathers comprehensive system information.",
      requiresAdmin: false,
      category: 'monitoring',
      estimatedDuration: 3,
      riskLevel: 'low'
    },
    "SERVICE_STATUS": {
      id: "PS_006",
      script: "Get-Service | Where-Object {$_.Status -eq 'Stopped'} | Select-Object Name, Status | Format-Table -AutoSize",
      description: "Lists stopped Windows services.",
      requiresAdmin: false,
      category: 'monitoring',
      estimatedDuration: 2,
      riskLevel: 'low'
    },

    // Security Commands
    "FIREWALL_STATUS": {
      id: "PS_007",
      script: "Get-NetFirewallProfile | Select-Object Name, Enabled; Write-Output 'Firewall status retrieved'",
      description: "Checks Windows Firewall status across profiles.",
      requiresAdmin: false,
      category: 'security',
      estimatedDuration: 1,
      riskLevel: 'low'
    },
    "WINDOWS_UPDATE": {
      id: "PS_008",
      script: "Install-Module PSWindowsUpdate -Force; Get-WUList | Install-WUUpdate -AcceptAll -AutoReboot:$false",
      description: "Checks and installs available Windows updates (non-reboot).",
      requiresAdmin: true,
      category: 'maintenance',
      estimatedDuration: 300,
      riskLevel: 'high'
    }
  };

  /**
   * Main entry point: Convert natural language intent to PowerShell command
   * 
   * Phase 2: Strategy mapping + validation
   * Phase 3: Trust boundary verification
   * 
   * @param intent - Natural language intent from Gemini/Ollama
   * @param context - Additional execution context
   * @returns Safe PowerShell command or rejection
   */
  public async executePowerShellBridge(intent: PowerShellIntent): Promise<PowerShellCommand> {
    const startTime = performance.now();
    const requestId = this.generateRequestId();

    try {
      // Phase 2: Validate strategy (using logic that intent is just a string check here)
      const isValidIntent = intent.intent.length > 0;
      if (!isValidIntent) {
        throw new Error(`Invalid intent: ${intent.intent}`);
      }

      // Find matching command or generate generic
      const command = this.mapIntentToCommand(intent.intent) || this.createGenericCommand(intent.intent);

      // Phase 3: Trust boundary verification
      const isTrusted = await cryptoEngine.verifyTrustBoundary(command.script);
      if (!isTrusted) {
        throw new Error(`Trust boundary violation for command ${command.id}`);
      }

      // Phase 2: Risk assessment
      if (command.riskLevel === 'high' && !intent.force) {
        // Fix: changed 'warning' to 'warn' as 'warning' is not a valid log level
        await vault.addLog(
          `PowerShellBridge [${requestId}]: High-risk command ${command.id} blocked without force flag`,
          'warn'
        );
        throw new Error(`High-risk operation requires force flag`);
      }

      // Persist command for auditing (Phase 3 compliance)
      await this.persistCommand(command, requestId);

      const duration = performance.now() - startTime;
      await vault.addLog(
        `PowerShellBridge [${requestId}]: Command ${command.id} prepared in ${duration.toFixed(0)}ms`,
        'info'
      );

      return command;

    } catch (error) {
      const duration = performance.now() - startTime;
      await vault.addLog(
        `PowerShellBridge [${requestId}]: Intent processing failed (${duration.toFixed(0)}ms): ${error}`,
        'error'
      );
      throw error;
    }
  }

  /**
   * Execute the prepared PowerShell command (actual execution)
   * 
   * This would typically be called from a worker or external process
   * 
   * @param command - Prepared PowerShell command
   * @returns Execution result with full output
   */
  public async executeCommand(command: PowerShellCommand): Promise<ExecutionResult> {
    const startTime = performance.now();

    try {
      // In production, this would spawn PowerShell process with proper isolation
      // For now, simulate execution with validation
      const simulatedOutput = this.simulateExecution(command);
      
      const result: ExecutionResult = {
        commandId: command.id,
        success: true,
        output: simulatedOutput,
        executionTime: performance.now() - startTime,
        requiresAdmin: command.requiresAdmin,
        timestamp: new Date()
      };

      await vault.addLog(
        `PowerShellBridge: Executed ${command.id} successfully (${result.executionTime.toFixed(0)}ms)`,
        'info'
      );

      return result;

    } catch (error) {
      const result: ExecutionResult = {
        commandId: command.id,
        success: false,
        output: '',
        error: error instanceof Error ? error.message : String(error),
        executionTime: performance.now() - startTime,
        requiresAdmin: command.requiresAdmin,
        timestamp: new Date()
      };

      await vault.addLog(
        `PowerShellBridge: Execution failed ${command.id}: ${result.error}`,
        'error'
      );

      return result;
    }
  }

  /**
   * List available PowerShell commands by category
   */
  public getAvailableCommands(category?: string): PowerShellCommand[] {
    if (category) {
      return Object.values(this.allowedCommands).filter(cmd => cmd.category === category);
    }
    return Object.values(this.allowedCommands);
  }

  /**
   * Private: Map natural language intent to predefined command
   */
  private mapIntentToCommand(intent: string): PowerShellCommand | null {
    const upperIntent = intent.toUpperCase().replace(/[^A-Z]/g, '_');
    return this.allowedCommands[upperIntent] || null;
  }

  /**
   * Private: Create safe generic command for unknown intents
   */
  private createGenericCommand(intent: string): PowerShellCommand {
    return {
      id: `PS_GENERIC_${Date.now()}`,
      script: `Write-Host "PhoenixBird executing: ${intent}"; Write-Output "Command logged and audited"`,
      description: `Generic safe wrapper for intent: ${intent}`,
      requiresAdmin: false,
      category: 'maintenance',
      estimatedDuration: 1,
      riskLevel: 'low'
    };
  }

  /**
   * Private: Persist command for audit trail (Phase 3 requirement)
   */
  private async persistCommand(command: PowerShellCommand, requestId: string): Promise<void> {
    const filePath = `${this.commandBasePath}${command.id}_${requestId}.ps1`;
    await vault.saveFile(filePath, command.script);
    
    // Sign the persisted command
    const signature = await cryptoEngine.signData(command.script);
    await vault.saveFile(`${filePath}.sig`, signature);
  }

  /**
   * Private: Simulate PowerShell execution for development
   */
  private simulateExecution(command: PowerShellCommand): string {
    const outputs: Record<string, string> = {
      "PS_001": "Temp cleanup complete. 1.2GB freed.",
      "PS_002": "Drive C: optimization complete. ReTrim executed.",
      "PS_003": "DNS cache cleared successfully.",
      "PS_004": "Debloat complete. Removed 12 packages."
    };
    
    return outputs[command.id] || 
           `Command ${command.id} executed successfully (simulation mode)`;
  }

  /**
   * Private: Generate unique request ID
   */
  private generateRequestId(): string {
    return `psbridge-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Export singleton instance
export const powershellBridge = new PowerShellBridge();
