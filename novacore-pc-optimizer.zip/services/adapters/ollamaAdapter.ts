
// services/adapters/ollamaAdapter.ts

import { vault } from "../memoryVault";
import { cryptoEngine } from "../core/cryptoEngine";
import { CognitiveEvent } from "../types";

/**
 * Ollama API Request/Response interfaces
 */
export interface OllamaRequest {
  model: string;
  prompt: string;
  stream: boolean;
  context?: number[];
  temperature?: number;
  top_p?: number;
  top_k?: number;
}

export interface OllamaResponse {
  response: string;
  done: boolean;
  context?: number[];
  total_duration?: number;
  load_duration?: number;
  prompt_eval_count?: number;
  eval_count?: number;
}

export interface OllamaHealthCheck {
  isAlive: boolean;
  responseTime: number;
  timestamp: Date;
}

/**
 * OllamaAdapter - Local LLM inference with fallback support
 * 
 * Integrates with Phase 2 (strategy selection) and Phase 3 (trust boundaries)
 * Provides offline-first AI inference when Gemini is unavailable
 */
class OllamaAdapter {
  private baseUrl: string = "http://localhost:11434/api/generate";
  private healthCheckUrl: string = "http://localhost:11434/api/tags";
  private requestTimeout: number = 30000; // 30 seconds
  private maxRetries: number = 3;
  private retryDelayMs: number = 1000;

  /**
   * Generate a response using local Ollama instance
   * 
   * Implements Phase 2 pre-processing and Phase 3 trust verification
   * Falls back gracefully if Ollama is unavailable
   * 
   * @param prompt - The input prompt for inference
   * @param model - The model to use (default: mistral)
   * @param contextVector - Previous context for multi-turn conversations
   * @returns Generated response or fallback message
   */
  public async generateLocal(
    prompt: string,
    model: string = "mistral",
    contextVector?: number[]
  ): Promise<string> {
    const startTime = performance.now();
    const requestId = this.generateRequestId();

    try {
      // Phase 3: Verify trust boundary before processing
      const isTrusted = await cryptoEngine.verifyTrustBoundary(prompt);
      if (!isTrusted) {
        // Fix: changed 'warning' to 'warn'
        await vault.addLog(
          `Ollama Adapter [${requestId}]: Untrusted request rejected at boundary`,
          'warn'
        );
        return "TRUST_BOUNDARY_VIOLATION: Request rejected for security reasons.";
      }

      // Prepare request with context preservation
      const requestBody: OllamaRequest = {
        model,
        prompt: this.buildContextualPrompt(prompt),
        stream: false,
        context: contextVector,
        temperature: 0.7,
        top_p: 0.9,
        top_k: 40
      };

      // Attempt generation with retry logic
      const response = await this.requestWithRetry(
        this.baseUrl,
        requestBody,
        requestId
      );

      if (!response.ok) {
        throw new Error(
          `Ollama HTTP Error: ${response.status} ${response.statusText}`
        );
      }

      const data: OllamaResponse = await response.json();
      const duration = performance.now() - startTime;

      // Log successful inference
      await vault.addLog(
        `Ollama Adapter [${requestId}]: Generated response in ${duration.toFixed(0)}ms`,
        'info'
      );

      // Log cognitive event for Phase 4 monitoring
      await this.logCognitiveEvent({
        type: 'local_inference',
        model,
        requestId
      });

      return data.response;

    } catch (error) {
      const duration = performance.now() - startTime;
      const errorMsg = error instanceof Error ? error.message : String(error);

      await vault.addLog(
        `Ollama Adapter [${requestId}]: Local inference failed (${duration.toFixed(0)}ms) - ${errorMsg}`,
        'error'
      );

      // Return user-friendly fallback
      return this.generateFallbackResponse(model);
    }
  }

  /**
   * Check if Ollama service is responsive and healthy
   * 
   * Used by Phase 2 strategy selection to determine inference path
   * 
   * @returns Health check result with timing information
   */
  public async checkPulse(): Promise<OllamaHealthCheck> {
    const startTime = performance.now();
    
    try {
      const res = await Promise.race([
        fetch(this.healthCheckUrl),
        new Promise<Response>((_, reject) =>
          setTimeout(() => reject(new Error('Health check timeout')), 5000)
        )
      ]);

      const responseTime = performance.now() - startTime;
      const isAlive = res.ok;

      if (isAlive) {
        await vault.addLog(
          `Ollama Adapter: Health check passed (${responseTime.toFixed(0)}ms)`,
          'info'
        );
      }

      return {
        isAlive,
        responseTime,
        timestamp: new Date()
      };

    } catch (error) {
      const responseTime = performance.now() - startTime;
      // Fix: changed 'warning' to 'warn'
      await vault.addLog(
        `Ollama Adapter: Health check failed (${responseTime.toFixed(0)}ms)`,
        'warn'
      );

      return {
        isAlive: false,
        responseTime,
        timestamp: new Date()
      };
    }
  }

  /**
   * Stream response from Ollama for real-time display
   * 
   * Useful for long-running inference tasks
   * 
   * @param prompt - The input prompt
   * @param model - The model to use
   * @param onChunk - Callback for each streamed chunk
   */
  public async generateLocalStream(
    prompt: string,
    model: string = "mistral",
    onChunk?: (chunk: string) => void
  ): Promise<string> {
    try {
      const requestBody: OllamaRequest = {
        model,
        prompt: this.buildContextualPrompt(prompt),
        stream: true
      };

      const response = await fetch(this.baseUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
        signal: AbortSignal.timeout(this.requestTimeout)
      });

      if (!response.ok) throw new Error("Ollama instance unreachable.");

      let fullResponse = "";
      const reader = response.body?.getReader();

      if (!reader) throw new Error("No response body available");

      const decoder = new TextDecoder();
      let done = false;

      while (!done) {
        const { value, done: streamDone } = await reader.read();
        done = streamDone;

        if (value) {
          const text = decoder.decode(value, { stream: true });
          const lines = text.split('\n').filter(line => line.trim());

          for (const line of lines) {
            try {
              const json: OllamaResponse = JSON.parse(line);
              fullResponse += json.response;
              onChunk?.(json.response);
            } catch {
              // Skip non-JSON lines
            }
          }
        }
      }

      await vault.addLog(
        `Ollama Adapter: Streamed response completed (${fullResponse.length} chars)`,
        'info'
      );

      return fullResponse;

    } catch (error) {
      console.warn("Ollama Adapter: Streaming unavailable. Falling back to standard generation.");
      return this.generateFallbackResponse(model);
    }
  }

  /**
   * Private: Send request with exponential backoff retry logic
   */
  private async requestWithRetry(
    url: string,
    body: OllamaRequest,
    requestId: string,
    attempt: number = 1
  ): Promise<Response> {
    try {
      const response = await Promise.race([
        fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body)
        }),
        new Promise<Response>((_, reject) =>
          setTimeout(() => reject(new Error('Request timeout')), this.requestTimeout)
        )
      ]);

      return response;

    } catch (error) {
      if (attempt < this.maxRetries) {
        const delayMs = this.retryDelayMs * Math.pow(2, attempt - 1);
        // Fix: changed 'warning' to 'warn'
        await vault.addLog(
          `Ollama Adapter [${requestId}]: Retry ${attempt}/${this.maxRetries} in ${delayMs}ms`,
          'warn'
        );
        
        await this.delay(delayMs);
        return this.requestWithRetry(url, body, requestId, attempt + 1);
      }

      throw error;
    }
  }

  /**
   * Private: Build contextual prompt with system instructions
   */
  private buildContextualPrompt(userPrompt: string): string {
    return `[PhoenixBird Local Context - Ollama]\n[Model Role: Advanced System Assistant]\n\n${userPrompt}`;
  }

  /**
   * Private: Generate fallback response when Ollama is unavailable
   */
  private generateFallbackResponse(model: string): string {
    return `OLLAMA_OFFLINE: Local inference (${model}) is unavailable. Ensure Ollama is running on localhost:11434. Falling back to Gemini or offline mode.`;
  }

  /**
   * Private: Generate unique request ID for tracking
   */
  private generateRequestId(): string {
    return `ollama-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Private: Delay utility for retry logic
   */
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Private: Log cognitive event for Phase 4 monitoring
   */
  private async logCognitiveEvent(event: Partial<CognitiveEvent>): Promise<void> {
    try {
      const fullEvent: CognitiveEvent = {
        timestamp: new Date(),
        source: 'ollama_adapter',
        type: event.type || 'inference',
        ...event
      };

      // Send to cognition mapper for real-time tracking
      await vault.addLog(
        `Cognitive Event: ${JSON.stringify(fullEvent)}`,
        'debug'
      );
    } catch (error) {
      console.warn("Failed to log cognitive event:", error);
    }
  }
}

// Export singleton instance
export const ollamaAdapter = new OllamaAdapter();
