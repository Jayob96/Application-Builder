
import { powershellBridge } from "./powershellBridge";
import { pythonBridge } from "./pythonBridge";
import { vault } from "../memoryVault";

export interface NativeOSInfo {
  platform: 'win32' | 'darwin' | 'linux';
  arch: string;
  isDesktop: boolean;
}

class NativeBridge {
  private osInfo: NativeOSInfo | null = null;

  public async getOSInfo(): Promise<NativeOSInfo> {
    if (this.osInfo) return this.osInfo;
    
    // Check if running inside Electron
    const isDesktop = typeof window !== 'undefined' && 'process' in window;
    
    if (isDesktop) {
      const process = (window as any).process;
      this.osInfo = {
        platform: process.platform,
        arch: process.arch,
        isDesktop: true
      };
    } else {
      this.osInfo = {
        platform: navigator.userAgent.toLowerCase().includes('win') ? 'win32' : 'linux',
        arch: 'web',
        isDesktop: false
      };
    }
    
    return this.osInfo;
  }

  /**
   * Execute optimized system logic based on host OS
   */
  public async executeOptimization(intent: string): Promise<any> {
    const os = await this.getOSInfo();
    await vault.addLog(`NativeBridge: Executing intent ${intent} on ${os.platform}`, 'info');

    if (os.platform === 'win32') {
      return powershellBridge.executePowerShellBridge({ intent });
    } else {
      // macOS and Linux fall back to Python-based system automation
      return pythonBridge.generatePythonBridge({ task: `OS_OPTIMIZE_${intent}` });
    }
  }

  /**
   * Triggers a native system alert/notification
   */
  public notify(title: string, body: string) {
    if (Notification.permission === 'granted') {
      new Notification(title, { body, icon: './assets/icon.png' });
    }
  }
}

export const nativeBridge = new NativeBridge();
