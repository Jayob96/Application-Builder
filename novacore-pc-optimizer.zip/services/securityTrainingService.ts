import {
  ThreatPattern,
  TrainingProgress,
  MutationMatrixState,
  SystemSpecs,
  LogicEvolution,
} from "../types";
import { trainSecurityModel, evolveSystemLogic } from "./geminiService";
import { vault } from "./memoryVault";

export const THREAT_DATASET: ThreatPattern[] = [
  {
    id: "T-01",
    name: "Kernel Hook Intercept",
    vector: "Instruction Pointer Redirection",
    complexity: 0.85,
    description: "Attempts to redirect system calls to shadow kernel binaries.",
    signature: "0x88 0xAF 0xDE [JMP_SHADOW_KRNL] 0x00 0xFF",
  },
  {
    id: "T-02",
    name: "Polymorphic Heap Overflow",
    vector: "Memory Corruption",
    complexity: 0.92,
    description: "Dynamic buffer exhaustion targeting browser memory pools.",
    signature: "MALLOC_OVERRIDE(8192) + NOP_SLED(4096) + PAYLOAD_ROT(13)",
  },
  {
    id: "T-03",
    name: "Lateral SMB Pivot",
    vector: "Network Propagation",
    complexity: 0.74,
    description: "Unauthorized port 445 relaying using stolen identity tokens.",
    signature: "SMB_TREE_CONNECT(0x01) -> IPC$ -> TOKEN_STEAL",
  },
  {
    id: "T-04",
    name: "Spectre-V5 Speculation",
    vector: "Side-Channel Leak",
    complexity: 0.98,
    description: "Exfiltrating kernel memory via branch prediction timing analysis.",
    signature: "BRANCH_PREDICT_FAIL -> CACHE_PROBE(L1D) -> TIMING_DELTA",
  },
  {
    id: "T-05",
    name: "Instruction Shim Overlay",
    vector: "CPU Logic Bypass",
    complexity: 0.95,
    description: "Injecting hidden Opcodes into signed binaries to bypass ring-0 checks.",
    signature: "0x0F 0x3F 0xDE [OP_OVERRIDE] 0x90 0x90",
  },
];

export interface EpochRunResult {
  threat: ThreatPattern;
  result: unknown;
  progress: TrainingProgress;
  matrix: MutationMatrixState;
  evolution: LogicEvolution;
}

class SecurityTrainingService {
  private matrix: MutationMatrixState = {
    grid: Array.from({ length: 10 }, () =>
      Array.from({ length: 10 }, () => this.randHex()),
    ),
    stability: 45,
    mutationDepth: 12.4,
  };

  private evolution: LogicEvolution = {
    version: "1.4.2",
    complexity: 64,
    lastMutation: Date.now(),
    evolutionPath: ["GEN_01", "KRNL_OPT_A"],
    stabilityIndex: 88,
  };

  private progress: TrainingProgress = {
    epoch: 0,
    accuracy: 68.4,
    loss: 0.4211,
    entropyDivergence: 0.88,
    activeThreatId: null,
  };

  private randHex(): string {
    return Math.floor(Math.random() * 0xff)
      .toString(16)
      .toUpperCase()
      .padStart(2, "0");
  }

  public getMatrix(): MutationMatrixState {
    return this.matrix;
  }

  public getProgress(): TrainingProgress {
    return this.progress;
  }

  public getEvolution(): LogicEvolution {
    return this.evolution;
  }

  public seedEntropy(x: number, y: number): void {
    const col = Math.floor((x % 500) / 50);
    const row = Math.floor((y % 500) / 50);
    if (this.matrix.grid[row] && this.matrix.grid[row][col]) {
      this.matrix.grid[row][col] = this.randHex();
      this.matrix.mutationDepth += 0.05;
    }
  }

  public shiftMatrix(): void {
    this.matrix.grid = this.matrix.grid.map(row =>
      row.map(cell => (Math.random() > 0.95 ? this.randHex() : cell)),
    );
  }

  public async runEpoch(specs: SystemSpecs | null): Promise<EpochRunResult | null> {
    this.progress.epoch += 1;
    const threat =
      THREAT_DATASET[Math.floor(Math.random() * THREAT_DATASET.length)];
    this.progress.activeThreatId = threat.id;

    try {
      const result = await trainSecurityModel(specs, threat, this.progress);

      const gain = (result as any).accuracyGain ?? 1.5;
      this.progress.accuracy = Math.min(100, this.progress.accuracy + gain);
      this.progress.loss *= 1 - gain / 20;
      this.progress.entropyDivergence *= 0.98;

      this.matrix.mutationDepth += 0.8;
      this.matrix.stability = Math.min(100, this.matrix.stability + 0.5);

      if (
        this.progress.accuracy > 92 &&
        !this.evolution.evolutionPath.includes(`EVO_${this.progress.epoch}`)
      ) {
        await this.evolveLogic(specs);
      }

      return {
        threat,
        result,
        progress: { ...this.progress },
        matrix: { ...this.matrix },
        evolution: { ...this.evolution },
      };
    } catch (e) {
      console.error("[SecurityTraining] Epoch synthesis failed", e);
      return null;
    }
  }

  private async evolveLogic(specs: SystemSpecs | null): Promise<void> {
    try {
      const evolution = await evolveSystemLogic(specs, this.evolution);

      this.evolution.version =
        evolution.nextVersion ?? `${this.evolution.version}.1`;
      this.evolution.complexity += 4;
      this.evolution.lastMutation = Date.now();
      this.evolution.evolutionPath.push(
        `KRNL_REV_${this.evolution.version}`,
      );
      this.evolution.stabilityIndex = Math.min(
        100,
        this.evolution.stabilityIndex + (evolution.stabilityImpact ?? 2),
      );

      await vault.saveFile(
        `C:/NovaCore/Kernel/logic_v${this.evolution.version}.sys`,
        evolution.binary ?? "0xDE_AD_BE_EF",
      );
      await vault.addLog(
        `AUTONOMOUS_MUTATION: Core evolved to version ${this.evolution.version}`,
        "info",
      );
      vault.rotateKey();
    } catch (e) {
      console.error("[SecurityTraining] Evolution cycle collapsed", e);
    }
  }
}

export const trainingLab = new SecurityTrainingService();
