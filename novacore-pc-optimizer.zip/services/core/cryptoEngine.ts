
import { vault } from "../memoryVault";
import { cognitiveMap } from "./cognitiveMap";

export interface CryptoSignature {
  signature: string;
  algorithm: 'HMAC-SHA256' | 'SHA256' | 'RSA-SHA256';
  timestamp: number;
  keyId: string;
  verified: boolean;
}

export interface TrustVerificationResult {
  isTrusted: boolean;
  reason: string;
  confidence: number;
  signature?: CryptoSignature;
  riskFactors?: string[];
}

class CryptoEngine {
  private readonly hmacSecret = "dev-secret-logic-vault-001";
  private readonly masterKeyId = 'phoenixbird_master_001';
  private keyRotationInterval: number = 24 * 60 * 60 * 1000;
  private activeKeys: Map<string, string> = new Map();

  constructor() {
    this.activeKeys.set(this.masterKeyId, this.hmacSecret);
  }

  public async generateHMAC(message: string, keyId: string = this.masterKeyId): Promise<CryptoSignature> {
    const secret = this.activeKeys.get(keyId) || this.hmacSecret;
    const encoder = new TextEncoder();
    const keyData = encoder.encode(secret);
    const data = encoder.encode(message);

    const cryptoKey = await window.crypto.subtle.importKey(
      'raw',
      keyData,
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );

    const signature = await window.crypto.subtle.sign('HMAC', cryptoKey, data);
    const signatureHex = Array.from(new Uint8Array(signature))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');

    return {
      signature: signatureHex,
      algorithm: 'HMAC-SHA256',
      timestamp: Date.now(),
      keyId,
      verified: true
    };
  }

  public async verifyHMAC(message: string, signature: string, keyId: string): Promise<TrustVerificationResult> {
    const generated = await this.generateHMAC(message, keyId);
    const isValid = generated.signature === signature.replace('HMAC_', '');
    
    return {
      isTrusted: isValid,
      reason: isValid ? 'Signature verified' : 'Invalid HMAC signature',
      confidence: isValid ? 1.0 : 0.1
    };
  }

  public async hashData(data: string): Promise<string> {
    const encoder = new TextEncoder();
    const hashBuffer = await window.crypto.subtle.digest('SHA-256', encoder.encode(data));
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  public async signData(data: string): Promise<string> {
    const sig = await this.generateHMAC(data);
    return sig.signature;
  }

  public async verifyTrustBoundary(data: string | object): Promise<TrustVerificationResult> {
    const message = typeof data === 'string' ? data : JSON.stringify(data);
    const entropyScore = this.calculateEntropy(message);
    
    if (entropyScore > 7.9) {
      return {
        isTrusted: false,
        reason: 'Excessive entropy detected',
        confidence: 0.05
      };
    }

    return {
      isTrusted: true,
      reason: 'Boundary verified',
      confidence: 1.0
    };
  }

  private calculateEntropy(text: string): number {
    const len = text.length;
    if (len === 0) return 0;
    const freq: Record<string, number> = {};
    for (let i = 0; i < len; i++) {
      freq[text[i]] = (freq[text[i]] || 0) + 1;
    }
    let entropy = 0;
    for (const char in freq) {
      const p = freq[char] / len;
      entropy -= p * Math.log2(p);
    }
    return entropy;
  }
}

export const cryptoEngine = new CryptoEngine();
