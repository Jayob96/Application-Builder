
// services/core/cognitiveMap.ts
// PhoenixBird Phase 4: Real-Time Cognition Tracking & Analysis

import { vault } from "../memoryVault";
import { cryptoEngine } from "./cryptoEngine";
import { ragRetrieval } from "./ragRetrieval";

/**
 * Core cognition interfaces (shared across PhoenixBird)
 */
export interface CognitionNode {
  id: string;
  decision: string;
  confidence: number;  // 0-1
  timestamp: number;
  source: 'firewall' | 'ollama' | 'powershell' | 'python' | 'gemini' | 'strategy';
  category: 'threat' | 'optimization' | 'inference' | 'execution' | 'learning';
  contextHash?: string;  // Cryptographic context ID
  impactScore?: number;  // 0-10 business impact
  relatedNodes?: string[];  // Node ID references
}

export interface CognitiveEvent {
  timestamp: Date;
  source: string;
  type: string;
  confidence?: number;
  metadata?: Record<string, any>;
  requestId?: string;
}

export interface CognitionPattern {
  patternId: string;
  description: string;
  frequency: number;
  confidenceTrend: number[];
  firstSeen: number;
  lastSeen: number;
}

export interface MapAnalytics {
  totalNodes: number;
  activePatterns: number;
  avgConfidence: number;
  threatDensity: number;
  recentActivity: number;  // nodes/hour
  anomalyScore: number;
}

/**
 * CognitiveMap - Phase 4 Real-Time System Awareness
 * 
 * Tracks all AI decisions across PhoenixBird components
 * Detects behavioral patterns and anomalies
 * Provides Phase 4 training data for model improvement
 */
class CognitiveMap {
  private map: CognitionNode[] = [];
  private patterns: CognitionPattern[] = [];
  private maxMapSize: number = 10000;  // 10k nodes (~1 week at high volume)
  private patternDecay: number = 0.95;  // Daily confidence decay

  constructor() {
    this.startPatternDetection();
    this.startAnalyticsRefresh();
    this.loadHistoricalMap();
  }

  /**
   * Track a cognitive decision (main public API)
   * 
   * Called by all adapters/services after decisions
   */
  public async track(
    decision: string, 
    confidence: number,
    source: CognitionNode['source'],
    category: CognitionNode['category'],
    context?: Record<string, any>,
    impactScore?: number
  ): Promise<string> {
    const nodeId = this.generateNodeId();
    const contextHash = context ? await cryptoEngine.hashData(JSON.stringify(context)) : undefined;

    const node: CognitionNode = {
      id: nodeId,
      decision,
      confidence,
      timestamp: Date.now(),
      source,
      category,
      contextHash,
      impactScore: impactScore || this.calculateImpact(confidence, category)
    };

    // Add to map with bounds checking
    this.map.push(node);
    if (this.map.length > this.maxMapSize) {
      this.map.shift();
    }

    // Extract patterns
    await this.extractPatterns(node);

    // Persist critical nodes
    await this.persistNode(node);

    // Log for vault auditing
    await vault.addLog(
      `CognitiveMap: Tracked ${source}/${category} [${nodeId}] confidence:${confidence.toFixed(2)}`,
      'debug'
    );

    return nodeId;
  }

  /**
   * Get current cognitive map snapshot
   */
  public getMap(filter?: Partial<CognitionNode>): CognitionNode[] {
    if (!filter) return this.map.slice(-100);  // Recent 100 by default
    
    return this.map.filter(node => {
      return Object.entries(filter).every(([key, value]) => 
        node[key as keyof CognitionNode] === value
      );
    });
  }

  /**
   * Get real-time analytics dashboard data
   */
  public getAnalytics(): MapAnalytics {
    const recent = this.map.slice(-1000);
    const threatNodes = recent.filter(n => n.category === 'threat');
    const avgConfidence = recent.reduce((sum, n) => sum + n.confidence, 0) / recent.length;
    
    return {
      totalNodes: this.map.length,
      activePatterns: this.patterns.length,
      avgConfidence: Number(avgConfidence.toFixed(3)),
      threatDensity: (threatNodes.length / recent.length) * 100,
      recentActivity: this.calculateActivityRate(recent),
      anomalyScore: this.detectAnomalies(recent)
    };
  }

  /**
   * Query cognitive patterns for Phase 4 training
   */
  public getPatterns(minFrequency: number = 3): CognitionPattern[] {
    return this.patterns.filter(p => p.frequency >= minFrequency);
  }

  /**
   * Export map data for fine-tuning (Phase 4)
   */
  public async exportForTraining(): Promise<CognitionNode[]> {
    // Filter high-confidence, high-impact decisions
    const trainingData = this.map.filter(node => 
      node.confidence > 0.8 && node.impactScore! > 5
    );
    
    await vault.addLog(`CognitiveMap: Exported ${trainingData.length} nodes for Phase 4 training`, 'info');
    return trainingData.slice(-5000);  // Last 5k high-quality samples
  }

  /**
   * Private: Pattern detection engine
   */
  private async extractPatterns(node: CognitionNode): Promise<void> {
    const decisionHash = await cryptoEngine.hashData(node.decision);
    
    // Look for repeating decision patterns
    const similarNodes = this.map.filter(n => 
      n.decision.includes(node.decision.slice(0, 20)) && 
      Math.abs(n.timestamp - node.timestamp) < 3600000  // Within 1 hour
    );

    if (similarNodes.length >= 3) {
      const patternId = `PAT_${decisionHash.slice(0, 8)}`;
      const existingPattern = this.patterns.find(p => p.patternId === patternId);
      
      if (existingPattern) {
        existingPattern.frequency += 1;
        existingPattern.confidenceTrend.push(node.confidence);
        existingPattern.lastSeen = node.timestamp;
        if (existingPattern.confidenceTrend.length > 50) {
          existingPattern.confidenceTrend.shift();
        }
      } else {
        this.patterns.push({
          patternId,
          description: `${node.source} repeating: ${node.decision.slice(0, 50)}`,
          frequency: 1,
          confidenceTrend: [node.confidence],
          firstSeen: node.timestamp,
          lastSeen: node.timestamp
        });
      }

      // Decay old patterns
      this.patterns = this.patterns.filter(p => p.frequency > 1);
    }
  }

  /**
   * Private: Continuous analytics refresh
   */
  private startAnalyticsRefresh(): void {
    setInterval(() => {
      // Decay pattern confidence weekly
      this.patterns.forEach(p => {
        p.confidenceTrend = p.confidenceTrend.map(c => c * this.patternDecay);
      });
    }, 24 * 60 * 60 * 1000);  // Daily
  }

  /**
   * Private: Pattern detection background process
   */
  private startPatternDetection(): void {
    setInterval(async () => {
      await this.extractPatternsFromRecent();
    }, 30000);  // Every 30 seconds
  }

  /**
   * Extract patterns from the recent history of nodes
   */
  private async extractPatternsFromRecent(): Promise<void> {
    const recentNodes = this.map.slice(-100);
    for (const node of recentNodes) {
      await this.extractPatterns(node);
    }
  }

  /**
   * Private: Load historical map from vault
   */
  private async loadHistoricalMap(): Promise<void> {
    try {
      const historical = await vault.readFile('cognitive_map_backup.json');
      if (historical) {
        const nodes: CognitionNode[] = JSON.parse(historical);
        this.map.push(...nodes.slice(-1000));  // Load recent 1k
        await vault.addLog(`CognitiveMap: Loaded ${nodes.length} historical nodes`, 'info');
      }
    } catch (error) {
      console.debug('No historical map found');
    }
  }

  /**
   * Private: Persist critical nodes
   */
  private async persistNode(node: CognitionNode): Promise<void> {
    try {
      if (node.impactScore! > 7) {
        await vault.saveFile(
          `cognitive_map/${node.id}.json`, 
          JSON.stringify(node)
        );
        
        // Backup map hourly
        if (this.map.length % 3600 === 0) {
          await vault.saveFile('cognitive_map_backup.json', JSON.stringify(this.map.slice(-5000)));
        }
      }
    } catch (error) {
      console.warn('CognitiveMap persistence failed:', error);
    }
  }

  // Utility calculations
  private calculateImpact(confidence: number, category: string): number {
    const baseImpact: Record<string, number> = { threat: 10, optimization: 6, inference: 4, execution: 3, learning: 8 };
    const impact = baseImpact[category] || 2;
    return Math.floor(impact * confidence * 10) / 10;
  }

  private calculateActivityRate(recent: CognitionNode[]): number {
    const hourAgo = Date.now() - 3600000;
    const recentCount = recent.filter(n => n.timestamp > hourAgo).length;
    return Math.floor((recentCount / 3600) * 1000);  // nodes per hour
  }

  private detectAnomalies(recent: CognitionNode[]): number {
    if (recent.length === 0) return 0;
    const avgConfidence = recent.reduce((sum, n) => sum + n.confidence, 0) / recent.length;
    const stdDev = this.calculateStdDev(recent.map(n => n.confidence));
    return stdDev > 0.2 ? 0.8 : 0.1;  // High variance = anomaly
  }

  private calculateStdDev(numbers: number[]): number {
    if (numbers.length === 0) return 0;
    const mean = numbers.reduce((a, b) => a + b) / numbers.length;
    return Math.sqrt(numbers.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / numbers.length);
  }

  private generateNodeId(): string {
    return `COG_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Search map by decision content (RAG integration)
   */
  public async searchMap(query: string): Promise<CognitionNode[]> {
    // Simplified similarity search (full impl in Phase 1)
    return this.map.filter(node => 
      node.decision.toLowerCase().includes(query.toLowerCase())
    ).slice(0, 10);
  }
}

// Export singleton instance
export const cognitiveMap = new CognitiveMap();
