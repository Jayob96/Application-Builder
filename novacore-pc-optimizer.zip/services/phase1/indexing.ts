
// services/phase1/indexing.ts
// PhoenixBird Phase 1: Semantic Index & Search

import { vault } from "../memoryVault";
import { cryptoEngine } from "../core/cryptoEngine";
import { cognitiveMap } from "../core/cognitiveMap";
import { TelemetryChunk } from "../../types";

/**
 * Index search result with ranking
 */
export interface IndexSearchResult {
  chunk: TelemetryChunk;
  relevanceScore: number;
  matchType: 'keyword' | 'semantic' | 'entropy';
  metadata?: Record<string, any>;
}

/**
 * Index statistics
 */
export interface IndexStatistics {
  totalChunks: number;
  indexSize: number;
  avgChunkSize: number;
  entropy: {
    min: number;
    max: number;
    avg: number;
  };
  lastBuilt: number;
}

/**
 * TelemetryIndex - Phase 1 Semantic Search Layer
 * 
 * In-memory inverted index for fast keyword search
 * Bridges to FAISS for semantic similarity
 * Provides hybrid search capabilities
 */
class TelemetryIndex {
  private index: Map<string, TelemetryChunk> = new Map();
  private keywordIndex: Map<string, Set<string>> = new Map();  // word -> chunk IDs
  private lastBuiltTime: number = 0;
  private readonly maxIndexSize = 50000;  // 50k chunks

  constructor() {
    this.initializeKeywordIndex();
  }

  /**
   * Build index from chunks
   */
  public async buildIndex(chunks: TelemetryChunk[]): Promise<IndexStatistics> {
    const requestId = this.generateRequestId();
    const startTime = performance.now();

    try {
      // Clear existing index
      this.index.clear();
      this.keywordIndex.clear();

      let processedCount = 0;

      for (const chunk of chunks) {
        // Size limit enforcement
        if (this.index.size >= this.maxIndexSize) {
          await vault.addLog(
            `TelemetryIndex [${requestId}]: Index size limit reached`,
            'warn'
          );
          break;
        }

        // Phase 3: Verify chunk integrity
        const trustResult = await cryptoEngine.verifyTrustBoundary(chunk.text);
        if (!trustResult.isTrusted) {
          await vault.addLog(
            `TelemetryIndex [${requestId}]: Untrusted chunk ${chunk.chunkId} rejected`,
            'warn'
          );
          continue;
        }

        // Add to main index
        this.index.set(chunk.chunkId, chunk);

        // Build keyword index
        this.indexKeywords(chunk);

        processedCount++;
      }

      // Compute statistics
      const stats = this.computeStatistics();
      this.lastBuiltTime = Date.now();

      // Cognitive tracking
      // Fix: changed 'embedding' to 'gemini' as 'embedding' is not a valid source
      await cognitiveMap.track(
        `Built index with ${processedCount} chunks`,
        0.99,
        'gemini',
        'learning',
        {
          processedChunks: processedCount,
          indexSize: this.index.size,
          buildTime: performance.now() - startTime
        },
        5
      );

      await vault.addLog(
        `TelemetryIndex [${requestId}]: Built index with ${processedCount} chunks (${(performance.now() - startTime).toFixed(0)}ms)`,
        'info'
      );

      return stats;

    } catch (error) {
      await vault.addLog(`TelemetryIndex build failed [${requestId}]: ${error}`, 'error');
      throw error;
    }
  }

  /**
   * Keyword search (fast, recall-focused)
   */
  public search(query: string, limit: number = 5): TelemetryChunk[] {
    const queryLower = query.toLowerCase();
    const results = new Map<string, number>();  // chunkId -> score

    // Extract keywords from query
    const keywords = this.extractKeywords(queryLower);

    // Find chunks matching keywords
    for (const keyword of keywords) {
      const chunkIds = this.keywordIndex.get(keyword);
      if (chunkIds) {
        for (const chunkId of chunkIds) {
          const currentScore = results.get(chunkId) || 0;
          results.set(chunkId, currentScore + 1);  // Boost for each keyword hit
        }
      }
    }

    // Also check for substring matches
    this.index.forEach((chunk, chunkId) => {
      if (chunk.text.toLowerCase().includes(queryLower)) {
        const currentScore = results.get(chunkId) || 0;
        results.set(chunkId, currentScore + 0.5);  // Lower boost for substring
      }
    });

    // Convert to results and sort by relevance
    const sortedResults = Array.from(results.entries())
      .map(([chunkId, score]) => {
        const chunk = this.index.get(chunkId);
        return { chunk: chunk!, relevanceScore: score, matchType: 'keyword' as const };
      })
      .sort((a, b) => b.relevanceScore - a.relevanceScore)
      .slice(0, limit);

    return sortedResults.map(r => r.chunk);
  }

  /**
   * Advanced search with filters
   */
  public advancedSearch(
    query: string,
    filters?: {
      minEntropy?: number;
      maxEntropy?: number;
      source?: string;
      limit?: number;
    }
  ): IndexSearchResult[] {
    const limit = filters?.limit || 10;
    const results: IndexSearchResult[] = [];

    // Keyword search baseline
    const keywordResults = this.search(query, limit * 2);

    for (const chunk of keywordResults) {
      // Apply filters
      if (filters?.minEntropy && chunk.entropy < filters.minEntropy) continue;
      if (filters?.maxEntropy && chunk.entropy > filters.maxEntropy) continue;

      const relevanceScore = query.toLowerCase().split(' ')
        .filter(word => chunk.text.toLowerCase().includes(word))
        .length / query.split(' ').length;

      results.push({
        chunk,
        relevanceScore,
        matchType: 'keyword'
      });
    }

    return results.slice(0, limit);
  }

  /**
   * Entropy-based search (find anomalies/high-info chunks)
   */
  public searchByEntropy(
    minEntropy: number,
    maxEntropy: number = 8,
    limit: number = 5
  ): TelemetryChunk[] {
    const results: TelemetryChunk[] = [];

    this.index.forEach(chunk => {
      if (chunk.entropy >= minEntropy && chunk.entropy <= maxEntropy) {
        results.push(chunk);
      }
    });

    // Sort by entropy (descending)
    return results
      .sort((a, b) => (b.entropy || 0) - (a.entropy || 0))
      .slice(0, limit);
  }

  /**
   * Get chunks by source
   */
  public getBySource(source: string, limit: number = 10): TelemetryChunk[] {
    const results: TelemetryChunk[] = [];

    this.index.forEach(chunk => {
      if (chunk.corpusId.includes(source) || chunk.metadata?.source === source) {
        results.push(chunk);
      }
    });

    return results.slice(0, limit);
  }

  /**
   * Get index statistics
   */
  public getStatistics(): IndexStatistics {
    return this.computeStatistics();
  }

  /**
   * Clear index
   */
  public async clear(): Promise<void> {
    this.index.clear();
    this.keywordIndex.clear();
    await vault.addLog('TelemetryIndex: Cleared', 'info');
  }

  /**
   * Export index for backup
   */
  public async exportIndex(): Promise<string> {
    const exportData = {
      chunks: Array.from(this.index.values()),
      keywords: Object.fromEntries(
        Array.from(this.keywordIndex.entries()).map(([k, v]) => [k, Array.from(v)])
      ),
      timestamp: Date.now()
    };

    return JSON.stringify(exportData);
  }

  /**
   * Import index from backup
   */
  public async importIndex(data: string): Promise<void> {
    try {
      const importData = JSON.parse(data);
      
      this.index.clear();
      this.keywordIndex.clear();

      // Restore chunks
      for (const chunk of importData.chunks) {
        this.index.set(chunk.chunkId, chunk);
        this.indexKeywords(chunk);
      }

      // Restore keywords
      for (const [keyword, chunkIds] of Object.entries(importData.keywords)) {
        this.keywordIndex.set(keyword, new Set(chunkIds as string[]));
      }

      await vault.addLog('TelemetryIndex: Imported successfully', 'info');
    } catch (error) {
      await vault.addLog(`Import failed: ${error}`, 'error');
      throw error;
    }
  }

  // Private utilities
  private initializeKeywordIndex(): void {
    // Pre-populate with common system keywords
    const commonKeywords = [
      'cpu', 'memory', 'disk', 'network', 'process', 'thread',
      'error', 'warning', 'info', 'debug', 'critical',
      'thermal', 'performance', 'optimization', 'threat', 'security'
    ];

    for (const keyword of commonKeywords) {
      this.keywordIndex.set(keyword, new Set());
    }
  }

  private indexKeywords(chunk: TelemetryChunk): void {
    const keywords = this.extractKeywords(chunk.text.toLowerCase());

    for (const keyword of keywords) {
      if (!this.keywordIndex.has(keyword)) {
        this.keywordIndex.set(keyword, new Set());
      }
      this.keywordIndex.get(keyword)!.add(chunk.chunkId);
    }
  }

  private extractKeywords(text: string): string[] {
    return text
      .match(/\b\w{3,}\b/g) || []  // Words 3+ chars
      .filter(word => !this.isStopword(word))
      .slice(0, 20);  // Limit keywords
  }

  private isStopword(word: string): boolean {
    const stopwords = new Set([
      'the', 'and', 'for', 'are', 'but', 'not', 'can', 'has', 'you', 'all',
      'this', 'that', 'with', 'from', 'was', 'were', 'been', 'have', 'will'
    ]);
    return stopwords.has(word);
  }

  private computeStatistics(): IndexStatistics {
    const chunks = Array.from(this.index.values());
    const entropies = chunks.map(c => c.entropy);

    return {
      totalChunks: chunks.length,
      indexSize: chunks.reduce((sum, c) => sum + c.text.length, 0),
      avgChunkSize: chunks.length > 0 ? chunks.reduce((sum, c) => sum + c.text.length, 0) / chunks.length : 0,
      entropy: {
        min: Math.min(...entropies, 0),
        max: Math.max(...entropies, 0),
        avg: entropies.length > 0 ? entropies.reduce((a, b) => a + b, 0) / entropies.length : 0
      },
      lastBuilt: this.lastBuiltTime
    };
  }

  private generateRequestId(): string {
    return `index-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Export singleton instance
export const telemetryIndex = new TelemetryIndex();
