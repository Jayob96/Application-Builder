
// services/phase1/chunkingEngine.ts
// PhoenixBird Phase 1: Semantic Text Chunking & Preparation

import { vault } from "../memoryVault";
import { cryptoEngine } from "../core/cryptoEngine";
import { cognitiveMap } from "../core/cognitiveMap";
import { CorpusEntry, TelemetryChunk } from "../../types";

/**
 * Chunking strategy interfaces
 */
export interface ChunkingStrategy {
  name: string;
  maxChunkSize: number;
  overlapSize: number;
  strategy: 'fixed' | 'semantic' | 'sentence' | 'paragraph';
}

export interface ChunkingMetrics {
  totalChunks: number;
  avgChunkSize: number;
  entropyStats: {
    min: number;
    max: number;
    avg: number;
  };
  processingTime: number;
}

/**
 * ChunkingEngine - Phase 1 Text Segmentation
 * 
 * Splits corpus entries into semantic chunks for embedding/RAG
 * Supports multiple strategies: fixed-size, semantic boundaries, sentences
 */
class ChunkingEngine {
  private readonly defaultStrategy: ChunkingStrategy = {
    name: 'semantic_overlap',
    maxChunkSize: 512,  // Characters
    overlapSize: 100,   // Overlap for context preservation
    strategy: 'semantic'
  };

  constructor() {
    this.validateStrategies();
  }

  /**
   * Split corpus entries into semantic chunks
   */
  public async splitToSemanticChunks(
    entries: CorpusEntry[],
    strategy?: ChunkingStrategy
  ): Promise<TelemetryChunk[]> {
    const requestId = this.generateRequestId();
    const startTime = performance.now();

    try {
      const strat = strategy || this.defaultStrategy;
      const chunks: TelemetryChunk[] = [];

      for (const entry of entries) {
        // Phase 3: Trust verification
        const trustResult = await cryptoEngine.verifyTrustBoundary(entry.raw);
        if (!trustResult.isTrusted) {
          await vault.addLog(
            `ChunkingEngine: Untrusted corpus entry ${entry.id} rejected`,
            'warn'
          );
          continue;
        }

        // Apply selected chunking strategy
        const entryChunks = await this.applyChunkingStrategy(entry, strat);
        chunks.push(...entryChunks);
      }

      // Compute metrics
      const metrics = this.computeChunkingMetrics(chunks, performance.now() - startTime);

      // Cognitive tracking
      // Fix: changed 'embedding' to 'gemini' as 'embedding' is not a valid source
      await cognitiveMap.track(
        `Chunking complete: ${chunks.length} chunks from ${entries.length} entries`,
        0.98,
        'gemini',
        'learning',
        { 
          strategy: strat.name, 
          totalChunks: chunks.length, 
          avgSize: metrics.avgChunkSize 
        },
        7
      );

      await vault.addLog(
        `ChunkingEngine [${requestId}]: Generated ${chunks.length} chunks (${metrics.processingTime.toFixed(0)}ms)`,
        'info'
      );

      return chunks;

    } catch (error) {
      await vault.addLog(`ChunkingEngine failed [${requestId}]: ${error}`, 'error');
      throw error;
    }
  }

  /**
   * Apply specific chunking strategy
   */
  private async applyChunkingStrategy(
    entry: CorpusEntry, 
    strategy: ChunkingStrategy
  ): Promise<TelemetryChunk[]> {
    switch (strategy.strategy) {
      case 'fixed':
        return this.fixedSizeChunking(entry, strategy.maxChunkSize, strategy.overlapSize);
      
      case 'semantic':
        return this.semanticChunking(entry, strategy.maxChunkSize, strategy.overlapSize);
      
      case 'sentence':
        return this.sentenceChunking(entry, strategy.maxChunkSize);
      
      case 'paragraph':
        return this.paragraphChunking(entry, strategy.maxChunkSize);
      
      default:
        return this.fixedSizeChunking(entry, strategy.maxChunkSize, strategy.overlapSize);
    }
  }

  /**
   * Fixed-size chunking with overlap
   */
  private fixedSizeChunking(
    entry: CorpusEntry, 
    maxSize: number, 
    overlap: number
  ): TelemetryChunk[] {
    const chunks: TelemetryChunk[] = [];
    const text = entry.raw;
    
    let position = 0;
    let chunkIndex = 0;

    while (position < text.length) {
      const end = Math.min(position + maxSize, text.length);
      const chunkText = text.substring(position, end);
      
      const chunk: TelemetryChunk = {
        chunkId: `${entry.id}_CH_${chunkIndex}`,
        corpusId: entry.id,
        text: chunkText,
        entropy: this.calculateEntropy(chunkText),
        timestamp: Date.now(),
        metadata: { strategy: 'fixed', size: chunkText.length }
      };

      chunks.push(chunk);
      position = end - overlap;  // Overlap for context
      chunkIndex++;
    }

    return chunks;
  }

  /**
   * Semantic boundary chunking (sentence/paragraph breaks)
   */
  private semanticChunking(
    entry: CorpusEntry, 
    maxSize: number, 
    overlap: number
  ): TelemetryChunk[] {
    const chunks: TelemetryChunk[] = [];
    const text = entry.raw;
    
    // Split by sentence boundaries (. ! ?)
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
    
    let currentChunk = '';
    let chunkIndex = 0;
    const overlapBuffer: string[] = [];

    for (const sentence of sentences) {
      // Check if adding sentence would exceed max size
      if ((currentChunk + sentence).length > maxSize && currentChunk.length > 0) {
        // Save current chunk
        chunks.push({
          chunkId: `${entry.id}_CH_${chunkIndex}`,
          corpusId: entry.id,
          text: currentChunk.trim(),
          entropy: this.calculateEntropy(currentChunk),
          timestamp: Date.now(),
          metadata: { strategy: 'semantic', size: currentChunk.length }
        });

        // Prepare overlap
        overlapBuffer.push(sentence);
        if (overlapBuffer.length > 2) overlapBuffer.shift();

        currentChunk = overlapBuffer.join(' ');
        chunkIndex++;
      } else {
        currentChunk += sentence;
      }
    }

    // Handle remaining text
    if (currentChunk.trim().length > 0) {
      chunks.push({
        chunkId: `${entry.id}_CH_${chunkIndex}`,
        corpusId: entry.id,
        text: currentChunk.trim(),
        entropy: this.calculateEntropy(currentChunk),
        timestamp: Date.now(),
        metadata: { strategy: 'semantic', size: currentChunk.length }
      });
    }

    return chunks;
  }

  /**
   * Sentence-based chunking
   */
  private sentenceChunking(
    entry: CorpusEntry, 
    maxSize: number
  ): TelemetryChunk[] {
    const chunks: TelemetryChunk[] = [];
    const sentences = entry.raw.match(/[^.!?]+[.!?]+/g) || [entry.raw];
    
    return sentences.map((sentence, i) => ({
      chunkId: `${entry.id}_CH_${i}`,
      corpusId: entry.id,
      text: sentence.trim(),
      entropy: this.calculateEntropy(sentence),
      timestamp: Date.now(),
      metadata: { strategy: 'sentence', size: sentence.length }
    }));
  }

  /**
   * Paragraph-based chunking
   */
  private paragraphChunking(
    entry: CorpusEntry, 
    maxSize: number
  ): TelemetryChunk[] {
    const chunks: TelemetryChunk[] = [];
    const paragraphs = entry.raw.split(/\n\n+/);
    
    return paragraphs.map((para, i) => ({
      chunkId: `${entry.id}_CH_${i}`,
      corpusId: entry.id,
      text: para.trim(),
      entropy: this.calculateEntropy(para),
      timestamp: Date.now(),
      metadata: { strategy: 'paragraph', size: para.length }
    }));
  }

  /**
   * Calculate Shannon entropy for chunk (measures randomness/information density)
   */
  private calculateEntropy(text: string): number {
    if (!text || text.length === 0) return 0;

    const chars = text.split('');
    const freq: Record<string, number> = {};
    
    chars.forEach(c => {
      freq[c] = (freq[c] || 0) + 1;
    });

    let entropy = 0;
    const len = chars.length;
    
    Object.values(freq).forEach(count => {
      const p = count / len;
      entropy -= p * Math.log2(p);
    });

    // Normalize to 0-8 range
    return Math.min(entropy, 8);
  }

  /**
   * Compute chunking operation metrics
   */
  private computeChunkingMetrics(
    chunks: TelemetryChunk[], 
    processingTime: number
  ): ChunkingMetrics {
    const sizes = chunks.map(c => c.text.length);
    const entropies = chunks.map(c => c.entropy);

    return {
      totalChunks: chunks.length,
      avgChunkSize: sizes.reduce((a, b) => a + b, 0) / chunks.length || 0,
      entropyStats: {
        min: Math.min(...entropies),
        max: Math.max(...entropies),
        avg: entropies.reduce((a, b) => a + b, 0) / entropies.length || 0
      },
      processingTime
    };
  }

  /**
   * Get available chunking strategies
   */
  public getAvailableStrategies(): ChunkingStrategy[] {
    return [
      { name: 'fixed_overlap', maxChunkSize: 512, overlapSize: 100, strategy: 'fixed' },
      { name: 'semantic_boundary', maxChunkSize: 1024, overlapSize: 200, strategy: 'semantic' },
      { name: 'sentence_split', maxChunkSize: 2048, overlapSize: 0, strategy: 'sentence' },
      { name: 'paragraph_split', maxChunkSize: 4096, overlapSize: 0, strategy: 'paragraph' }
    ];
  }

  private validateStrategies(): void {
    // Validate default strategy is sound
    if (this.defaultStrategy.maxChunkSize < 100) {
      throw new Error('ChunkingEngine: Max chunk size must be >= 100 chars');
    }
  }

  private generateRequestId(): string {
    return `chunk-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Export singleton instance
export const chunkingEngine = new ChunkingEngine();
