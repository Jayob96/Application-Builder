
// services/phase1/corpusProcessor.ts
// PhoenixBird Phase 1: Corpus Entry Processing & Validation

import { vault } from "../memoryVault";
import { cryptoEngine } from "../core/cryptoEngine";
import { cognitiveMap } from "../core/cognitiveMap";
import { SystemSpecs, CorpusEntry } from "../../types";

/**
 * Processing metrics
 */
export interface CorpusProcessingMetrics {
  totalEntries: number;
  validEntries: number;
  rejectedEntries: number;
  avgEntrySize: number;
  processingTime: number;
}

/**
 * CorpusProcessor - Phase 1 Entry Point
 * 
 * Ingests raw telemetry/logs and transforms into corpus entries
 * Validates, enriches, and prepares for chunking/embedding
 */
class CorpusProcessor {
  private readonly maxEntrySize = 1000000;  // 1MB per entry
  private readonly batchSize = 100;

  constructor() {
    // Initialization if needed
  }

  /**
   * Process telemetry logs into corpus entries
   */
  public async processTelemetryCorpus(
    logs: string[],
    specs: SystemSpecs | null,
    options?: {
      source?: string;
      metadata?: Record<string, any>;
    }
  ): Promise<CorpusEntry[]> {
    const requestId = this.generateRequestId();
    const startTime = performance.now();

    try {
      const entries: CorpusEntry[] = [];

      for (let i = 0; i < logs.length; i++) {
        const log = logs[i];

        // Validate individual entry
        if (!this.validateLog(log)) {
          await vault.addLog(
            `CorpusProcessor [${requestId}]: Skipped invalid log at index ${i}`,
            'warn'
          );
          continue;
        }

        // Phase 3: Trust boundary check
        const trustResult = await cryptoEngine.verifyTrustBoundary(log);
        if (!trustResult.isTrusted) {
          await vault.addLog(
            `CorpusProcessor [${requestId}]: Untrusted log rejected at index ${i}`,
            'warn'
          );
          continue;
        }

        // Create corpus entry with enrichment
        const entry: CorpusEntry = {
          id: `CORP_${Date.now()}_${i}`,
          source: options?.source || 'SYSTEM_LOG',
          raw: log,
          timestamp: Date.now(),
          metadata: {
            index: i,
            logLength: log.length,
            arch: specs?.architecture || 'unknown',
            os: specs?.os || 'unknown',
            cpu: specs?.cpu || 'unknown',
            ...options?.metadata
          }
        };

        entries.push(entry);
      }

      // Compute metrics
      const metrics = this.computeMetrics(entries, logs, performance.now() - startTime);

      // Cognitive tracking
      // Fix: changed 'embedding' to 'gemini' as 'embedding' is not a valid source
      // Fix: metadata passed to track must be Record<string, any>
      await cognitiveMap.track(
        `Processed corpus: ${entries.length} entries from ${logs.length} logs`,
        0.99,
        'gemini',
        'learning',
        {
          validEntries: entries.length,
          rejectedEntries: logs.length - entries.length,
          avgSize: metrics.avgEntrySize
        },
        6
      );

      await vault.addLog(
        `CorpusProcessor [${requestId}]: Processed ${entries.length}/${logs.length} entries (${metrics.processingTime.toFixed(0)}ms)`,
        'info'
      );

      return entries;

    } catch (error) {
      await vault.addLog(`CorpusProcessor failed [${requestId}]: ${error}`, 'error');
      throw error;
    }
  }

  /**
   * Process batch of telemetry entries
   */
  public async processBatch(
    entries: Array<{ source: string; content: string; timestamp?: number }>,
    specs: SystemSpecs | null
  ): Promise<CorpusEntry[]> {
    const requestId = this.generateRequestId();
    const corpus: CorpusEntry[] = [];

    for (const entry of entries) {
      const corpusEntry: CorpusEntry = {
        id: `CORP_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        source: entry.source,
        raw: entry.content,
        timestamp: entry.timestamp || Date.now(),
        metadata: {
          sourceSystem: entry.source,
          os: specs?.os || 'unknown',
          cpu: specs?.cpu || 'unknown'
        }
      };

      corpus.push(corpusEntry);
    }

    await vault.addLog(
      `CorpusProcessor: Batch processed ${corpus.length} entries`,
      'info'
    );

    return corpus;
  }

  /**
   * Enrich corpus entry with additional metadata
   */
  public async enrichEntry(
    entry: CorpusEntry,
    enrichment: Record<string, any>
  ): Promise<CorpusEntry> {
    return {
      ...entry,
      metadata: {
        ...entry.metadata,
        ...enrichment,
        enrichedAt: Date.now()
      }
    };
  }

  /**
   * Validate corpus entry
   */
  public validateEntry(entry: CorpusEntry): boolean {
    return (
      entry.id &&
      entry.source &&
      entry.raw &&
      entry.raw.length > 0 &&
      entry.raw.length <= this.maxEntrySize &&
      entry.timestamp &&
      entry.metadata
    );
  }

  /**
   * Filter corpus by criteria
   */
  public filterCorpus(
    entries: CorpusEntry[],
    filter: {
      source?: string;
      minSize?: number;
      maxSize?: number;
      afterTimestamp?: number;
    }
  ): CorpusEntry[] {
    return entries.filter(entry => {
      if (filter.source && entry.source !== filter.source) return false;
      if (filter.minSize && entry.raw.length < filter.minSize) return false;
      if (filter.maxSize && entry.raw.length > filter.maxSize) return false;
      if (filter.afterTimestamp && entry.timestamp < filter.afterTimestamp) return false;
      return true;
    });
  }

  /**
   * Deduplicate corpus entries
   */
  public deduplicateCorpus(entries: CorpusEntry[]): CorpusEntry[] {
    const seen = new Set<string>();
    return entries.filter(entry => {
      const hash = entry.raw.substring(0, 100);  // Simple dedup
      if (seen.has(hash)) return false;
      seen.add(hash);
      return true;
    });
  }

  // Private utilities
  private validateLog(log: string): boolean {
    return (
      log &&
      typeof log === 'string' &&
      log.length > 0 &&
      log.length <= this.maxEntrySize
    );
  }

  private computeMetrics(
    validEntries: CorpusEntry[],
    allLogs: string[],
    processingTime: number
  ): CorpusProcessingMetrics {
    const sizes = validEntries.map(e => e.raw.length);

    return {
      totalEntries: allLogs.length,
      validEntries: validEntries.length,
      rejectedEntries: allLogs.length - validEntries.length,
      avgEntrySize: sizes.length > 0 ? sizes.reduce((a, b) => a + b, 0) / sizes.length : 0,
      processingTime
    };
  }

  private generateRequestId(): string {
    return `corpus-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Export singleton
export const corpusProcessor = new CorpusProcessor();
