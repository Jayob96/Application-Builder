
// services/learningService.ts
// PhoenixBird Phase 4: Neural Loop - Autonomous System Optimization

import * as geminiService from "./geminiService";
import { cognitiveMap } from "./core/cognitiveMap";
import { cryptoEngine } from "./core/cryptoEngine";
import { vault } from "./memoryVault";
import { PerformanceSnapshot, SystemSpecs, TuningManifest, CognitiveEvent } from "../types";

/**
 * Neural Loop optimization interfaces
 */
export interface OptimizationCycle {
  cycleId: string;
  timestamp: number;
  samplesAnalyzed: number;
  efficiencyDelta: number;
  manifestGenerated: boolean;
  tuningType: string;
}

export interface EfficiencyMetrics {
  avgCpuUsage: number;
  avgThermalIndex: number;
  avgRamUsage: number;
  peakLoad: number;
  efficiency: number;  // Composite score
  trend: 'improving' | 'stable' | 'degrading';
}

/**
 * NeuralLoopService - Phase 4 Autonomous Optimization
 * 
 * Continuously analyzes performance telemetry
 * Synthesizes optimization manifests via Gemini
 * Feeds improvements back into system
 */
class NeuralLoopService {
  private history: PerformanceSnapshot[] = [];
  private optimizationCycles: OptimizationCycle[] = [];
  private isProcessing = false;
  private onTuningCallback: (manifest: TuningManifest) => void = () => {};
  private readonly maxHistory = 500;  // ~17 minutes at 2s intervals
  private readonly sampleThreshold = 20;  // Trigger after 20 samples
  private lastOptimizationTime = Date.now();
  private minimumIntervalMs = 60000;  // Min 60s between optimizations

  constructor() {
    this.startAutoOptimization();
  }

  /**
   * Subscribe to tuning manifest generation
   */
  public subscribe(callback: (manifest: TuningManifest) => void): void {
    this.onTuningCallback = callback;
    vault.addLog('NeuralLoop: Tuning callback registered', 'info');
  }

  /**
   * Ingest performance snapshot for analysis
   */
  public async ingest(snapshot: PerformanceSnapshot, specs: SystemSpecs | null): Promise<void> {
    try {
      // Phase 3: Trust snapshot verification
      const trustResult = await cryptoEngine.verifyTrustBoundary(JSON.stringify(snapshot));
      if (!trustResult.isTrusted) {
        await vault.addLog(`NeuralLoop: Untrusted snapshot rejected`, 'warn');
        return;
      }

      // Add to history with timestamp
      this.history.push({ ...snapshot, timestamp: Date.now() });
      if (this.history.length > this.maxHistory) {
        this.history.shift();
      }

      // Check if optimization cycle should trigger
      const shouldOptimize = this.shouldTriggerOptimization();
      
      if (shouldOptimize && !this.isProcessing) {
        await this.runSelfOptimization(specs);
      }

    } catch (error) {
      await vault.addLog(`NeuralLoop ingest failed: ${error}`, 'error');
    }
  }

  /**
   * Run autonomous optimization cycle
   */
  private async runSelfOptimization(specs: SystemSpecs | null): Promise<void> {
    const cycleId = this.generateCycleId();
    const requestId = `neuralloop-${cycleId}`;
    const startTime = performance.now();

    this.isProcessing = true;

    try {
      // Compute current efficiency
      const metrics = this.computeEfficiencyMetrics();
      const efficiencyDelta = this.computeEfficiencyDelta();

      // Phase 4: Synthesize tuning manifest via Gemini
      // Fix: use synthesized export from geminiService
      const manifest = await geminiService.synthesizeTuningManifest(specs, this.history);

      if (!manifest) {
        throw new Error('Gemini failed to synthesize manifest');
      }

      // Phase 3: Sign and verify manifest
      // Fix: manifest might need a signature field, extending it locally if needed or assuming it exists on the object
      const manifestWithSig = manifest as any;
      const manifestSignature = await cryptoEngine.generateHMAC(JSON.stringify(manifest));
      manifestWithSig.signature = manifestSignature;

      // Persist scripts to MemoryVault
      for (const script of manifest.scripts) {
        await vault.saveFile(script.file, script.content);
        
        // Sign each script
        const scriptSig = await cryptoEngine.generateHMAC(script.content);
        await vault.saveFile(`${script.file}.sig`, scriptSig.signature);
      }

      // Log optimization cycle
      const cycle: OptimizationCycle = {
        cycleId,
        timestamp: Date.now(),
        samplesAnalyzed: this.history.length,
        efficiencyDelta,
        manifestGenerated: true,
        tuningType: manifest.tuningType
      };
      this.optimizationCycles.push(cycle);

      // Cognitive tracking
      // Fix: changed 'learning' to 'gemini' as 'learning' is not a valid source
      await cognitiveMap.track(
        `Neural loop optimization cycle: ${manifest.tuningType}`,
        0.96,
        'gemini',
        'learning',
        {
          cycleId,
          efficiencyDelta,
          samplesAnalyzed: this.history.length,
          scripts: manifest.scripts.length
        },
        9
      );

      const duration = performance.now() - startTime;
      await vault.addLog(
        `NeuralLoop [${requestId}]: Synthesized ${manifest.tuningType} manifest (${duration.toFixed(0)}ms)`,
        'info'
      );

      // Trigger callback with manifest
      this.onTuningCallback(manifest);
      this.lastOptimizationTime = Date.now();

    } catch (error) {
      await vault.addLog(`NeuralLoop optimization failed [${requestId}]: ${error}`, 'error');
      
      // Log failed cycle
      this.optimizationCycles.push({
        cycleId,
        timestamp: Date.now(),
        samplesAnalyzed: this.history.length,
        efficiencyDelta: 0,
        manifestGenerated: false,
        tuningType: 'failed'
      });
    } finally {
      this.isProcessing = false;
    }
  }

  /**
   * Compute current system efficiency metrics
   */
  private computeEfficiencyMetrics(): EfficiencyMetrics {
    if (this.history.length === 0) {
      return {
        avgCpuUsage: 0,
        avgThermalIndex: 0,
        avgRamUsage: 0,
        peakLoad: 0,
        efficiency: 100,
        trend: 'stable'
      };
    }

    const recent = this.history.slice(-50);  // Last 50 samples
    const avgCpu = recent.reduce((sum, s) => sum + s.cpu, 0) / recent.length;
    const avgThermal = recent.reduce((sum, s) => sum + s.temp, 0) / recent.length;
    const avgRam = recent.reduce((sum, s) => sum + s.ram, 0) / recent.length;
    const peakLoad = Math.max(...recent.map(s => s.cpu));

    // Composite efficiency: lower is better
    const efficiency = Math.max(0, 100 - (avgCpu * 0.4 + avgThermal * 0.3 + avgRam * 0.3));

    // Trend detection
    const first20 = recent.slice(0, 20);
    const last20 = recent.slice(-20);
    const firstAvg = first20.reduce((sum, s) => sum + s.efficiency, 0) / first20.length;
    const lastAvg = last20.reduce((sum, s) => sum + s.efficiency, 0) / last20.length;
    const trend = lastAvg > firstAvg + 2 ? 'improving' : lastAvg < firstAvg - 2 ? 'degrading' : 'stable';

    return {
      avgCpuUsage: Number(avgCpu.toFixed(2)),
      avgThermalIndex: Number(avgThermal.toFixed(2)),
      avgRamUsage: Number(avgRam.toFixed(2)),
      peakLoad: Number(peakLoad.toFixed(2)),
      efficiency: Number(efficiency.toFixed(2)),
      trend: trend as 'improving' | 'stable' | 'degrading'
    };
  }

  /**
   * Compute efficiency delta (improvement/degradation)
   */
  private computeEfficiencyDelta(): number {
    if (this.history.length < 2) return 0;

    const first = this.history[0].efficiency || 50;
    const last = this.history[this.history.length - 1].efficiency || 50;
    return Number((last - first).toFixed(2));
  }

  /**
   * Get efficiency trend over time
   */
  public getEfficiencyTrend(windowSize: number = 50): number {
    if (this.history.length < 2) return 0;

    const window = this.history.slice(-windowSize);
    const first = window[0].efficiency || 50;
    const last = window[window.length - 1].efficiency || 50;
    return Number((last - first).toFixed(3));
  }

  /**
   * Get current system metrics
   */
  public getCurrentMetrics(): EfficiencyMetrics {
    return this.computeEfficiencyMetrics();
  }

  /**
   * Get recent optimization cycles
   */
  public getOptimizationHistory(limit: number = 10): OptimizationCycle[] {
    return this.optimizationCycles.slice(-limit);
  }

  /**
   * Get performance snapshot history
   */
  public getSnapshotHistory(limit: number = 100): PerformanceSnapshot[] {
    return this.history.slice(-limit);
  }

  /**
   * Get neural loop status
   */
  public getStatus(): {
    isProcessing: boolean;
    snapshotsCollected: number;
    cyclesCompleted: number;
    lastOptimization: number;
    efficiency: number;
    trend: string;
  } {
    const metrics = this.computeEfficiencyMetrics();
    return {
      isProcessing: this.isProcessing,
      snapshotsCollected: this.history.length,
      cyclesCompleted: this.optimizationCycles.length,
      lastOptimization: Date.now() - this.lastOptimizationTime,
      efficiency: metrics.efficiency,
      trend: metrics.trend
    };
  }

  // Private helpers
  private shouldTriggerOptimization(): boolean {
    const timeSinceLastOpt = Date.now() - this.lastOptimizationTime;
    const samplesSinceLastOpt = this.history.length % this.sampleThreshold;

    return timeSinceLastOpt > this.minimumIntervalMs && samplesSinceLastOpt === 0;
  }

  private startAutoOptimization(): void {
    // Background check every 5 seconds
    setInterval(async () => {
      if (this.shouldTriggerOptimization() && !this.isProcessing && this.history.length > 0) {
        await vault.addLog('NeuralLoop: Auto-triggered optimization check', 'debug');
      }
    }, 5000);
  }

  private generateCycleId(): string {
    return `cycle-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Export singleton instance
export const neuralLoop = new NeuralLoopService();
