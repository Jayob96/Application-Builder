
import { GoogleGenAI } from "@google/genai";
import { vault } from "../memoryVault";
import { cryptoEngine } from "../core/cryptoEngine";
import { ragRetrieval } from "../core/ragRetrieval";
import { cognitiveMap } from "../core/cognitiveMap";
import {
  NetworkPacket,
  FirewallVerdict,
  FirewallPolicy,
  ThreatIndicator,
  ThreatCategory,
  TrafficProfile,
  FirewallAuditEntry,
  FirewallAction,
} from "../../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Default firewall policy - can be overridden per environment
 */
const defaultPolicy: FirewallPolicy = {
  trustedIps: ["127.0.0.1", "localhost"],
  blockedIps: [],
  allowedPorts: [80, 443, 53, 22, 3306, 5432],
  maxEntropyThreshold: 7.5,
  maxPacketRatePerSecond: 1000,
  humanReviewThreshold: 75,
};

/**
 * Known threat signatures and patterns
 */
const threatSignatures = {
  highEntropy: { threshold: 7.2, score: 30, category: "MALWARE" as ThreatCategory },
  portScanning: { threshold: 50, score: 60, category: "ANOMALY" as ThreatCategory },
  dnsExfiltration: { threshold: 500, score: 70, category: "EXFILTRATION" as ThreatCategory },
  geoAnomaly: { score: 40, category: "ANOMALY" as ThreatCategory },
  bruteforce: { threshold: 10, score: 80, category: "BRUTEFORCE" as ThreatCategory },
};

class AIFirewallService {
  private trafficLog: NetworkPacket[] = [];
  private auditTrail: FirewallAuditEntry[] = [];
  private trafficProfiles: Map<string, TrafficProfile> = new Map();
  private policy: FirewallPolicy = defaultPolicy;
  private isAnalyzing = false;
  private suspiciousPatterns: Map<string, number> = new Map(); // IP -> threat counter

  constructor() {
    this.initializeService();
  }

  private async initializeService(): Promise<void> {
    const savedPolicyStr = await vault.readFile("firewall_policy.json");
    if (savedPolicyStr) {
      this.policy = JSON.parse(savedPolicyStr);
    }
    this.startTrafficMonitoring();
  }

  private startTrafficMonitoring(): void {
    setInterval(async () => {
      if (this.trafficLog.length > 0 && !this.isAnalyzing) {
        const batchSize = Math.min(10, this.trafficLog.length);
        const batch = this.trafficLog.splice(0, batchSize);
        await this.analyzeBatch(batch);
      }
    }, 5000);
  }

  public async ingestPacket(packet: NetworkPacket): Promise<FirewallVerdict> {
    const preFlightVerdict = this.performPreFlightChecks(packet);
    if (preFlightVerdict.action !== "ALLOW") {
      return preFlightVerdict;
    }

    this.trafficLog.push(packet);
    this.updateTrafficProfile(packet);

    if (this.suspiciousPatterns.has(packet.sourceIp)) {
      const threatCount = this.suspiciousPatterns.get(packet.sourceIp) || 0;
      if (threatCount > 3) {
        return await this.analyzePacketWithGemini([packet]);
      }
    }

    return {
      action: "ALLOW",
      threatLevel: 0,
      reasoning: "Packet passed pre-flight checks.",
      confidence: 0.95,
      threats: [],
      recommendations: [],
      analyzedAt: Date.now(),
    };
  }

  private performPreFlightChecks(packet: NetworkPacket): FirewallVerdict {
    if (this.policy.blockedIps.includes(packet.sourceIp)) {
      return {
        action: "BLOCK",
        threatLevel: 100,
        reasoning: `Source IP ${packet.sourceIp} is on the blocked list.`,
        confidence: 1.0,
        threats: [{ category: "MALWARE", score: 100, evidence: "Blacklisted source IP", source: "ip_blocklist" }],
        recommendations: ["Block all traffic from this IP", "Investigate source"],
        analyzedAt: Date.now(),
      };
    }

    if (!this.policy.allowedPorts.includes(packet.port)) {
      return {
        action: "BLOCK",
        threatLevel: 70,
        reasoning: `Port ${packet.port} is not in the allowed ports list.`,
        confidence: 0.9,
        threats: [{ category: "ANOMALY", score: 70, evidence: `Unexpected port ${packet.port}`, source: "port_validation" }],
        recommendations: ["Block traffic on this port", "Review firewall rules"],
        analyzedAt: Date.now(),
      };
    }

    const sourceProfile = this.trafficProfiles.get(packet.sourceIp);
    if (sourceProfile && sourceProfile.packetCount > this.policy.maxPacketRatePerSecond) {
      return {
        action: "THROTTLE",
        threatLevel: 50,
        reasoning: `Source ${packet.sourceIp} exceeds rate limit.`,
        confidence: 0.85,
        threats: [{ category: "ANOMALY", score: 50, evidence: `Packet rate exceeds ${this.policy.maxPacketRatePerSecond}/sec`, source: "rate_limit" }],
        recommendations: ["Apply rate limiting", "Monitor for DDoS"],
        analyzedAt: Date.now(),
      };
    }

    return {
      action: "ALLOW",
      threatLevel: 0,
      reasoning: "Passed all pre-flight checks.",
      confidence: 1.0,
      threats: [],
      recommendations: [],
      analyzedAt: Date.now(),
    };
  }

  private updateTrafficProfile(packet: NetworkPacket): void {
    const existing = this.trafficProfiles.get(packet.sourceIp) || {
      sourceIp: packet.sourceIp,
      packetCount: 0,
      avgPacketSize: 0,
      avgEntropy: 0,
      uniqueDestinations: new Set<string>(),
      uniquePorts: new Set<number>(),
      protocolDistribution: {} as Record<string, number>,
    };

    existing.packetCount++;
    existing.avgPacketSize = (existing.avgPacketSize + packet.payloadSize) / 2;
    existing.avgEntropy = (existing.avgEntropy + packet.entropy) / 2;
    existing.uniqueDestinations.add(packet.destinationIp);
    existing.uniquePorts.add(packet.port);

    const proto = packet.protocol as string;
    existing.protocolDistribution[proto] = (existing.protocolDistribution[proto] || 0) + 1;

    this.trafficProfiles.set(packet.sourceIp, existing);
  }

  private async analyzeBatch(packets: NetworkPacket[]): Promise<void> {
    if (packets.length === 0) return;

    this.isAnalyzing = true;
    try {
      for (const packet of packets) {
        const verdict = await this.analyzePacketWithGemini([packet]);
        await this.recordAuditEntry(packet.id, verdict);

        if (verdict.threatLevel > 50) {
          const count = this.suspiciousPatterns.get(packet.sourceIp) || 0;
          this.suspiciousPatterns.set(packet.sourceIp, count + 1);
        }

        // Fix: Use 'track' instead of 'recordDecision'
        await cognitiveMap.track(
          `firewall_verdict for ${packet.sourceIp}`,
          verdict.confidence,
          'firewall',
          'threat',
          {
            packetId: packet.id,
            sourceIp: packet.sourceIp,
            threatLevel: verdict.threatLevel,
            action: verdict.action,
          }
        );
      }
    } finally {
      this.isAnalyzing = false;
    }
  }

  private async analyzePacketWithGemini(packets: NetworkPacket[]): Promise<FirewallVerdict> {
    try {
      const summary = `${packets.length} packets from ${packets[0].sourceIp}`;
      
      // Fix: Use 'performRAGQuery' instead of 'search'
      const retrieval = await ragRetrieval.performRAGQuery(`Threats similar to: ${summary}`);

      const prompt = `
You are a cybersecurity threat analyst. Analyze the following network traffic for security threats.

PACKET DATA:
${JSON.stringify(packets, null, 2)}

SIMILAR HISTORICAL THREATS:
${retrieval.context}

Respond with a JSON object:
{
  "threatLevel": <0-100>,
  "action": "<ALLOW|BLOCK|QUARANTINE|THROTTLE|ALERT>",
  "threats": [{ "category": "...", "score": <0-100>, "evidence": "..." }],
  "reasoning": "...",
  "confidence": <0-1>,
  "recommendations": ["..."]
}
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });

      const analysis = JSON.parse(response.text || "{}");

      return {
        threatLevel: analysis.threatLevel,
        action: analysis.action,
        reasoning: analysis.reasoning,
        confidence: analysis.confidence,
        threats: analysis.threats || [],
        recommendations: analysis.recommendations || [],
        analyzedAt: Date.now(),
      };
    } catch (error) {
      return this.performHeuristicAnalysis(packets);
    }
  }

  private performHeuristicAnalysis(packets: NetworkPacket[]): FirewallVerdict {
    const threats: ThreatIndicator[] = [];
    for (const packet of packets) {
      if (packet.entropy > this.policy.maxEntropyThreshold) {
        threats.push({
          category: "MALWARE",
          score: Math.min(100, packet.entropy * 12),
          evidence: `High payload entropy: ${packet.entropy.toFixed(2)}`,
          source: "entropy_analysis",
        });
      }
    }

    const maxThreatLevel = threats.length > 0 ? Math.max(...threats.map((t) => t.score)) : 0;
    const action: FirewallAction = maxThreatLevel > 70 ? "QUARANTINE" : "ALLOW";

    return {
      threatLevel: maxThreatLevel,
      action,
      reasoning: threats.length > 0 ? `Detected ${threats.length} threat(s).` : "No threats detected.",
      confidence: 0.7,
      threats,
      recommendations: threats.length > 0 ? ["Monitor source", "Review logs"] : [],
      analyzedAt: Date.now(),
    };
  }

  private async recordAuditEntry(packetId: string, verdict: FirewallVerdict): Promise<void> {
    const entry: FirewallAuditEntry = {
      packetId,
      verdict,
      signature: "",
      timestamp: Date.now(),
      actor: "AIFirewall",
    };

    entry.signature = await cryptoEngine.signData(JSON.stringify(entry));
    this.auditTrail.push(entry);

    await vault.saveFile(`C:/NovaCore/Firewall/Audit/${packetId}.json`, JSON.stringify(entry));

    if (this.auditTrail.length > 1000) {
      this.auditTrail.shift();
    }
  }

  public getAuditTrail(limit: number = 100): FirewallAuditEntry[] {
    return this.auditTrail.slice(-limit);
  }

  public async updatePolicy(newPolicy: Partial<FirewallPolicy>): Promise<void> {
    this.policy = { ...this.policy, ...newPolicy };
    await vault.saveFile("firewall_policy.json", JSON.stringify(this.policy));
  }
}

export const aiFirewall = new AIFirewallService();