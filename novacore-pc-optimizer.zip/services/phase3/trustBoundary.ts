// trustBoundary.ts

export interface ScrubOptions {
  /** If true, scrub IP addresses (IPv4 & simple IPv6). */
  scrubIp: boolean;
  /** If true, scrub user paths (Windows & POSIX). */
  scrubUserPaths: boolean;
  /** If true, scrub emails. */
  scrubEmails: boolean;
  /** If true, scrub possible hostnames. */
  scrubHostnames: boolean;
  /** If true, scrub file system roots (e.g., C:\Users\...). */
  scrubFsRoots: boolean;
}

export interface ScrubResult {
  /** The fully scrubbed string. */
  sanitized: string;
  /** How many IP addresses were scrubbed. */
  ipCount: number;
  /** How many user paths were scrubbed. */
  userPathCount: number;
  /** How many email addresses were scrubbed. */
  emailCount: number;
  /** How many hostnames were scrubbed. */
  hostnameCount: number;
  /** How many filesystem root paths were scrubbed. */
  fsRootCount: number;
}

/**
 * Default scrub options for external trust boundaries (LLM, logs, exports).
 */
export const defaultScrubOptions: ScrubOptions = {
  scrubIp: true,
  scrubUserPaths: true,
  scrubEmails: true,
  scrubHostnames: true,
  scrubFsRoots: true,
};

/**
 * Core scrub function with structured result.
 */
export const scrubTrustBoundaryDetailed = (
  input: string,
  options: ScrubOptions = defaultScrubOptions,
): ScrubResult => {
  let sanitized = input;

  let ipCount = 0;
  let userPathCount = 0;
  let emailCount = 0;
  let hostnameCount = 0;
  let fsRootCount = 0;

  // IPv4 (simple) + basic IPv6 pattern
  if (options.scrubIp) {
    const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
    const ipv6Regex = /\b(?:[a-fA-F0-9]{1,4}:){2,7}[a-fA-F0-9]{1,4}\b/g;

    sanitized = sanitized.replace(ipv4Regex, () => {
      ipCount++;
      return "[IP_REDACTED]";
    });

    sanitized = sanitized.replace(ipv6Regex, () => {
      ipCount++;
      return "[IPV6_REDACTED]";
    });
  }

  // Windows-style user paths: C:\Users\<user>\..., D:\Users\<user>\...
  // POSIX-style user paths: /home/<user>/..., /Users/<user>/...
  if (options.scrubUserPaths) {
    const windowsUserPathRegex = /[A-Za-z]:\\Users\\[^\\\s]+/g;
    const posixUserPathRegex = /(?:\/home\/|\/Users\/)[^\/\s]+/g;

    sanitized = sanitized.replace(windowsUserPathRegex, match => {
      userPathCount++;
      const drive = match.slice(0, 2); // e.g., "C:"
      return `${drive}\\Users\\[USER_REDACTED]`;
    });

    sanitized = sanitized.replace(posixUserPathRegex, match => {
      userPathCount++;
      const prefix = match.startsWith("/home/") ? "/home" : "/Users";
      return `${prefix}/[USER_REDACTED]`;
    });
  }

  // Email addresses
  if (options.scrubEmails) {
    const emailRegex = /\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}\b/g;
    sanitized = sanitized.replace(emailRegex, () => {
      emailCount++;
      return "[EMAIL_REDACTED]";
    });
  }

  // Hostnames (simple heuristic: something.something with no spaces)
  if (options.scrubHostnames) {
    const hostnameRegex = /\b[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+\b/g;
    sanitized = sanitized.replace(hostnameRegex, match => {
      // Avoid double-scrubbing emails (already handled above)
      if (match.includes("@")) return match;
      hostnameCount++;
      return "[HOST_REDACTED]";
    });
  }

  // Filesystem roots (C:\, D:\, /root, /etc, etc.)
  if (options.scrubFsRoots) {
    const windowsRootRegex = /\b[A-Za-z]:\\(Windows|Program Files|Program Files \(x86\)|Users)\b/g;
    const posixRootRegex = /\b\/(root|etc|var|usr|opt|srv)\b/g;

    sanitized = sanitized.replace(windowsRootRegex, () => {
      fsRootCount++;
      return "[FS_ROOT_REDACTED]";
    });

    sanitized = sanitized.replace(posixRootRegex, () => {
      fsRootCount++;
      return "[FS_ROOT_REDACTED]";
    });
  }

  return {
    sanitized,
    ipCount,
    userPathCount,
    emailCount,
    hostnameCount,
    fsRootCount,
  };
};

/**
 * Backwards-compatible simple API: returns only the sanitized string.
 */
export const scrubTrustBoundary = (data: string): string => {
  return scrubTrustBoundaryDetailed(data, defaultScrubOptions).sanitized;
};
