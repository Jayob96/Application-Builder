// types.ts (Context filtering additions)

export type DataClassification = 'PUBLIC' | 'INTERNAL' | 'CONFIDENTIAL' | 'RESTRICTED';
export type FilterMode = 'FULL' | 'SANITIZED' | 'MINIMAL' | 'REDACTED';

/**
 * System specification details - comprehensive hardware/software profile
 */
export interface SystemSpecs {
  // Hardware CPU info
  cpu: {
    model: string;
    cores: number;
    threads: number;
    frequency: number; // GHz
    cache: number; // MB
    serialNumber?: string; // RESTRICTED
    vendor: string;
  };
  // GPU details
  gpu: {
    model: string;
    vram: number; // GB
    architecture: string;
    driver: string;
    serialNumber?: string; // RESTRICTED
    vendor: string;
  };
  // OS information
  os: {
    name: string; // Windows, Linux, macOS
    version: string;
    build: string;
    kernel?: string;
    licenseKey?: string; // RESTRICTED
  };
  // Memory configuration
  memory: {
    total: number; // GB
    available: number; // GB
    type: string; // DDR4, DDR5, etc.
  };
  // Storage details
  storage: {
    total: number; // GB
    available: number; // GB
    type: string; // SSD, HDD, NVMe
    encryptionStatus: 'ENCRYPTED' | 'UNENCRYPTED' | 'UNKNOWN';
  };
  // Network configuration
  network: {
    ipAddress?: string; // INTERNAL
    macAddress?: string; // INTERNAL
    hostname?: string; // INTERNAL
    vpnActive: boolean;
    publicIp?: string; // INTERNAL
  };
  // Security posture
  security: {
    firewallEnabled: boolean;
    antivirusStatus: 'ACTIVE' | 'INACTIVE' | 'UNKNOWN';
    tpmAvailable: boolean;
    secureBootEnabled: boolean;
  };
  // Geolocation (if available)
  location?: {
    country?: string; // INTERNAL
    region?: string; // INTERNAL
    timezone?: string; // PUBLIC
    latitude?: number; // RESTRICTED
    longitude?: number; // RESTRICTED
  };
  // Metadata
  timestamp: number;
  source: string;
}

/**
 * Field-level classification: what data can be shared where
 */
export interface FieldClassification {
  /** Field name (dot notation for nested, e.g., "cpu.serialNumber") */
  field: string;
  /** Minimum clearance level to view this field */
  classification: DataClassification;
  /** Description of why this field is classified */
  reason: string;
  /** Whether to redact value (true) or remove field entirely (false) */
  redactInsteadOfRemove: boolean;
  /** If redacting, what placeholder to use */
  redactionPlaceholder?: string;
}

/**
 * Filtered context prepared for external consumption
 */
export interface FilteredContext {
  /** Fields included in this context */
  includedFields: string[];
  /** Fields redacted in this context */
  redactedFields: string[];
  /** Fields removed entirely */
  removedFields: string[];
  /** Data classification level of this context */
  classification: DataClassification;
  /** Which filter mode was applied */
  filterMode: FilterMode;
  /** Timestamp of filtering */
  filteredAt: number;
  /** HMAC signature for audit trail */
  signature?: string;
  /** Actual filtered data */
  data: Record<string, unknown>;
}

/**
 * Audit log entry for context filtering
 */
export interface FilterAuditEntry {
  /** Unique event ID */
  id: string;
  /** Original specs source */
  source: string;
  /** Filter mode applied */
  filterMode: FilterMode;
  /** Requester identity (system, user, service) */
  requester: string;
  /** Intended use (e.g., "gemini_analysis", "dashboard", "export") */
  purpose: string;
  /** How many fields were redacted */
  redactedCount: number;
  /** How many fields were removed */
  removedCount: number;
  /** Timestamp of filtering operation */
  timestamp: number;
  /** HMAC signature of request + response */
  signature: string;
}

/**
 * Context filter policies - define what can be shared in what contexts
 */
export interface ContextFilterPolicy {
  /** Policy identifier */
  id: string;
  /** Default filter mode for this context */
  defaultFilterMode: FilterMode;
  /** Target audience (e.g., "gemini_ai", "dashboard_ui", "external_api") */
  audience: string;
  /** List of allowed field classifications for this audience */
  allowedClassifications: DataClassification[];
  /** Whether to log all filtering operations */
  auditLogging: boolean;
  /** Whether to sign filtered results */
  signResults: boolean;
  /** Custom field overrides (higher security takes precedence) */
  fieldOverrides?: Partial<FieldClassification>[];
}

/**
 * Filtering result with detailed metadata
 */
export interface FilteringResult {
  /** Whether filtering succeeded */
  success: boolean;
  /** Error message if filtering failed */
  error?: string;
  /** The filtered context data */
  context: FilteredContext;
  /** Whether further redaction is needed */
  requiresAdditionalReview: boolean;
  /** Recommendations for using this context */
  recommendations: string[];
}

---

// contextFilter.ts (UPGRADED SERVICE)

import { SystemSpecs, FilteredContext, FilterAuditEntry, ContextFilterPolicy, FilteringResult, FilterMode, DataClassification, FieldClassification } from "../types";
import { cryptoEngine } from "./cryptoEngine";
import { memoryVault } from "./memoryVault";
import { cognitiveMap } from "./cognitiveMap";

/**
 * Field-level classification registry
 * Defines which fields are sensitive and how to handle them
 */
const fieldClassifications: FieldClassification[] = [
  // CPU fields
  {
    field: "cpu.serialNumber",
    classification: "RESTRICTED",
    reason: "Hardware identifier that reveals device identity",
    redactInsteadOfRemove: true,
    redactionPlaceholder: "[RESTRICTED]",
  },
  {
    field: "cpu.model",
    classification: "INTERNAL",
    reason: "Reveals system capabilities for fingerprinting",
    redactInsteadOfRemove: false,
  },
  {
    field: "cpu.cores",
    classification: "PUBLIC",
    reason: "General performance characteristic",
    redactInsteadOfRemove: false,
  },
  
  // GPU fields
  {
    field: "gpu.serialNumber",
    classification: "RESTRICTED",
    reason: "Hardware identifier",
    redactInsteadOfRemove: true,
    redactionPlaceholder: "[RESTRICTED]",
  },
  {
    field: "gpu.vram",
    classification: "PUBLIC",
    reason: "General capability information",
    redactInsteadOfRemove: false,
  },
  
  // OS fields
  {
    field: "os.licenseKey",
    classification: "RESTRICTED",
    reason: "License information is confidential",
    redactInsteadOfRemove: true,
    redactionPlaceholder: "[REDACTED]",
  },
  {
    field: "os.version",
    classification: "INTERNAL",
    reason: "Reveals potential vulnerabilities",
    redactInsteadOfRemove: false,
  },
  
  // Network fields
  {
    field: "network.ipAddress",
    classification: "INTERNAL",
    reason: "Reveals network position",
    redactInsteadOfRemove: true,
    redactionPlaceholder: "[INTERNAL_NETWORK]",
  },
  {
    field: "network.macAddress",
    classification: "INTERNAL",
    reason: "Unique device identifier on network",
    redactInsteadOfRemove: true,
    redactionPlaceholder: "[INTERNAL_MAC]",
  },
  {
    field: "network.hostname",
    classification: "INTERNAL",
    reason: "Identifies system on network",
    redactInsteadOfRemove: true,
    redactionPlaceholder: "[HOSTNAME]",
  },
  {
    field: "network.publicIp",
    classification: "INTERNAL",
    reason: "Reveals external network position",
    redactInsteadOfRemove: true,
    redactionPlaceholder: "[PUBLIC_IP]",
  },
  {
    field: "network.vpnActive",
    classification: "CONFIDENTIAL",
    reason: "Reveals security posture",
    redactInsteadOfRemove: false,
  },
  
  // Location fields
  {
    field: "location.latitude",
    classification: "RESTRICTED",
    reason: "Precise geographic location",
    redactInsteadOfRemove: true,
    redactionPlaceholder: "[REDACTED]",
  },
  {
    field: "location.longitude",
    classification: "RESTRICTED",
    reason: "Precise geographic location",
    redactInsteadOfRemove: true,
    redactionPlaceholder: "[REDACTED]",
  },
  {
    field: "location.country",
    classification: "INTERNAL",
    reason: "Broad geographic location",
    redactInsteadOfRemove: true,
    redactionPlaceholder: "[COUNTRY]",
  },
  {
    field: "location.timezone",
    classification: "PUBLIC",
    reason: "General timezone is low-sensitivity",
    redactInsteadOfRemove: false,
  },
  
  // Storage fields
  {
    field: "storage.encryptionStatus",
    classification: "CONFIDENTIAL",
    reason: "Reveals security configuration",
    redactInsteadOfRemove: false,
  },
];

/**
 * Predefined filter policies for common contexts
 */
const filterPolicies: ContextFilterPolicy[] = [
  {
    id: "GEMINI_AI_ANALYSIS",
    audience: "gemini_ai",
    defaultFilterMode: "SANITIZED",
    allowedClassifications: ["PUBLIC", "INTERNAL"],
    auditLogging: true,
    signResults: true,
    fieldOverrides: [
      {
        field: "cpu.cores",
        classification: "PUBLIC",
        reason: "Safe for AI analysis",
        redactInsteadOfRemove: false,
      },
    ],
  },
  {
    id: "DASHBOARD_UI",
    audience: "dashboard_ui",
    defaultFilterMode: "MINIMAL",
    allowedClassifications: ["PUBLIC"],
    auditLogging: true,
    signResults: false,
  },
  {
    id: "SECURITY_AUDIT",
    audience: "security_audit",
    defaultFilterMode: "FULL",
    allowedClassifications: ["PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED"],
    auditLogging: true,
    signResults: true,
  },
  {
    id: "EXTERNAL_API",
    audience: "external_api",
    defaultFilterMode: "REDACTED",
    allowedClassifications: ["PUBLIC"],
    auditLogging: true,
    signResults: true,
  },
];

/**
 * Context Filter Service
 * Applies security-aware filtering to system specifications
 */
class ContextFilterService {
  private auditTrail: FilterAuditEntry[] = [];
  private policies: Map<string, ContextFilterPolicy> = new Map();

  constructor() {
    this.initializePolicies();
  }

  private initializePolicies(): void {
    for (const policy of filterPolicies) {
      this.policies.set(policy.id, policy);
    }
    console.log("[ContextFilter] Loaded", filterPolicies.length, "filter policies");
  }

  /**
   * Main entry point: filter context for specified audience
   */
  public filterContextForAI(
    specs: SystemSpecs | null,
    requester: string = "gemini_ai",
    purpose: string = "ai_analysis",
  ): FilteringResult {
    try {
      if (!specs) {
        return {
          success: true,
          context: {
            includedFields: [],
            redactedFields: [],
            removedFields: [],
            classification: "PUBLIC",
            filterMode: "MINIMAL",
            filteredAt: Date.now(),
            data: {},
          },
          requiresAdditionalReview: false,
          recommendations: ["No system specs provided"],
        };
      }

      // Get filter policy for requester
      const policy = this.policies.get(requester) || this.policies.get("GEMINI_AI_ANALYSIS")!;

      // Apply filtering
      const filtered = this.applyFiltering(specs, policy);

      // Sign if policy requires it
      if (policy.signResults) {
        filtered.signature = this.signContext(filtered);
      }

      // Audit log
      const auditEntry = this.createAuditEntry(specs, filtered, requester, purpose, policy);
      this.auditTrail.push(auditEntry);
      memoryVault.store(`filter_audit_${auditEntry.id}`, auditEntry);

      // Feed to cognitive map for monitoring
      cognitiveMap.recordDecision("context_filter", {
        requester,
        purpose,
        redactedCount: filtered.redactedFields.length,
        removedCount: filtered.removedFields.length,
      });

      // Determine if additional review needed
      const requiresReview = filtered.removedFields.length > 5 || 
                            filtered.redactedFields.length > 10;

      return {
        success: true,
        context: filtered,
        requiresAdditionalReview: requiresReview,
        recommendations: this.getRecommendations(filtered, requester),
      };
    } catch (error) {
      console.error("[ContextFilter] Filtering failed:", error);
      return {
        success: false,
        error: String(error),
        context: {
          includedFields: [],
          redactedFields: [],
          removedFields: [],
          classification: "PUBLIC",
          filterMode: "MINIMAL",
          filteredAt: Date.now(),
          data: {},
        },
        requiresAdditionalReview: true,
        recommendations: ["Filtering failed; return empty context"],
      };
    }
  }

  /**
   * Apply filtering rules to system specs
   */
  private applyFiltering(specs: SystemSpecs, policy: ContextFilterPolicy): FilteredContext {
    const data: Record<string, unknown> = {};
    const includedFields: string[] = [];
    const redactedFields: string[] = [];
    const removedFields: string[] = [];

    // Recursively filter all fields
    this.filterObject(specs, data, "", policy, includedFields, redactedFields, removedFields);

    return {
      includedFields,
      redactedFields,
      removedFields,
      classification: this.getMaxClassification(includedFields),
      filterMode: policy.defaultFilterMode,
      filteredAt: Date.now(),
      data,
    };
  }

  /**
   * Recursively filter object properties
   */
  private filterObject(
    source: any,
    target: any,
    path: string,
    policy: ContextFilterPolicy,
    included: string[],
    redacted: string[],
    removed: string[],
  ): void {
    if (!source || typeof source !== "object") return;

    for (const [key, value] of Object.entries(source)) {
      const fieldPath = path ? `${path}.${key}` : key;
      const classification = this.getFieldClassification(fieldPath);

      // Check if allowed by policy
      if (!policy.allowedClassifications.includes(classification)) {
        // Not allowed - redact or remove
        if (classification === "RESTRICTED") {
          target[key] = "[RESTRICTED]";
          redacted.push(fieldPath);
        } else {
          removed.push(fieldPath);
        }
        continue;
      }

      // Field is allowed
      if (typeof value === "object" && !Array.isArray(value) && value !== null) {
        target[key] = {};
        this.filterObject(value, target[key], fieldPath, policy, included, redacted, removed);
      } else {
        target[key] = value;
        included.push(fieldPath);
      }
    }
  }

  /**
   * Get classification for a specific field
   */
  private getFieldClassification(fieldPath: string): DataClassification {
    const classification = fieldClassifications.find(f => f.field === fieldPath);
    return classification?.classification || "INTERNAL";
  }

  /**
   * Determine highest classification in included fields
   */
  private getMaxClassification(includedFields: string[]): DataClassification {
    const levels = { PUBLIC: 0, INTERNAL: 1, CONFIDENTIAL: 2, RESTRICTED: 3 };
    let max = 0;

    for (const field of includedFields) {
      const classification = this.getFieldClassification(field);
      max = Math.max(max, levels[classification]);
    }

    return ["PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED"][max] as DataClassification;
  }

  /**
   * Sign the filtered context for audit trail
   */
  private signContext(context: FilteredContext): string {
    const signatureData = JSON.stringify({
      data: context.data,
      timestamp: context.filteredAt,
      classification: context.classification,
    });
    return cryptoEngine.signData(signatureData);
  }

  /**
   * Create audit entry for this filtering operation
   */
  private createAuditEntry(
    specs: SystemSpecs,
    filtered: FilteredContext,
    requester: string,
    purpose: string,
    policy: ContextFilterPolicy,
  ): FilterAuditEntry {
    const entry: FilterAuditEntry = {
      id: `filter_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      source: specs.source,
      filterMode: filtered.filterMode,
      requester,
      purpose,
      redactedCount: filtered.redactedFields.length,
      removedCount: filtered.removedFields.length,
      timestamp: Date.now(),
      signature: "", // Will be filled below
    };

    entry.signature = cryptoEngine.signData(JSON.stringify(entry));
    return entry;
  }

  /**
   * Generate recommendations for using filtered context
   */
  private getRecommendations(context: FilteredContext, requester: string): string[] {
    const recommendations: string[] = [];

    if (context.removedFields.length > 0) {
      recommendations.push(`${context.removedFields.length} fields were removed due to classification level`);
    }

    if (context.redactedFields.length > 0) {
      recommendations.push(`${context.redactedFields.length} fields were redacted for security`);
    }

    if (context.classification === "RESTRICTED") {
      recommendations.push("This context contains restricted fields and should be handled with care");
    }

    if (context.filterMode === "MINIMAL") {
      recommendations.push("Very limited context available; results may be less accurate");
    }

    return recommendations;
  }

  /**
   * Get audit trail
   */
  public getAuditTrail(limit: number = 100): FilterAuditEntry[] {
    return this.auditTrail.slice(-limit);
  }

  /**
   * Add or update filter policy
   */
  public registerPolicy(policy: ContextFilterPolicy): void {
    this.policies.set(policy.id, policy);
    memoryVault.store(`filter_policy_${policy.id}`, policy);
    console.log("[ContextFilter] Policy registered:", policy.id);
  }

  /**
   * Get current field classification registry
   */
  public getFieldClassifications(): FieldClassification[] {
    return fieldClassifications;
  }

  /**
   * Verify filtered context signature
   */
  public verifySignature(context: FilteredContext): boolean {
    if (!context.signature) {
      console.warn("[ContextFilter] No signature present");
      return false;
    }

    try {
      const signatureData = JSON.stringify({
        data: context.data,
        timestamp: context.filteredAt,
        classification: context.classification,
      });

      return cryptoEngine.verifySignature(signatureData, context.signature);
    } catch (error) {
      console.error("[ContextFilter] Signature verification failed:", error);
      return false;
    }
  }
}

export const contextFilter = new ContextFilterService();