
// types.ts (Context filtering additions)

export type DataClassification = 'PUBLIC' | 'INTERNAL' | 'CONFIDENTIAL' | 'RESTRICTED';
export type FilterMode = 'FULL' | 'SANITIZED' | 'MINIMAL' | 'REDACTED';

/**
 * System specification details - comprehensive hardware/software profile
 */
export interface SystemSpecs {
  // Hardware CPU info
  cpu: {
    model: string;
    cores: number;
    threads: number;
    frequency: number; // GHz
    cache: number; // MB
    serialNumber?: string; // RESTRICTED
    vendor: string;
  };
  // GPU details
  gpu: {
    model: string;
    vram: number; // GB
    architecture: string;
    driver: string;
    serialNumber?: string; // RESTRICTED
    vendor: string;
  };
  // OS information
  os: {
    name: string; // Windows, Linux, macOS
    version: string;
    build: string;
    kernel?: string;
    licenseKey?: string; // RESTRICTED
  };
  // Memory configuration
  memory: {
    total: number; // GB
    available: number; // GB
    type: string; // DDR4, DDR5, etc.
  };
  // Storage details
  storage: {
    total: number; // GB
    available: number; // GB
    type: string; // SSD, HDD, NVMe
    encryptionStatus: 'ENCRYPTED' | 'UNENCRYPTED' | 'UNKNOWN';
  };
  // Network configuration
  network: {
    ipAddress?: string; // INTERNAL
    macAddress?: string; // INTERNAL
    hostname?: string; // INTERNAL
    vpnActive: boolean;
    publicIp?: string; // INTERNAL
  };
  // Security posture
  security: {
    firewallEnabled: boolean;
    antivirusStatus: 'ACTIVE' | 'INACTIVE' | 'UNKNOWN';
    tpmAvailable: boolean;
    secureBootEnabled: boolean;
  };
  // Geolocation (if available)
  location?: {
    country?: string; // INTERNAL
    region?: string; // INTERNAL
    timezone?: string; // PUBLIC
    latitude?: number; // RESTRICTED
    longitude?: number; // RESTRICTED
  };
  // Metadata
  timestamp: number;
  source: string;
}

/**
 * Field-level classification: what data can be shared where
 */
export interface FieldClassification {
  /** Field name (dot notation for nested, e.g., "cpu.serialNumber") */
  field: string;
  /** Minimum clearance level to view this field */
  classification: DataClassification;
  /** Description of why this field is classified */
  reason: string;
  /** Whether to redact value (true) or remove field entirely (false) */
  redactInsteadOfRemove: boolean;
  /** If redacting, what placeholder to use */
  redactionPlaceholder?: string;
}

/**
 * Filtered context prepared for external consumption
 */
export interface FilteredContext {
  /** Fields included in this context */
  includedFields: string[];
  /** Fields redacted in this context */
  redactedFields: string[];
  /** Fields removed entirely */
  removedFields: string[];
  /** Data classification level of this context */
  classification: DataClassification;
  /** Which filter mode was applied */
  filterMode: FilterMode;
  /** Timestamp of filtering */
  filteredAt: number;
  /** HMAC signature for audit trail */
  signature?: string;
  /** Actual filtered data */
  data: Record<string, unknown>;
}

/**
 * Audit log entry for context filtering
 */
export interface FilterAuditEntry {
  /** Unique event ID */
  id: string;
  /** Original specs source */
  source: string;
  /** Filter mode applied */
  filterMode: FilterMode;
  /** Requester identity (system, user, service) */
  requester: string;
  /** Intended use (e.g., "gemini_analysis", "dashboard", "export") */
  purpose: string;
  /** How many fields were redacted */
  redactedCount: number;
  /** How many fields were removed */
  removedCount: number;
  /** Timestamp of filtering operation */
  timestamp: number;
  /** HMAC signature of request + response */
  signature: string;
}

/**
 * Context filter policies - define what can be shared in what contexts
 */
export interface ContextFilterPolicy {
  /** Policy identifier */
  id: string;
  /** Default filter mode for this context */
  defaultFilterMode: FilterMode;
  /** Target audience (e.g., "gemini_ai", "dashboard_ui", "external_api") */
  audience: string;
  /** List of allowed field classifications for this audience */
  allowedClassifications: DataClassification[];
  /** Whether to log all filtering operations */
  auditLogging: boolean;
  /** Whether to sign filtered results */
  signResults: boolean;
  /** Custom field overrides (higher security takes precedence) */
  fieldOverrides?: Partial<FieldClassification>[];
}

/**
 * Filtering result with detailed metadata
 */
export interface FilteringResult {
  /** Whether filtering succeeded */
  success: boolean;
  /** Error message if filtering failed */
  error?: string;
  /** The filtered context data */
  context: FilteredContext;
  /** Whether further redaction is needed */
  requiresAdditionalReview: boolean;
  /** Recommendations for using this context */
  recommendations: string[];
}

/**
 * Validates a Python task intent against allowed operations and system state.
 */
export const validatePythonTask = async (task: string): Promise<boolean> => {
  const allowedTasks = ["SYSTEM_ANALYSIS", "GENERATE_EMBEDDINGS", "PREPARE_TRAINING_DATA", "DEEPSPEED_SETUP"];
  const normalizedTask = task.toUpperCase().replace(/[^A-Z]/g, '_');
  return allowedTasks.includes(normalizedTask) || normalizedTask.startsWith('OS_OPTIMIZE_');
};

/**
 * Context Filter Service
 * Applies security-aware filtering to system specifications
 */
class ContextFilterService {
  private auditTrail: FilterAuditEntry[] = [];
  private policies: Map<string, ContextFilterPolicy> = new Map();

  constructor() {
    this.initializePolicies();
  }

  private initializePolicies(): void {
    // Basic initialization if needed
  }
}
