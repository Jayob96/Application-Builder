// types.ts (or a dedicated policy types file)
export type PolicySeverity = "INFO" | "WARN" | "BLOCK";

export interface PolicyThreshold {
  /** Human-readable label for the threshold, e.g. "CPU_USAGE" */
  id: string;
  /** Maximum allowed value before violation is triggered. */
  max: number;
  /** If true, values strictly greater than max are violations. */
  strictGreaterThan: boolean;
  /** Severity of violating this threshold. */
  severity: PolicySeverity;
  /** Optional description for logging / UI. */
  description?: string;
}

export interface ThermalPolicy {
  /** If true, high thermal states are allowed up to maxSafeTemp. */
  allowHighThermal: boolean;
  /** Maximum safe temperature in °C before violation. */
  maxSafeTemp: number;
  /** Hard cutoff temperature in °C where policy always blocks. */
  hardCutoffTemp: number;
}

export interface CpuPolicy {
  /** Maximum allowed CPU usage percentage. */
  maxCpuUsage: number;
  /** If true, bursts above maxCpuUsage are tolerated for short durations. */
  allowShortBursts: boolean;
  /** Maximum burst duration in ms. */
  maxBurstDurationMs: number;
}

export interface SecurityPolicy {
  /** If true, suspicious processes are quarantined. */
  quarantineSuspicious: boolean;
  /** If true, all policy violations are logged. */
  logViolations: boolean;
  /** If true, system will attempt auto-mitigation (e.g., throttling). */
  autoMitigate: boolean;
}

export interface SystemPolicy {
  /** Policy identifier, e.g. "DEF_BALANCED". */
  id: string;
  /** Human-readable display name. */
  name: string;
  /** Optional description for dashboards. */
  description?: string;
  /** CPU-related limits. */
  cpu: CpuPolicy;
  /** Thermal-related limits. */
  thermal: ThermalPolicy;
  /** Security behavior flags. */
  security: SecurityPolicy;
  /** Additional numeric thresholds keyed by logical ID. */
  thresholds?: PolicyThreshold[];
}

export interface PolicyCheckInput {
  /** Current CPU usage percentage. */
  cpuUsage: number;
  /** Current temperature in °C. */
  temperature: number;
  /** Optional duration of the current CPU burst in ms. */
  burstDurationMs?: number;
  /** Optional map of extra metrics, e.g. { GPU_TEMP: 78 }. */
  metrics?: Record<string, number>;
}

export interface PolicyViolation {
  /** Identifier of the violated rule or threshold. */
  id: string;
  /** Severity of this violation. */
  severity: PolicySeverity;
  /** Human-readable explanation. */
  message: string;
}

export interface PolicyCheckResult {
  /** Whether the system is compliant with the active policy. */
  compliant: boolean;
  /** All detected violations (empty if compliant). */
  violations: PolicyViolation[];
  /** ID of the policy that was applied. */
  policyId: string;
}
