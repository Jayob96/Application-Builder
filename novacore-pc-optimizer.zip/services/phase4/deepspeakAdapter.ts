// deepspeakAdapter.ts

export type DeepspeakOpCode =
  | "SET_KRNL_CACHE_STRATEGY"
  | "FLUSH_PAGE_FILE_BUFFER"
  | "INIT_P_FILTER_HARDENED";

export interface DeepspeakCommand {
  /** High-level, human-readable instruction. */
  instruction: string;
  /** Normalized instruction key (lowercased, trimmed). */
  normalized: string;
  /** Mapped low-level opcode, if recognized. */
  opcode?: DeepspeakOpCode;
  /** Raw payload that would be sent to DeepSpeak (never executed directly here). */
  payload: string;
  /** Whether this command is considered safe. */
  safe: boolean;
  /** Reason/explanation for mapping and safety assessment. */
  reason: string;
}

/**
 * Internal canonical mapping from normalized instructions to DeepSpeak opcodes.
 */
const DEEPSPEAK_MAP: Record<string, { opcode: DeepspeakOpCode; payload: string; reason: string }> = {
  "optimize cache": {
    opcode: "SET_KRNL_CACHE_STRATEGY",
    payload: "SET_KRNL_CACHE_STRATEGY 0x01",
    reason: "Optimize kernel cache strategy with conservative preset (0x01).",
  },
  "clear memory": {
    opcode: "FLUSH_PAGE_FILE_BUFFER",
    payload: "FLUSH_PAGE_FILE_BUFFER",
    reason: "Flush page file buffers to reclaim memory without unsafe operations.",
  },
  "harden firewall": {
    opcode: "INIT_P_FILTER_HARDENED",
    payload: "INIT_P_FILTER_HARDENED",
    reason: "Apply hardened packet filter profile to firewall subsystem.",
  },
};

/**
 * Analyze and adapt a high-level instruction into a structured DeepSpeak command.
 * Does NOT execute anything; only maps and classifies.
 */
export const adaptToDeepspeakDetailed = (instruction: string): DeepspeakCommand => {
  const normalized = instruction.trim().toLowerCase();

  const known = DEEPSPEAK_MAP[normalized];
  if (known) {
    return {
      instruction,
      normalized,
      opcode: known.opcode,
      payload: known.payload,
      safe: true,
      reason: known.reason,
    };
  }

  // Basic safeguard: flag anything that looks dangerous
  const lower = normalized;
  const looksDangerous =
    lower.includes("format") ||
    lower.includes("delete c:") ||
    lower.includes("wipe disk") ||
    lower.includes("overclock") ||
    lower.includes("shutdown") ||
    lower.includes("kill process") ||
    lower.includes("registry") ||
    lower.includes("firmware");

  if (looksDangerous) {
    return {
      instruction,
      normalized,
      opcode: undefined,
      payload: `RAW_EXEC_BLOCKED: ${instruction}`,
      safe: false,
      reason:
        "Instruction contains potentially dangerous keywords and was not mapped to a known safe DeepSpeak opcode.",
    };
  }

  return {
    instruction,
    normalized,
    opcode: undefined,
    payload: `RAW_EXEC: ${instruction}`,
    safe: false,
    reason:
      "Instruction is not recognized in the DeepSpeak mapping table and must be reviewed manually before execution.",
  };
};

/**
 * Backwards-compatible simple API:
 * Returns only the payload string, preserving original behavior,
 * but blocks obviously dangerous instructions.
 */
export const adaptToDeepspeak = (instruction: string): string => {
  const result = adaptToDeepspeakDetailed(instruction);
  return result.payload;
};
