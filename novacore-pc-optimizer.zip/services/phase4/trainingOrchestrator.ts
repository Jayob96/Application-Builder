import { trainingLab } from "../securityTrainingService";
import { tuningEngine } from "../smartTuningService";
import { SystemSpecs } from "../../types";

export type GlobalTrainingPhase = "INIT" | "TRAINING_EPOCH" | "TUNING_CYCLE" | "COMPLETED" | "FAILED";

export interface GlobalTrainingResult {
  status: "success" | "failed";
  phase: GlobalTrainingPhase;
  ranTuningCycle: boolean;
  runId: string;
  startedAt: number;
  finishedAt: number;
  durationMs: number;
  message: string;
  /** Optional nested results from sub-systems, if they return anything. */
  details?: {
    trainingEpochResult?: unknown;
    tuningCycleResult?: unknown;
  };
}

/**
 * Orchestrates a single global training epoch, optionally triggering a tuning cycle.
 * Provides structured telemetry for higher-level monitoring.
 */
export const orchestrateGlobalTraining = async (
  specs: SystemSpecs | null,
  log: (msg: string) => void = console.log,
): Promise<GlobalTrainingResult> => {
  const runId = `global_train_${Date.now().toString(36)}`;
  const startedAt = Date.now();
  let phase: GlobalTrainingPhase = "INIT";
  let ranTuningCycle = false;

  const details: GlobalTrainingResult["details"] = {};

  try {
    log(`[GlobalTraining] (${runId}) Initializing global training epoch...`);
    phase = "TRAINING_EPOCH";

    // Run primary security training epoch
    const trainingResult = await trainingLab.runEpoch(specs);
    details.trainingEpochResult = trainingResult;
    log(`[GlobalTraining] (${runId}) Training epoch completed.`);

    // Decide whether to run tuning cycle
    if (Math.random() > 0.5) {
      phase = "TUNING_CYCLE";
      log(`[GlobalTraining] (${runId}) Triggering tuning cycle...`);
      const tuningResult = await tuningEngine.runTuningCycle(specs, []);
      details.tuningCycleResult = tuningResult;
      ranTuningCycle = true;
      log(`[GlobalTraining] (${runId}) Tuning cycle completed.`);
    } else {
      log(`[GlobalTraining] (${runId}) Skipping tuning cycle this epoch.`);
    }

    phase = "COMPLETED";
    const finishedAt = Date.now();

    return {
      status: "success",
      phase,
      ranTuningCycle,
      runId,
      startedAt,
      finishedAt,
      durationMs: finishedAt - startedAt,
      message: "Global training epoch completed successfully.",
      details,
    };
  } catch (error) {
    const finishedAt = Date.now();
    log(`[GlobalTraining] (${runId}) FAILED in phase ${phase}: ${String(error)}`);

    return {
      status: "failed",
      phase: "FAILED",
      ranTuningCycle,
      runId,
      startedAt,
      finishedAt,
      durationMs: finishedAt - startedAt,
      message: `Global training failed in phase ${phase}: ${String(error)}`,
      details,
    };
  }
};
