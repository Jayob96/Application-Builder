import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Terminal, Activity, Zap, Flame, Cloud, Target, Cpu, TrendingUp, AlertTriangle, Download } from 'lucide-react';
import { storageService } from '../services/Infrastructure/storageService';

interface SystemMetrics {
  cpu?: number;      // 0-100
  memory?: number;   // 0-100
  temperature?: number;
  network?: number;  // 0-100
  diskUsage?: number; // 0-100
}

interface HealthThresholds {
  cpu?: { warning: number; critical: number };
  memory?: { warning: number; critical: number };
  temperature?: { warning: number; critical: number };
  network?: { warning: number; critical: number };
  diskUsage?: { warning: number; critical: number };
}

interface Alert {
  type: string;
  value: number;
  threshold: number;
  severity: 'warning' | 'critical';
  timestamp: number;
}

interface Props {
  status: string;
  uptime: number;
  systemMetrics?: SystemMetrics;
  enableAlerts?: boolean;
  enableTrends?: boolean;
  enableExport?: boolean;
  theme?: 'dark' | 'light' | 'auto';
  onAlertChange?: (alert: Alert) => void;
  historyPoints?: number;
  refreshInterval?: number;
  healthThresholds?: HealthThresholds;
}

/**
 * Enhanced TerminalHeader Component v2.0
 * 
 * Features:
 * - Real-time system metrics (CPU, memory, temperature, network, disk)
 * - Health status indicators (green/yellow/red)
 * - Trend sparklines for visual analysis
 * - Alert system with configurable thresholds
 * - Theme support (dark/light/auto)
 * - Export metrics for reporting
 * - Performance optimized with React.memo
 */
const TerminalHeader: React.FC<Props> = ({
  status,
  uptime,
  systemMetrics = {} as SystemMetrics,
  enableAlerts = true,
  enableTrends = true,
  enableExport = true,
  theme = 'auto',
  onAlertChange,
  historyPoints = 60,
  refreshInterval = 2000,
  healthThresholds = {
    cpu: { warning: 75, critical: 90 },
    memory: { warning: 80, critical: 95 },
    temperature: { warning: 65, critical: 80 },
    network: { warning: 50, critical: 20 },
    diskUsage: { warning: 85, critical: 95 }
  }
}) => {
  const [syncInfo, setSyncInfo] = useState(storageService.getSyncStatus());
  const [metricHistory, setMetricHistory] = useState<Record<string, number[]>>({});
  const [currentAlerts, setCurrentAlerts] = useState<Alert[]>([]);
  const [isDarkMode, setIsDarkMode] = useState(theme === 'dark' || (theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches));

  const env = (import.meta as any).env || {};
  const hasBackpackKey = !!env.VITE_BACKPACK_API_KEY;

  const sessionId = React.useMemo(
    () => Math.random().toString(16).slice(2, 12).toUpperCase(),
    []
  );

  // Update sync status
  useEffect(() => {
    const interval = setInterval(() => {
      setSyncInfo(storageService.getSyncStatus());
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  // Track metric history for trends
  useEffect(() => {
    setMetricHistory(prev => {
      const updated = { ...prev };
      Object.entries(systemMetrics).forEach(([key, value]) => {
        if (typeof value === 'number') {
          updated[key] = [...(updated[key] || []), value].slice(-historyPoints);
        }
      });
      return updated;
    });
  }, [systemMetrics, historyPoints]);

  // Check for alerts
  useEffect(() => {
    const alerts: Alert[] = [];

    Object.entries(systemMetrics).forEach(([key, value]) => {
      if (typeof value !== 'number') return;

      const threshold = healthThresholds[key as keyof HealthThresholds];
      if (!threshold) return;

      if (value >= threshold.critical) {
        alerts.push({
          type: key,
          value,
          threshold: threshold.critical,
          severity: 'critical',
          timestamp: Date.now()
        });
      } else if (value >= threshold.warning) {
        alerts.push({
          type: key,
          value,
          threshold: threshold.warning,
          severity: 'warning',
          timestamp: Date.now()
        });
      }
    });

    setCurrentAlerts(alerts);
    alerts.forEach(alert => onAlertChange?.(alert));
  }, [systemMetrics, healthThresholds, onAlertChange]);

  // Calculate health score
  const healthScore = useMemo(() => {
    const { cpu = 0, memory = 0, temperature = 0, network = 100, diskUsage = 0 } = systemMetrics;
    const score = (
      (100 - cpu * 0.3) +
      (100 - memory * 0.3) +
      (100 - (temperature / 100) * 0.2) +
      (network * 0.2) +
      (100 - diskUsage * 0.1)
    ) / 5;
    return Math.max(0, Math.min(100, score));
  }, [systemMetrics]);

  // Determine health status
  const getHealthStatus = useCallback(() => {
    if (currentAlerts.some(a => a.severity === 'critical')) return 'CRITICAL';
    if (currentAlerts.some(a => a.severity === 'warning')) return 'WARNING';
    return status;
  }, [status, currentAlerts]);

  // Get status color
  const getStatusColor = useCallback(() => {
    const healthStatus = getHealthStatus();
    if (healthStatus === 'CRITICAL') return 'text-red-500';
    if (healthStatus === 'WARNING') return 'text-yellow-500';
    return 'text-green-500';
  }, [getHealthStatus]);

  // Get status indicator
  const getStatusIndicator = useCallback(() => {
    const healthStatus = getHealthStatus();
    if (healthStatus === 'CRITICAL') return '🔴';
    if (healthStatus === 'WARNING') return '🟡';
    return '🟢';
  }, [getHealthStatus]);

  // Export metrics
  const handleExport = useCallback(() => {
    const data = {
      timestamp: Date.now(),
      status,
      uptime,
      systemMetrics,
      healthScore,
      alerts: currentAlerts
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `system-metrics-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [status, uptime, systemMetrics, healthScore, currentAlerts]);

  // Format uptime
  const formatUptime = useCallback(() => {
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = uptime % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }, [uptime]);

  // Sparkline component
  const Sparkline = React.memo(({ data, color = 'orange' }: { data: number[]; color?: string }) => {
    if (data.length < 2) return <div className="w-12 h-4" />;

    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min || 1;

    const points = data.map((v, i) => {
      const x = (i / (data.length - 1)) * 60;
      const y = 20 - ((v - min) / range) * 20;
      return `${x},${y}`;
    }).join(' ');

    const colorMap: Record<string, string> = {
      orange: '#f97316',
      green: '#22c55e',
      red: '#ef4444'
    };

    return (
      <svg width="60" height="20" className="overflow-visible">
         <polyline 
            points={points} 
            fill="none" 
            stroke={colorMap[color as keyof typeof colorMap] || color} 
            strokeWidth="1.5" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
         />
      </svg>
    );
  });

  return (
    <div className={`glass-panel p-4 rounded-xl border-b border-orange-500/10 flex items-center justify-between ${isDarkMode ? 'bg-black/80 text-white' : 'bg-white/80 text-black'}`}>
      <div className="flex items-center gap-6">
         <div className="flex flex-col">
            <h1 className="text-xl font-black italic tracking-tighter flex items-center gap-2">
               <Terminal size={24} className="text-orange-500" />
               PHOENIX<span className="text-orange-500">HUNTER</span>
            </h1>
            <div className="flex items-center gap-2 text-[10px] font-mono mt-1">
               <span className={`flex items-center gap-1 ${getStatusColor()}`}>
                 {getStatusIndicator()} {status}
               </span>
               <span className="text-zinc-600">|</span>
               <span className="text-zinc-500">UPTIME: {formatUptime()}</span>
            </div>
         </div>

         {/* Metrics Grid */}
         <div className="hidden lg:flex items-center gap-6 px-6 border-l border-zinc-800/50">
            <div className="flex flex-col gap-1">
               <div className="flex items-center gap-2 text-[10px] font-bold text-zinc-500 uppercase">
                  <Cpu size={12} /> CPU
               </div>
               <div className="flex items-center gap-2">
                  <span className="text-lg font-black">{systemMetrics.cpu || 0}%</span>
                  {enableTrends && <Sparkline data={metricHistory.cpu || []} color="orange" />}
               </div>
            </div>
            <div className="flex flex-col gap-1">
               <div className="flex items-center gap-2 text-[10px] font-bold text-zinc-500 uppercase">
                  <Activity size={12} /> MEM
               </div>
               <div className="flex items-center gap-2">
                  <span className="text-lg font-black">{systemMetrics.memory || 0}%</span>
                  {enableTrends && <Sparkline data={metricHistory.memory || []} color="green" />}
               </div>
            </div>
            <div className="flex flex-col gap-1">
               <div className="flex items-center gap-2 text-[10px] font-bold text-zinc-500 uppercase">
                  <Cloud size={12} /> NET
               </div>
               <div className="flex items-center gap-2">
                  <span className="text-lg font-black">{systemMetrics.network || 0}%</span>
                  {enableTrends && <Sparkline data={metricHistory.network || []} color="red" />}
               </div>
            </div>
         </div>
      </div>

      <div className="flex items-center gap-4">
         {currentAlerts.length > 0 && (
            <div className="flex items-center gap-2 px-3 py-1 bg-red-500/10 border border-red-500/20 rounded text-red-500 animate-pulse">
               <AlertTriangle size={14} />
               <span className="text-xs font-bold">{currentAlerts.length} ALERTS</span>
            </div>
         )}
         
         <div className="text-right">
             <div className="text-[10px] font-bold text-zinc-500 uppercase">Health Score</div>
             <div className={`text-2xl font-black ${healthScore > 80 ? 'text-green-500' : healthScore > 50 ? 'text-yellow-500' : 'text-red-500'}`}>
                {healthScore.toFixed(0)}%
             </div>
         </div>

         {enableExport && (
            <button onClick={handleExport} className="p-2 hover:bg-white/5 rounded text-zinc-500 hover:text-white transition-colors">
               <Download size={18} />
            </button>
         )}
      </div>
    </div>
  );
};

export default React.memo(TerminalHeader);