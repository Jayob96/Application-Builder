import React, { useMemo, useCallback, useState } from 'react';
import { ScoringWeights } from '../types';
import { observabilityService } from '../services/Infrastructure/observabilityService';

/**
 * Enhanced Props Interface
 * Supports delta tracking, historical comparison, and ROI visualization
 */
interface Props {
  weights: ScoringWeights;
  previousWeights?: ScoringWeights;
  title?: string;
  showDelta?: boolean;
  showROIImpact?: boolean;
  roiMetrics?: {
    currentROI: number;
    previousROI: number;
    improvement: number;
  };
  onExport?: (data: ExportData) => void;
}

interface ExportData {
  timestamp: number;
  weights: ScoringWeights;
  deltas?: Record<string, number>;
  roiImprovement?: number;
  csv: string;
}

/**
 * Filter Descriptions for Tooltips
 */
const FILTER_DESCRIPTIONS: Record<string, string> = {
  liquidity: "Pooled value available for swaps - higher liquidity = lower slippage risk",
  holderDistribution: "Token spread across wallets - concentrated holders = higher rug risk",
  velocity: "Trade frequency and transaction speed - indicates market activity level",
  volatility: "Price variance in 24-hour window - high volatility = higher risk/reward",
  sentiment: "Community perception and hype level - measured via social metrics",
  volumeTrend: "Recent trading activity momentum - trending up = bullish signal",
  age: "Days since token contract creation - older tokens generally safer",
  concentration: "Top 10 holder percentage of supply - >50% = major red flag",
  authorityRisk: "Mint/freeze authority active status - renounced = safer token"
};

/**
 * ForensicRadar: Real-Time Neural Weight Visualization
 * 
 * Enhanced Features:
 * - Real-time weight animation with 1000ms smooth transition
 * - Delta tracking showing weight changes (+/- indicators)
 * - Historical comparison with previous weight sets
 * - Interactive tooltips with filter descriptions
 * - ROI impact visualization and metrics
 * - Export capabilities for reporting
 * - Performance optimized with React.memo and useMemo
 */
const ForensicRadar: React.FC<Props> = ({
  weights,
  previousWeights,
  title = "Neural Calibration",
  showDelta = true,
  showROIImpact = false,
  roiMetrics,
  onExport
}) => {
  const [hoveredFilter, setHoveredFilter] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState(false);

  // Memoize entries to prevent unnecessary re-renders
  const entries = useMemo(() => Object.entries(weights), [weights]);

  // Calculate deltas if previous weights available
  const deltas = useMemo(() => {
    if (!previousWeights || !showDelta) return null;
    
    const deltasMap: Record<string, number> = {};
    entries.forEach(([key, val]) => {
      const prev = previousWeights[key as keyof ScoringWeights];
      deltasMap[key] = Number(val) - Number(prev);
    });
    return deltasMap;
  }, [weights, previousWeights, showDelta, entries]);

  // Validate weights sum to 1.0
  const totalWeight = useMemo(() => {
    const sum = entries.reduce((acc, [, val]) => acc + Number(val), 0);
    if (Math.abs(sum - 1.0) > 0.01) {
      console.warn('ForensicRadar: Weights do not sum to 1.0:', sum);
    }
    return sum;
  }, [entries]);

  // Export weights report
  const handleExport = useCallback(async () => {
    setIsExporting(true);
    try {
      const csv = entries
        .map(([key, val]) => `${key},${Number(val).toFixed(4)},${(Number(val) * 100).toFixed(2)}%`)
        .join('\n');

      const exportData: ExportData = {
        timestamp: Date.now(),
        weights,
        deltas: deltas || undefined,
        roiImprovement: roiMetrics?.improvement,
        csv: `Filter,Weight,Percentage\n${csv}`
      };

      onExport?.(exportData);

      // Also trigger browser download
      const blob = new Blob([exportData.csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `forensic-weights-${Date.now()}.csv`;
      a.click();
      URL.revokeObjectURL(url);

      observabilityService.log('FORENSIC_RADAR', 'success', 'Weights exported successfully');
    } catch (error) {
      observabilityService.log('FORENSIC_RADAR', 'error', 'Export failed');
    } finally {
      setIsExporting(false);
    }
  }, [entries, deltas, roiMetrics, weights, onExport]);

  // Format filter names (camelCase → Title Case)
  const formatFilterName = useCallback((name: string): string => {
    return name
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, str => str.toUpperCase())
      .trim();
  }, []);

  // Get color intensity based on weight magnitude
  const getFilterColor = useCallback((weight: number): string => {
    if (weight < 0.08) return 'from-red-700 via-red-600 to-red-500';
    if (weight < 0.10) return 'from-red-600 via-orange-600 to-orange-500';
    if (weight < 0.12) return 'from-orange-600 via-orange-500 to-amber-500';
    if (weight < 0.15) return 'from-orange-500 via-amber-500 to-amber-400';
    return 'from-amber-500 via-yellow-500 to-yellow-400';
  }, []);

  // Get delta indicator color and symbol
  const getDeltaIndicator = useCallback((delta: number): { color: string; symbol: string; formatted: string } => {
    if (Math.abs(delta) < 0.001) return { color: 'text-zinc-500', symbol: '≈', formatted: '±0.0%' };
    if (delta > 0) return { 
      color: 'text-green-400', 
      symbol: '↑', 
      formatted: `+${(delta * 100).toFixed(2)}%` 
    };
    return { 
      color: 'text-red-400', 
      symbol: '↓', 
      formatted: `${(delta * 100).toFixed(2)}%` 
    };
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-4 pb-3 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-orange-500 animate-pulse shadow-[0_0_10px_rgba(249,115,22,0.8)]" />
          <h3 className="text-[10px] font-black text-white uppercase tracking-[0.3em]">
            {title}
          </h3>
        </div>

        {/* Header Stats */}
        <div className="flex items-center gap-4 text-[9px] font-bold uppercase tracking-wider">
          {roiMetrics && showROIImpact && (
            <div className="flex items-center gap-2">
              <span className="text-zinc-500">ROI</span>
              <span className={roiMetrics.improvement > 0 ? 'text-green-400' : 'text-red-400'}>
                {roiMetrics.improvement > 0 ? '+' : ''}{(roiMetrics.improvement * 100).toFixed(2)}%
              </span>
            </div>
          )}
          
          {totalWeight !== 1.0 && (
            <div className="flex items-center gap-2 text-yellow-500">
              <span>⚠️ SUM: {(totalWeight * 100).toFixed(1)}%</span>
            </div>
          )}

          {/* Export Button */}
          <button
            onClick={handleExport}
            disabled={isExporting}
            className="px-2 py-0.5 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-50 rounded text-zinc-400 hover:text-orange-400 transition-all"
            title="Export weights as CSV"
          >
            {isExporting ? '⏳' : '↓'}
          </button>
        </div>
      </div>

      {/* ROI Impact Summary */}
      {showROIImpact && roiMetrics && (
        <div className="bg-gradient-to-r from-orange-500/10 to-amber-500/10 border border-orange-500/20 rounded p-3 mb-4">
          <div className="grid grid-cols-3 gap-4 text-[9px] font-bold uppercase tracking-widest">
            <div className="space-y-1">
              <span className="text-zinc-500">Previous ROI</span>
              <p className="text-white">{(roiMetrics.previousROI * 100).toFixed(2)}%</p>
            </div>
            <div className="space-y-1">
              <span className="text-zinc-500">Current ROI</span>
              <p className="text-orange-400">{(roiMetrics.currentROI * 100).toFixed(2)}%</p>
            </div>
            <div className="space-y-1">
              <span className="text-zinc-500">Improvement</span>
              <p className={roiMetrics.improvement > 0 ? 'text-green-400' : 'text-red-400'}>
                {roiMetrics.improvement > 0 ? '↑' : '↓'} {Math.abs(roiMetrics.improvement * 100).toFixed(2)}%
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Weight Bars Grid */}
      <div className="grid grid-cols-1 gap-4">
        {entries.map(([key, val]) => {
          const percentage = Number(val) * 100;
          const delta = deltas?.[key];
          const deltaInfo = delta !== undefined ? getDeltaIndicator(delta) : null;

          return (
            <div
              key={key}
              className="space-y-1.5 group"
              onMouseEnter={() => setHoveredFilter(key)}
              onMouseLeave={() => setHoveredFilter(null)}
            >
              {/* Label Row */}
              <div className="flex justify-between items-start">
                <div className="flex-1 min-w-0">
                  <div className="text-[9px] uppercase font-black tracking-widest text-zinc-400 group-hover:text-white transition-colors">
                    {formatFilterName(key)}
                  </div>
                  
                  {/* Tooltip */}
                  {hoveredFilter === key && (
                    <div className="text-[8px] text-zinc-500 mt-1 leading-tight max-w-xs">
                      {FILTER_DESCRIPTIONS[key]}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {/* Percentage */}
                  <span className="text-orange-400 font-bold text-[9px] tabular-nums">
                    {percentage.toFixed(1)}%
                  </span>

                  {/* Delta Indicator */}
                  {deltaInfo && showDelta && (
                    <span className={`text-[9px] font-black tabular-nums ${deltaInfo.color}`}>
                      {deltaInfo.symbol} {deltaInfo.formatted}
                    </span>
                  )}
                </div>
              </div>

              {/* Progress Bar */}
              <div className="h-1.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800 shadow-inner">
                <div
                  className={`h-full bg-gradient-to-r ${getFilterColor(Number(val))} transition-all duration-1000 shadow-[0_0_12px_rgba(249,115,22,0.2)] group-hover:shadow-[0_0_15px_rgba(249,115,22,0.4)]`}
                  style={{ width: `${percentage}%` }}
                />
              </div>

              {/* Previous Weight Indicator (if available) */}
              {previousWeights && showDelta && (
                <div className="text-[8px] text-zinc-600 flex items-center gap-1">
                  <span>Previous:</span>
                  <span className="font-mono">{(Number(previousWeights[key as keyof ScoringWeights]) * 100).toFixed(1)}%</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer Stats */}
      <div className="text-[8px] text-zinc-600 pt-4 border-t border-zinc-800 flex justify-between">
        <span>Total Weight: {(totalWeight * 100).toFixed(2)}%</span>
        <span>Updated: {new Date().toLocaleTimeString()}</span>
      </div>
    </div>
  );
};

export default React.memo(ForensicRadar);