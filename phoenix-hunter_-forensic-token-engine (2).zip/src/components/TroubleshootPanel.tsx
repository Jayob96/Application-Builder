
import React, { useState, useEffect } from 'react';
import { selfHealingService, IncidentRecord } from '../services/Infrastructure/SelfHealingService';
import { Activity, AlertTriangle, CheckCircle, Database, RefreshCw, Shield, Trash2, Wrench } from 'lucide-react';
import { vfs } from '../services/Infrastructure/VirtualFileSystem';

const TroubleshootPanel: React.FC = () => {
  const [db, setDb] = useState(selfHealingService.getDatabase());
  const [activeTab, setActiveTab] = useState<'issues' | 'events' | 'database'>('issues');

  useEffect(() => {
    const interval = setInterval(() => {
      setDb({ ...selfHealingService.getDatabase() });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleResolve = (signature: string) => {
    selfHealingService.resolveIncident(signature);
    setDb({ ...selfHealingService.getDatabase() });
  };

  const handleClear = () => {
    if (confirm('Are you sure you want to wipe the incident memory?')) {
      selfHealingService.clearHistory();
      setDb({ ...selfHealingService.getDatabase() });
    }
  };

  const activeIncidents = Object.values(db.incidents)
    .filter(i => i.status === 'ACTIVE')
    .sort((a, b) => b.lastSeen - a.lastSeen);

  const resolvedIncidents = Object.values(db.incidents)
    .filter(i => i.status === 'RESOLVED')
    .sort((a, b) => b.lastSeen - a.lastSeen);

  const healthColor = db.systemHealth > 80 ? 'text-green-500' : db.systemHealth > 50 ? 'text-yellow-500' : 'text-red-500';

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-hidden">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass-panel p-4 rounded-xl border-orange-500/20 bg-black/40 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">System Health</div>
            <div className={`text-3xl font-black ${healthColor}`}>{db.systemHealth.toFixed(0)}%</div>
          </div>
          <Activity size={24} className={healthColor} />
        </div>
        <div className="glass-panel p-4 rounded-xl border-orange-500/20 bg-black/40 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Active Issues</div>
            <div className="text-3xl font-black text-white">{activeIncidents.length}</div>
          </div>
          <AlertTriangle size={24} className="text-orange-500" />
        </div>
        <div className="glass-panel p-4 rounded-xl border-orange-500/20 bg-black/40 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Learned Patterns</div>
            <div className="text-3xl font-black text-white">{Object.keys(db.incidents).length}</div>
          </div>
          <Database size={24} className="text-blue-500" />
        </div>
        <div className="glass-panel p-4 rounded-xl border-orange-500/20 bg-black/40 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Events Logged</div>
            <div className="text-3xl font-black text-white">{db.recentEvents.length}</div>
          </div>
          <Activity size={24} className="text-zinc-500" />
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 glass-panel rounded-xl border-orange-500/20 bg-black/60 flex flex-col min-h-0">
        {/* Toolbar */}
        <div className="flex items-center justify-between p-4 border-b border-white/5">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('issues')}
              className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${activeTab === 'issues' ? 'bg-orange-500 text-black' : 'bg-white/5 text-zinc-400 hover:text-white'}`}
            >
              Diagnostic Panel
            </button>
            <button
              onClick={() => setActiveTab('events')}
              className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${activeTab === 'events' ? 'bg-orange-500 text-black' : 'bg-white/5 text-zinc-400 hover:text-white'}`}
            >
              Raw Event Stream
            </button>
            <button
              onClick={() => setActiveTab('database')}
              className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${activeTab === 'database' ? 'bg-orange-500 text-black' : 'bg-white/5 text-zinc-400 hover:text-white'}`}
            >
              JSON Database
            </button>
          </div>
          <div className="flex gap-2">
            <button onClick={() => selfHealingService.forceLearn()} className="p-2 bg-white/5 hover:bg-green-500/20 hover:text-green-500 rounded transition-all" title="Force Save">
              <RefreshCw size={16} />
            </button>
            <button onClick={handleClear} className="p-2 bg-white/5 hover:bg-red-500/20 hover:text-red-500 rounded transition-all" title="Wipe Memory">
              <Trash2 size={16} />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
          
          {/* TAB: ISSUES */}
          {activeTab === 'issues' && (
            <div className="space-y-8">
              {activeIncidents.length === 0 && resolvedIncidents.length === 0 && (
                <div className="flex flex-col items-center justify-center h-64 text-zinc-600">
                  <Shield size={64} className="mb-4 text-green-500/20" />
                  <span className="text-sm font-black uppercase tracking-widest">System Nominal</span>
                </div>
              )}

              {/* Active Issues */}
              {activeIncidents.length > 0 && (
                <section>
                  <h3 className="text-xs font-black text-red-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <AlertTriangle size={14} /> Active Incidents
                  </h3>
                  <div className="space-y-3">
                    {activeIncidents.map((incident, idx) => (
                      <IncidentCard key={idx} incident={incident} onResolve={() => handleResolve(incident.signature)} />
                    ))}
                  </div>
                </section>
              )}

              {/* Resolved Issues */}
              {resolvedIncidents.length > 0 && (
                <section>
                  <h3 className="text-xs font-black text-green-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <CheckCircle size={14} /> Recently Resolved
                  </h3>
                  <div className="space-y-3 opacity-60 hover:opacity-100 transition-opacity">
                    {resolvedIncidents.map((incident, idx) => (
                      <IncidentCard key={idx} incident={incident} />
                    ))}
                  </div>
                </section>
              )}
            </div>
          )}

          {/* TAB: RAW EVENTS */}
          {activeTab === 'events' && (
            <div className="space-y-1 font-mono text-[10px]">
              {db.recentEvents.map((log, idx) => (
                <div key={idx} className="flex gap-4 p-2 hover:bg-white/5 rounded border-b border-white/5">
                  <span className="text-zinc-500">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  <span className={`font-bold w-20 ${log.type === 'error' ? 'text-red-500' : 'text-yellow-500'}`}>{log.type.toUpperCase()}</span>
                  <span className="text-zinc-400 w-32 truncate">{log.actor}</span>
                  <span className="text-zinc-300 flex-1">{log.message}</span>
                </div>
              ))}
            </div>
          )}

          {/* TAB: DATABASE */}
          {activeTab === 'database' && (
            <pre className="text-[10px] text-green-400 bg-black/50 p-4 rounded-xl font-mono overflow-x-auto">
              {JSON.stringify(db, null, 2)}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
};

const IncidentCard: React.FC<{ incident: IncidentRecord; onResolve?: () => void }> = ({ incident, onResolve }) => {
  return (
    <div className={`p-4 rounded-lg border ${incident.status === 'ACTIVE' ? 'bg-red-500/5 border-red-500/20' : 'bg-green-500/5 border-green-500/20'} flex justify-between items-start gap-4`}>
      <div className="flex-1 space-y-2">
        <div className="flex items-center gap-3">
          <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${
            incident.severity === 'CRITICAL' ? 'bg-red-500 text-black' : 
            incident.severity === 'HIGH' ? 'bg-orange-500 text-black' : 'bg-yellow-500 text-black'
          }`}>
            {incident.severity}
          </span>
          <span className="text-xs font-mono text-zinc-400">{incident.signature.slice(0, 40)}...</span>
          <span className="text-[10px] text-zinc-600 bg-black/30 px-2 rounded-full">Occurrences: {incident.count}</span>
        </div>
        <p className="text-sm font-medium text-zinc-200">{incident.message}</p>
        
        {incident.suggestedFix && (
          <div className="flex items-center gap-2 text-xs text-green-400 mt-2 bg-green-500/10 p-2 rounded">
            <Wrench size={12} />
            <span className="font-bold uppercase tracking-wider">Recommended Fix:</span>
            {incident.suggestedFix}
          </div>
        )}
        
        <div className="flex gap-4 text-[10px] text-zinc-600 pt-2">
          <span>First Seen: {new Date(incident.firstSeen).toLocaleString()}</span>
          <span>Last Seen: {new Date(incident.lastSeen).toLocaleString()}</span>
          <span>Sources: {incident.sources.join(', ')}</span>
        </div>
      </div>

      {onResolve && (
        <button 
          onClick={onResolve}
          className="p-2 bg-green-500/10 hover:bg-green-500/20 text-green-500 rounded-lg transition-all flex flex-col items-center gap-1 min-w-[60px]"
        >
          <CheckCircle size={18} />
          <span className="text-[8px] font-black uppercase">Resolve</span>
        </button>
      )}
    </div>
  );
};

export default TroubleshootPanel;
