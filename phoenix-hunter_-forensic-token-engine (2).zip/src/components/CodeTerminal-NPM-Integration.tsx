/**
 * CodeTerminal npm Integration Extension
 * 
 * This file contains the logic for the 'npm' command in the CodeTerminal component.
 */

import { packageManager } from '../services/Infrastructure/PackageManagerService';

/**
 * Enhanced NPM COMMAND HANDLER
 * To be integrated into CodeTerminal.tsx
 */
export const handleNpmCommand = async (
  args: string[],
  print: (msg: string) => void,
  error: (msg: string) => void,
  handlePlay: () => void
) => {
  const subCmd = args[0];
  
  if (!subCmd) {
    print("Usage: npm <command>");
    print("Commands: install, uninstall, list, search, info, update, audit");
    return;
  }

  // --- NPM INSTALL ---
  if (subCmd === 'install' || subCmd === 'i') {
    const pkgName = args[1];
    
    if (!pkgName) {
      // Install all from package.json
      print("Installing packages from package.json...");
      const stats = packageManager.getInstallationStats();
      
      if (stats.total === 0) {
        print("No packages to install.");
      } else {
        print(`Found ${stats.total} package${stats.total !== 1 ? 's' : ''}`);
        const tree = packageManager.getPackageTree();
        tree.forEach(line => print(line));
        print(`Total size: ${stats.sizeFormatted}`);
      }
      return;
    }

    // Install specific package
    print(`Installing ${pkgName}...`);
    
    try {
      // Fetch package info
      const info = await packageManager.fetchPackageInfo(pkgName);
      print(`Found ${info.name}@${info.version}`);
      print("Resolving dependencies...");

      // Show installation options
      const hasSave = args.includes('--save');
      const hasSaveDev = args.includes('--save-dev');
      const hasGlobal = args.includes('--global');

      // Install package
      await new Promise(resolve => setTimeout(async () => {
        try {
          const result = await packageManager.installPackage(pkgName, {
            save: hasSave,
            saveDev: hasSaveDev,
            global: hasGlobal
          });

          if (result.success) {
            print(`✓ ${result.message}`);
            result.installed.forEach(pkg => {
              print(`  ✓ ${pkg.name}@${pkg.version}`);
            });

            if (result.failed.length > 0) {
              print(`✗ Failed to install: ${result.failed.join(', ')}`);
            }

            // Show new structure
            const stats = packageManager.getInstallationStats();
            print(`\nUpdated: node_modules (${stats.total} packages, ${stats.sizeFormatted})`);
            print(`Updated: package.json`);
            print(`Updated: package-lock.json`);
          } else {
            print(`✗ ${result.message}`);
          }
        } catch (e: any) {
          error(`Installation failed: ${e.message}`);
        }
        resolve(null);
      }, 500));

    } catch (e: any) {
      error(`Failed to fetch ${pkgName}: ${e.message}`);
    }
  }

  // --- NPM UNINSTALL ---
  else if (subCmd === 'uninstall' || subCmd === 'remove' || subCmd === 'rm') {
    const pkgName = args[1];
    
    if (!pkgName) {
      error("Usage: npm uninstall <package>");
      return;
    }

    print(`Removing ${pkgName}...`);

    await new Promise(resolve => setTimeout(async () => {
      const success = await packageManager.uninstallPackage(pkgName);

      if (success) {
        print(`✓ Removed ${pkgName}`);
        print(`Updated: package.json`);
        print(`Updated: package-lock.json`);
        
        const stats = packageManager.getInstallationStats();
        print(`\nRemaining: ${stats.total} package${stats.total !== 1 ? 's' : ''} (${stats.sizeFormatted})`);
      } else {
        error(`Package ${pkgName} not found`);
      }
      resolve(null);
    }, 300));
  }

  // --- NPM LIST ---
  else if (subCmd === 'list' || subCmd === 'ls') {
    const installed = packageManager.getInstalledPackages();

    if (installed.length === 0) {
      print("No packages installed");
      return;
    }

    print(`phoenix-hunter@2.1.0`);
    const tree = packageManager.getPackageTree();
    tree.forEach(line => print(line));

    const stats = packageManager.getInstallationStats();
    print(`\nTotal: ${stats.total} package${stats.total !== 1 ? 's' : ''}`);
    print(`Size: ${stats.sizeFormatted}`);
  }

  // --- NPM SEARCH ---
  else if (subCmd === 'search') {
    const query = args.slice(1).join(' ');

    if (!query) {
      error("Usage: npm search <query>");
      return;
    }

    print(`Searching for "${query}" in registry...`);

    await new Promise(resolve => setTimeout(async () => {
      try {
        const results = await packageManager.searchPackages(query, 10);

        if (results.length === 0) {
          print("No packages found");
        } else {
          print(`Found ${results.length} package${results.length !== 1 ? 's' : ''}:\n`);

          results.forEach((pkg, index) => {
            const keywords = pkg.keywords?.slice(0, 3).join(', ') || 'none';
            print(`${index + 1}. ${pkg.name}`);
            print(`   Version: ${pkg.version}`);
            if (pkg.description) print(`   ${pkg.description}`);
            print(`   Keywords: ${keywords}`);
            print('');
          });
        }
      } catch (e: any) {
        error(`Search failed: ${e.message}`);
      }
      resolve(null);
    }, 400));
  }

  // --- NPM INFO ---
  else if (subCmd === 'info') {
    const pkgName = args[1];

    if (!pkgName) {
      error("Usage: npm info <package>");
      return;
    }

    print(`Fetching information for ${pkgName}...`);

    await new Promise(resolve => setTimeout(async () => {
      try {
        const pkg = await packageManager.fetchPackageInfo(pkgName);

        print(`\n${pkg.name}@${pkg.version}`);
        print('═'.repeat(50));
        
        if (pkg.description) print(`Description: ${pkg.description}`);
        if (pkg.author) print(`Author: ${pkg.author}`);
        if (pkg.license) print(`License: ${pkg.license}`);
        if (pkg.homepage) print(`Homepage: ${pkg.homepage}`);
        if (pkg.repository) print(`Repository: ${pkg.repository}`);
        
        if (pkg.keywords && pkg.keywords.length > 0) {
          print(`Keywords: ${pkg.keywords.slice(0, 5).join(', ')}`);
        }

        if (pkg.dependencies && Object.keys(pkg.dependencies).length > 0) {
          print(`\nDependencies: ${Object.keys(pkg.dependencies).length}`);
          Object.entries(pkg.dependencies)
            .slice(0, 5)
            .forEach(([name, version]) => {
              print(`  • ${name}: ${version}`);
            });
          if (Object.keys(pkg.dependencies).length > 5) {
            print(`  ... and ${Object.keys(pkg.dependencies).length - 5} more`);
          }
        }
      } catch (e: any) {
        error(`Failed to fetch ${pkgName}: ${e.message}`);
      }
      resolve(null);
    }, 300));
  }

  // --- NPM UPDATE ---
  else if (subCmd === 'update') {
    const pkgName = args[1];

    if (!pkgName) {
      print("Checking for updates...");
      // Update all packages
      await new Promise(resolve => setTimeout(() => {
        const installed = packageManager.getInstalledPackages();
        print(`Checked ${installed.length} package${installed.length !== 1 ? 's' : ''}`);
        print("All packages are up to date");
        resolve(null);
      }, 800));
      return;
    }

    print(`Updating ${pkgName}...`);

    await new Promise(resolve => setTimeout(async () => {
      try {
        const result = await packageManager.updatePackage(pkgName);

        if (result.success) {
          print(`✓ ${result.message}`);
          result.installed.forEach(pkg => {
            print(`  ✓ ${pkg.name}@${pkg.version}`);
          });
        } else {
          print(`✗ ${result.message}`);
        }
      } catch (e: any) {
        error(`Update failed: ${e.message}`);
      }
      resolve(null);
    }, 500));
  }

  // --- NPM AUDIT ---
  else if (subCmd === 'audit') {
    const fix = args[1] === 'fix';

    print("Auditing packages for vulnerabilities...");

    await new Promise(resolve => setTimeout(async () => {
      try {
        const audit = await packageManager.auditPackages();

        if (audit.vulnerabilities.length === 0) {
          print("✓ No vulnerabilities found");
          print("  All packages are secure");
        } else {
          print(`⚠ Found ${audit.vulnerabilities.length} vulnerabilities:\n`);

          audit.vulnerabilities.forEach((vuln: any) => {
            const severityColor = vuln.severity === 'critical' ? '🔴' : '🟡';
            print(`${severityColor} ${vuln.severity.toUpperCase()}: ${vuln.name}@${vuln.version}`);
            print(`   ${vuln.issue}`);
          });

          if (fix) {
            print("\nRunning audit fix...");
            await new Promise(r => setTimeout(() => {
              print("✓ Fixed 0 vulnerabilities");
              print(`  ${audit.vulnerabilities.length} still require manual review`);
              r(null);
            }, 800));
          }
        }
      } catch (e: any) {
        error(`Audit failed: ${e.message}`);
      }
      resolve(null);
    }, 400));
  }

  // --- NPM RUN / NPM START ---
  else if (subCmd === 'run' || subCmd === 'start') {
    const script = args[1];

    if (subCmd === 'start' || script === 'dev') {
      print("> phoenix-hunter@2.1.0 dev");
      print("> vite");
      await new Promise(r => setTimeout(() => { print("  ➜  Local:   http://localhost:5173/"); r(null); }, 300));
      await new Promise(r => setTimeout(() => { print("  ➜  Network: use --host to expose"); r(null); }, 400));
    } else if (script === 'build') {
      print("> phoenix-hunter@2.1.0 build");
      print("> tsc && vite build");
      await new Promise(r => setTimeout(() => { print("Compiling..."); r(null); }, 300));
      await new Promise(r => setTimeout(() => { print("dist/index.html   1.42 kB"); r(null); }, 1000));
      await new Promise(r => setTimeout(() => { print("dist/assets/index-D8s9.js   412.04 kB"); r(null); }, 1300));
      await new Promise(r => setTimeout(() => { print("✓ Built in 1.9s"); r(null); }, 1500));
    } else if (script === 'test') {
      handlePlay();
    } else {
      error(`Missing script: "${script}"`);
      print("Available scripts: dev, build, test");
    }
  }

  // --- NPM UNKNOWN COMMAND ---
  else {
    error(`Unknown command: ${subCmd}`);
    print("Try: npm install, list, search, info, update, audit, uninstall");
  }
};
