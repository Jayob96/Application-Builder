
import React, { useState, useMemo, useCallback } from 'react';
import { ActiveToken } from '../types';
import { TrendingUp, TrendingDown, Activity, Loader2, Eye, ShoppingCart, LogOut, Crosshair, ChevronUp, ChevronDown, Download, Search, Filter, X } from 'lucide-react';

interface Props {
  tokens: ActiveToken[];
  limit?: number;
  onSnipe?: (id: string) => void;
  onExit?: (id: string) => void;
  onViewAudit?: (token: ActiveToken) => void;
  enableSorting?: boolean;
  enableFiltering?: boolean;
  enableSearch?: boolean;
  enableExport?: boolean;
  enableBulkActions?: boolean;
  pageSize?: number;
  onExport?: (data: ExportData) => void;
  defaultSort?: string;
  expandedRiskView?: boolean;
}

interface ExportData {
  timestamp: number;
  format: 'csv' | 'json';
  tokens: ActiveToken[];
  count: number;
}

type SortKey = 'symbol' | 'stage' | 'score' | 'roi' | 'marketCap' | 'age';
type SortDirection = 'asc' | 'desc';
type RiskFilter = 'ALL' | 'SAFE' | 'CAUTION' | 'WARNING' | 'CRITICAL';
type StageFilter = 'ALL' | 'TRACKING' | 'AUDITING' | 'SNIPED' | 'EXITED';

/**
 * Enhanced TokenTable Component v2.0
 * 
 * Features:
 * - Advanced sorting (click headers)
 * - Smart filtering (risk, stage, ROI)
 * - Real-time search
 * - Bulk selection & actions
 * - Pagination for scale
 * - Data export (CSV/JSON)
 * - Performance optimized
 */
const TokenTable: React.FC<Props> = ({
  tokens,
  limit,
  onSnipe,
  onExit,
  onViewAudit,
  enableSorting = true,
  enableFiltering = true,
  enableSearch = true,
  enableExport = true,
  enableBulkActions = true,
  pageSize = 20,
  onExport,
  defaultSort = 'score',
  expandedRiskView = false
}) => {
  const [sortKey, setSortKey] = useState<SortKey>(defaultSort as SortKey);
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState<RiskFilter>('ALL');
  const [stageFilter, setStageFilter] = useState<StageFilter>('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedTokens, setSelectedTokens] = useState<Set<string>>(new Set());

  // Filter tokens
  const filteredTokens = useMemo(() => {
    return tokens.filter(token => {
      // Risk filter
      if (riskFilter !== 'ALL') {
        const riskLevel = token.analysis?.riskLevel || 'UNKNOWN';
        if (riskLevel !== riskFilter) return false;
      }

      // Stage filter
      if (stageFilter !== 'ALL' && token.stage !== stageFilter) return false;

      // Search filter
      if (searchTerm) {
        const search = searchTerm.toLowerCase();
        return (
          token.symbol.toLowerCase().includes(search) ||
          token.mint.toLowerCase().includes(search) ||
          token.discoverySource.toLowerCase().includes(search)
        );
      }

      return true;
    });
  }, [tokens, riskFilter, stageFilter, searchTerm]);

  // Sort tokens
  const sortedTokens = useMemo(() => {
    const sorted = [...filteredTokens];
    sorted.sort((a, b) => {
      let aVal: any;
      let bVal: any;

      switch (sortKey) {
        case 'symbol':
          aVal = a.symbol;
          bVal = b.symbol;
          break;
        case 'stage':
          aVal = a.stage;
          bVal = b.stage;
          break;
        case 'score':
          aVal = a.analysis?.forensicScore || 0;
          bVal = b.analysis?.forensicScore || 0;
          break;
        case 'roi':
          aVal = a.currentRoi;
          bVal = b.currentRoi;
          break;
        case 'marketCap':
          aVal = a.marketCap;
          bVal = b.marketCap;
          break;
        case 'age':
          aVal = Date.now() - (a.launchedAt || 0);
          bVal = Date.now() - (b.launchedAt || 0);
          break;
        default:
          return 0;
      }

      if (typeof aVal === 'string') {
        return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }

      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    });

    return sorted;
  }, [filteredTokens, sortKey, sortDirection]);

  // Paginate tokens
  const paginatedTokens = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedTokens.slice(start, start + pageSize);
  }, [sortedTokens, currentPage, pageSize]);

  const totalPages = Math.ceil(sortedTokens.length / pageSize);

  // Handle sorting
  const handleSort = useCallback((key: SortKey) => {
    if (sortKey === key) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDirection('desc');
    }
    setCurrentPage(1);
  }, [sortKey, sortDirection]);

  // Handle bulk selection
  const handleSelectToken = useCallback((tokenId: string) => {
    setSelectedTokens(prev => {
      const updated = new Set(prev);
      if (updated.has(tokenId)) {
        updated.delete(tokenId);
      } else {
        updated.add(tokenId);
      }
      return updated;
    });
  }, []);

  const handleSelectAll = useCallback(() => {
    if (selectedTokens.size === paginatedTokens.length) {
      setSelectedTokens(new Set());
    } else {
      setSelectedTokens(new Set(paginatedTokens.map(t => t.id)));
    }
  }, [paginatedTokens, selectedTokens.size]);

  // Export handler
  const handleExport = useCallback((format: 'csv' | 'json') => {
    if (format === 'json') {
      const data = JSON.stringify(sortedTokens, null, 2);
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `tokens-${Date.now()}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      const csv = ['symbol,stage,score,roi,marketCap,riskLevel,discoverySource']
        .concat(sortedTokens.map(t => 
          `${t.symbol},${t.stage},${t.analysis?.forensicScore || 0},${((t.currentRoi - 1) * 100).toFixed(1)},${t.marketCap},${t.analysis?.riskLevel || 'UNKNOWN'},${t.discoverySource}`
        ))
        .join('\n');

      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `tokens-${Date.now()}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    }

    onExport?.({
      timestamp: Date.now(),
      format,
      tokens: sortedTokens,
      count: sortedTokens.length
    });
  }, [sortedTokens, onExport]);

  // Sort indicator
  const SortIcon = ({ column }: { column: SortKey }) => {
    if (sortKey !== column) return <ChevronUp size={12} className="opacity-30" />;
    return sortDirection === 'asc' 
      ? <ChevronUp size={12} className="text-orange-400" />
      : <ChevronDown size={12} className="text-orange-400" />;
  };

  const displayTokens = limit ? paginatedTokens.slice(0, limit) : paginatedTokens;

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="space-y-3">
        {/* Search & Filters Row */}
        {(enableSearch || enableFiltering) && (
          <div className="glass-panel rounded-lg p-4 border border-zinc-800/50 space-y-3">
            {/* Search */}
            {enableSearch && (
              <div className="relative">
                <Search size={14} className="absolute left-3 top-3 text-zinc-600" />
                <input
                  type="text"
                  placeholder="Search tokens (symbol, mint, source)..."
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full pl-10 pr-3 py-2 bg-black/40 border border-zinc-800/50 rounded text-white text-[12px] placeholder-zinc-600 focus:outline-none focus:border-orange-500/50"
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm('')}
                    className="absolute right-3 top-2.5 text-zinc-600 hover:text-zinc-400"
                  >
                    <X size={14} />
                  </button>
                )}
              </div>
            )}

            {/* Filter Buttons */}
            {enableFiltering && (
              <div className="flex gap-2 flex-wrap">
                {/* Risk Filter */}
                <div className="flex gap-1">
                  {(['ALL', 'SAFE', 'CAUTION', 'WARNING', 'CRITICAL'] as const).map(level => (
                    <button
                      key={level}
                      onClick={() => {
                        setRiskFilter(level);
                        setCurrentPage(1);
                      }}
                      className={`px-2 py-1 rounded text-[9px] font-bold uppercase transition-colors ${
                        riskFilter === level
                          ? 'bg-orange-500/20 border border-orange-500/50 text-orange-400'
                          : 'bg-zinc-800/30 border border-zinc-800/50 text-zinc-500 hover:border-zinc-700/50'
                      }`}
                    >
                      {level}
                    </button>
                  ))}
                </div>

                {/* Stage Filter */}
                <div className="flex gap-1">
                  {(['ALL', 'TRACKING', 'AUDITING', 'SNIPED', 'EXITED'] as const).map(stage => (
                    <button
                      key={stage}
                      onClick={() => {
                        setStageFilter(stage);
                        setCurrentPage(1);
                      }}
                      className={`px-2 py-1 rounded text-[9px] font-bold uppercase transition-colors ${
                        stageFilter === stage
                          ? 'bg-blue-500/20 border border-blue-500/50 text-blue-400'
                          : 'bg-zinc-800/30 border border-zinc-800/50 text-zinc-500 hover:border-zinc-700/50'
                      }`}
                    >
                      {stage}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Results Summary */}
            <div className="text-[9px] text-zinc-600 flex justify-between">
              <span>Showing {paginatedTokens.length} of {sortedTokens.length} tokens</span>
              {enableExport && (
                <div className="flex gap-1">
                  <button
                    onClick={() => handleExport('json')}
                    className="text-zinc-500 hover:text-orange-400 transition-colors"
                  >
                    JSON
                  </button>
                  <span className="text-zinc-800">•</span>
                  <button
                    onClick={() => handleExport('csv')}
                    className="text-zinc-500 hover:text-orange-400 transition-colors"
                  >
                    CSV
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Bulk Actions */}
        {enableBulkActions && selectedTokens.size > 0 && (
          <div className="glass-panel rounded-lg p-3 border border-orange-500/30 bg-orange-500/5 flex items-center justify-between">
            <span className="text-[10px] font-bold text-orange-400">
              {selectedTokens.size} token{selectedTokens.size !== 1 ? 's' : ''} selected
            </span>
            <div className="flex gap-2">
              <button
                onClick={() => selectedTokens.forEach(id => onSnipe?.(id))}
                className="px-3 py-1 bg-orange-500/20 hover:bg-orange-500/30 text-orange-400 rounded text-[9px] font-bold transition-colors"
              >
                Snipe All
              </button>
              <button
                onClick={() => setSelectedTokens(new Set())}
                className="px-3 py-1 bg-zinc-800/30 hover:bg-zinc-800/50 text-zinc-500 rounded text-[9px] font-bold transition-colors"
              >
                Clear
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Table */}
      <div className="glass-panel rounded-xl overflow-hidden border-zinc-800/50 shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[900px]">
            <thead>
              <tr className="bg-white/[0.02] border-b border-zinc-800/50">
                {enableBulkActions && (
                  <th className="px-4 py-4 text-center w-10">
                    <input
                      type="checkbox"
                      checked={selectedTokens.size === paginatedTokens.length && paginatedTokens.length > 0}
                      onChange={handleSelectAll}
                      className="w-4 h-4"
                    />
                  </th>
                )}
                <th
                  className={`px-6 py-4 text-[10px] font-black text-zinc-600 uppercase tracking-widest ${enableSorting ? 'cursor-pointer hover:text-orange-500' : ''}`}
                  onClick={() => enableSorting && handleSort('symbol')}
                >
                  <div className="flex items-center gap-2">Asset Signal <SortIcon column="symbol" /></div>
                </th>
                <th
                  className={`px-6 py-4 text-[10px] font-black text-zinc-600 uppercase tracking-widest text-center ${enableSorting ? 'cursor-pointer hover:text-orange-500' : ''}`}
                  onClick={() => enableSorting && handleSort('stage')}
                >
                  <div className="flex items-center justify-center gap-2">Neural Phase <SortIcon column="stage" /></div>
                </th>
                <th
                  className={`px-6 py-4 text-[10px] font-black text-zinc-600 uppercase tracking-widest ${enableSorting ? 'cursor-pointer hover:text-orange-500' : ''}`}
                  onClick={() => enableSorting && handleSort('score')}
                >
                  <div className="flex items-center gap-2">Forensic Score <SortIcon column="score" /></div>
                </th>
                <th
                  className={`px-6 py-4 text-[10px] font-black text-zinc-600 uppercase tracking-widest text-right ${enableSorting ? 'cursor-pointer hover:text-orange-500' : ''}`}
                  onClick={() => enableSorting && handleSort('roi')}
                >
                  <div className="flex items-center justify-end gap-2">Thermal ROI <SortIcon column="roi" /></div>
                </th>
                <th className="px-6 py-4 text-[10px] font-black text-zinc-600 uppercase tracking-widest text-center">Commands</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/30">
              {displayTokens.map((token) => (
                <tr key={token.id} className="group hover:bg-orange-500/[0.02] transition-colors">
                  {enableBulkActions && (
                    <td className="px-4 py-4 text-center">
                      <input
                        type="checkbox"
                        checked={selectedTokens.has(token.id)}
                        onChange={() => handleSelectToken(token.id)}
                        className="w-4 h-4"
                      />
                    </td>
                  )}
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center font-black italic text-zinc-100 group-hover:border-orange-500/50 transition-colors">
                        {token.symbol[0]}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-black text-white group-hover:text-orange-400 transition-colors">{token.symbol}</span>
                          <span className="text-[7px] font-black bg-orange-500/10 text-orange-500 px-1.5 py-0.5 rounded border border-orange-500/20 uppercase">{token.discoverySource}</span>
                        </div>
                        <div className="text-[10px] text-zinc-700 font-mono mt-0.5">{token.mint.slice(0, 10)}...</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-3 py-1 rounded-full text-[8px] font-black border uppercase tracking-widest inline-flex items-center gap-2 ${token.stage === 'TRACKING' ? 'bg-orange-500/10 text-orange-500 border-orange-500/20' : 'bg-zinc-800/50 text-zinc-500 border-zinc-800/50'}`}>
                      {token.stage === 'AUDITING' ? <Loader2 size={10} className="animate-spin" /> : <div className="w-1 h-1 rounded-full bg-current" />}
                      {token.stage}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="max-w-[120px] space-y-1.5">
                      <div className="flex justify-between text-[8px] font-black text-orange-500/50 uppercase">
                        <span>{token.analysis?.riskLevel || 'EVAL'}</span>
                        <span>{token.analysis?.forensicScore?.toFixed(0) || 0}%</span>
                      </div>
                      <div className="h-1 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                        <div className="h-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.5)]" style={{ width: `${token.analysis?.forensicScore || 0}%` }} />
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className={`flex flex-col items-end gap-1 ${token.currentRoi >= 1 ? 'text-orange-400' : 'text-red-500'}`}>
                      <div className="text-base font-black italic tabular-nums flex items-center gap-1">
                        {token.currentRoi >= 1 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                        {((token.currentRoi - 1) * 100).toFixed(1)}%
                      </div>
                      <div className="text-[8px] text-zinc-700 font-black uppercase tracking-widest">MC: ${(token.marketCap / 1000).toFixed(1)}k</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-center gap-2">
                      <button onClick={() => onViewAudit?.(token)} className="p-2 bg-white/5 hover:bg-orange-500/10 rounded-lg text-zinc-500 hover:text-orange-400 transition-all" title="View audit"><Eye size={14} /></button>
                      {token.stage === 'TRACKING' ? (
                        <button onClick={() => onExit?.(token.id)} className="p-2 bg-red-500/10 hover:bg-red-500/20 rounded-lg text-red-500 transition-all" title="Exit position"><LogOut size={14} /></button>
                      ) : (
                        <button onClick={() => onSnipe?.(token.id)} className="p-2 bg-orange-500/10 hover:bg-orange-500/20 rounded-lg text-orange-500 transition-all" title="Snipe"><Crosshair size={14} /></button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="px-6 py-4 bg-white/[0.02] border-t border-zinc-800/50 flex items-center justify-between text-[9px]">
            <span className="text-zinc-600">
              Page {currentPage} of {totalPages}
            </span>
            <div className="flex gap-2">
              <button
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="px-3 py-1 border border-zinc-800/50 rounded disabled:opacity-50 hover:border-orange-500/50 text-zinc-500 hover:text-orange-400"
              >
                ← Prev
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).slice(
                Math.max(0, currentPage - 2),
                Math.min(totalPages, currentPage + 1)
              ).map(page => (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`px-2 py-1 rounded ${currentPage === page ? 'bg-orange-500/20 text-orange-400 border border-orange-500/50' : 'border border-zinc-800/50 text-zinc-500 hover:border-orange-500/50'}`}
                >
                  {page}
                </button>
              ))}
              <button
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
                className="px-3 py-1 border border-zinc-800/50 rounded disabled:opacity-50 hover:border-orange-500/50 text-zinc-500 hover:text-orange-400"
              >
                Next →
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default React.memo(TokenTable);
