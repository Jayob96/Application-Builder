
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  FileCode, ChevronRight, ChevronDown, X, 
  Play, Save, Zap, FilePlus, 
  FolderPlus, Cpu as KernelIcon,
  Terminal as TerminalIcon, Search, Trash2,
  Command, RefreshCw, RotateCcw,
  Table, Edit2, Copy
} from 'lucide-react';
import { FileNode } from '../services/Infrastructure/fileRegistry';
import { SystemLog } from '../types';
import { logger } from '../services/Infrastructure/observabilityService';
import { packageManager } from '../services/Infrastructure/PackageManagerService';
import { handleNpmCommand } from './CodeTerminal-NPM-Integration';
import { vfs } from '../services/Infrastructure/VirtualFileSystem';
import { troubleshootReporter } from '../services/Infrastructure/troubleshootReporter';
import { pythonKernel } from '../services/Infrastructure/PythonKernelService';

interface CodeTerminalProps {
  logs: SystemLog[];
}

const CodeTerminal: React.FC<CodeTerminalProps> = ({ logs }) => {
  const [fileTree, setFileTree] = useState<FileNode[]>(vfs.getTree());
  const [openFiles, setOpenFiles] = useState<FileNode[]>([]);
  const [activeFile, setActiveFile] = useState<FileNode | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isTerminalOpen, setIsTerminalOpen] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [consoleTab, setConsoleTab] = useState<'kernel' | 'audit' | 'debug' | 'cli'>('cli');
  const [isSaving, setIsSaving] = useState(false);
  
  const editorRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);
  const codeRef = useRef<HTMLElement>(null);
  const terminalEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const [termInput, setTermInput] = useState('');
  const [termHistory, setTermHistory] = useState<string[]>([
    "Phoenix Neural Engine v2.1.0 [Kernel: SOL-99]",
    "Python 3.11 Runtime (WASM): READY",
    "Type 'help' for commands or 'python' to ignite kernel.",
  ]);
  const [currentPath, setCurrentPath] = useState<string>('/src');

  useEffect(() => {
    const unsubscribe = vfs.subscribe((newTree) => {
      setFileTree(newTree);
      if (activeFile) {
         const path = resolveActivePath(activeFile, newTree);
         if (path) {
             const node = findNodeByPath(path, newTree);
             if (node && node.content !== activeFile.content && !activeFile.isModified) {
                 setActiveFile(node);
             }
         }
      }
    });
    return () => unsubscribe();
  }, [activeFile]);

  useEffect(() => {
    if (openFiles.length === 0) {
      const config = findNodeByPath('/config.json', fileTree);
      if (config) {
        setOpenFiles([config]);
        setActiveFile(config);
      }
    }
  }, []);

  useEffect(() => {
    if (activeFile && !activeFile.name.endsWith('.csv') && codeRef.current && (window as any).Prism) {
      (window as any).Prism.highlightElement(codeRef.current);
    }
  }, [activeFile?.content, activeFile?.name]);

  useEffect(() => {
    if (terminalEndRef.current && isTerminalOpen) {
      terminalEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [termHistory, logs, isTerminalOpen, consoleTab]);

  const findNodeByPath = (path: string, nodes: FileNode[]): FileNode | null => {
    const norm = normalizePath(path);
    if (norm === '/' || norm === '') return null;
    const parts = norm.split('/').filter(Boolean);
    let current: FileNode | undefined;
    let pool = nodes;
    for (const part of parts) {
      current = pool.find(n => n.name === part);
      if (!current) return null;
      pool = current.children || [];
    }
    return current || null;
  };

  const normalizePath = (path: string): string => {
    if (path.startsWith('~')) path = path.replace('~', '');
    if (!path.startsWith('/')) path = `${currentPath}/${path}`;
    const parts = path.split('/').filter(p => p !== '' && p !== '.');
    const stack: string[] = [];
    for (const part of parts) {
      if (part === '..') stack.pop();
      else stack.push(part);
    }
    return '/' + stack.join('/');
  };

  const resolveActivePath = (target: FileNode, currentNodes: FileNode[] = fileTree, currentPrefix: string = ''): string | null => {
    for (const node of currentNodes) {
      const path = `${currentPrefix}/${node.name}`;
      if (node.name === target.name && node.type === target.type) return path;
      if (node.children) {
        const found = resolveActivePath(target, node.children, path);
        if (found) return found;
      }
    }
    return null;
  };

  const getLanguage = (filename: string) => {
    const ext = filename.split('.').pop() || '';
    const map: Record<string, string> = {
      'tsx': 'tsx', 'ts': 'typescript', 'json': 'json', 'js': 'javascript',
      'py': 'python', 'csv': 'csv'
    };
    return map[ext] || 'plaintext';
  };

  const parseCSV = (content: string = "") => {
    if (!content.trim()) return [[""]];
    return content.split('\n').map(line => line.split(',').map(cell => cell.trim()));
  };

  const stringifyCSV = (grid: string[][]) => grid.map(row => row.join(',')).join('\n');

  const handleCellChange = (rowIndex: number, colIndex: number, value: string) => {
    if (!activeFile) return;
    const grid = parseCSV(activeFile.content);
    grid[rowIndex][colIndex] = value;
    const newContent = stringifyCSV(grid);
    const path = resolveActivePath(activeFile);
    if (path) {
      vfs.updateFile(path, newContent);
      setActiveFile({ ...activeFile, content: newContent, isModified: true });
    }
  };

  const addRow = () => {
    if (!activeFile) return;
    const grid = parseCSV(activeFile.content);
    grid.push(new Array(grid[0]?.length || 1).fill(""));
    const path = resolveActivePath(activeFile);
    if (path) vfs.updateFile(path, stringifyCSV(grid));
  };

  const addColumn = () => {
    if (!activeFile) return;
    const grid = parseCSV(activeFile.content);
    grid.forEach(row => row.push(""));
    const path = resolveActivePath(activeFile);
    if (path) vfs.updateFile(path, stringifyCSV(grid));
  };

  const handleEditorChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (!activeFile) return;
    const newContent = e.target.value;
    setActiveFile({ ...activeFile, content: newContent, isModified: true });
  };

  const handleSave = () => {
    if (!activeFile) return;
    setIsSaving(true);
    const path = resolveActivePath(activeFile);
    if (path) {
      vfs.updateFile(path, activeFile.content || '');
      logger.log(`Live Save: ${path} persistent.`, 'success', {}, 1, 'vfs');
    }
    setTimeout(() => setIsSaving(false), 500);
  };

  const handleCreateNode = (type: 'file' | 'folder') => {
    const name = prompt(`Enter ${type} name:`);
    if (!name) return;
    const parentPath = currentPath === '/' ? '' : currentPath;
    const fullPath = `${parentPath}/${name}`;
    try {
      if (type === 'file') {
        const content = name.endsWith('.py') ? "print('Phoenix Neural Online')\n" : "// New File\n";
        vfs.createFile(fullPath, content, { isOpen: true });
      } else {
        vfs.createFolder(fullPath, { isOpen: true });
      }
      logger.log(`VFS: Created ${type} ${name}`, 'success');
    } catch (e: any) {
      alert(e.message);
    }
  };

  const handleNodeClick = (node: FileNode) => {
    const path = resolveActivePath(node);
    if (node.type === 'folder') {
      if (path) vfs.toggleFolder(path);
    } else {
      if (!openFiles.find(f => f.name === node.name)) {
        setOpenFiles([...openFiles, node]);
      }
      setActiveFile(node);
    }
  };

  const handleRenameNode = (e: React.MouseEvent, node: FileNode) => {
    e.stopPropagation();
    const newName = prompt(`Rename ${node.name} to:`, node.name);
    if (!newName || newName === node.name) return;
    const path = resolveActivePath(node);
    if (path) {
        try {
            vfs.renameNode(path, newName);
            if (activeFile?.name === node.name) {
                const newFile = { ...activeFile, name: newName };
                setActiveFile(newFile);
                setOpenFiles(prev => prev.map(f => f.name === node.name ? newFile : f));
            }
        } catch (err: any) {
            alert(err.message);
        }
    }
  };

  const handleDuplicateNode = (e: React.MouseEvent, node: FileNode) => {
    e.stopPropagation();
    const path = resolveActivePath(node);
    if (path) {
        try {
            vfs.duplicateNode(path);
        } catch (err: any) {
            alert(err.message);
        }
    }
  };

  const handleDeleteNode = (e: React.MouseEvent, node: FileNode) => {
    e.stopPropagation();
    const path = resolveActivePath(node);
    if (path && confirm(`Permanently delete ${path}?`)) {
      vfs.deleteNode(path);
      if (activeFile?.name === node.name) setActiveFile(null);
      setOpenFiles(prev => prev.filter(f => f.name !== node.name));
    }
  };

  const handlePlay = async () => {
    if (!activeFile) return;
    const isPython = activeFile.name.endsWith('.py');
    logger.log(`VFS Runtime: Executing ${activeFile.name}...`, 'info');
    
    if (isPython) {
        setConsoleTab('cli');
        setTermHistory(prev => [...prev, `[PYTHON_IGNITION] Running ${activeFile.name}...`]);
        try {
            await pythonKernel.run(activeFile.content || "", (msg) => {
                setTermHistory(prev => [...prev, msg]);
            });
            setTermHistory(prev => [...prev, "[PYTHON_FINISH] Process exited successfully."]);
        } catch(e) {
            // Error already printed by onOutput
        }
    } else {
        setTimeout(() => logger.log("JS Runtime simulation complete.", "success"), 500);
    }
  };

  const executeCommand = async (cmdStr: string) => {
    const parts = cmdStr.trim().split(/\s+/);
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1);
    setTermHistory(prev => [...prev, `${currentPath} $ ${cmdStr}`]);
    const print = (msg: string) => setTermHistory(prev => [...prev, msg]);
    const error = (msg: string) => setTermHistory(prev => [...prev, `Error: ${msg}`]);

    try {
      switch (cmd) {
        case 'help':
          print("Phoenix Shell v2.2 (Python Enhanced)");
          print("Commands: ls, cd, pwd, mkdir, touch, rm, cat, python, pip, npm, clear, reset, diagnose");
          break;
        case 'ls': {
          const node = currentPath === '/' ? { children: fileTree } : findNodeByPath(currentPath, fileTree);
          if (node?.children) {
            node.children.forEach(c => print(`${c.type === 'folder' ? 'DIR ' : 'FILE'} ${c.name}`));
          }
          break;
        }
        case 'cd': {
          const target = args[0] || '/';
          const newPath = normalizePath(target);
          if (newPath === '/' || findNodeByPath(newPath, fileTree)?.type === 'folder') {
            setCurrentPath(newPath);
          } else error("Invalid directory");
          break;
        }
        case 'pwd': print(currentPath); break;
        case 'touch': {
          if (!args[0]) return error("Missing name");
          vfs.createFile(normalizePath(args[0]), '');
          break;
        }
        case 'python': {
            if (args.length === 0) {
                print("Initializing Python Kernel...");
                await pythonKernel.init();
                print("Python 3.11 WASM ready. Usage: python <filename.py>");
            } else {
                const target = findNodeByPath(args[0], fileTree);
                if (target && target.content) {
                    print(`[PYTHON] Executing ${target.name}...`);
                    await pythonKernel.run(target.content, print);
                } else error(`File not found: ${args[0]}`);
            }
            break;
        }
        case 'pip': {
            if (args[0] === 'install') {
                print(`[PIP] Synthesizing ${args[1]}...`);
                await pythonKernel.install(args[1]);
                print(`[PIP] Package ${args[1]} successfully installed.`);
            } else error("Usage: pip install <package>");
            break;
        }
        case 'mkdir': {
          if (!args[0]) return error("Missing name");
          vfs.createFolder(normalizePath(args[0]));
          break;
        }
        case 'rm': {
          if (!args[0]) return error("Missing target");
          vfs.deleteNode(normalizePath(args[0]));
          break;
        }
        case 'clear': setTermHistory([]); break;
        case 'npm': await handleNpmCommand(args, print, error, handlePlay); break;
        case 'diagnose': {
            print("Running diagnostics...");
            const report = await troubleshootReporter.runDiagnostics();
            print(JSON.stringify(report, null, 2));
            break;
        }
        default: if (cmd) error(`Command not found: ${cmd}`);
      }
    } catch (e: any) { error(e.message); }
  };

  const filteredLogs = useMemo(() => {
    if (consoleTab === 'cli') return [];
    if (consoleTab === 'kernel') return logs.filter(l => l.actor === 'system' || l.actor === 'kernel' || l.actor === 'vfs' || l.actor === 'pythonRuntime');
    if (consoleTab === 'audit') return logs.filter(l => l.type === 'audit');
    return logs.filter(l => l.type === 'error');
  }, [logs, consoleTab]);

  return (
    <div className="h-full flex flex-col glass-panel border-orange-500/20 rounded-xl overflow-hidden bg-[#050505] text-zinc-300 shadow-2xl">
      <div className="h-10 bg-black/80 flex items-center justify-between px-4 border-b border-orange-500/20 shrink-0">
        <div className="flex items-center gap-6">
          <div className="flex gap-1.5 group">
            <button onClick={() => setTermHistory([])} className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]" />
            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className={`w-2.5 h-2.5 rounded-full bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.5)]`} />
            <button onClick={() => setIsTerminalOpen(!isTerminalOpen)} className="w-2.5 h-2.5 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]" />
          </div>
          <span className="text-[10px] font-black uppercase tracking-[0.4em] text-orange-500/80 italic flex items-center gap-2">
            <KernelIcon size={12} className="animate-pulse" /> Phoenix IDE // <span className="text-zinc-500">v2.2 (Python Support)</span>
          </span>
        </div>
        <div className="flex items-center gap-4">
           <button onClick={() => vfs.factoryReset()} className="flex items-center gap-1.5 px-3 py-1 rounded bg-red-500/10 hover:bg-red-500/20 text-red-500 text-[10px] font-black uppercase tracking-widest border border-red-500/20">
             <RotateCcw size={10} /> Reset VFS
           </button>
          <div className="flex gap-1">
             <button onClick={handleSave} className={`p-1.5 hover:bg-white/5 rounded transition-all ${isSaving ? 'text-orange-500 animate-spin' : 'text-zinc-500 hover:text-orange-500'}`}>
                <Save size={14} />
             </button>
             <button onClick={handlePlay} className="p-1.5 hover:bg-white/5 rounded text-zinc-500 hover:text-green-500 transition-all">
                <Play size={14} />
             </button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {isSidebarOpen && (
          <div className="w-64 bg-black/60 border-r border-orange-500/10 flex flex-col shrink-0">
            <div className="p-4 flex items-center justify-between border-b border-white/5 bg-white/[0.02]">
              <span className="text-[9px] font-black uppercase tracking-[0.2em] text-zinc-500">VFS Registry</span>
              <div className="flex gap-3 text-zinc-600">
                <button onClick={() => handleCreateNode('file')} className="hover:text-orange-500"><FilePlus size={14} /></button>
                <button onClick={() => handleCreateNode('folder')} className="hover:text-orange-500"><FolderPlus size={14} /></button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-0.5 custom-scrollbar">
              {renderFileTree(fileTree, 0, handleNodeClick, activeFile, searchTerm, handleDeleteNode, resolveActivePath, handleRenameNode, handleDuplicateNode)}
            </div>
            <div className="p-4 border-t border-orange-500/10 bg-orange-500/5">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Filter VFS..."
                className="w-full bg-black/60 border border-orange-500/20 rounded px-3 py-2 text-[10px] text-orange-100 outline-none"
              />
            </div>
          </div>
        )}

        <div className="flex-1 flex flex-col min-w-0 bg-[#080808] relative">
          <div className="h-10 flex bg-black/40 border-b border-orange-500/10 overflow-x-auto shrink-0 custom-scrollbar">
            {openFiles.map((file) => (
              <div
                key={file.name}
                onClick={() => setActiveFile(file)}
                className={`h-full min-w-[140px] px-4 flex items-center justify-between gap-4 border-r border-white/5 cursor-pointer transition-all group relative ${activeFile?.name === file.name ? 'bg-[#121212] text-orange-500' : 'text-zinc-500 hover:bg-white/[0.02]'}`}
              >
                {activeFile?.name === file.name && <div className="absolute top-0 left-0 w-full h-0.5 bg-orange-500" />}
                <div className="flex items-center gap-2 truncate">
                  {file.name.endsWith('.csv') ? <Table size={14} /> : <FileCode size={14} />}
                  <span className={`text-[11px] font-black uppercase tracking-widest truncate ${file.isModified ? 'italic text-orange-300' : ''}`}>{file.name}</span>
                </div>
                <X size={12} className="opacity-0 group-hover:opacity-100 hover:text-red-500" onClick={(e) => {
                    e.stopPropagation();
                    const nextOpen = openFiles.filter(f => f.name !== file.name);
                    setOpenFiles(nextOpen);
                    if (activeFile?.name === file.name) setActiveFile(nextOpen[nextOpen.length - 1] || null);
                  }}
                />
              </div>
            ))}
          </div>

          <div className="flex-1 relative flex overflow-hidden">
            {activeFile ? (
              activeFile.name.endsWith('.csv') ? (
                <div className="flex-1 overflow-auto bg-[#0c0c0c] p-4 custom-scrollbar">
                  <table className="w-full text-[11px] font-mono border-collapse bg-black/40 border border-zinc-800 rounded-lg">
                    <thead>
                      <tr className="bg-zinc-900 border-b border-zinc-800">
                        <th className="px-2 py-1 text-zinc-700 w-8">#</th>
                        {parseCSV(activeFile.content)[0]?.map((_, i) => (
                          <th key={i} className="px-4 py-2 text-orange-500/80 uppercase font-black text-left border-r border-zinc-800">{String.fromCharCode(65 + i)}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {parseCSV(activeFile.content).map((row, rowIndex) => (
                        <tr key={rowIndex} className="border-b border-zinc-800 hover:bg-orange-500/[0.02]">
                          <td className="px-2 py-1 text-zinc-700 text-center bg-black/20">{rowIndex + 1}</td>
                          {row.map((cell, colIndex) => (
                            <td key={colIndex} className="p-0 border-r border-zinc-800">
                              <input
                                type="text"
                                value={cell}
                                onChange={(e) => handleCellChange(rowIndex, colIndex, e.target.value)}
                                className="w-full h-8 px-3 bg-transparent text-zinc-300 outline-none focus:bg-orange-500/10 focus:text-white"
                              />
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <>
                  <div className="w-14 bg-black/40 border-r border-orange-500/10 text-[10px] text-zinc-700 font-mono pr-4 pt-5 text-right select-none shrink-0 z-10">
                    {Array.from({length: activeFile.content?.split('\n').length || 1}).map((_, i) => (
                      <div key={i} className="leading-6">{i+1}</div>
                    ))}
                  </div>
                  <div className="flex-1 relative overflow-hidden bg-[#0c0c0c]">
                    <pre ref={preRef} className="absolute inset-0 p-5 m-0 !bg-transparent pointer-events-none z-0 overflow-hidden">
                      <code ref={codeRef} className={`language-${getLanguage(activeFile.name)} text-[13px] leading-6 font-mono`}>{activeFile.content}</code>
                    </pre>
                    <textarea
                      ref={editorRef}
                      className="absolute inset-0 w-full h-full p-5 bg-transparent text-transparent caret-orange-500 font-mono text-[13px] leading-6 outline-none resize-none z-10 whitespace-pre selection:bg-orange-500/20 overflow-auto custom-scrollbar"
                      value={activeFile.content}
                      onChange={handleEditorChange}
                      onScroll={(e) => {
                        if (preRef.current) {
                          preRef.current.scrollTop = e.currentTarget.scrollTop;
                          preRef.current.scrollLeft = e.currentTarget.scrollLeft;
                        }
                      }}
                      spellCheck={false}
                      autoComplete="off"
                    />
                  </div>
                </>
              )
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center opacity-20 select-none">
                <Command size={80} className="mb-6 text-orange-500 animate-pulse" />
                <span className="text-sm font-black uppercase tracking-[0.6em] text-orange-500">Live VFS Ready</span>
              </div>
            )}
          </div>

          {isTerminalOpen && (
            <div className="h-64 bg-black/95 border-t border-orange-500/20 flex flex-col shrink-0 z-20">
              <div className="h-8 px-5 flex items-center justify-between bg-white/[0.03] border-b border-white/5">
                <div className="flex gap-6 text-[9px] font-black uppercase tracking-[0.3em] h-full">
                  <button onClick={() => setConsoleTab('cli')} className={`h-full flex items-center transition-all ${consoleTab === 'cli' ? 'text-orange-500 border-b-2 border-orange-500' : 'text-zinc-600 hover:text-orange-400'}`}>Terminal</button>
                  <button onClick={() => setConsoleTab('kernel')} className={`h-full flex items-center transition-all ${consoleTab === 'kernel' ? 'text-orange-500 border-b-2 border-orange-500' : 'text-zinc-600 hover:text-orange-400'}`}>Kernel</button>
                </div>
                <X size={12} className="text-zinc-600 hover:text-red-500 cursor-pointer" onClick={() => setIsTerminalOpen(false)} />
              </div>
              <div className="flex-1 p-4 overflow-y-auto font-mono text-[10px] space-y-1.5 custom-scrollbar bg-black/50" onClick={() => inputRef.current?.focus()}>
                {consoleTab === 'cli' ? (
                  <>
                     {termHistory.map((line, i) => (
                       <div key={i} className="text-zinc-400 whitespace-pre-wrap">{line}</div>
                     ))}
                     <div className="flex items-center gap-2 text-orange-500 pt-1">
                       <span>{currentPath} $</span>
                       <input ref={inputRef} type="text" value={termInput} onChange={(e) => setTermInput(e.target.value)} onKeyDown={(e) => {
                         if (e.key === 'Enter') { executeCommand(termInput); setTermInput(''); }
                       }} className="w-full bg-transparent border-none outline-none text-orange-100 font-mono caret-orange-500" autoFocus />
                     </div>
                     <div ref={terminalEndRef} />
                  </>
                ) : (
                  <>
                    {filteredLogs.slice(0, 50).map((log, i) => (
                      <div key={i} className="flex gap-4 group">
                        <span className="text-zinc-800 shrink-0 font-bold">[{new Date(log.timestamp).toLocaleTimeString([], {hour12:false})}]</span>
                        <span className={`uppercase font-black shrink-0 ${log.type === 'error' ? 'text-red-500' : 'text-orange-500/40'}`}>PHX::{log.actor || 'SYS'}</span>
                        <span className={`${log.type === 'error' ? 'text-red-400' : 'text-zinc-400'}`}>{log.message}</span>
                      </div>
                    ))}
                    <div ref={terminalEndRef} />
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

function renderFileTree(
    nodes: FileNode[],
    depth: number,
    onNodeClick: (n: FileNode) => void,
    activeFile: FileNode | null,
    search: string,
    onDelete: (e: React.MouseEvent, n: FileNode) => void,
    resolvePath: (n: FileNode) => string | null,
    onRename?: (e: React.MouseEvent, n: FileNode) => void,
    onDuplicate?: (e: React.MouseEvent, n: FileNode) => void
  ) {
  return nodes
    .filter(node => !search || node.name.toLowerCase().includes(search.toLowerCase()) || (node.children && node.children.some(c => c.name.toLowerCase().includes(search.toLowerCase()))))
    .map((node, i) => (
    <div key={node.name + i}>
      <div
        onClick={() => onNodeClick(node)}
        className={`flex items-center gap-3 py-1.5 px-3 rounded-lg cursor-pointer transition-all group ${activeFile?.name === node.name ? 'bg-orange-500/10 text-orange-400 border-l-2 border-orange-500' : 'text-zinc-500 hover:bg-white/[0.03] hover:text-zinc-300'}`}
        style={{ paddingLeft: `${depth * 14 + 12}px` }}
      >
        <span className="opacity-60">
          {node.type === 'folder' ? (
            node.isOpen ? <ChevronDown size={14} className="text-orange-500" /> : <ChevronRight size={14} />
          ) : (node.name.endsWith('.csv') ? <Table size={14} className={activeFile?.name === node.name ? 'text-orange-500' : 'text-zinc-600'} /> : <FileCode size={14} className={activeFile?.name === node.name ? 'text-orange-500' : 'text-zinc-600'} />)}
        </span>
        <span className={`truncate font-mono text-[10px] flex-1 ${node.type === 'folder' ? 'font-black uppercase tracking-[0.2em] text-zinc-600' : 'font-medium'}`}>
          {node.name}
        </span>
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
           {node.type === 'file' && onDuplicate && (
             <Copy size={12} className="hover:text-blue-400" onClick={(e) => onDuplicate(e, node)} />
           )}
           {onRename && (
             <Edit2 size={12} className="hover:text-amber-400" onClick={(e) => onRename(e, node)} />
           )}
           <Trash2 size={12} className="hover:text-red-500" onClick={(e) => onDelete(e, node)} />
        </div>
      </div>
      {node.type === 'folder' && node.isOpen && node.children && (
        <div className="ml-2 border-l border-white/5">
          {renderFileTree(node.children, depth + 1, onNodeClick, activeFile, search, onDelete, resolvePath, onRename, onDuplicate)}
        </div>
      )}
    </div>
  ));
}

export default CodeTerminal;
