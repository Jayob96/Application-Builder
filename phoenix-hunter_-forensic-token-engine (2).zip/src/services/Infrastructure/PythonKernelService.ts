import { logger } from './observabilityService';
import { phx_vfs, readFile, writeFile, findFileByPath, loadVFS } from './fileRegistry';

/**
 * Python Execution Result
 */
export interface PythonExecutionResult {
  success: boolean;
  output: string[];
  errors: string[];
  result: any;
  executionTime: number;
  memoryUsage?: number;
}

/**
 * Python Package Info
 */
export interface PythonPackage {
  name: string;
  version: string;
  installed: boolean;
}

/**
 * Pyodide Configuration
 */
export interface PyodideConfig {
  indexURL: string;
  fullStdLib?: boolean;
  stdin?: () => string;
  stdout?: (msg: string) => void;
  stderr?: (msg: string) => void;
}

/**
 * PythonKernelService - Python Runtime via Pyodide WASM
 * 
 * Features:
 * - Python 3.11 execution in browser via WebAssembly
 * - VFS integration for file I/O
 * - Package management (micropip)
 * - Multi-script execution support
 * - Performance monitoring
 * - Error handling and recovery
 * - Stdout/stderr capture
 * - Memory management
 * - Async execution
 */
export class PythonKernelService {
  private static instance: PythonKernelService;
  
  // Pyodide Instance
  private pyodide: any = null;
  private isInitializing = false;
  private initializationError: Error | null = null;
  
  // Installed Packages
  private installedPackages: Set<string> = new Set();
  
  // Execution History
  private executionHistory: Array<{
    code: string;
    result: PythonExecutionResult;
    timestamp: number;
  }> = [];
  
  // Configuration
  private readonly PYODIDE_VERSION = "v0.26.1";
  private readonly PYODIDE_CDN = `https://cdn.jsdelivr.net/pyodide/${this.PYODIDE_VERSION}/full/`;
  private readonly MAX_EXECUTION_TIME = 30000; // 30 seconds
  private readonly MAX_HISTORY_SIZE = 100;
  
  // Statistics
  private stats = {
    totalExecutions: 0,
    successfulExecutions: 0,
    failedExecutions: 0,
    totalExecutionTime: 0,
    packagesInstalled: 0,
    initializationTime: 0,
  };

  private constructor() {
    logger.log(
      "🐍 PythonKernelService created",
      "info",
      {},
      1,
      "pythonKernel"
    );
  }

  /**
   * Get singleton instance
   */
  static getInstance(): PythonKernelService {
    if (!this.instance) {
      this.instance = new PythonKernelService();
    }
    return this.instance;
  }

  /**
   * Initialize Pyodide runtime
   */
  async init(): Promise<any> {
    // Return cached instance if already initialized
    if (this.pyodide) {
      return this.pyodide;
    }

    // If initialization failed previously, throw error
    if (this.initializationError) {
      throw this.initializationError;
    }

    // Wait if initialization is in progress
    if (this.isInitializing) {
      while (this.isInitializing) {
        await new Promise(r => setTimeout(r, 100));
      }
      
      if (this.initializationError) {
        throw this.initializationError;
      }
      
      return this.pyodide;
    }

    this.isInitializing = true;
    const startTime = performance.now();

    logger.log(
      "🔥 Python Kernel: Igniting WASM Engine...",
      "info",
      { version: this.PYODIDE_VERSION },
      1,
      "pythonKernel"
    );

    try {
      // Check if loadPyodide is available
      if (typeof (window as any).loadPyodide !== 'function') {
        throw new Error(
          "Pyodide not loaded. Ensure pyodide.js is included in your HTML: " +
          `<script src="${this.PYODIDE_CDN}pyodide.js"></script>`
        );
      }

      // Load Pyodide
      this.pyodide = await (window as any).loadPyodide({
        indexURL: this.PYODIDE_CDN,
        fullStdLib: false, // Load only essential modules for faster startup
      });

      logger.log(
        "⚡ Pyodide core loaded",
        "success",
        {},
        1,
        "pythonKernel"
      );

      // Load micropip for package management
      await this.pyodide.loadPackage(["micropip"]);
      this.installedPackages.add("micropip");

      logger.log(
        "📦 micropip loaded",
        "success",
        {},
        1,
        "pythonKernel"
      );

      // Inject VFS Bridge
      this.injectVFSBridge();

      // Inject utility functions
      await this.injectUtilityFunctions();

      // Calculate initialization time
      const initTime = performance.now() - startTime;
      this.stats.initializationTime = initTime;

      logger.log(
        `✅ Python Kernel: Neural link established (Python 3.11) in ${initTime.toFixed(0)}ms`,
        "success",
        {
          version: this.PYODIDE_VERSION,
          initTime: `${initTime.toFixed(0)}ms`,
          packages: Array.from(this.installedPackages),
        },
        1,
        "pythonKernel"
      );

      return this.pyodide;
    } catch (err: any) {
      this.initializationError = err;

      logger.reportError(
        err,
        {
          cdnUrl: this.PYODIDE_CDN,
          version: this.PYODIDE_VERSION,
        },
        "pythonKernel"
      );

      logger.log(
        `❌ Python Kernel: Failed to ignite - ${err.message}`,
        "error",
        { error: err.message, stack: err.stack },
        4,
        "pythonKernel"
      );

      this.pyodide = null;
      throw err;
    } finally {
      this.isInitializing = false;
    }
  }

  /**
   * Execute Python code
   */
  async run(
    code: string,
    onOutput?: (msg: string) => void,
    onError?: (msg: string) => void
  ): Promise<PythonExecutionResult> {
    const startTime = performance.now();
    const output: string[] = [];
    const errors: string[] = [];

    // Output handlers
    const outputHandler = (msg: string) => {
      output.push(msg);
      if (onOutput) onOutput(msg);
    };

    const errorHandler = (msg: string) => {
      errors.push(msg);
      if (onError) onError(msg);
      if (!onError && onOutput) onOutput(`[ERROR] ${msg}`);
    };

    try {
      // Initialize Pyodide if not ready
      const py = await this.init();
      
      if (!py) {
        throw new Error("Python Kernel is not initialized.");
      }

      logger.startPerformanceMark('python_execution');

      // Set up stdout/stderr capture
      py.setStdout({ batched: outputHandler });
      py.setStderr({ batched: errorHandler });

      // Execute with timeout
      const executionPromise = py.runPythonAsync(code);
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(
          () => reject(new Error(`Execution timeout after ${this.MAX_EXECUTION_TIME}ms`)),
          this.MAX_EXECUTION_TIME
        )
      );

      const result = await Promise.race([executionPromise, timeoutPromise]);

      const executionTime = logger.endPerformanceMark('python_execution', false) || 0;

      // Update statistics
      this.stats.totalExecutions++;
      this.stats.successfulExecutions++;
      this.stats.totalExecutionTime += executionTime;

      const executionResult: PythonExecutionResult = {
        success: true,
        output,
        errors,
        result,
        executionTime,
      };

      // Store in history
      this.addToHistory(code, executionResult);

      logger.log(
        `✅ Python execution complete (${executionTime.toFixed(0)}ms)`,
        "success",
        {
          executionTime: `${executionTime.toFixed(0)}ms`,
          outputLines: output.length,
          errorLines: errors.length,
        },
        1,
        "pythonKernel"
      );

      return executionResult;
    } catch (err: any) {
      const executionTime = performance.now() - startTime;

      errorHandler(`[PYTHON_CRASH] ${err.message}`);

      // Update statistics
      this.stats.totalExecutions++;
      this.stats.failedExecutions++;
      this.stats.totalExecutionTime += executionTime;

      logger.reportError(
        err,
        {
          codeLength: code.length,
          executionTime: `${executionTime.toFixed(0)}ms`,
        },
        "pythonKernel"
      );

      const executionResult: PythonExecutionResult = {
        success: false,
        output,
        errors,
        result: null,
        executionTime,
      };

      // Store in history
      this.addToHistory(code, executionResult);

      return executionResult;
    }
  }

  /**
   * Execute Python script from VFS
   */
  async runScript(
    scriptPath: string,
    onOutput?: (msg: string) => void,
    onError?: (msg: string) => void
  ): Promise<PythonExecutionResult> {
    logger.log(
      `🐍 Executing script: ${scriptPath}`,
      "info",
      { path: scriptPath },
      1,
      "pythonKernel"
    );

    // Read script from VFS
    const scriptContent = readFile(scriptPath);

    if (!scriptContent) {
      const error = `Script not found: ${scriptPath}`;
      logger.log(
        `❌ ${error}`,
        "error",
        { path: scriptPath },
        3,
        "pythonKernel"
      );
      
      return {
        success: false,
        output: [],
        errors: [error],
        result: null,
        executionTime: 0,
      };
    }

    // Execute script
    return this.run(scriptContent, onOutput, onError);
  }

  /**
   * Install Python package via micropip
   */
  async install(pkg: string): Promise<boolean> {
    try {
      const py = await this.init();
      
      if (!py) {
        throw new Error("Python Kernel is not initialized.");
      }

      logger.log(
        `📦 Installing package: ${pkg}`,
        "info",
        { package: pkg },
        1,
        "pythonKernel"
      );

      logger.startPerformanceMark(`install_${pkg}`);

      const micropip = py.pyimport("micropip");
      await micropip.install(pkg);

      const installTime = logger.endPerformanceMark(`install_${pkg}`, false) || 0;

      this.installedPackages.add(pkg);
      this.stats.packagesInstalled++;

      logger.log(
        `✅ Package '${pkg}' synthesized (${installTime.toFixed(0)}ms)`,
        "success",
        {
          package: pkg,
          installTime: `${installTime.toFixed(0)}ms`,
        },
        1,
        "pythonKernel"
      );

      return true;
    } catch (err: any) {
      logger.reportError(
        err,
        { package: pkg },
        "pythonKernel"
      );

      logger.log(
        `❌ Failed to install package: ${pkg} - ${err.message}`,
        "error",
        { package: pkg, error: err.message },
        3,
        "pythonKernel"
      );

      return false;
    }
  }

  /**
   * Get list of installed packages
   */
  getInstalledPackages(): string[] {
    return Array.from(this.installedPackages);
  }

  /**
   * Check if package is installed
   */
  isPackageInstalled(pkg: string): boolean {
    return this.installedPackages.has(pkg);
  }

  /**
   * Get execution statistics
   */
  getStats() {
    return {
      ...this.stats,
      averageExecutionTime: this.stats.totalExecutions > 0
        ? this.stats.totalExecutionTime / this.stats.totalExecutions
        : 0,
      successRate: this.stats.totalExecutions > 0
        ? (this.stats.successfulExecutions / this.stats.totalExecutions) * 100
        : 0,
    };
  }

  /**
   * Get execution history
   */
  getHistory(): typeof this.executionHistory {
    return [...this.executionHistory];
  }

  /**
   * Clear execution history
   */
  clearHistory(): void {
    this.executionHistory = [];
    logger.log(
      "🧹 Python execution history cleared",
      "info",
      {},
      1,
      "pythonKernel"
    );
  }

  /**
   * Check if kernel is initialized
   */
  isInitialized(): boolean {
    return this.pyodide !== null;
  }

  /**
   * Reset kernel (force reinitialization)
   */
  reset(): void {
    this.pyodide = null;
    this.isInitializing = false;
    this.initializationError = null;
    this.installedPackages.clear();
    
    logger.log(
      "🔄 Python Kernel reset",
      "warning",
      {},
      2,
      "pythonKernel"
    );
  }

  // ==================== PRIVATE METHODS ====================

  /**
   * Inject VFS bridge module
   */
  private injectVFSBridge(): void {
    if (!this.pyodide) return;

    try {
      this.pyodide.registerJsModule("phx_vfs", {
        read: (path: string) => {
          const content = readFile(path);
          if (content === null) {
            throw new Error(`File not found: ${path}`);
          }
          return content;
        },
        write: (path: string, content: string) => {
          const success = writeFile(path, content);
          if (!success) {
            throw new Error(`Failed to write file: ${path}`);
          }
          return success;
        },
        exists: (path: string) => {
          const root = loadVFS();
          return findFileByPath(root, path) !== null;
        },
        list: (dirPath: string) => {
          const root = loadVFS();
          const dir = findFileByPath(root, dirPath || '/');
          
          if (!dir || dir.type !== 'folder') {
            return [];
          }
          
          return dir.children ? dir.children.map(c => c.name) : [];
        },
      });

      logger.log(
        "🔗 VFS bridge injected",
        "success",
        {},
        1,
        "pythonKernel"
      );
    } catch (err: any) {
      logger.reportError(
        err,
        {},
        "pythonKernel"
      );
    }
  }

  /**
   * Inject utility functions into Python environment
   */
  private async injectUtilityFunctions(): Promise<void> {
    if (!this.pyodide) return;

    try {
      await this.pyodide.runPythonAsync(`
import sys
from datetime import datetime

# Utility functions
def phx_log(message, level="INFO"):
    """Log message to Phoenix Hunter console"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"[{timestamp}] [{level}] {message}")

def phx_debug(message):
    """Debug logging"""
    phx_log(message, "DEBUG")

def phx_info(message):
    """Info logging"""
    phx_log(message, "INFO")

def phx_warning(message):
    """Warning logging"""
    phx_log(message, "WARNING")

def phx_error(message):
    """Error logging"""
    phx_log(message, "ERROR")

# Make utilities globally available
sys.modules['phx_utils'] = sys.modules[__name__]
      `);

      logger.log(
        "🛠️ Python utilities injected",
        "success",
        {},
        1,
        "pythonKernel"
      );
    } catch (err: any) {
      logger.log(
        `⚠️ Failed to inject utilities: ${err.message}`,
        "warning",
        {},
        2,
        "pythonKernel"
      );
    }
  }

  /**
   * Add execution to history
   */
  private addToHistory(code: string, result: PythonExecutionResult): void {
    this.executionHistory.push({
      code,
      result,
      timestamp: Date.now(),
    });

    // Prune history if too large
    if (this.executionHistory.length > this.MAX_HISTORY_SIZE) {
      this.executionHistory = this.executionHistory.slice(-this.MAX_HISTORY_SIZE);
    }
  }
}

// ==================== EXPORTS ====================

/**
 * Global Python Kernel instance
 */
export const pythonKernel = PythonKernelService.getInstance();

/**
 * Export class for advanced usage
 */
export default PythonKernelService;

/**
 * Helper function to quickly run Python code
 */
export async function runPython(
  code: string,
  onOutput?: (msg: string) => void
): Promise<PythonExecutionResult> {
  return pythonKernel.run(code, onOutput);
}

/**
 * Helper function to run Python script from VFS
 */
export async function runPythonScript(
  scriptPath: string,
  onOutput?: (msg: string) => void
): Promise<PythonExecutionResult> {
  return pythonKernel.runScript(scriptPath, onOutput);
}

/**
 * Helper function to install Python package
 */
export async function installPackage(pkg: string): Promise<boolean> {
  return pythonKernel.install(pkg);
}
