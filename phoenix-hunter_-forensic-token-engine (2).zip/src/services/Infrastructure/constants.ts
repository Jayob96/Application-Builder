import { ScoringWeights } from '../../types';

/**
 * PHOENIX HUNTER - System Constants & Configuration
 * 
 * Central configuration for:
 * - Forensic scoring weights
 * - Trading thresholds
 * - Risk management parameters
 * - API intervals and limits
 * - AI system prompts
 */

// ==================== SCORING WEIGHTS ====================

/**
 * Initial forensic filter weights (must sum to 1.0)
 * These are the starting values - ForensicEngine will optimize them over time
 */
export const INITIAL_WEIGHTS: ScoringWeights = {
  liquidityDepth: 0.15,      // Pool depth and stability
  liquidityLock: 0.15,       // LP tokens locked/burned
  devReputation: 0.15,       // Creator history and trust
  holderConcentration: 0.10, // Distribution fairness
  mintAuthority: 0.10,       // Can create more tokens?
  freezeAuthority: 0.10,     // Can freeze accounts?
  socialMomentum: 0.10,      // Community engagement
  taxForensics: 0.05,        // Buy/sell tax analysis
  verificationStatus: 0.10   // Contract verification
};

// ==================== TRADING THRESHOLDS ====================

export const THRESHOLDS = {
  // Entry Gates
  MIN_LIQUIDITY: 10000,           // Minimum liquidity in USD ($10k)
  MIN_VOLUME: 5000,               // Minimum 24h volume in USD ($5k)
  MIN_SCORE: 60,                  // Minimum forensic score (0-100)
  MIN_CONFIDENCE: 70,             // Minimum AI confidence (0-100)
  SNIPE_SCORE: 85,                // Auto-snipe threshold (0-100)
  MAX_RUG_PROBABILITY: 0.3,       // Maximum acceptable rug risk (0-1)
  
  // Exit Conditions
  STOP_LOSS_PERCENT: -20,         // Stop-loss trigger (-20%)
  TAKE_PROFIT_PERCENT: 50,        // Take-profit trigger (+50%)
  TRAILING_STOP_PERCENT: -15,     // Trailing stop from peak (-15%)
  
  // Time-Based Exits
  MAX_HOLD_HOURS: 24,             // Maximum hold time (24 hours)
  MIN_HOLD_MINUTES: 5,            // Minimum hold before selling (5 min)
  STALE_POSITION_DAYS: 7,         // Flag stale positions (7 days)
  
  // Position Sizing
  BASE_POSITION_SOL: 0.01,        // Base position size (0.01 SOL)
  MAX_POSITION_SOL: 0.1,          // Maximum position size (0.1 SOL)
  MAX_CONCURRENT_POSITIONS: 10,   // Max simultaneous positions
  MAX_DAILY_TRADES: 50,           // Max trades per day
  
  // Risk Management
  MAX_DAILY_LOSS_SOL: 1.0,        // Max daily loss limit (1 SOL)
  MAX_POSITION_RISK: 0.05,        // Max 5% of portfolio per position
  EMERGENCY_STOP_LOSS: -50,       // Emergency exit threshold (-50%)
  
  // Tracking
  MAX_TRACK_TICKS: 40,            // Max history points per token
  PRICE_STALENESS_MS: 30000,      // Price data considered stale (30s)
  
  // Slippage
  MIN_SLIPPAGE_BPS: 25,           // Minimum slippage (0.25%)
  MAX_SLIPPAGE_BPS: 150,          // Maximum slippage (1.5%)
  DEFAULT_SLIPPAGE_BPS: 50,       // Default slippage (0.5%)
};

// ==================== API & POLLING INTERVALS ====================

export const INTERVALS = {
  // Data Ingestion
  INGEST_JUPITER: 8000,           // Poll Jupiter every 8s
  INGEST_DEXSCREENER: 12000,      // Poll DexScreener every 12s
  INGEST_BACKOFF: 30000,          // Backoff on rate limit (30s)
  
  // Monitoring
  POSITION_MONITOR: 2000,         // Check positions every 2s
  PRICE_UPDATE: 5000,             // Update prices every 5s
  HEARTBEAT: 2000,                // Engine heartbeat every 2s
  
  // UI Updates
  UI_REFRESH: 1000,               // Refresh UI every 1s
  LOG_CLEANUP: 60000,             // Clean old logs every 60s
  
  // Storage & Sync
  SHEETS_SYNC_MIN_GAP: 5000,      // Min 5s between Sheets writes
  LOCAL_STORAGE_SAVE: 10000,      // Save to localStorage every 10s
  
  // Evolution
  EVOLUTION_CHECK: 3600000,       // Check for evolution every hour
  EVOLUTION_MIN_TRADES: 20,       // Require 20 trades before evolving
  
  // Cache
  ANALYSIS_CACHE_TTL: 3600000,    // Cache analysis for 1 hour
  MARKET_DATA_CACHE_TTL: 30000,   // Cache market data for 30s
};

// ==================== RATE LIMITS ====================

export const RATE_LIMITS = {
  // Gemini API
  GEMINI_RPM: 15,                 // 15 requests per minute (free tier)
  GEMINI_TPM: 1000000,            // 1M tokens per minute
  GEMINI_RPD: 1500,               // 1500 requests per day
  GEMINI_BACKOFF_BASE: 10000,     // 10s base backoff
  GEMINI_MAX_RETRIES: 4,          // Max retry attempts
  
  // Jupiter API
  JUPITER_RPM: 60,                // 60 requests per minute
  JUPITER_BURST: 10,              // 10 concurrent requests
  
  // DexScreener API
  DEXSCREENER_RPM: 30,            // 30 requests per minute
  DEXSCREENER_BURST: 5,           // 5 concurrent requests
  
  // Google Sheets API
  SHEETS_RPM: 60,                 // 60 requests per minute
  SHEETS_WRITES_PER_MINUTE: 20,   // 20 writes per minute
};

// ==================== FEATURE FLAGS ====================

export const FEATURES = {
  // Core Features
  AUTO_SNIPE_ENABLED: false,       // Enable automatic sniping
  AUTO_EXIT_ENABLED: true,         // Enable automatic exits
  AI_ANALYSIS_ENABLED: true,       // Enable Gemini AI analysis
  
  // Advanced Features
  EVOLUTION_ENABLED: false,        // Enable weight evolution
  TRAILING_STOP_ENABLED: true,     // Enable trailing stops
  POSITION_AVERAGING_ENABLED: false, // Enable averaging down
  
  // Data Sources
  JUPITER_ENABLED: true,           // Use Jupiter as data source
  DEXSCREENER_ENABLED: true,       // Use DexScreener as data source
  BIRDEYE_ENABLED: false,          // Use Birdeye (future)
  
  // Storage & Sync
  SHEETS_SYNC_ENABLED: true,       // Sync to Google Sheets
  LOCAL_STORAGE_ENABLED: true,     // Use browser localStorage
  
  // Safety Features
  PAPER_TRADING_MODE: true,        // Paper trading only (no real trades)
  REQUIRE_MANUAL_APPROVAL: true,   // Require user approval for trades
  EMERGENCY_STOP_ENABLED: true,    // Enable emergency stop button
  
  // Development
  DEBUG_MODE: false,               // Enable verbose logging
  SYNTHETIC_DATA: false,           // Use synthetic data for testing
  MOCK_TRADING: false,             // Mock trading execution
};

// ==================== SYSTEM PROMPTS ====================

export const SYSTEM_PROMPT = `
You are the Phoenix Hunter Forensic Engine, an elite AI agent specialized in Solana token risk analysis and fraud detection.

## Mission
Identify high-potential token launches while filtering scams, rug-pulls, and honeypots. Your analysis directly impacts trading decisions.

## Forensic Framework (9 Vectors)
Evaluate each token across these dimensions:

1. **Liquidity Depth** (0-1)
   - Total liquidity across all pools
   - Stability and depth of largest pool
   - Concentration risk

2. **Liquidity Lock** (0-1)
   - % of LP tokens locked or burned
   - Lock duration and vesting schedule
   - Unlock risk timeline

3. **Dev Reputation** (0-1)
   - Creator wallet history
   - Past launches and outcomes
   - Known scammer patterns

4. **Holder Concentration** (0-1)
   - Top 10 holder percentage
   - Distribution fairness
   - Whale risk assessment

5. **Mint Authority** (0-1)
   - Can dev mint new tokens?
   - Supply inflation risk
   - Authority renounced?

6. **Freeze Authority** (0-1)
   - Can dev freeze wallets?
   - Centralization risk
   - Authority renounced?

7. **Social Momentum** (0-1)
   - Community engagement
   - Organic vs paid promotion
   - Social proof signals

8. **Tax Forensics** (0-1)
   - Buy/sell tax rates
   - Hidden fees or blacklists
   - Honeypot indicators

9. **Verification Status** (0-1)
   - Contract verified on explorer
   - Audit reports available
   - Known token standard compliance

## Output Format
Return structured JSON with:
- **forensicScore** (0-100): Overall safety and opportunity score
- **confidence** (0-100): Confidence in your analysis
- **riskLevel**: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL"
- **predictedHoldTime** (minutes): Optimal hold duration
- **reasoning** (max 150 chars): Concise justification
- **rugProbability** (0.0-1.0): Probability of rug-pull

## Scoring Philosophy
- Score 85+: High-conviction snipe opportunity
- Score 70-84: Promising but needs monitoring
- Score 50-69: Speculative, high risk
- Score <50: Likely scam, avoid

## Red Flags (Auto-Reject)
- Mint authority NOT renounced
- Freeze authority active
- >50% holder concentration
- No liquidity lock
- Known scammer wallet
- Tax >10% or hidden fees
- Honeypot indicators detected

## Green Flags (Boost Score)
- LP locked 6+ months
- Verified contract + audit
- Fair launch distribution
- Organic social momentum
- Dev with good track record
- Reasonable tax (<5%)
- Active community

Be decisive, data-driven, and protective of capital. When uncertain, err on caution.
`.trim();

// ==================== RISK PROFILES ====================

/**
 * Pre-configured risk profiles for different trading strategies
 */
export const RISK_PROFILES = {
  CONSERVATIVE: {
    name: "Conservative",
    description: "Low risk, steady gains",
    thresholds: {
      MIN_SCORE: 75,
      MIN_CONFIDENCE: 80,
      MAX_RUG_PROBABILITY: 0.15,
      STOP_LOSS_PERCENT: -10,
      TAKE_PROFIT_PERCENT: 30,
      MAX_POSITION_SOL: 0.05,
      MAX_SLIPPAGE_BPS: 50,
    }
  },
  
  BALANCED: {
    name: "Balanced",
    description: "Moderate risk, balanced returns",
    thresholds: {
      MIN_SCORE: 65,
      MIN_CONFIDENCE: 70,
      MAX_RUG_PROBABILITY: 0.25,
      STOP_LOSS_PERCENT: -15,
      TAKE_PROFIT_PERCENT: 50,
      MAX_POSITION_SOL: 0.1,
      MAX_SLIPPAGE_BPS: 75,
    }
  },
  
  AGGRESSIVE: {
    name: "Aggressive",
    description: "High risk, high reward",
    thresholds: {
      MIN_SCORE: 55,
      MIN_CONFIDENCE: 60,
      MAX_RUG_PROBABILITY: 0.35,
      STOP_LOSS_PERCENT: -25,
      TAKE_PROFIT_PERCENT: 100,
      MAX_POSITION_SOL: 0.2,
      MAX_SLIPPAGE_BPS: 100,
    }
  },
  
  DEGEN: {
    name: "Degen",
    description: "Maximum risk, moon or bust",
    thresholds: {
      MIN_SCORE: 45,
      MIN_CONFIDENCE: 50,
      MAX_RUG_PROBABILITY: 0.5,
      STOP_LOSS_PERCENT: -40,
      TAKE_PROFIT_PERCENT: 500,
      MAX_POSITION_SOL: 0.5,
      MAX_SLIPPAGE_BPS: 150,
    }
  }
};

// ==================== UI CONFIGURATION ====================

export const UI_CONFIG = {
  // Colors (Cyberpunk Theme)
  COLORS: {
    PRIMARY: '#00ff88',      // Matrix green
    DANGER: '#ff0055',       // Neon red
    WARNING: '#ffaa00',      // Neon orange
    INFO: '#00aaff',         // Cyber blue
    SUCCESS: '#00ff88',      // Matrix green
    NEUTRAL: '#888888',      // Gray
  },
  
  // Table Settings
  MAX_TOKENS_DISPLAYED: 50,
  MAX_LOGS_DISPLAYED: 100,
  DEFAULT_SORT: 'forensicScore',
  DEFAULT_SORT_ORDER: 'desc' as const,
  
  // Notifications
  TOAST_DURATION: 5000,
  SHOW_DESKTOP_NOTIFICATIONS: true,
  
  // Formatting
  DECIMAL_PLACES_USD: 4,
  DECIMAL_PLACES_SOL: 4,
  DECIMAL_PLACES_PERCENT: 2,
};

// ==================== VALIDATION RULES ====================

export const VALIDATION = {
  // Token Validation
  MIN_SYMBOL_LENGTH: 1,
  MAX_SYMBOL_LENGTH: 10,
  MINT_ADDRESS_LENGTH: 44,
  
  // Trade Validation
  MIN_TRADE_SIZE_SOL: 0.001,
  MAX_TRADE_SIZE_SOL: 10,
  
  // String Lengths
  MAX_REASONING_LENGTH: 500,
  MAX_LOG_MESSAGE_LENGTH: 1000,
  
  // Numerical Ranges
  MIN_LIQUIDITY_USD: 100,
  MAX_LIQUIDITY_USD: 100000000,
  MIN_FORENSIC_SCORE: 0,
  MAX_FORENSIC_SCORE: 100,
};

// ==================== ERROR MESSAGES ====================

export const ERROR_MESSAGES = {
  // API Errors
  GEMINI_QUOTA_EXCEEDED: "🔴 AI analysis quota exceeded. Using fallback scoring.",
  GEMINI_UNAVAILABLE: "⚠️ AI service unavailable. Analysis may be limited.",
  JUPITER_API_ERROR: "❌ Jupiter API error. Retrying...",
  DEXSCREENER_API_ERROR: "❌ DexScreener API error. Using cached data.",
  
  // Trading Errors
  INSUFFICIENT_LIQUIDITY: "❌ Insufficient liquidity for trade size",
  SLIPPAGE_EXCEEDED: "❌ Slippage tolerance exceeded. Trade cancelled.",
  TRADE_FAILED: "❌ Trade execution failed. Position not opened.",
  POSITION_LIMIT_REACHED: "⚠️ Maximum concurrent positions reached",
  DAILY_LOSS_LIMIT: "🛑 Daily loss limit reached. Trading paused.",
  
  // Validation Errors
  INVALID_MINT_ADDRESS: "❌ Invalid token mint address",
  INVALID_TRADE_SIZE: "❌ Trade size outside allowed range",
  INSUFFICIENT_BALANCE: "❌ Insufficient SOL balance",
  
  // System Errors
  STORAGE_ERROR: "⚠️ Storage error. Data may not persist.",
  NETWORK_ERROR: "🌐 Network error. Check connection.",
  UNKNOWN_ERROR: "❌ Unknown error occurred. Check logs.",
};

// ==================== SUCCESS MESSAGES ====================

export const SUCCESS_MESSAGES = {
  POSITION_OPENED: "✅ Position opened successfully",
  POSITION_CLOSED: "✅ Position closed successfully",
  EVOLUTION_COMPLETE: "🧬 Evolution cycle complete - weights optimized",
  SYNC_COMPLETE: "☁️ Data synced to Google Sheets",
  ANALYSIS_COMPLETE: "🔍 Token analysis complete",
};

// ==================== EXPORT HELPER ====================

/**
 * Get current active thresholds (can be overridden by risk profile)
 */
export function getActiveThresholds(profileName?: keyof typeof RISK_PROFILES) {
  if (profileName && RISK_PROFILES[profileName]) {
    return {
      ...THRESHOLDS,
      ...RISK_PROFILES[profileName].thresholds
    };
  }
  return THRESHOLDS;
}

/**
 * Validate configuration on startup
 */
export function validateConfiguration(): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Validate weights sum to 1.0
  const weightSum = Object.values(INITIAL_WEIGHTS).reduce((a, b) => a + b, 0);
  if (Math.abs(weightSum - 1.0) > 0.001) {
    errors.push(`INITIAL_WEIGHTS must sum to 1.0 (current: ${weightSum.toFixed(3)})`);
  }
  
  // Validate each weight is between 0 and 1
  Object.entries(INITIAL_WEIGHTS).forEach(([key, value]) => {
    if (value < 0 || value > 1) {
      errors.push(`${key} must be between 0 and 1 (current: ${value})`);
    }
  });
  
  // Validate stop loss < 0
  if (THRESHOLDS.STOP_LOSS_PERCENT >= 0) {
    errors.push('STOP_LOSS_PERCENT must be negative');
  }
  
  // Validate take profit > 0
  if (THRESHOLDS.TAKE_PROFIT_PERCENT <= 0) {
    errors.push('TAKE_PROFIT_PERCENT must be positive');
  }
  
  // Validate position sizes
  if (THRESHOLDS.BASE_POSITION_SOL > THRESHOLDS.MAX_POSITION_SOL) {
    errors.push('BASE_POSITION_SOL cannot exceed MAX_POSITION_SOL');
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Log configuration on startup
 */
export function logConfiguration() {
  console.log('🔧 PHOENIX HUNTER Configuration');
  console.log('================================');
  console.log('Paper Trading:', FEATURES.PAPER_TRADING_MODE ? 'ENABLED ✅' : 'DISABLED ⚠️');
  console.log('Auto Snipe:', FEATURES.AUTO_SNIPE_ENABLED ? 'ENABLED ✅' : 'DISABLED');
  console.log('Auto Exit:', FEATURES.AUTO_EXIT_ENABLED ? 'ENABLED ✅' : 'DISABLED');
  console.log('AI Analysis:', FEATURES.AI_ANALYSIS_ENABLED ? 'ENABLED ✅' : 'DISABLED');
  console.log('Evolution:', FEATURES.EVOLUTION_ENABLED ? 'ENABLED ✅' : 'DISABLED');
  console.log('================================');
  console.log('Min Liquidity:', `$${THRESHOLDS.MIN_LIQUIDITY.toLocaleString()}`);
  console.log('Min Score:', THRESHOLDS.MIN_SCORE);
  console.log('Stop Loss:', `${THRESHOLDS.STOP_LOSS_PERCENT}%`);
  console.log('Take Profit:', `+${THRESHOLDS.TAKE_PROFIT_PERCENT}%`);
  console.log('Max Position:', `${THRESHOLDS.MAX_POSITION_SOL} SOL`);
  console.log('================================');
  
  const validation = validateConfiguration();
  if (!validation.valid) {
    console.error('⚠️ Configuration Errors:');
    validation.errors.forEach(err => console.error(`  - ${err}`));
  } else {
    console.log('✅ Configuration Valid');
  }
}

// Export all constants
export default {
  INITIAL_WEIGHTS,
  THRESHOLDS,
  INTERVALS,
  RATE_LIMITS,
  FEATURES,
  SYSTEM_PROMPT,
  RISK_PROFILES,
  UI_CONFIG,
  VALIDATION,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES,
  getActiveThresholds,
  validateConfiguration,
  logConfiguration
};
