// src/services/VirtualFileSystem.ts
// ============================================================================
// PRODUCTION-GRADE VIRTUAL FILE SYSTEM (VFS)
// Complete implementation with search, undo/redo, validation, and more
// ============================================================================

import React from 'react'
import { PROJECT_FILES, FileNode } from './fileRegistry'
import { observabilityService } from './observabilityService'

// ============================================================================
// TYPES & INTERFACES
// ============================================================================

export type VFSEventType = 
  | 'change' | 'create' | 'delete' | 'update' | 'rename' 
  | 'move' | 'duplicate' | 'toggle' | 'reset'

export interface VFSEvent {
  type: VFSEventType
  path: string
  timestamp: number
  previousValue?: any
  newValue?: any
  source: 'user' | 'system' | 'import'
}

export interface VFSStats {
  totalFiles: number
  totalFolders: number
  totalSize: number
  lastModified: number
  filesByType: Record<string, number>
}

export interface SearchResult {
  path: string
  node: FileNode
  matchType: 'name' | 'content' | 'type'
  context?: string
}

interface HistoryEntry {
  event: VFSEvent
  state: FileNode[]
  timestamp: number
}

type VFSListener = (tree: FileNode[], event: VFSEvent) => void
type VFSValidator = (path: string, node: FileNode) => boolean | string

// ============================================================================
// CONSTANTS
// ============================================================================

const STORAGE_KEY = 'phx_vfs_data'
const HISTORY_KEY = 'phx_vfs_history'
const MAX_HISTORY = 50
const MAX_FILE_SIZE = 50 * 1024 * 1024 // 50MB
const FORBIDDEN_NAMES = ['.', '..', 'CON', 'PRN', 'AUX', 'NUL']
const FORBIDDEN_CHARS = /[<>:"|?*\x00-\x1F]/g

// ============================================================================
// VIRTUAL FILE SYSTEM CLASS
// ============================================================================

class VirtualFileSystem {
  private static instance: VirtualFileSystem
  private tree: FileNode[] = []
  private listeners: Set<VFSListener> = new Set()
  private validators: Map<string, VFSValidator> = new Map()
  private history: HistoryEntry[] = []
  private historyIndex: number = -1
  private stats: VFSStats | null = null
  private cache: Map<string, FileNode | null> = new Map()

  private constructor() {
    this.load()
    this.loadHistory()
    this.updateStats()
  }

  static getInstance(): VirtualFileSystem {
    if (!this.instance) this.instance = new VirtualFileSystem()
    return this.instance
  }

  // ========================================================================
  // INITIALIZATION & PERSISTENCE
  // ========================================================================

  private load() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      if (saved) {
        this.tree = JSON.parse(saved)
        observabilityService.log(
          'VFS: Loaded from storage',
          'success',
          { files: this.tree.length },
          1,
          'VirtualFileSystem'
        )
      } else {
        this.tree = JSON.parse(JSON.stringify(PROJECT_FILES))
      }
    } catch (error) {
      observabilityService.log(`VFS: Load error: ${error}`, 'error', {}, 3, 'VirtualFileSystem')
      this.tree = JSON.parse(JSON.stringify(PROJECT_FILES))
    }
  }

  private save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.tree))
      this.invalidateCache()
      this.updateStats()
    } catch (error) {
      observabilityService.log(`VFS: Save error: ${error}`, 'error', {}, 3, 'VirtualFileSystem')
    }
  }

  private loadHistory() {
    try {
      const saved = localStorage.getItem(HISTORY_KEY)
      if (saved) {
        this.history = JSON.parse(saved)
        this.historyIndex = this.history.length - 1
      }
    } catch (error) {
      this.history = []
      this.historyIndex = -1
    }
  }

  private saveHistory() {
    try {
      this.history = this.history.slice(0, this.historyIndex + 1)
      if (this.history.length > MAX_HISTORY) {
        this.history = this.history.slice(-MAX_HISTORY)
      }
      localStorage.setItem(HISTORY_KEY, JSON.stringify(this.history))
    } catch (error) {
      observabilityService.log(`VFS: History save error: ${error}`, 'error', {}, 2, 'VirtualFileSystem')
    }
  }

  private notify(event: VFSEvent) {
    this.listeners.forEach(listener => {
      try {
        listener([...this.tree], event)
      } catch (error) {
        observabilityService.log(`VFS: Listener error: ${error}`, 'error', {}, 2, 'VirtualFileSystem')
      }
    })
  }

  private recordHistory(event: VFSEvent) {
    const entry: HistoryEntry = {
      event,
      state: JSON.parse(JSON.stringify(this.tree)),
      timestamp: Date.now(),
    }
    this.historyIndex++
    this.history[this.historyIndex] = entry
    if (this.historyIndex < this.history.length - 1) {
      this.history = this.history.slice(0, this.historyIndex + 1)
    }
    this.saveHistory()
  }

  private invalidateCache(path?: string) {
    if (path) {
      this.cache.delete(path)
      const parts = path.split('/').filter(Boolean)
      for (let i = 0; i < parts.length; i++) {
        this.cache.delete('/' + parts.slice(0, i + 1).join('/'))
      }
    } else {
      this.cache.clear()
    }
  }

  private updateStats() {
    const stats: VFSStats = {
      totalFiles: 0,
      totalFolders: 0,
      totalSize: 0,
      lastModified: Date.now(),
      filesByType: {},
    }

    const traverse = (nodes: FileNode[]) => {
      nodes.forEach(node => {
        if (node.type === 'folder') {
          stats.totalFolders++
          if (node.children) traverse(node.children)
        } else {
          stats.totalFiles++
          const size = node.content?.length ?? 0
          stats.totalSize += size
          const ext = node.name.split('.').pop() || 'unknown'
          stats.filesByType[ext] = (stats.filesByType[ext] ?? 0) + 1
        }
      })
    }

    traverse(this.tree)
    this.stats = stats
  }

  // ========================================================================
  // SUBSCRIPTION & OBSERVATION
  // ========================================================================

  subscribe(listener: VFSListener): () => void {
    this.listeners.add(listener)
    listener([...this.tree], {
      type: 'change',
      path: '/',
      timestamp: Date.now(),
      source: 'system',
    })
    return () => this.listeners.delete(listener)
  }

  getTree(): FileNode[] {
    return JSON.parse(JSON.stringify(this.tree))
  }

  getStats(): VFSStats | null {
    return this.stats ? { ...this.stats } : null
  }

  getHistory() {
    return this.history.map(entry => ({
      ...entry,
      state: JSON.parse(JSON.stringify(entry.state)),
    }))
  }

  getHistoryIndex(): number {
    return this.historyIndex
  }

  // ========================================================================
  // VALIDATION & CONSTRAINTS
  // ========================================================================

  registerValidator(key: string, validator: VFSValidator) {
    this.validators.set(key, validator)
  }

  private validateName(name: string): boolean {
    if (!name || name.length === 0) return false
    if (name.length > 255) return false
    if (FORBIDDEN_NAMES.includes(name.toUpperCase())) return false
    if (FORBIDDEN_CHARS.test(name)) return false
    return true
  }

  private validateSize(content?: string): boolean {
    if (!content) return true
    return content.length <= MAX_FILE_SIZE
  }

  private runValidators(path: string, node: FileNode): boolean {
    for (const [_, validator] of this.validators) {
      const result = validator(path, node)
      if (result !== true) {
        throw new Error(typeof result === 'string' ? result : 'Validation failed')
      }
    }
    return true
  }

  // ========================================================================
  // SEARCH & FILTER
  // ========================================================================

  search(query: string, options?: {
    matchCase?: boolean
    searchContent?: boolean
    fileType?: string
  }): SearchResult[] {
    const results: SearchResult[] = []
    const regex = new RegExp(query, options?.matchCase ? 'g' : 'gi')

    const traverse = (nodes: FileNode[], path: string = '') => {
      nodes.forEach(node => {
        const currentPath = path ? `${path}/${node.name}` : `/${node.name}`

        if (regex.test(node.name)) {
          results.push({ path: currentPath, node, matchType: 'name' })
        }

        if (options?.searchContent && node.type === 'file' && node.content) {
          const contentRegex = new RegExp(query, options?.matchCase ? 'g' : 'gi')
          if (contentRegex.test(node.content)) {
            const lines = node.content.split('\n')
            const line = lines.findIndex(l => contentRegex.test(l))
            results.push({
              path: currentPath,
              node,
              matchType: 'content',
              context: line >= 0 ? lines[line] : undefined,
            })
          }
        }

        if (options?.fileType && node.name.endsWith(options.fileType)) {
          if (!results.some(r => r.path === currentPath)) {
            results.push({ path: currentPath, node, matchType: 'type' })
          }
        }

        if (node.type === 'folder' && node.children) {
          traverse(node.children, currentPath)
        }
      })
    }

    traverse(this.tree)
    return results
  }

  filter(predicate: (node: FileNode, path: string) => boolean): SearchResult[] {
    const results: SearchResult[] = []

    const traverse = (nodes: FileNode[], path: string = '') => {
      nodes.forEach(node => {
        const currentPath = path ? `${path}/${node.name}` : `/${node.name}`

        if (predicate(node, currentPath)) {
          results.push({ path: currentPath, node, matchType: 'name' })
        }

        if (node.type === 'folder' && node.children) {
          traverse(node.children, currentPath)
        }
      })
    }

    traverse(this.tree)
    return results
  }

  // ========================================================================
  // READ OPERATIONS
  // ========================================================================

  findNode(path: string): FileNode | null {
    if (this.cache.has(path)) {
      return this.cache.get(path) || null
    }

    const parts = path.split('/').filter(Boolean)
    if (parts.length === 0) return null

    const traverse = (nodes: FileNode[], remaining: string[]): FileNode | null => {
      if (remaining.length === 0) return null
      const [current, ...rest] = remaining
      const node = nodes.find(n => n.name === current)
      if (!node) return null
      if (rest.length === 0) return node
      if (node.type === 'folder' && node.children) {
        return traverse(node.children, rest)
      }
      return null
    }

    const result = traverse(this.tree, parts)
    this.cache.set(path, result)
    return result
  }

  getFileContent(path: string): string | null {
    const node = this.findNode(path)
    return node && node.type === 'file' ? (node.content || null) : null
  }

  getFolderChildren(path: string): FileNode[] | null {
    const node = this.findNode(path)
    return node && node.type === 'folder' ? (node.children || []) : null
  }

  listFilesRecursive(path: string = '/'): SearchResult[] {
    const parentNode = path === '/' ? null : this.findNode(path)
    const nodes = path === '/' ? this.tree : parentNode?.children

    if (!nodes) return []

    const results: SearchResult[] = []
    const traverse = (nodeList: FileNode[], currentPath: string) => {
      nodeList.forEach(node => {
        const nodePath = currentPath === '/' 
          ? `/${node.name}` 
          : `${currentPath}/${node.name}`
        results.push({ path: nodePath, node, matchType: 'name' })
        if (node.type === 'folder' && node.children) {
          traverse(node.children, nodePath)
        }
      })
    }
    traverse(nodes, path === '/' ? '' : path)
    return results
  }

  // ========================================================================
  // WRITE OPERATIONS
  // ========================================================================

  createFile(path: string, content: string = '', metadata?: Partial<FileNode>): FileNode {
    const parts = path.split('/').filter(Boolean)
    const fileName = parts.pop()

    if (!fileName || !this.validateName(fileName)) {
      throw new Error(`Invalid file name: ${fileName}`)
    }
    if (!this.validateSize(content)) {
      throw new Error(`File size exceeds limit: ${MAX_FILE_SIZE} bytes`)
    }

    const newNode: FileNode = {
      name: fileName,
      type: 'file',
      content,
      isModified: false,
      createdAt: Date.now(),
      modifiedAt: Date.now(),
      ...metadata,
    }

    const parentPath = parts.length === 0 ? '/' : '/' + parts.join('/')
    this.createNode(parentPath, newNode)

    const event: VFSEvent = {
      type: 'create',
      path: path,
      timestamp: Date.now(),
      newValue: newNode,
      source: 'user',
    }

    this.recordHistory(event)
    this.notify(event)

    return newNode
  }

  createFolder(path: string, metadata?: Partial<FileNode>): FileNode {
    const parts = path.split('/').filter(Boolean)
    const folderName = parts.pop()

    if (!folderName || !this.validateName(folderName)) {
      throw new Error(`Invalid folder name: ${folderName}`)
    }

    const newNode: FileNode = {
      name: folderName,
      type: 'folder',
      children: [],
      isOpen: false,
      createdAt: Date.now(),
      modifiedAt: Date.now(),
      ...metadata,
    }

    const parentPath = parts.length === 0 ? '/' : '/' + parts.join('/')
    this.createNode(parentPath, newNode)

    const event: VFSEvent = {
      type: 'create',
      path: path,
      timestamp: Date.now(),
      newValue: newNode,
      source: 'user',
    }

    this.recordHistory(event)
    this.notify(event)

    return newNode
  }

  private createNode(parentPath: string, newNode: FileNode) {
    if (parentPath === '/' || parentPath === '') {
      if (this.tree.some(n => n.name === newNode.name)) {
        throw new Error(`File already exists: ${newNode.name}`)
      }
      this.runValidators(parentPath, newNode)
      this.tree = [...this.tree, newNode].sort((a, b) =>
        a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'folder' ? -1 : 1
      )
    } else {
      const parts = parentPath.split('/').filter(Boolean)
      this.tree = this.recursiveAdd(this.tree, parts, newNode)
    }
    this.save()
  }

  private recursiveAdd(nodes: FileNode[], parts: string[], newNode: FileNode): FileNode[] {
    const [current, ...rest] = parts
    return nodes.map(node => {
      if (node.name === current && node.type === 'folder') {
        if (rest.length === 0) {
          const children = node.children || []
          if (children.some(c => c.name === newNode.name)) {
            throw new Error(`Entry already exists: ${newNode.name}`)
          }
          this.runValidators(`/${current}/${newNode.name}`, newNode)
          return {
            ...node,
            children: [...children, newNode].sort((a, b) =>
              a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'folder' ? -1 : 1
            ),
            modifiedAt: Date.now(),
          }
        }
        return {
          ...node,
          children: this.recursiveAdd(node.children || [], rest, newNode),
        }
      }
      return node
    })
  }

  updateFile(path: string, content: string): void {
    if (!this.validateSize(content)) {
      throw new Error(`File size exceeds limit: ${MAX_FILE_SIZE} bytes`)
    }

    const parts = path.split('/').filter(Boolean)
    const previousContent = this.getFileContent(path)

    this.tree = this.recursiveUpdate(this.tree, parts, content)
    this.save()
    this.invalidateCache(path)

    const event: VFSEvent = {
      type: 'update',
      path,
      timestamp: Date.now(),
      previousValue: previousContent,
      newValue: content,
      source: 'user',
    }

    this.recordHistory(event)
    this.notify(event)
  }

  private recursiveUpdate(nodes: FileNode[], parts: string[], content: string): FileNode[] {
    const [current, ...rest] = parts
    return nodes.map(node => {
      if (node.name === current) {
        if (rest.length === 0) {
          return {
            ...node,
            content,
            isModified: false,
            modifiedAt: Date.now(),
          }
        }
        return {
          ...node,
          children: this.recursiveUpdate(node.children || [], rest, content),
        }
      }
      return node
    })
  }

  deleteNode(path: string): void {
    const parts = path.split('/').filter(Boolean)
    const targetName = parts.pop()

    if (!targetName) return

    const previousNode = this.findNode(path)

    if (parts.length === 0) {
      this.tree = this.tree.filter(n => n.name !== targetName)
    } else {
      this.tree = this.recursiveDelete(this.tree, parts, targetName)
    }

    this.save()
    this.invalidateCache(path)

    const event: VFSEvent = {
      type: 'delete',
      path,
      timestamp: Date.now(),
      previousValue: previousNode,
      source: 'user',
    }

    this.recordHistory(event)
    this.notify(event)
  }

  private recursiveDelete(nodes: FileNode[], parts: string[], targetName: string): FileNode[] {
    const [current, ...rest] = parts
    return nodes.map(node => {
      if (node.name === current && node.type === 'folder') {
        if (rest.length === 0) {
          return {
            ...node,
            children: node.children?.filter(c => c.name !== targetName),
            modifiedAt: Date.now(),
          }
        }
        return {
          ...node,
          children: this.recursiveDelete(node.children || [], rest, targetName),
        }
      }
      return node
    })
  }

  renameNode(path: string, newName: string): void {
    if (!this.validateName(newName)) {
      throw new Error(`Invalid name: ${newName}`)
    }

    const parts = path.split('/').filter(Boolean)
    const targetName = parts.pop()

    if (!targetName || targetName === newName) return

    const previousNode = this.findNode(path)

    this.tree = this.recursiveRename(this.tree, parts, targetName, newName)
    this.save()
    this.invalidateCache(path)

    const event: VFSEvent = {
      type: 'rename',
      path,
      timestamp: Date.now(),
      previousValue: { ...previousNode, name: targetName },
      newValue: { ...previousNode, name: newName },
      source: 'user',
    }

    this.recordHistory(event)
    this.notify(event)
  }

  private recursiveRename(
    nodes: FileNode[],
    parts: string[],
    targetName: string,
    newName: string
  ): FileNode[] {
    if (parts.length === 0) {
      if (nodes.some(n => n.name === newName && n.name !== targetName)) {
        throw new Error(`Name already exists: ${newName}`)
      }
      return nodes
        .map(node => (node.name === targetName ? { ...node, name: newName, modifiedAt: Date.now() } : node))
        .sort((a, b) =>
          a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'folder' ? -1 : 1
        )
    }

    const [current, ...rest] = parts
    return nodes.map(node => {
      if (node.name === current && node.type === 'folder') {
        return {
          ...node,
          children: this.recursiveRename(node.children || [], rest, targetName, newName),
        }
      }
      return node
    })
  }

  moveNode(sourcePath: string, destinationPath: string): void {
    const node = this.findNode(sourcePath)
    if (!node) throw new Error(`Source not found: ${sourcePath}`)

    this.deleteNode(sourcePath)
    const destPath = destinationPath === '/' ? '/' : destinationPath
    this.createNode(destPath, JSON.parse(JSON.stringify(node)))

    const event: VFSEvent = {
      type: 'move',
      path: `${sourcePath} → ${destinationPath}`,
      timestamp: Date.now(),
      previousValue: sourcePath,
      newValue: destinationPath,
      source: 'user',
    }

    this.recordHistory(event)
    this.notify(event)
  }

  duplicateNode(path: string, newName?: string): void {
    const nodeToCopy = this.findNode(path)
    if (!nodeToCopy) throw new Error(`Source not found: ${path}`)

    const parts = path.split('/').filter(Boolean)
    const targetName = parts.pop()!
    const parentPath = parts.length === 0 ? '/' : '/' + parts.join('/')

    const nameParts = targetName.split('.')
    const ext = nameParts.length > 1 ? nameParts.pop() : ''
    const base = nameParts.join('.')
    const copyName =
      newName ||
      `${base}_copy${ext ? '.' + ext : ''}`.replace(/\.copy\./, '_copy.')

    const copyNode = JSON.parse(JSON.stringify(nodeToCopy))
    copyNode.name = copyName
    copyNode.createdAt = Date.now()
    copyNode.modifiedAt = Date.now()

    this.createNode(parentPath, copyNode)

    const event: VFSEvent = {
      type: 'duplicate',
      path: `${path} → ${parentPath}/${copyName}`,
      timestamp: Date.now(),
      previousValue: path,
      newValue: copyNode,
      source: 'user',
    }

    this.recordHistory(event)
    this.notify(event)
  }

  toggleFolder(path: string): void {
    const parts = path.split('/').filter(Boolean)
    const node = this.findNode(path)
    const previousState = node?.isOpen

    this.tree = this.recursiveToggle(this.tree, parts)
    this.save()
    this.invalidateCache(path)

    const event: VFSEvent = {
      type: 'toggle',
      path,
      timestamp: Date.now(),
      previousValue: previousState,
      newValue: !previousState,
      source: 'user',
    }

    this.notify(event)
  }

  private recursiveToggle(nodes: FileNode[], parts: string[]): FileNode[] {
    const [current, ...rest] = parts
    return nodes.map(node => {
      if (node.name === current && node.type === 'folder') {
        if (rest.length === 0) {
          return { ...node, isOpen: !node.isOpen }
        }
        return {
          ...node,
          children: this.recursiveToggle(node.children || [], rest),
        }
      }
      return node
    })
  }

  // ========================================================================
  // BATCH OPERATIONS
  // ========================================================================

  createMultiple(files: Array<{ path: string; content?: string }>): FileNode[] {
    const created: FileNode[] = []
    for (const file of files) {
      try {
        const node = this.createFile(file.path, file.content)
        created.push(node)
      } catch (error) {
        observabilityService.log(
          `VFS: Failed to create ${file.path}: ${error}`,
          'error',
          {},
          2,
          'VirtualFileSystem'
        )
      }
    }
    return created
  }

  deleteMultiple(paths: string[]): void {
    for (const path of paths) {
      try {
        this.deleteNode(path)
      } catch (error) {
        observabilityService.log(
          `VFS: Failed to delete ${path}: ${error}`,
          'error',
          {},
          2,
          'VirtualFileSystem'
        )
      }
    }
  }

  // ========================================================================
  // IMPORT/EXPORT
  // ========================================================================

  export(): string {
    return JSON.stringify(this.tree, null, 2)
  }

  exportToFile(filename: string = 'vfs_export.json'): void {
    const data = this.export()
    const blob = new Blob([data], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = filename
    link.click()
    URL.revokeObjectURL(url)
  }

  import(json: string): void {
    try {
      const imported = JSON.parse(json)
      if (!Array.isArray(imported)) {
        throw new Error('Invalid VFS format: expected array')
      }
      this.tree = imported
      this.save()
      this.updateStats()

      const event: VFSEvent = {
        type: 'reset',
        path: '/',
        timestamp: Date.now(),
        source: 'system',
      }

      this.notify(event)
      observabilityService.log(
        'VFS: Imported successfully',
        'success',
        { files: this.tree.length },
        1,
        'VirtualFileSystem'
      )
    } catch (error) {
      observabilityService.log(
        `VFS: Import error: ${error}`,
        'error',
        {},
        3,
        'VirtualFileSystem'
      )
      throw error
    }
  }

  importFromFile(file: File): Promise<void> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = (event) => {
        try {
          const content = event.target?.result as string
          this.import(content)
          resolve()
        } catch (error) {
          reject(error)
        }
      }
      reader.onerror = () => reject(new Error('File read error'))
      reader.readAsText(file)
    })
  }

  // ========================================================================
  // UNDO/REDO
  // ========================================================================

  undo(): boolean {
    if (this.historyIndex <= 0) return false

    this.historyIndex--
    const entry = this.history[this.historyIndex]
    this.tree = JSON.parse(JSON.stringify(entry.state))
    this.save()

    const event: VFSEvent = {
      ...entry.event,
      type: 'change',
      source: 'system',
    }

    this.notify(event)
    return true
  }

  redo(): boolean {
    if (this.historyIndex >= this.history.length - 1) return false

    this.historyIndex++
    const entry = this.history[this.historyIndex]
    this.tree = JSON.parse(JSON.stringify(entry.state))
    this.save()

    const event: VFSEvent = {
      ...entry.event,
      type: 'change',
      source: 'system',
    }

    this.notify(event)
    return true
  }

  canUndo(): boolean {
    return this.historyIndex > 0
  }

  canRedo(): boolean {
    return this.historyIndex < this.history.length - 1
  }

  // ========================================================================
  // UTILITY OPERATIONS
  // ========================================================================

  factoryReset(): void {
    this.tree = JSON.parse(JSON.stringify(PROJECT_FILES))
    this.history = []
    this.historyIndex = -1
    this.cache.clear()
    this.save()
    this.saveHistory()

    const event: VFSEvent = {
      type: 'reset',
      path: '/',
      timestamp: Date.now(),
      source: 'system',
    }

    this.notify(event)
  }

  clearCache(): void {
    this.cache.clear()
  }

  getTreeSize(): number {
    return JSON.stringify(this.tree).length
  }

  getMemoryUsage() {
    return {
      treeSize: this.getTreeSize(),
      cacheSize: this.cache.size,
      historySize: JSON.stringify(this.history).length,
      total:
        this.getTreeSize() +
        this.cache.size +
        JSON.stringify(this.history).length,
    }
  }

  // ========================================================================
  // 10. REACT COMPONENT INTEGRATION
  // ========================================================================

  /**
   * React hook for file system management
   */
  // Note: Using React.useState directly since we imported React
}

export const useVirtualFileSystem = () => {
  const [tree, setTree] = React.useState(() => VirtualFileSystem.getInstance().getTree())
  const [stats, setStats] = React.useState(() => VirtualFileSystem.getInstance().getStats())
  const [canUndo, setCanUndo] = React.useState(VirtualFileSystem.getInstance().canUndo())
  const [canRedo, setCanRedo] = React.useState(VirtualFileSystem.getInstance().canRedo())

  React.useEffect(() => {
    const vfsInstance = VirtualFileSystem.getInstance()
    const unsubscribe = vfsInstance.subscribe((newTree, event) => {
      setTree(newTree)
      setStats(vfsInstance.getStats())
      setCanUndo(vfsInstance.canUndo())
      setCanRedo(vfsInstance.canRedo())
      
      // Auto-log significant events
      if (['create', 'delete', 'update'].includes(event.type)) {
        observabilityService.log(
          `VFS: ${event.type} - ${event.path}`,
          'info',
          {},
          0,
          'VFS'
        )
      }
    })

    return () => unsubscribe()
  }, [])

  const vfsInstance = VirtualFileSystem.getInstance()
  return {
    tree,
    stats,
    canUndo,
    canRedo,
    undo: vfsInstance.undo.bind(vfsInstance),
    redo: vfsInstance.redo.bind(vfsInstance),
    createFile: vfsInstance.createFile.bind(vfsInstance),
    updateFile: vfsInstance.updateFile.bind(vfsInstance),
    deleteNode: vfsInstance.deleteNode.bind(vfsInstance),
    search: vfsInstance.search.bind(vfsInstance),
    export: vfsInstance.export.bind(vfsInstance),
  }
}

export const vfs = VirtualFileSystem.getInstance()
