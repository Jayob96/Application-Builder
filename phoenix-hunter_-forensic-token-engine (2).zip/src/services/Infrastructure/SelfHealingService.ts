
import { vfs } from './VirtualFileSystem';
import { SystemLog } from '../../types';
import { logger } from './observabilityService';

export interface IncidentRecord {
  signature: string; // Hash of the error message/context
  message: string;
  firstSeen: number;
  lastSeen: number;
  count: number;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  sources: string[];
  suggestedFix?: string;
  status: 'ACTIVE' | 'RESOLVED' | 'IGNORED';
}

export interface TroubleshootDatabase {
  version: string;
  lastUpdated: number;
  systemHealth: number; // 0-100
  incidents: Record<string, IncidentRecord>;
  recentEvents: SystemLog[];
}

const DB_PATH = '/logs/troubleshoot_db.json';

class SelfHealingService {
  private static instance: SelfHealingService;
  private db: TroubleshootDatabase;
  private isDirty: boolean = false;

  private constructor() {
    this.db = this.loadDatabase();
    this.setupAutoSave();
    
    // Subscribe to the main logger to ingest events
    logger.subscribe((log) => {
      if (log.type === 'error' || log.type === 'warning') {
        this.ingestLog(log);
      }
    });
  }

  static getInstance(): SelfHealingService {
    if (!this.instance) {
      this.instance = new SelfHealingService();
    }
    return this.instance;
  }

  /**
   * Load DB from VFS or initialize default
   */
  private loadDatabase(): TroubleshootDatabase {
    try {
      const content = vfs.getFileContent(DB_PATH);
      if (content) {
        return JSON.parse(content);
      }
    } catch (e) {
      // Ignore load errors, start fresh
    }

    // Default structure
    return {
      version: '1.0.0',
      lastUpdated: Date.now(),
      systemHealth: 100,
      incidents: {},
      recentEvents: []
    };
  }

  /**
   * Save DB to VFS with robust error handling
   */
  private saveDatabase() {
    if (!this.isDirty) return;
    
    this.db.lastUpdated = Date.now();
    const content = JSON.stringify(this.db, null, 2);

    try {
      // Ensure logs directory exists
      if (!vfs.findNode('/logs')) {
        try {
            vfs.createFolder('/logs');
        } catch (e) {
            // Ignore if folder already exists (race condition)
        }
      }

      // Try to create or update file
      if (vfs.findNode(DB_PATH)) {
        vfs.updateFile(DB_PATH, content);
      } else {
        try {
          vfs.createFile(DB_PATH, content);
        } catch (e: any) {
          // If create fails because it exists, try update
          if (e.message && (e.message.includes('exists') || e.message.includes('already'))) {
            try {
               vfs.updateFile(DB_PATH, content);
            } catch (updateErr) {
               console.warn('[SelfHealing] Update fallback failed:', updateErr);
            }
          } else {
             console.warn('[SelfHealing] Create failed:', e);
          }
        }
      }
      
      this.isDirty = false;
    } catch (e) {
      console.error('Failed to save troubleshoot DB:', e);
    }
  }

  private setupAutoSave() {
    setInterval(() => this.saveDatabase(), 5000);
  }

  /**
   * Ingest a log entry and "learn" from it
   */
  private ingestLog(log: SystemLog) {
    // 1. Update Recent Events (Rolling buffer of 50)
    this.db.recentEvents.unshift(log);
    if (this.db.recentEvents.length > 50) {
      this.db.recentEvents.pop();
    }

    // 2. Generate Signature (Simple categorization)
    // Simplify message to group similar errors (remove dynamic IDs, timestamps)
    const simpleMsg = log.message.replace(/0x[a-fA-F0-9]{10,}/g, '[HASH]').replace(/\d+/g, '[NUM]');
    const signature = `${log.actor}::${simpleMsg}`;

    // 3. Update Incident Knowledge Base
    if (!this.db.incidents[signature]) {
      this.db.incidents[signature] = {
        signature,
        message: log.message,
        firstSeen: log.timestamp,
        lastSeen: log.timestamp,
        count: 1,
        severity: log.severity >= 3 ? 'CRITICAL' : log.severity === 2 ? 'HIGH' : 'MEDIUM',
        sources: [log.actor || 'unknown'],
        status: 'ACTIVE',
        suggestedFix: this.diagnoseFix(log.message, log.actor)
      };
    } else {
      const incident = this.db.incidents[signature];
      incident.lastSeen = log.timestamp;
      incident.count++;
      if (!incident.sources.includes(log.actor || 'unknown')) {
        incident.sources.push(log.actor || 'unknown');
      }
      // Re-open resolved issues if they recur
      if (incident.status === 'RESOLVED') {
        incident.status = 'ACTIVE';
      }
    }

    // 4. Update System Health Score
    this.calculateHealth();
    this.isDirty = true;
  }

  /**
   * Simple Heuristic Learning Model
   * Maps keywords to potential solutions based on common patterns.
   */
  private diagnoseFix(message: string, actor: string = ''): string {
    const msg = message.toLowerCase();
    
    if (msg.includes('429') || msg.includes('quota') || msg.includes('limit')) {
      return 'Rate Limit Hit: Increase interval delay in constants.ts or rotate API keys.';
    }
    if (msg.includes('timeout') || msg.includes('network') || msg.includes('fetch')) {
      return 'Connectivity Issue: Check network connection or increase request timeout.';
    }
    if (msg.includes('json') && msg.includes('parse')) {
      return 'Data Corruption: API returned invalid JSON. Clear cache or check endpoint status.';
    }
    if (msg.includes('unauthorized') || msg.includes('401') || msg.includes('403')) {
      return 'Auth Failure: Verify API Key configuration in .env or settings.';
    }
    if (actor === 'vfs' && msg.includes('space')) {
      return 'Storage Full: Clear old logs or reset VFS.';
    }
    if (msg.includes('entry already exists')) {
      return 'VFS Conflict: SelfHealingService handles file collisions automatically.';
    }
    
    return 'Unknown Issue: Check stack trace in System Logs.';
  }

  private calculateHealth() {
    let score = 100;
    const now = Date.now();
    const oneHour = 3600000;

    Object.values(this.db.incidents).forEach(incident => {
      // Only active issues affect health
      if (incident.status === 'ACTIVE') {
        // Decay impact if old
        const isRecent = (now - incident.lastSeen) < oneHour;
        if (isRecent) {
          if (incident.severity === 'CRITICAL') score -= 20;
          else if (incident.severity === 'HIGH') score -= 10;
          else score -= 2;
        }
      }
    });

    this.db.systemHealth = Math.max(0, Math.min(100, score));
  }

  // --- Public API ---

  public getDatabase(): TroubleshootDatabase {
    return this.db;
  }

  public resolveIncident(signature: string) {
    if (this.db.incidents[signature]) {
      this.db.incidents[signature].status = 'RESOLVED';
      this.calculateHealth();
      this.isDirty = true;
      this.saveDatabase();
    }
  }

  public clearHistory() {
    this.db.incidents = {};
    this.db.recentEvents = [];
    this.db.systemHealth = 100;
    this.isDirty = true;
    this.saveDatabase();
  }

  public forceLearn() {
    // Manually trigger a save to disk
    this.saveDatabase();
  }
}

export const selfHealingService = SelfHealingService.getInstance();
