import { storageService } from './storageService';
import { jupiterClient } from '../TradeExecution/jupiterClient';
import { logger } from './observabilityService';

export interface DiagnosticReport {
  timestamp: string;
  environment: Record<string, string>;
  connectivity: Record<string, string>;
  services: Record<string, string>;
  issues: string[];
}

export class TroubleshootReporter {
  async runDiagnostics(): Promise<DiagnosticReport> {
    const report: DiagnosticReport = {
      timestamp: new Date().toISOString(),
      environment: {},
      connectivity: {},
      services: {},
      issues: []
    };

    // 1. Environment Checks
    const env = (import.meta as any).env || {};
    report.environment = {
      API_KEY: env.API_KEY ? 'Present (Masked)' : 'Missing',
      VITE_JUPITER_API_KEY: env.VITE_JUPITER_API_KEY ? 'Present' : 'Missing (Using Public)',
      VITE_BACKPACK_API_KEY: env.VITE_BACKPACK_API_KEY ? 'Present' : 'Missing',
      VITE_SHEETS_API_KEY: env.VITE_SHEETS_API_KEY ? 'Present' : 'Missing',
    };

    if (report.environment.API_KEY === 'Missing') {
      report.issues.push('CRITICAL: Gemini API Key (API_KEY) is missing. AI analysis will fail.');
    }

    // 2. Service Integrity
    report.services = {
      StorageService: storageService ? 'INITIALIZED' : 'MISSING',
      JupiterClient: jupiterClient ? 'INITIALIZED' : 'MISSING',
      Logger: logger ? 'INITIALIZED' : 'MISSING',
    };

    // 3. Connectivity Checks
    try {
      const start = Date.now();
      const jup = await jupiterClient.getRecent(1);
      const latency = Date.now() - start;
      report.connectivity.JupiterAPI = jup.length >= 0 ? `OK (${latency}ms)` : 'Empty Response';
    } catch (e: any) {
      report.connectivity.JupiterAPI = `FAILED: ${e.message}`;
      report.issues.push(`Jupiter API unreachable: ${e.message}`);
    }

    if (storageService.isConfigured()) {
        try {
            const connected = await storageService.testConnection();
            report.connectivity.GoogleSheets = connected ? 'OK' : 'FAILED';
            if (!connected) report.issues.push('Google Sheets configured but connection failed.');
        } catch (e: any) {
            report.connectivity.GoogleSheets = `ERROR: ${e.message}`;
        }
    } else {
        report.connectivity.GoogleSheets = 'Skipped (Not Configured)';
    }

    // 4. Runtime Environment
    if (typeof window !== 'undefined') {
        const w = window as any;
        if (!w.Buffer) report.issues.push('Polyfill Warning: window.Buffer is undefined. Transaction signing may fail.');
        if (!w.process) report.issues.push('Polyfill Warning: window.process is undefined.');
    }

    return report;
  }
}

export const troubleshootReporter = new TroubleshootReporter();