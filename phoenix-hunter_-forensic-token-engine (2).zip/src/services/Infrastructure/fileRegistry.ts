import { INITIAL_WEIGHTS, THRESHOLDS, FEATURES } from './constants';
import { ScoringWeights, EvolutionReport, TokenMetadata, AnalysisResult } from '../../types';
import { logger } from './observabilityService';

/**
 * Virtual File System Node
 * Represents files and folders in the Phoenix Hunter workspace
 */
export interface FileNode {
  name: string;
  type: 'file' | 'folder';
  content?: string;
  children?: FileNode[];
  isOpen?: boolean;
  isModified?: boolean;
  createdAt?: number;
  modifiedAt?: number;
  size?: number;
  tags?: string[];
  description?: string;
  readOnly?: boolean;
  mimeType?: string;
}

/**
 * System Configuration Schema
 */
export interface SystemConfig {
  systemName: string;
  version: string;
  bootMessage: string;
  weights: ScoringWeights;
  thresholds: typeof THRESHOLDS;
  features: typeof FEATURES;
  apiKeys?: {
    gemini?: string;
    jupiter?: string;
    dexscreener?: string;
    sheets?: string;
  };
  walletConfig?: {
    publicKey?: string;
    rpcEndpoint?: string;
    commitment?: string;
  };
  evolutionConfig?: {
    enabled: boolean;
    minSamples: number;
    maxWeightChange: number;
    evolutionInterval: number;
  };
  loggingConfig?: {
    level: 'debug' | 'info' | 'warning' | 'error';
    maxLogs: number;
    persistLogs: boolean;
  };
}

/**
 * Default System Configuration
 */
const DEFAULT_CONFIG: SystemConfig = {
  systemName: "Phoenix Hunter",
  version: "2.0.0",
  bootMessage: "🔥 Initializing Neural Core...",
  weights: { ...INITIAL_WEIGHTS },
  thresholds: { ...THRESHOLDS },
  features: { ...FEATURES },
  evolutionConfig: {
    enabled: false,
    minSamples: 20,
    maxWeightChange: 0.3,
    evolutionInterval: 3600000, // 1 hour
  },
  loggingConfig: {
    level: 'info',
    maxLogs: 1000,
    persistLogs: true,
  },
};

// ==================== PYTHON SCRIPTS ====================

/**
 * ML Calibration Script - Analyzes live token data and suggests weight adjustments
 */
const ML_CALIBRATE_PY = `#!/usr/bin/env python3
"""
Phoenix Hunter - ML Calibration Engine
Analyzes live ingestion data and suggests forensic weight adjustments
"""

import phx_vfs
import json
import statistics
from datetime import datetime


def load_token_data():
    """Load and parse token data from test.csv"""
    data = phx_vfs.read("/data/test.csv")
    
    if not data:
        print("[ERR] test.csv is empty or missing.")
        return None
    
    lines = data.strip().split("\\n")
    if len(lines) < 2:
        print("[ML_CORE] Waiting for more token samples...")
        return None
    
    # Parse CSV
    headers = lines[0].split(",")
    samples = []
    
    for line in lines[1:]:
        values = line.split(",")
        if len(values) == len(headers):
            samples.append(dict(zip(headers, values)))
    
    return samples


def analyze_performance(samples):
    """Analyze token performance metrics"""
    print(f"\\n[ML_CORE] Analyzing {len(samples)} token samples...")
    print("=" * 50)
    
    # Extract numeric metrics
    liquidity_values = []
    rug_prob_values = []
    forensic_scores = []
    
    for sample in samples:
        try:
            liquidity_values.append(float(sample.get('Liquidity', 0)))
            rug_prob_values.append(float(sample.get('RugProb', 0)))
            forensic_scores.append(float(sample.get('ForensicScore', 0)))
        except ValueError:
            continue
    
    if not liquidity_values:
        print("[ERR] No valid numeric data found.")
        return None
    
    # Calculate statistics
    stats = {
        'avg_liquidity': statistics.mean(liquidity_values),
        'median_liquidity': statistics.median(liquidity_values),
        'avg_rug_prob': statistics.mean(rug_prob_values),
        'avg_forensic_score': statistics.mean(forensic_scores),
        'total_samples': len(samples),
        'high_risk_count': sum(1 for r in rug_prob_values if r > 0.5),
        'low_liquidity_count': sum(1 for l in liquidity_values if l < 10000),
    }
    
    # Print metrics
    print(f"📊 Total Samples: {stats['total_samples']}")
    print(f"💰 Avg Liquidity: \${stats['avg_liquidity']:,.0f}")
    print(f"💰 Median Liquidity: \${stats['median_liquidity']:,.0f}")
    print(f"⚠️  Avg Rug Probability: {stats['avg_rug_prob']:.2%}")
    print(f"🎯 Avg Forensic Score: {stats['avg_forensic_score']:.1f}")
    print(f"🚨 High Risk Tokens: {stats['high_risk_count']}")
    print(f"📉 Low Liquidity Tokens: {stats['low_liquidity_count']}")
    
    return stats


def suggest_weight_adjustments(stats):
    """Suggest weight adjustments based on performance data"""
    print("\\n[ML_CORE] Computing weight adjustments...")
    print("-" * 50)
    
    adjustments = {}
    reasoning = []
    
    # Liquidity Depth Adjustment
    if stats['avg_liquidity'] < 15000:
        adjustments['liquidityDepth'] = 0.20
        reasoning.append("⬆️ Increased liquidityDepth (low avg liquidity detected)")
    elif stats['median_liquidity'] > 50000:
        adjustments['liquidityDepth'] = 0.12
        reasoning.append("⬇️ Decreased liquidityDepth (high avg liquidity)")
    
    # Rug Risk Adjustment
    if stats['avg_rug_prob'] > 0.4:
        adjustments['mintAuthority'] = 0.15
        adjustments['freezeAuthority'] = 0.15
        adjustments['taxForensics'] = 0.10
        reasoning.append("⬆️ Increased security filters (high rug risk detected)")
    elif stats['avg_rug_prob'] < 0.2:
        adjustments['socialMomentum'] = 0.15
        reasoning.append("⬆️ Increased socialMomentum (low rug environment)")
    
    # High Risk Token Adjustment
    if stats['high_risk_count'] > stats['total_samples'] * 0.5:
        adjustments['devReputation'] = 0.20
        reasoning.append("⬆️ Increased devReputation (many high-risk tokens)")
    
    # Low Liquidity Adjustment
    if stats['low_liquidity_count'] > stats['total_samples'] * 0.3:
        adjustments['liquidityLock'] = 0.18
        reasoning.append("⬆️ Increased liquidityLock (many low-liq tokens)")
    
    return adjustments, reasoning


def save_calibration_report(stats, adjustments, reasoning):
    """Save calibration report to VFS"""
    report = {
        'timestamp': datetime.now().isoformat(),
        'statistics': stats,
        'suggested_weights': adjustments,
        'reasoning': reasoning,
        'status': 'COMPLETE'
    }
    
    report_json = json.dumps(report, indent=2)
    phx_vfs.write("/reports/calibration_latest.json", report_json)
    print(f"\\n✅ Calibration report saved to /reports/calibration_latest.json")
    
    return report


def run_calibration():
    """Main calibration sequence"""
    print("\\n" + "=" * 50)
    print("🧬 PHOENIX HUNTER - ML CALIBRATION ENGINE")
    print("=" * 50)
    
    # Load data
    samples = load_token_data()
    if not samples:
        return
    
    # Analyze performance
    stats = analyze_performance(samples)
    if not stats:
        return
    
    # Suggest adjustments
    adjustments, reasoning = suggest_weight_adjustments(stats)
    
    # Print results
    print("\\n🎯 SUGGESTED WEIGHT ADJUSTMENTS:")
    print("-" * 50)
    if adjustments:
        print(json.dumps(adjustments, indent=2))
        print("\\n📋 REASONING:")
        for reason in reasoning:
            print(f"  {reason}")
    else:
        print("✅ Current weights are optimal - no adjustments needed")
    
    # Save report
    save_calibration_report(stats, adjustments, reasoning)
    
    print("\\n[ML_CORE] Calibration sequence complete.")
    print("=" * 50)


if __name__ == "__main__":
    run_calibration()
`;

/**
 * Data Export Script - Export token analysis data to CSV
 */
const EXPORT_DATA_PY = `#!/usr/bin/env python3
"""
Phoenix Hunter - Data Export Utility
Exports token analysis data in various formats
"""

import phx_vfs
import json
from datetime import datetime


def export_to_csv(data, filename):
    """Export data to CSV format"""
    if not data:
        print("[ERR] No data to export")
        return
    
    # Extract headers
    headers = list(data[0].keys())
    csv_lines = [",".join(headers)]
    
    # Add data rows
    for row in data:
        values = [str(row.get(h, "")) for h in headers]
        csv_lines.append(",".join(values))
    
    csv_content = "\\n".join(csv_lines)
    phx_vfs.write(f"/exports/{filename}", csv_content)
    
    print(f"✅ Exported {len(data)} rows to /exports/{filename}")


def export_analysis_results():
    """Export all analysis results"""
    print("\\n📤 Exporting Analysis Results...")
    print("-" * 50)
    
    # Read test data
    test_data = phx_vfs.read("/data/test.csv")
    if test_data:
        lines = test_data.strip().split("\\n")
        print(f"Found {len(lines) - 1} token records")
        
        # Copy to exports
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        phx_vfs.write(f"/exports/tokens_export_{timestamp}.csv", test_data)
        print(f"✅ Exported to /exports/tokens_export_{timestamp}.csv")
    else:
        print("⚠️  No test data found")
    
    print("-" * 50)
    print("Export complete!")


if __name__ == "__main__":
    export_analysis_results()
`;

/**
 * Performance Monitor Script
 */
const PERFORMANCE_MONITOR_PY = `#!/usr/bin/env python3
"""
Phoenix Hunter - Performance Monitor
Real-time monitoring of system metrics
"""

import phx_vfs
import json
import time


def monitor_system():
    """Monitor system performance metrics"""
    print("\\n" + "=" * 50)
    print("📊 PHOENIX HUNTER - PERFORMANCE MONITOR")
    print("=" * 50)
    
    # Read config
    config = phx_vfs.read("/config.json")
    if config:
        config_data = json.loads(config)
        print(f"\\n🔧 System: {config_data.get('systemName', 'Unknown')}")
        print(f"📌 Version: {config_data.get('version', 'Unknown')}")
    
    # Read test data
    test_data = phx_vfs.read("/data/test.csv")
    if test_data:
        lines = test_data.strip().split("\\n")
        token_count = len(lines) - 1
        print(f"\\n📊 Total Tokens Analyzed: {token_count}")
    else:
        print("\\n⚠️  No analysis data found")
    
    # Check evolution reports
    evolution_data = phx_vfs.read("/data/evolution.json")
    if evolution_data:
        evolutions = json.loads(evolution_data)
        print(f"🧬 Evolution Cycles: {len(evolutions)}")
    else:
        print("🧬 Evolution Cycles: 0")
    
    print("\\n" + "=" * 50)
    print("✅ Monitoring complete")


if __name__ == "__main__":
    monitor_system()
`;

// ==================== PROJECT FILE STRUCTURE ====================

/**
 * Default Project File Structure
 */
export const PROJECT_FILES: FileNode[] = [
  {
    name: 'config.json',
    type: 'file',
    content: JSON.stringify(DEFAULT_CONFIG, null, 2),
    createdAt: Date.now(),
    modifiedAt: Date.now(),
    size: JSON.stringify(DEFAULT_CONFIG).length,
    description: 'System configuration file',
    mimeType: 'application/json',
  },
  {
    name: 'scripts',
    type: 'folder',
    isOpen: true,
    createdAt: Date.now(),
    modifiedAt: Date.now(),
    description: 'Python automation scripts',
    children: [
      {
        name: 'ml_calibrate.py',
        type: 'file',
        content: ML_CALIBRATE_PY,
        createdAt: Date.now(),
        modifiedAt: Date.now(),
        size: ML_CALIBRATE_PY.length,
        tags: ['ml', 'calibration', 'weights'],
        description: 'ML-based weight calibration engine',
        mimeType: 'text/x-python',
      },
      {
        name: 'export_data.py',
        type: 'file',
        content: EXPORT_DATA_PY,
        createdAt: Date.now(),
        modifiedAt: Date.now(),
        size: EXPORT_DATA_PY.length,
        tags: ['export', 'data', 'csv'],
        description: 'Data export utility',
        mimeType: 'text/x-python',
      },
      {
        name: 'performance_monitor.py',
        type: 'file',
        content: PERFORMANCE_MONITOR_PY,
        createdAt: Date.now(),
        modifiedAt: Date.now(),
        size: PERFORMANCE_MONITOR_PY.length,
        tags: ['monitoring', 'performance'],
        description: 'System performance monitor',
        mimeType: 'text/x-python',
      },
    ],
  },
  {
    name: 'data',
    type: 'folder',
    isOpen: false,
    createdAt: Date.now(),
    modifiedAt: Date.now(),
    description: 'Data storage directory',
    children: [
      {
        name: 'test.csv',
        type: 'file',
        content: "Timestamp,Token,Symbol,Mint,ForensicScore,RiskLevel,Status,Liquidity,Holders,RugProb,Confidence,ROI\n",
        createdAt: Date.now(),
        modifiedAt: Date.now(),
        size: 100,
        tags: ['data', 'analysis', 'csv'],
        description: 'Token analysis data',
        mimeType: 'text/csv',
      },
      {
        name: 'evolution.json',
        type: 'file',
        content: "[]",
        createdAt: Date.now(),
        modifiedAt: Date.now(),
        size: 2,
        tags: ['evolution', 'history'],
        description: 'Evolution cycle history',
        mimeType: 'application/json',
      },
      {
        name: 'positions.json',
        type: 'file',
        content: "[]",
        createdAt: Date.now(),
        modifiedAt: Date.now(),
        size: 2,
        tags: ['trading', 'positions'],
        description: 'Trading position history',
        mimeType: 'application/json',
      },
    ],
  },
  {
    name: 'reports',
    type: 'folder',
    isOpen: false,
    createdAt: Date.now(),
    modifiedAt: Date.now(),
    description: 'Generated reports and analysis',
    children: [],
  },
  {
    name: 'exports',
    type: 'folder',
    isOpen: false,
    createdAt: Date.now(),
    modifiedAt: Date.now(),
    description: 'Exported data files',
    children: [],
  },
  {
    name: 'logs',
    type: 'folder',
    isOpen: false,
    createdAt: Date.now(),
    modifiedAt: Date.now(),
    description: 'System logs',
    children: [
      {
        name: 'system.log',
        type: 'file',
        content: `[${new Date().toISOString()}] Phoenix Hunter initialized\n`,
        createdAt: Date.now(),
        modifiedAt: Date.now(),
        size: 50,
        description: 'System event log',
        mimeType: 'text/plain',
      },
    ],
  },
  {
    name: 'README.md',
    type: 'file',
    content: `# Phoenix Hunter v2.0

## Virtual File System

This is the Phoenix Hunter virtual file system. It contains:

- **config.json** - System configuration
- **scripts/** - Python automation scripts
- **data/** - Token analysis data storage
- **reports/** - Generated analysis reports
- **exports/** - Exported data files
- **logs/** - System logs

## Scripts

### ml_calibrate.py
Analyzes live token data and suggests forensic weight adjustments based on performance metrics.

Usage: Run from Scripts panel to calibrate weights

### export_data.py
Exports token analysis data to CSV format for external analysis.

### performance_monitor.py
Real-time monitoring of system performance metrics.

## Data Files

### test.csv
Stores analyzed token data for ML calibration and performance tracking.

### evolution.json
History of weight evolution cycles with attribution analysis.

### positions.json
Trading position history with entry/exit data.
`,
    createdAt: Date.now(),
    modifiedAt: Date.now(),
    size: 800,
    description: 'System documentation',
    mimeType: 'text/markdown',
    readOnly: true,
  },
];

// ==================== VFS MANAGEMENT FUNCTIONS ====================

const VFS_STORAGE_KEY = 'phx_vfs_data';
const VFS_VERSION_KEY = 'phx_vfs_version';
const CURRENT_VFS_VERSION = '2.0';

/**
 * Load system configuration from VFS
 */
export const loadSystemConfig = (): SystemConfig => {
  try {
    const savedFiles = localStorage.getItem(VFS_STORAGE_KEY);
    
    if (!savedFiles) {
      logger.log(
        "📁 No saved VFS found - using defaults",
        "info",
        {},
        1,
        "vfsService"
      );
      return DEFAULT_CONFIG;
    }
    
    const root: FileNode[] = JSON.parse(savedFiles);
    const configNode = findFileByPath(root, '/config.json');
    
    if (!configNode || !configNode.content) {
      logger.log(
        "⚠️ config.json not found - using defaults",
        "warning",
        {},
        2,
        "vfsService"
      );
      return DEFAULT_CONFIG;
    }
    
    const config = JSON.parse(configNode.content);
    
    // Merge with defaults to ensure all fields exist
    const mergedConfig: SystemConfig = {
      ...DEFAULT_CONFIG,
      ...config,
      weights: { ...DEFAULT_CONFIG.weights, ...config.weights },
      thresholds: { ...DEFAULT_CONFIG.thresholds, ...config.thresholds },
      features: { ...DEFAULT_CONFIG.features, ...config.features },
    };
    
    logger.log(
      "✅ System config loaded from VFS",
      "success",
      { version: mergedConfig.version },
      1,
      "vfsService"
    );
    
    return mergedConfig;
  } catch (e: any) {
    logger.log(
      `❌ Failed to load config: ${e.message}`,
      "error",
      { error: e },
      3,
      "vfsService"
    );
    return DEFAULT_CONFIG;
  }
};

/**
 * Save system configuration to VFS
 */
export const saveSystemConfig = (config: SystemConfig): boolean => {
  try {
    const savedFiles = localStorage.getItem(VFS_STORAGE_KEY);
    const root: FileNode[] = savedFiles ? JSON.parse(savedFiles) : PROJECT_FILES;
    
    const configNode = findFileByPath(root, '/config.json');
    
    if (configNode) {
      configNode.content = JSON.stringify(config, null, 2);
      configNode.modifiedAt = Date.now();
      configNode.isModified = true;
      configNode.size = configNode.content.length;
    }
    
    localStorage.setItem(VFS_STORAGE_KEY, JSON.stringify(root));
    
    logger.log(
      "💾 System config saved to VFS",
      "success",
      {},
      1,
      "vfsService"
    );
    
    return true;
  } catch (e: any) {
    logger.log(
      `❌ Failed to save config: ${e.message}`,
      "error",
      { error: e },
      3,
      "vfsService"
    );
    return false;
  }
};

/**
 * Load VFS root structure
 */
export const loadVFS = (): FileNode[] => {
  try {
    const savedFiles = localStorage.getItem(VFS_STORAGE_KEY);
    const version = localStorage.getItem(VFS_VERSION_KEY);
    
    if (!savedFiles || version !== CURRENT_VFS_VERSION) {
      logger.log(
        "🔄 Initializing VFS with default structure",
        "info",
        { version: CURRENT_VFS_VERSION },
        1,
        "vfsService"
      );
      
      // Initialize with defaults
      localStorage.setItem(VFS_STORAGE_KEY, JSON.stringify(PROJECT_FILES));
      localStorage.setItem(VFS_VERSION_KEY, CURRENT_VFS_VERSION);
      
      return PROJECT_FILES;
    }
    
    const root = JSON.parse(savedFiles);
    
    logger.log(
      "✅ VFS loaded from storage",
      "success",
      { fileCount: countFiles(root) },
      1,
      "vfsService"
    );
    
    return root;
  } catch (e: any) {
    logger.log(
      `❌ VFS load failed: ${e.message}`,
      "error",
      { error: e },
      3,
      "vfsService"
    );
    return PROJECT_FILES;
  }
};

/**
 * Save VFS to localStorage
 */
export const saveVFS = (root: FileNode[]): boolean => {
  try {
    localStorage.setItem(VFS_STORAGE_KEY, JSON.stringify(root));
    localStorage.setItem(VFS_VERSION_KEY, CURRENT_VFS_VERSION);
    
    logger.log(
      "💾 VFS saved to storage",
      "success",
      { fileCount: countFiles(root) },
      1,
      "vfsService"
    );
    
    return true;
  } catch (e: any) {
    logger.log(
      `❌ VFS save failed: ${e.message}`,
      "error",
      { error: e },
      3,
      "vfsService"
    );
    return false;
  }
};

/**
 * Find file by path
 */
export const findFileByPath = (root: FileNode[], path: string): FileNode | null => {
  const parts = path.split('/').filter(p => p);
  let current: FileNode[] = root;
  
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    const node = current.find(n => n.name === part);
    
    if (!node) return null;
    if (i === parts.length - 1) return node;
    
    if (node.type === 'folder' && node.children) {
      current = node.children;
    } else {
      return null;
    }
  }
  
  return null;
};

/**
 * Write content to file
 */
export const writeFile = (path: string, content: string): boolean => {
  try {
    const root = loadVFS();
    const file = findFileByPath(root, path);
    
    if (!file || file.type !== 'file') {
      logger.log(
        `❌ File not found: ${path}`,
        "error",
        { path },
        3,
        "vfsService"
      );
      return false;
    }
    
    if (file.readOnly) {
      logger.log(
        `❌ File is read-only: ${path}`,
        "error",
        { path },
        3,
        "vfsService"
      );
      return false;
    }
    
    file.content = content;
    file.modifiedAt = Date.now();
    file.isModified = true;
    file.size = content.length;
    
    saveVFS(root);
    
    logger.log(
      `✅ File written: ${path}`,
      "success",
      { path, size: content.length },
      1,
      "vfsService"
    );
    
    return true;
  } catch (e: any) {
    logger.log(
      `❌ Write failed: ${e.message}`,
      "error",
      { path, error: e },
      3,
      "vfsService"
    );
    return false;
  }
};

/**
 * Read file content
 */
export const readFile = (path: string): string | null => {
  try {
    const root = loadVFS();
    const file = findFileByPath(root, path);
    
    if (!file || file.type !== 'file') {
      return null;
    }
    
    return file.content || null;
  } catch (e: any) {
    logger.log(
      `❌ Read failed: ${e.message}`,
      "error",
      { path, error: e },
      3,
      "vfsService"
    );
    return null;
  }
};

/**
 * Append content to file
 */
export const appendFile = (path: string, content: string): boolean => {
  const existing = readFile(path) || '';
  return writeFile(path, existing + content);
};

/**
 * Count total files in tree
 */
const countFiles = (nodes: FileNode[]): number => {
  return nodes.reduce((count, node) => {
    if (node.type === 'file') return count + 1;
    if (node.type === 'folder' && node.children) {
      return count + countFiles(node.children);
    }
    return count;
  }, 0);
};

/**
 * Export VFS as JSON
 */
export const exportVFS = (): string => {
  const root = loadVFS();
  return JSON.stringify(root, null, 2);
};

/**
 * Import VFS from JSON
 */
export const importVFS = (jsonData: string): boolean => {
  try {
    const imported = JSON.parse(jsonData);
    
    if (!Array.isArray(imported)) {
      throw new Error("Invalid VFS format");
    }
    
    localStorage.setItem(VFS_STORAGE_KEY, jsonData);
    localStorage.setItem(VFS_VERSION_KEY, CURRENT_VFS_VERSION);
    
    logger.log(
      "✅ VFS imported successfully",
      "success",
      { fileCount: countFiles(imported) },
      1,
      "vfsService"
    );
    
    return true;
  } catch (e: any) {
    logger.log(
      `❌ VFS import failed: ${e.message}`,
      "error",
      { error: e },
      3,
      "vfsService"
    );
    return false;
  }
};

/**
 * Reset VFS to defaults
 */
export const resetVFS = (): boolean => {
  try {
    localStorage.setItem(VFS_STORAGE_KEY, JSON.stringify(PROJECT_FILES));
    localStorage.setItem(VFS_VERSION_KEY, CURRENT_VFS_VERSION);
    
    logger.log(
      "🔄 VFS reset to defaults",
      "warning",
      {},
      2,
      "vfsService"
    );
    
    return true;
  } catch (e: any) {
    logger.log(
      `❌ VFS reset failed: ${e.message}`,
      "error",
      { error: e },
      3,
      "vfsService"
    );
    return false;
  }
};

// ==================== PYTHON VFS BRIDGE ====================

/**
 * Python VFS Bridge - Provides Python scripts access to VFS
 * This would be exposed via a Python runtime (e.g., Pyodide)
 */
export const phx_vfs = {
  read: (path: string): string | null => readFile(path),
  write: (path: string, content: string): boolean => writeFile(path, content),
  append: (path: string, content: string): boolean => appendFile(path, content),
  exists: (path: string): boolean => findFileByPath(loadVFS(), path) !== null,
  list: (dirPath: string): string[] => {
    const root = loadVFS();
    const dir = findFileByPath(root, dirPath);
    if (dir && dir.type === 'folder' && dir.children) {
      return dir.children.map(c => c.name);
    }
    return [];
  },
};

// Export all
export default {
  DEFAULT_CONFIG,
  PROJECT_FILES,
  loadSystemConfig,
  saveSystemConfig,
  loadVFS,
  saveVFS,
  findFileByPath,
  writeFile,
  readFile,
  appendFile,
  exportVFS,
  importVFS,
  resetVFS,
  phx_vfs,
  ML_CALIBRATE_PY,
  EXPORT_DATA_PY,
  PERFORMANCE_MONITOR_PY,
};
