import { ActiveToken } from "../../types";
import { LoggedTrade } from "../TradeExecution/tradeHistoryService";
import { logger } from "./observabilityService";

const SHEETS_API_BASE = "https://sheets.googleapis.com/v4/spreadsheets";
const USER_AGENT = "Solana-Sentinel-Bot/1.0";
const MIN_SYNC_INTERVAL_MS = 500; // Rate-limit: max 2 writes/second

export class StorageService {
  private static instance: StorageService;
  private spreadsheetId: string;
  private apiKey: string;
  private isReady: boolean = false;
  private lastSyncTime: number = 0;

  private constructor() {
    // Vite environment variables (VITE_ prefix required)
    // Use import.meta.env instead of process.env to avoid "process is not defined" in browser
    const metaEnv = (import.meta as any).env || {};
    // Primary ID provided by the user as a fallback if env is missing
    this.spreadsheetId = metaEnv.VITE_SPREADSHEET_ID || "14aI5fL9PEta31dcz-baVBaUfCbjhZgRbEukipkSSUIQ";
    // Using the user-provided API key from the request
    this.apiKey = metaEnv.VITE_SHEETS_API_KEY || "AIzaSyA8Zh28cW2-NS4gCFRUvDEZZ9DTI7WSsf4";

    if (this.isConfigured()) {
      this.isReady = true;
      logger.log(
        `Cloud Storage Link Established: ID ${this.spreadsheetId.slice(0, 8)}...`,
        "success",
        { configured: true },
        1,
        "storageService"
      );
    } else {
      console.warn(
        `[StorageService] Missing VITE_SPREADSHEET_ID. API Key ${this.apiKey.slice(0, 5)}... active. Cloud sync requires spreadsheet ID.`
      );
    }
  }

  static getInstance(): StorageService {
    if (!this.instance) this.instance = new StorageService();
    return this.instance;
  }

  /**
   * Returns true only if both ID and API Key are configured
   */
  public isConfigured(): boolean {
    return !!(this.spreadsheetId && this.apiKey);
  }

  /**
   * Returns current sync status for UI display
   */
  public getSyncStatus(): {
    isConfigured: boolean;
    isReady: boolean;
    lastSyncTime: number;
    timeSinceLastSync: number;
  } {
    const now = Date.now();
    return {
      isConfigured: this.isConfigured(),
      isReady: this.isReady,
      lastSyncTime: this.lastSyncTime,
      timeSinceLastSync: this.lastSyncTime > 0 ? now - this.lastSyncTime : -1,
    };
  }

  /**
   * Appends a token audit result to the AuditLog sheet
   * Row format: Timestamp | Symbol | Mint | ForensicScore | RiskLevel | Verdict | MarketCap | Liquidity | Reasoning
   */
  async syncTokenAudit(token: ActiveToken): Promise<boolean> {
    if (!this.isConfigured()) return false;

    try {
      const row = [
        new Date().toISOString(),
        token.symbol || "UNKNOWN",
        token.mint || "unknown",
        token.analysis?.forensicScore ?? 0,
        token.analysis?.riskLevel || "N/A",
        token.verdict || "WATCH",
        token.marketCap ?? 0,
        token.liquidity ?? 0,
        token.analysis?.reasoning || "",
      ];

      await this.appendToSheet("AuditLog!A:I", row);
      return true;
    } catch (err: any) {
      logger.log(
        `Token audit sync failed for ${token.symbol}: ${err.message}`,
        "error",
        { mint: token.mint },
        3,
        "storageService"
      );
      return false;
    }
  }

  /**
   * Appends a trade execution result to the TradeLog sheet
   * Row format: Timestamp | Symbol | Side | Price | Quantity | Venue | PnL | TradeId
   */
  async syncTrade(
    trade: LoggedTrade,
    pnl: number
  ): Promise<boolean> {
    if (!this.isConfigured()) return false;

    try {
      const row = [
        new Date(trade.timestamp).toISOString(),
        trade.symbol || "UNKNOWN",
        trade.side || "UNKNOWN",
        trade.price ?? 0,
        trade.quantity ?? 0,
        trade.venue || "UNKNOWN",
        pnl ?? 0,
        trade.id || "unknown",
      ];

      await this.appendToSheet("TradeLog!A:H", row);
      return true;
    } catch (err: any) {
      logger.log(
        `Trade sync failed for ${trade.symbol}: ${err.message}`,
        "error",
        { tradeId: trade.id },
        3,
        "storageService"
      );
      return false;
    }
  }

  /**
   * Low-level append helper using Google Sheets API v4
   * 
   * Includes rate-limiting to prevent quota exhaustion
   */
  private async appendToSheet(range: string, values: any[]): Promise<void> {
    if (!this.isConfigured()) {
      throw new Error("StorageService not configured (missing API key or Spreadsheet ID)");
    }

    // Rate-limiting: enforce minimum interval between writes
    const now = Date.now();
    const timeSinceLastSync = now - this.lastSyncTime;
    if (timeSinceLastSync < MIN_SYNC_INTERVAL_MS) {
      const delayMs = MIN_SYNC_INTERVAL_MS - timeSinceLastSync;
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
    
    // Sanitize values to prevent API errors
    const sanitizedValues = values.map((v) =>
      v === null || v === undefined ? "" : String(v)
    );

    const url = `${SHEETS_API_BASE}/${encodeURIComponent(
      this.spreadsheetId
    )}/values/${encodeURIComponent(range)}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS&key=${this.apiKey}`;

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": USER_AGENT,
      },
      body: JSON.stringify({
        values: [sanitizedValues],
        majorDimension: "ROWS",
      }),
    });

    this.lastSyncTime = Date.now();

    if (!response.ok) {
      let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
      try {
        const errorData = await response.json();
        if (errorData.error?.message) {
          errorMessage = errorData.error.message;
        }
      } catch {
        // If JSON parse fails, use default error message
      }

      throw new Error(errorMessage);
    }

    const sheetName = range.split("!")[0];
    logger.log(
      `Cloud Sync: Row appended to ${sheetName}`,
      "success",
      { range },
      1,
      "storageService"
    );
  }

  /**
   * Utility: Check if Sheets API is responding (no data written, just ping)
   * Useful for diagnostics
   */
  async testConnection(): Promise<boolean> {
    if (!this.isConfigured()) {
      logger.log("StorageService not configured", "error", {}, 2, "storageService");
      return false;
    }

    try {
      const url = `${SHEETS_API_BASE}/${encodeURIComponent(this.spreadsheetId)}?key=${this.apiKey}`;
      const response = await fetch(url, { headers: { "User-Agent": USER_AGENT } });

      if (!response.ok) {
        throw new Error(`API returned ${response.status}: ${response.statusText}`);
      }

      logger.log("Google Sheets API: Connection OK", "success", {}, 1, "storageService");
      return true;
    } catch (err: any) {
      logger.log(
        `Google Sheets API test failed: ${err.message}`,
        "error",
        {},
        3,
        "storageService"
      );
      return false;
    }
  }
}

export const storageService = StorageService.getInstance();