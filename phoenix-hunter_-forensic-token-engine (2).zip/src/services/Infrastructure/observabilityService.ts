import { SystemLog } from "../../types";
import { UI_CONFIG } from "./constants";

/**
 * Log Callback Type
 */
type LogCallback = (log: SystemLog) => void;

/**
 * Log Filter Configuration
 */
export interface LogFilter {
  types?: SystemLog['type'][];
  minSeverity?: number;
  maxSeverity?: number;
  actors?: string[];
  searchTerm?: string;
  startTime?: number;
  endTime?: number;
}

/**
 * Log Statistics
 */
export interface LogStats {
  total: number;
  byType: Record<SystemLog['type'], number>;
  bySeverity: Record<number, number>;
  byActor: Record<string, number>;
  errorRate: number;
  lastError: SystemLog | null;
  uptime: number;
}

/**
 * ObservabilityService - Centralized Logging & Monitoring
 * 
 * Features:
 * - Singleton pattern for global access
 * - Multi-subscriber pub/sub architecture
 * - Structured logging with context
 * - Severity-based filtering
 * - Log persistence and replay
 * - Performance metrics tracking
 * - Error reporting with stack traces
 * - Log export and analysis
 * - Real-time statistics
 */
export class ObservabilityService {
  private static instance: ObservabilityService;
  
  // Subscribers
  private listeners: LogCallback[] = [];
  
  // Log Storage
  private logs: SystemLog[] = [];
  private maxLogs: number = 1000;
  private persistLogs: boolean = true;
  
  // Statistics
  private stats: LogStats = {
    total: 0,
    byType: {
      info: 0,
      warning: 0,
      error: 0,
      success: 0,
      audit: 0,
      trade: 0,
      debug: 0,
    },
    bySeverity: {},
    byActor: {},
    errorRate: 0,
    lastError: null,
    uptime: Date.now(),
  };
  
  // Performance Tracking
  private performanceMarks: Map<string, number> = new Map();
  private performanceMeasures: Array<{
    name: string;
    duration: number;
    timestamp: number;
  }> = [];
  
  // Configuration
  private minLogLevel: SystemLog['type'] = 'debug';
  private minSeverity: number = 1;
  private enableConsoleOutput: boolean = true;
  private enablePerformanceTracking: boolean = true;
  
  // Storage Keys
  private readonly STORAGE_KEY = 'phx_logs';
  private readonly STATS_KEY = 'phx_log_stats';

  private constructor() {
    this.loadPersistedLogs();
    this.startPeriodicCleanup();
  }

  /**
   * Get singleton instance
   */
  static getInstance(): ObservabilityService {
    if (!this.instance) {
      this.instance = new ObservabilityService();
    }
    return this.instance;
  }

  /**
   * Subscribe to log stream
   */
  subscribe(callback: LogCallback): () => void {
    this.listeners.push(callback);
    
    // Return unsubscribe function
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  /**
   * Core logging method with flexible signatures
   */
  log(
    arg1: string,
    type: SystemLog['type'] = 'info',
    arg3?: Record<string, any> | string,
    severity: number = 1,
    actor: string = 'system'
  ): void {
    let message = arg1;
    let context = typeof arg3 === 'object' ? arg3 : {};
    let finalActor = actor;

    // Handle alternate signature: log(source, type, message)
    if (typeof arg3 === 'string') {
      finalActor = arg1; // source becomes actor
      message = arg3;    // arg3 becomes message
    }

    // Check if log should be emitted based on filters
    if (!this.shouldLog(type, severity)) {
      return;
    }

    // Create log entry
    const log: SystemLog = {
      id: this.generateLogId(),
      timestamp: Date.now(),
      message: this.sanitizeMessage(message),
      type,
      context: this.sanitizeContext(context),
      severity,
      actor: finalActor,
    };

    // Store log
    this.storeLogs(log);

    // Update statistics
    this.updateStats(log);

    // Emit to subscribers
    this.emitLog(log);

    // Console output (if enabled)
    if (this.enableConsoleOutput) {
      this.consoleLog(log);
    }

    // Persist to storage (if enabled)
    if (this.persistLogs) {
      this.persistToStorage();
    }
  }

  /**
   * Audit logging for security-sensitive operations
   */
  audit(
    token: string,
    detail: string,
    severity: number = 2,
    additionalContext?: Record<string, any>
  ): void {
    this.log(
      `[AUDIT] ${token}: ${detail}`,
      'audit',
      {
        token,
        detail,
        ...additionalContext,
      },
      severity,
      'forensicNode'
    );
  }

  /**
   * Trade execution logging
   */
  trade(
    token: string,
    action: string,
    price: number,
    severity: number = 3,
    additionalContext?: Record<string, any>
  ): void {
    this.log(
      `[TRADE] ${token} ${action.toUpperCase()} @ $${price.toFixed(6)}`,
      'trade',
      {
        token,
        action,
        price,
        priceFormatted: `$${price.toFixed(6)}`,
        ...additionalContext,
      },
      severity,
      'executionService'
    );
  }

  /**
   * Success logging with custom emoji/prefix
   */
  success(
    message: string,
    context?: Record<string, any>,
    actor: string = 'system'
  ): void {
    this.log(
      `✅ ${message}`,
      'success',
      context,
      1,
      actor
    );
  }

  /**
   * Warning logging
   */
  warning(
    message: string,
    context?: Record<string, any>,
    severity: number = 2,
    actor: string = 'system'
  ): void {
    this.log(
      `⚠️ ${message}`,
      'warning',
      context,
      severity,
      actor
    );
  }

  /**
   * Debug logging (only in debug mode)
   */
  debug(
    message: string,
    context?: Record<string, any>,
    actor: string = 'system'
  ): void {
    if (this.minLogLevel === 'debug') {
      this.log(
        `🔍 ${message}`,
        'debug',
        context,
        1,
        actor
      );
    }
  }

  /**
   * Error reporting with stack trace capture
   */
  reportError(
    error: unknown,
    context: Record<string, any> = {},
    source: string = 'system'
  ): void {
    let message = 'Unknown Error';
    let stack: string | undefined;
    let details: Record<string, any> = { ...context };

    // Parse error object
    if (error instanceof Error) {
      message = error.message;
      stack = error.stack;
      details.name = error.name;
      details.errorType = error.constructor.name;
    } else if (typeof error === 'string') {
      message = error;
    } else if (typeof error === 'object' && error !== null) {
      message = (error as any).message || JSON.stringify(error);
      details.raw = error;
    }

    // Attach stack trace
    if (stack) {
      details.stackTrace = stack;
      details.stackLines = stack.split('\n').slice(0, 10); // First 10 lines
    }

    // Capture current context
    details.timestamp = new Date().toISOString();
    details.userAgent = typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown';
    details.url = typeof window !== 'undefined' ? window.location.href : 'unknown';

    // Log error
    this.log(
      `❌ ${message}`,
      'error',
      details,
      4, // Critical severity
      source
    );

    // Console output for immediate visibility
    console.error(`[PHX-ERROR] ${source}:`, error);
    if (stack) {
      console.error('Stack Trace:', stack);
    }
  }

  /**
   * Performance tracking - Start timer
   */
  startPerformanceMark(name: string): void {
    if (!this.enablePerformanceTracking) return;
    
    this.performanceMarks.set(name, performance.now());
    
    this.debug(
      `Performance mark started: ${name}`,
      { mark: name },
      'performanceMonitor'
    );
  }

  /**
   * Performance tracking - End timer and measure
   */
  endPerformanceMark(name: string, logResult: boolean = true): number | null {
    if (!this.enablePerformanceTracking) return null;
    
    const startTime = this.performanceMarks.get(name);
    
    if (!startTime) {
      this.warning(
        `Performance mark not found: ${name}`,
        { mark: name },
        2,
        'performanceMonitor'
      );
      return null;
    }

    const duration = performance.now() - startTime;
    
    // Store measure
    this.performanceMeasures.push({
      name,
      duration,
      timestamp: Date.now(),
    });

    // Clean up mark
    this.performanceMarks.delete(name);

    // Prune old measures (keep last 100)
    if (this.performanceMeasures.length > 100) {
      this.performanceMeasures = this.performanceMeasures.slice(-100);
    }

    // Log result
    if (logResult) {
      const severity = duration > 5000 ? 3 : duration > 1000 ? 2 : 1;
      this.log(
        `⏱️ ${name}: ${duration.toFixed(2)}ms`,
        duration > 5000 ? 'warning' : 'info',
        { mark: name, duration, durationFormatted: `${duration.toFixed(2)}ms` },
        severity,
        'performanceMonitor'
      );
    }

    return duration;
  }

  /**
   * Get performance statistics
   */
  getPerformanceStats(): Record<string, { avg: number; min: number; max: number; count: number }> {
    const stats: Record<string, { avg: number; min: number; max: number; count: number }> = {};

    this.performanceMeasures.forEach(measure => {
      if (!stats[measure.name]) {
        stats[measure.name] = { avg: 0, min: Infinity, max: 0, count: 0 };
      }

      const stat = stats[measure.name];
      stat.count++;
      stat.min = Math.min(stat.min, measure.duration);
      stat.max = Math.max(stat.max, measure.duration);
      stat.avg = ((stat.avg * (stat.count - 1)) + measure.duration) / stat.count;
    });

    return stats;
  }

  /**
   * Get all logs (with optional filter)
   */
  getLogs(filter?: LogFilter): SystemLog[] {
    let filtered = [...this.logs];

    if (!filter) return filtered;

    // Filter by type
    if (filter.types && filter.types.length > 0) {
      filtered = filtered.filter(log => filter.types!.includes(log.type));
    }

    // Filter by severity
    if (filter.minSeverity !== undefined) {
      filtered = filtered.filter(log => log.severity >= filter.minSeverity!);
    }
    if (filter.maxSeverity !== undefined) {
      filtered = filtered.filter(log => log.severity <= filter.maxSeverity!);
    }

    // Filter by actor
    if (filter.actors && filter.actors.length > 0) {
      filtered = filtered.filter(log => filter.actors!.includes(log.actor));
    }

    // Filter by search term
    if (filter.searchTerm) {
      const term = filter.searchTerm.toLowerCase();
      filtered = filtered.filter(log =>
        log.message.toLowerCase().includes(term) ||
        log.actor.toLowerCase().includes(term) ||
        JSON.stringify(log.context).toLowerCase().includes(term)
      );
    }

    // Filter by time range
    if (filter.startTime) {
      filtered = filtered.filter(log => log.timestamp >= filter.startTime!);
    }
    if (filter.endTime) {
      filtered = filtered.filter(log => log.timestamp <= filter.endTime!);
    }

    return filtered;
  }

  /**
   * Get log statistics
   */
  getStats(): LogStats {
    return {
      ...this.stats,
      uptime: Date.now() - this.stats.uptime,
    };
  }

  /**
   * Clear all logs
   */
  clearLogs(): void {
    this.logs = [];
    
    if (this.persistLogs) {
      try {
        localStorage.removeItem(this.STORAGE_KEY);
      } catch (e) {
        console.warn('Failed to clear persisted logs:', e);
      }
    }

    this.log(
      '🧹 Logs cleared',
      'info',
      { count: this.logs.length },
      1,
      'observabilityService'
    );
  }

  /**
   * Export logs as JSON
   */
  exportLogs(filter?: LogFilter): string {
    const logs = this.getLogs(filter);
    return JSON.stringify(logs, null, 2);
  }

  /**
   * Export logs as CSV
   */
  exportLogsCSV(filter?: LogFilter): string {
    const logs = this.getLogs(filter);
    
    if (logs.length === 0) return '';

    const headers = ['Timestamp', 'Type', 'Severity', 'Actor', 'Message', 'Context'];
    const rows = logs.map(log => [
      new Date(log.timestamp).toISOString(),
      log.type,
      log.severity,
      log.actor,
      log.message.replace(/"/g, '""'), // Escape quotes
      JSON.stringify(log.context).replace(/"/g, '""'),
    ]);

    const csv = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(',')),
    ].join('\n');

    return csv;
  }

  /**
   * Configure service
   */
  configure(options: {
    maxLogs?: number;
    persistLogs?: boolean;
    minLogLevel?: SystemLog['type'];
    minSeverity?: number;
    enableConsoleOutput?: boolean;
    enablePerformanceTracking?: boolean;
  }): void {
    if (options.maxLogs !== undefined) this.maxLogs = options.maxLogs;
    if (options.persistLogs !== undefined) this.persistLogs = options.persistLogs;
    if (options.minLogLevel !== undefined) this.minLogLevel = options.minLogLevel;
    if (options.minSeverity !== undefined) this.minSeverity = options.minSeverity;
    if (options.enableConsoleOutput !== undefined) this.enableConsoleOutput = options.enableConsoleOutput;
    if (options.enablePerformanceTracking !== undefined) this.enablePerformanceTracking = options.enablePerformanceTracking;

    this.log(
      '⚙️ ObservabilityService configured',
      'info',
      options,
      1,
      'observabilityService'
    );
  }

  // ==================== PRIVATE METHODS ====================

  /**
   * Check if log should be emitted
   */
  private shouldLog(type: SystemLog['type'], severity: number): boolean {
    // Check severity threshold
    if (severity < this.minSeverity) return false;

    // Check log level
    const levels: SystemLog['type'][] = ['debug', 'info', 'success', 'warning', 'audit', 'trade', 'error'];
    const currentLevelIndex = levels.indexOf(this.minLogLevel);
    const logLevelIndex = levels.indexOf(type);

    if (logLevelIndex < currentLevelIndex) return false;

    return true;
  }

  /**
   * Generate unique log ID
   */
  private generateLogId(): string {
    return `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Sanitize message (prevent XSS, trim, etc.)
   */
  private sanitizeMessage(message: string): string {
    if (typeof message !== 'string') {
      message = String(message);
    }
    return message.trim().slice(0, 1000); // Max 1000 chars
  }

  /**
   * Sanitize context object
   */
  private sanitizeContext(context: Record<string, any>): Record<string, any> {
    try {
      // Remove circular references
      const seen = new WeakSet();
      return JSON.parse(JSON.stringify(context, (key, value) => {
        if (typeof value === 'object' && value !== null) {
          if (seen.has(value)) {
            return '[Circular]';
          }
          seen.add(value);
        }
        return value;
      }));
    } catch (e) {
      return { error: 'Failed to sanitize context' };
    }
  }

  /**
   * Store log in memory
   */
  private storeLogs(log: SystemLog): void {
    this.logs.push(log);

    // Prune old logs if exceeding max
    if (this.logs.length > this.maxLogs) {
      this.logs = this.logs.slice(-this.maxLogs);
    }
  }

  /**
   * Update statistics
   */
  private updateStats(log: SystemLog): void {
    this.stats.total++;
    this.stats.byType[log.type]++;
    this.stats.bySeverity[log.severity] = (this.stats.bySeverity[log.severity] || 0) + 1;
    this.stats.byActor[log.actor] = (this.stats.byActor[log.actor] || 0) + 1;

    if (log.type === 'error') {
      this.stats.lastError = log;
      this.stats.errorRate = this.stats.byType.error / this.stats.total;
    }
  }

  /**
   * Emit log to all subscribers
   */
  private emitLog(log: SystemLog): void {
    this.listeners.forEach(listener => {
      try {
        listener(log);
      } catch (e) {
        console.error('Log listener error:', e);
      }
    });
  }

  /**
   * Console output (formatted)
   */
  private consoleLog(log: SystemLog): void {
    const timestamp = new Date(log.timestamp).toLocaleTimeString();
    const prefix = `[${timestamp}] [${log.type.toUpperCase()}] [${log.actor}]`;

    const style = this.getConsoleStyle(log.type);

    if (log.type === 'error') {
      console.error(prefix, log.message, log.context);
    } else if (log.type === 'warning') {
      console.warn(prefix, log.message, log.context);
    } else {
      console.log(`%c${prefix}`, style, log.message, log.context);
    }
  }

  /**
   * Get console style for log type
   */
  private getConsoleStyle(type: SystemLog['type']): string {
    const styles: Record<SystemLog['type'], string> = {
      info: 'color: #00aaff',
      success: 'color: #00ff88',
      warning: 'color: #ffaa00',
      error: 'color: #ff0055; font-weight: bold',
      audit: 'color: #aa00ff',
      trade: 'color: #00ffaa; font-weight: bold',
      debug: 'color: #888888',
    };
    return styles[type] || '';
  }

  /**
   * Persist logs to localStorage
   */
  private persistToStorage(): void {
    try {
      // Store last 500 logs
      const toStore = this.logs.slice(-500);
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(toStore));
      localStorage.setItem(this.STATS_KEY, JSON.stringify(this.stats));
    } catch (e) {
      console.warn('Failed to persist logs:', e);
    }
  }

  /**
   * Load persisted logs from localStorage
   */
  private loadPersistedLogs(): void {
    if (!this.persistLogs) return;

    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      const storedStats = localStorage.getItem(this.STATS_KEY);

      if (stored) {
        this.logs = JSON.parse(stored);
      }

      if (storedStats) {
        this.stats = JSON.parse(storedStats);
      }
    } catch (e) {
      console.warn('Failed to load persisted logs:', e);
    }
  }

  /**
   * Start periodic cleanup of old logs
   */
  private startPeriodicCleanup(): void {
    setInterval(() => {
      const cutoff = Date.now() - (24 * 60 * 60 * 1000); // 24 hours
      const originalLength = this.logs.length;
      
      this.logs = this.logs.filter(log => log.timestamp > cutoff);

      if (this.logs.length < originalLength) {
        this.debug(
          `Cleaned up ${originalLength - this.logs.length} old logs`,
          { removed: originalLength - this.logs.length },
          'observabilityService'
        );
      }
    }, 60 * 60 * 1000); // Every hour
  }
}

// ==================== EXPORTS ====================

/**
 * Global logger instance
 */
export const logger = ObservabilityService.getInstance();

/**
 * Alias for backwards compatibility
 */
export const observabilityService = logger;

/**
 * Export class for advanced usage
 */
export default ObservabilityService;
