
import { searchByMint } from '../TradeExecution/jupiterClient';
import { scoreJupiterToken } from './jupiterScoring';
import { fetchDexscreenerData, scoreDexscreenerData } from './dexscreenerClient';
import { ForensicEngine } from '../PositionManagement/geminiService';
import { logger } from '../Infrastructure/observabilityService';
import { THRESHOLDS, VALIDATION } from '../Infrastructure/constants';
import { TokenMetadata, AnalysisResult, ScoringWeights } from '../../types';

/**
 * Comprehensive Token Analysis Result
 */
export interface TokenAnalysisResult {
  // Identification
  mint: string;
  symbol: string;
  name: string;
  
  // Scores
  heuristicScore: number;
  jupiterScore: {
    forensicScore: number;
    breakdown: Record<string, number>;
  };
  dexScore: number;
  aiVerdict: AnalysisResult | null;
  finalScore: number;
  
  // Metadata
  liquidity: number;
  marketCap: number;
  holders: number;
  verified: boolean;
  
  // Risk Assessment
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  rugProbability: number;
  confidence: number;
  
  // Recommendations
  recommendation: 'BUY' | 'WATCH' | 'AVOID';
  reasoning: string;
  
  // Timing
  analysisTime: number;
  timestamp: number;
}

/**
 * Analysis Configuration
 */
export interface AnalysisConfig {
  // Score Weights
  jupiterWeight: number;
  dexWeight: number;
  aiWeight: number;
  
  // Thresholds
  minScoreForAI: number;
  minFinalScore: number;
  snipeThreshold: number;
  
  // Timeouts
  maxAnalysisTime: number;
  fetchTimeout: number;
  
  // Features
  enableAIAnalysis: boolean;
  enableDexScreener: boolean;
  requireBothSources: boolean;
}

/**
 * Default Analysis Configuration
 */
const DEFAULT_CONFIG: AnalysisConfig = {
  jupiterWeight: 0.6,
  dexWeight: 0.4,
  aiWeight: 1.0,
  minScoreForAI: 70,
  minFinalScore: THRESHOLDS.MIN_SCORE,
  snipeThreshold: THRESHOLDS.SNIPE_SCORE,
  maxAnalysisTime: 90000, // 90 seconds (increased to allow for retries)
  fetchTimeout: 90000, // 90 seconds (increased to allow for retries)
  enableAIAnalysis: true,
  enableDexScreener: true,
  requireBothSources: false,
};

/**
 * Analyze New Token - Comprehensive Forensic Pipeline
 * 
 * Multi-stage analysis:
 * 1. Parallel data fetching (Jupiter + DexScreener)
 * 2. Heuristic scoring (rule-based)
 * 3. AI analysis (Gemini) if threshold met
 * 4. Final score calculation and recommendation
 * 
 * @param mint - Token mint address
 * @param forensicEngine - ForensicEngine instance for AI analysis
 * @param weights - Optional custom scoring weights
 * @param config - Optional analysis configuration
 * @returns Comprehensive token analysis result
 */
export async function analyzeNewToken(
  mint: string,
  forensicEngine: ForensicEngine,
  weights?: ScoringWeights,
  config: Partial<AnalysisConfig> = {}
): Promise<TokenAnalysisResult | null> {
  const startTime = performance.now();
  const analysisConfig = { ...DEFAULT_CONFIG, ...config };
  
  logger.startPerformanceMark(`analyze_${mint.slice(0, 8)}`);

  try {
    // Validate mint address
    if (!isValidMint(mint)) {
      logger.log(
        `❌ Invalid mint address: ${mint}`,
        'error',
        { mint },
        3,
        'forensicNode'
      );
      return null;
    }

    logger.log(
      `🔍 Starting forensic audit for ${mint.slice(0, 8)}...`,
      'info',
      { mint },
      1,
      'forensicNode'
    );

    // Stage 1: Parallel Data Fetching
    const { dexData, jupiterToken } = await fetchTokenData(
      mint,
      analysisConfig
    );

    // Check if we have minimum required data
    if (!jupiterToken && analysisConfig.requireBothSources) {
      logger.log(
        `⚠️ Audit aborted: Token missing from Jupiter V2`,
        'warning',
        { mint },
        2,
        'forensicNode'
      );
      return null;
    }

    if (!jupiterToken && !dexData) {
      logger.log(
        `⚠️ Audit aborted: No data available from any source`,
        'warning',
        { mint },
        2,
        'forensicNode'
      );
      return null;
    }

    // Stage 2: Heuristic Scoring
    const jupiterScore = jupiterToken 
      ? scoreJupiterToken(jupiterToken)
      : { forensicScore: 0, breakdown: {} };

    const dexScore = analysisConfig.enableDexScreener && dexData
      ? scoreDexscreenerData(dexData)
      : 0;

    // Combined heuristic score
    const heuristicScore = calculateHeuristicScore(
      jupiterScore.forensicScore,
      dexScore,
      analysisConfig
    );

    logger.log(
      `📊 Heuristic analysis complete: ${heuristicScore.toFixed(1)}/100`,
      'info',
      {
        mint,
        heuristicScore,
        jupiterScore: jupiterScore.forensicScore,
        dexScore,
      },
      1,
      'forensicNode'
    );

    // Stage 3: AI Analysis (if threshold met)
    let aiVerdict: AnalysisResult | null = null;
    
    if (
      analysisConfig.enableAIAnalysis &&
      heuristicScore >= analysisConfig.minScoreForAI &&
      jupiterToken
    ) {
      logger.log(
        `🧠 Triggering AI analysis (score: ${heuristicScore.toFixed(1)} >= ${analysisConfig.minScoreForAI})`,
        'info',
        { mint, heuristicScore },
        1,
        'forensicNode'
      );

      try {
        aiVerdict = await analyzeWithAI(
          jupiterToken,
          forensicEngine,
          weights
        );
      } catch (err: any) {
        logger.log(
          `⚠️ AI analysis failed: ${err.message}`,
          'warning',
          { mint, error: err.message },
          2,
          'forensicNode'
        );
        // Continue without AI verdict
      }
    }

    // Stage 4: Final Score Calculation
    const finalScore = calculateFinalScore(
      heuristicScore,
      aiVerdict,
      analysisConfig
    );

    // Stage 5: Risk Assessment
    const { riskLevel, rugProbability, confidence } = assessRisk(
      jupiterScore,
      dexScore,
      aiVerdict
    );

    // Stage 6: Generate Recommendation
    const { recommendation, reasoning } = generateRecommendation(
      finalScore,
      riskLevel,
      rugProbability,
      analysisConfig
    );

    // Calculate analysis time
    const analysisTime = logger.endPerformanceMark(`analyze_${mint.slice(0, 8)}`, false) || 0;

    // Build result
    const result: TokenAnalysisResult = {
      // Identification
      mint,
      symbol: jupiterToken?.symbol || dexData?.baseToken?.symbol || 'UNKNOWN',
      name: jupiterToken?.name || dexData?.baseToken?.name || 'Unknown Token',
      
      // Scores
      heuristicScore,
      jupiterScore,
      dexScore,
      aiVerdict,
      finalScore,
      
      // Metadata
      liquidity: jupiterToken?.liquidity || dexData?.liquidity?.usd || 0,
      marketCap: jupiterToken?.mcap || dexData?.fdv || 0,
      holders: jupiterToken?.holderCount || dexData?.makers?.h24 || 0,
      verified: jupiterToken?.isVerified || false,
      
      // Risk Assessment
      riskLevel,
      rugProbability,
      confidence,
      
      // Recommendations
      recommendation,
      reasoning,
      
      // Timing
      analysisTime,
      timestamp: Date.now(),
    };

    // Log final result
    logAnalysisResult(result);

    return result;
  } catch (error: any) {
    const analysisTime = performance.now() - startTime;
    
    logger.reportError(
      error,
      {
        mint,
        analysisTime: `${analysisTime.toFixed(0)}ms`,
      },
      'forensicNode'
    );

    logger.log(
      `❌ Forensic Pipeline Failure: ${error.message}`,
      'error',
      { mint, error: error.message, stack: error.stack },
      4,
      'forensicNode'
    );

    return null;
  }
}

/**
 * Fetch token data from all sources in parallel
 */
async function fetchTokenData(
  mint: string,
  config: AnalysisConfig
): Promise<{
  dexData: any;
  jupiterToken: any;
}> {
  logger.log(
    `📡 Fetching token data from sources...`,
    'info',
    { mint },
    1,
    'forensicNode'
  );

  const fetchPromises: Promise<any>[] = [];

  // Jupiter (always fetch)
  fetchPromises.push(
    searchByMint(mint).catch(err => {
      logger.log(
        `⚠️ Jupiter fetch failed: ${err.message}`,
        'warning',
        { mint },
        2,
        'forensicNode'
      );
      return null;
    })
  );

  // DexScreener (if enabled)
  if (config.enableDexScreener) {
    fetchPromises.push(
      fetchDexscreenerData(mint).catch(err => {
        logger.log(
          `⚠️ DexScreener fetch failed: ${err.message}`,
          'warning',
          { mint },
          2,
          'forensicNode'
        );
        return null;
      })
    );
  } else {
    fetchPromises.push(Promise.resolve(null));
  }

  // Add timeout
  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(
      () => reject(new Error(`Data fetch timeout after ${config.fetchTimeout}ms`)),
      config.fetchTimeout
    )
  );

  const [jupiterToken, dexData] = await Promise.race([
    Promise.all(fetchPromises),
    timeoutPromise,
  ]) as [any, any];

  logger.log(
    `✅ Data fetch complete`,
    'success',
    {
      mint,
      hasJupiter: !!jupiterToken,
      hasDex: !!dexData,
    },
    1,
    'forensicNode'
  );

  return { dexData, jupiterToken };
}

/**
 * Perform AI analysis using ForensicEngine
 */
async function analyzeWithAI(
  jupiterToken: any,
  forensicEngine: ForensicEngine,
  weights?: ScoringWeights
): Promise<AnalysisResult | null> {
  try {
    // Convert Jupiter token to TokenMetadata format
    const tokenMetadata: TokenMetadata = {
      id: jupiterToken.id,
      mint: jupiterToken.id,
      symbol: jupiterToken.symbol,
      name: jupiterToken.name,
      liquidity: jupiterToken.liquidity || 0,
      marketCap: jupiterToken.mcap || 0,
      holders: jupiterToken.holderCount || 0,
      contractVerified: jupiterToken.isVerified || false,
      discoverySource: 'JUPITER',
      // Add other required fields with defaults
      devHistory: { launches: 1, rugs: 0, avgRoi: 1.0 },
      socialScore: jupiterToken.organicScore || 50,
      launchedAt: Date.now(),
      source: 'JUPITER',
    };

    // Use current weights if not provided
    const scoringWeights = weights || forensicEngine.getWeights();

    // Analyze with AI
    const verdict = await forensicEngine.analyzeToken(
      tokenMetadata,
      scoringWeights
    );

    logger.log(
      `🧠 AI analysis complete: Score ${verdict.forensicScore}/100, Risk ${verdict.riskLevel}`,
      'success',
      {
        mint: jupiterToken.id,
        score: verdict.forensicScore,
        riskLevel: verdict.riskLevel,
        confidence: verdict.confidence,
      },
      1,
      'forensicNode'
    );

    return verdict;
  } catch (err: any) {
    logger.log(
      `❌ AI analysis failed: ${err.message}`,
      'error',
      { error: err.message },
      3,
      'forensicNode'
    );
    return null;
  }
}

/**
 * Calculate combined heuristic score
 */
function calculateHeuristicScore(
  jupiterScore: number,
  dexScore: number,
  config: AnalysisConfig
): number {
  const weighted =
    jupiterScore * config.jupiterWeight +
    dexScore * config.dexWeight;

  return Math.round(weighted);
}

/**
 * Calculate final score (heuristic + AI)
 */
function calculateFinalScore(
  heuristicScore: number,
  aiVerdict: AnalysisResult | null,
  config: AnalysisConfig
): number {
  if (!aiVerdict) {
    return heuristicScore;
  }

  // Blend heuristic and AI scores
  const blended =
    heuristicScore * (1 - config.aiWeight) +
    aiVerdict.forensicScore * config.aiWeight;

  return Math.round(blended);
}

/**
 * Assess overall risk
 */
function assessRisk(
  jupiterScore: { forensicScore: number },
  dexScore: number,
  aiVerdict: AnalysisResult | null
): {
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  rugProbability: number;
  confidence: number;
} {
  // Use AI risk level if available
  if (aiVerdict) {
    return {
      riskLevel: aiVerdict.riskLevel as any,
      rugProbability: aiVerdict.rugProbability,
      confidence: aiVerdict.confidence,
    };
  }

  // Fallback to heuristic risk assessment
  const avgScore = (jupiterScore.forensicScore + dexScore) / 2;
  
  let riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  let rugProbability: number;
  let confidence: number;

  if (avgScore >= 80) {
    riskLevel = 'LOW';
    rugProbability = 0.1;
    confidence = 70;
  } else if (avgScore >= 65) {
    riskLevel = 'MEDIUM';
    rugProbability = 0.3;
    confidence = 60;
  } else if (avgScore >= 45) {
    riskLevel = 'HIGH';
    rugProbability = 0.6;
    confidence = 50;
  } else {
    riskLevel = 'CRITICAL';
    rugProbability = 0.9;
    confidence = 40;
  }

  return { riskLevel, rugProbability, confidence };
}

/**
 * Generate trading recommendation
 */
function generateRecommendation(
  finalScore: number,
  riskLevel: string,
  rugProbability: number,
  config: AnalysisConfig
): {
  recommendation: 'BUY' | 'WATCH' | 'AVOID';
  reasoning: string;
} {
  // Auto-snipe threshold
  if (finalScore >= config.snipeThreshold && riskLevel === 'LOW') {
    return {
      recommendation: 'BUY',
      reasoning: `Excellent score (${finalScore}/100) with low risk. Auto-snipe candidate.`,
    };
  }

  // Buy threshold
  if (finalScore >= config.minFinalScore && rugProbability < 0.4) {
    return {
      recommendation: 'BUY',
      reasoning: `Strong score (${finalScore}/100) with acceptable risk (${(rugProbability * 100).toFixed(0)}%).`,
    };
  }

  // Watch threshold
  if (finalScore >= 50 && rugProbability < 0.6) {
    return {
      recommendation: 'WATCH',
      reasoning: `Moderate score (${finalScore}/100). Monitor for better entry.`,
    };
  }

  // Avoid
  return {
    recommendation: 'AVOID',
    reasoning: `Low score (${finalScore}/100) or high rug risk (${(rugProbability * 100).toFixed(0)}%). Not recommended.`,
  };
}

/**
 * Validate Solana mint address
 */
function isValidMint(mint: string): boolean {
  if (!mint || typeof mint !== 'string') return false;
  if (mint.length !== VALIDATION.MINT_ADDRESS_LENGTH) return false;
  // Basic base58 validation
  return /^[1-9A-HJ-NP-Za-km-z]{44}$/.test(mint);
}

/**
 * Log analysis result
 */
function logAnalysisResult(result: TokenAnalysisResult): void {
  const emoji = result.recommendation === 'BUY' ? '✅' : 
                result.recommendation === 'WATCH' ? '👀' : '❌';

  const color = result.riskLevel === 'LOW' ? 'success' :
                result.riskLevel === 'MEDIUM' ? 'info' :
                result.riskLevel === 'HIGH' ? 'warning' : 'error';

  logger.log(
    `${emoji} Analysis complete: ${result.symbol} | Score: ${result.finalScore}/100 | Risk: ${result.riskLevel} | ${result.recommendation}`,
    color,
    {
      mint: result.mint,
      symbol: result.symbol,
      finalScore: result.finalScore,
      heuristicScore: result.heuristicScore,
      aiScore: result.aiVerdict?.forensicScore,
      riskLevel: result.riskLevel,
      rugProb: `${(result.rugProbability * 100).toFixed(0)}%`,
      recommendation: result.recommendation,
      reasoning: result.reasoning,
      analysisTime: `${result.analysisTime.toFixed(0)}ms`,
      liquidity: `$${result.liquidity.toLocaleString()}`,
      marketCap: `$${result.marketCap.toLocaleString()}`,
    },
    result.recommendation === 'BUY' ? 1 : 2,
    'forensicNode'
  );
}

/**
 * Batch analyze multiple tokens
 */
export async function analyzeBatch(
  mints: string[],
  forensicEngine: ForensicEngine,
  weights?: ScoringWeights,
  config?: Partial<AnalysisConfig>,
  maxConcurrent: number = 5
): Promise<TokenAnalysisResult[]> {
  logger.log(
    `🔍 Starting batch analysis: ${mints.length} tokens`,
    'info',
    { count: mints.length, maxConcurrent },
    1,
    'forensicNode'
  );

  const results: TokenAnalysisResult[] = [];
  
  // Process in batches to avoid overwhelming APIs
  for (let i = 0; i < mints.length; i += maxConcurrent) {
    const batch = mints.slice(i, i + maxConcurrent);
    
    const batchResults = await Promise.all(
      batch.map(mint =>
        analyzeNewToken(mint, forensicEngine, weights, config)
          .catch(err => {
            logger.log(
              `❌ Batch analysis failed for ${mint}: ${err.message}`,
              'error',
              { mint, error: err.message },
              3,
              'forensicNode'
            );
            return null;
          })
      )
    );

    results.push(...batchResults.filter((r): r is TokenAnalysisResult => r !== null));

    // Small delay between batches
    if (i + maxConcurrent < mints.length) {
      await new Promise(r => setTimeout(r, 1000));
    }
  }

  logger.log(
    `✅ Batch analysis complete: ${results.length}/${mints.length} successful`,
    'success',
    { successful: results.length, total: mints.length },
    1,
    'forensicNode'
  );

  return results;
}

export default analyzeNewToken;
