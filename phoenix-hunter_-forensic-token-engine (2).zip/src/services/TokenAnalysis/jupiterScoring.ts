import type { JupiterTokenV2 } from '../TradeExecution/jupiterClient';
import { logger } from '../Infrastructure/observabilityService';

/**
 * Jupiter Forensic Score Result
 */
export interface JupiterForensicScore {
  // Overall Scores
  forensicScore: number;
  rugRisk: number;
  confidenceLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  
  // Analysis
  reasons: string[];
  breakdown: Record<string, number>;
  
  // Metadata
  totalChecks: number;
  passedChecks: number;
  failedChecks: number;
  
  // Recommendations
  recommendation: 'STRONG_BUY' | 'BUY' | 'NEUTRAL' | 'AVOID' | 'STRONG_AVOID';
}

/**
 * Scoring Thresholds
 */
const THRESHOLDS = {
  // Security
  MAX_TOP_HOLDER_PERCENT: 30,
  CRITICAL_TOP_HOLDER_PERCENT: 50,
  
  // Liquidity & Scale
  MIN_HOLDER_COUNT: 100,
  GOOD_HOLDER_COUNT: 1000,
  EXCELLENT_HOLDER_COUNT: 5000,
  
  MIN_LIQUIDITY_USD: 10000,
  GOOD_LIQUIDITY_USD: 50000,
  EXCELLENT_LIQUIDITY_USD: 250000,
  
  // Social & Activity
  MIN_ORGANIC_SCORE: 30,
  GOOD_ORGANIC_SCORE: 50,
  EXCELLENT_ORGANIC_SCORE: 70,
  
  // Trading Activity (24h)
  MIN_TRADERS_24H: 100,
  GOOD_TRADERS_24H: 1000,
  EXCELLENT_TRADERS_24H: 10000,
  
  MIN_NET_BUYERS_24H: 10,
  GOOD_NET_BUYERS_24H: 100,
  
  // Volume
  MIN_VOLUME_24H: 10000,
  GOOD_VOLUME_24H: 100000,
  EXCELLENT_VOLUME_24H: 1000000,
  
  // Price Action
  MAX_NEGATIVE_PRICE_CHANGE_24H: -30, // -30%
  MIN_POSITIVE_PRICE_CHANGE_24H: 5,   // +5%
  
  // Age
  MIN_AGE_HOURS: 1,
  GOOD_AGE_HOURS: 24,
};

/**
 * Score Jupiter Token V2 - Comprehensive Forensic Analysis
 * 
 * Analyzes 15+ dimensions:
 * 1. Mint Authority (critical)
 * 2. Freeze Authority (critical)
 * 3. Holder Concentration (critical)
 * 4. Holder Count & Distribution
 * 5. Liquidity Depth
 * 6. Organic Score
 * 7. Verification Status
 * 8. Trading Activity (24h)
 * 9. Volume Analysis
 * 10. Buy/Sell Pressure
 * 11. Price Action
 * 12. Token Age
 * 13. CEX Listings
 * 14. Market Cap & FDV
 * 15. Organic Buyer Ratio
 * 
 * @param token - Jupiter Token V2 data
 * @returns Comprehensive forensic score with breakdown
 */
export function scoreJupiterToken(token: JupiterTokenV2): JupiterForensicScore {
  const reasons: string[] = [];
  const breakdown: Record<string, number> = {};
  
  let score = 0; // Start at 0, build up
  let rugRisk = 0;
  let totalChecks = 0;
  let passedChecks = 0;
  let failedChecks = 0;

  logger.debug(
    `🔍 Analyzing Jupiter token: ${token.symbol}`,
    { mint: token.id, symbol: token.symbol },
    'jupiterScoring'
  );

  // ==================== CRITICAL SECURITY CHECKS ====================

  // 1. Mint Authority (30 points max)
  totalChecks++;
  if (token.audit.mintAuthorityDisabled) {
    score += 30;
    breakdown['mintAuthority'] = 1.0;
    reasons.push('✅ Mint authority renounced (+30)');
    passedChecks++;
  } else {
    rugRisk += 40;
    breakdown['mintAuthority'] = 0.0;
    reasons.push('🚨 Mint authority active (+40 rug risk)');
    failedChecks++;
  }

  // 2. Freeze Authority (25 points max)
  totalChecks++;
  if (token.audit.freezeAuthorityDisabled) {
    score += 25;
    breakdown['freezeAuthority'] = 1.0;
    reasons.push('✅ Freeze authority renounced (+25)');
    passedChecks++;
  } else {
    rugRisk += 35;
    breakdown['freezeAuthority'] = 0.0;
    reasons.push('🚨 Freeze authority active (+35 rug risk)');
    failedChecks++;
  }

  // 3. Holder Concentration (20 points max)
  totalChecks++;
  const topHolderPct = token.audit.topHoldersPercentage;
  if (topHolderPct < THRESHOLDS.MAX_TOP_HOLDER_PERCENT) {
    score += 20;
    breakdown['holderConcentration'] = 1.0;
    reasons.push(`✅ Low holder concentration: ${topHolderPct.toFixed(1)}% (+20)`);
    passedChecks++;
  } else if (topHolderPct < THRESHOLDS.CRITICAL_TOP_HOLDER_PERCENT) {
    score += 10;
    rugRisk += 15;
    breakdown['holderConcentration'] = 0.5;
    reasons.push(`⚠️ Moderate holder concentration: ${topHolderPct.toFixed(1)}% (+10, +15 risk)`);
  } else {
    rugRisk += 40;
    breakdown['holderConcentration'] = 0.0;
    reasons.push(`🚨 High holder concentration: ${topHolderPct.toFixed(1)}% (+40 rug risk)`);
    failedChecks++;
  }

  // ==================== LIQUIDITY & SCALE ====================

  // 4. Holder Count (10 points max)
  totalChecks++;
  if (token.holderCount >= THRESHOLDS.EXCELLENT_HOLDER_COUNT) {
    score += 10;
    breakdown['holderCount'] = 1.0;
    reasons.push(`✅ Excellent holder count: ${token.holderCount.toLocaleString()} (+10)`);
    passedChecks++;
  } else if (token.holderCount >= THRESHOLDS.GOOD_HOLDER_COUNT) {
    score += 7;
    breakdown['holderCount'] = 0.7;
    reasons.push(`✅ Good holder count: ${token.holderCount.toLocaleString()} (+7)`);
    passedChecks++;
  } else if (token.holderCount >= THRESHOLDS.MIN_HOLDER_COUNT) {
    score += 3;
    breakdown['holderCount'] = 0.3;
    reasons.push(`⚠️ Low holder count: ${token.holderCount.toLocaleString()} (+3)`);
  } else {
    rugRisk += 15;
    breakdown['holderCount'] = 0.0;
    reasons.push(`🚨 Very low holder count: ${token.holderCount.toLocaleString()} (+15 risk)`);
    failedChecks++;
  }

  // 5. Liquidity Depth (15 points max)
  totalChecks++;
  const liquidityUSD = token.liquidity || 0;
  if (liquidityUSD >= THRESHOLDS.EXCELLENT_LIQUIDITY_USD) {
    score += 15;
    breakdown['liquidityDepth'] = 1.0;
    reasons.push(`✅ Excellent liquidity: $${liquidityUSD.toLocaleString()} (+15)`);
    passedChecks++;
  } else if (liquidityUSD >= THRESHOLDS.GOOD_LIQUIDITY_USD) {
    score += 10;
    breakdown['liquidityDepth'] = 0.7;
    reasons.push(`✅ Good liquidity: $${liquidityUSD.toLocaleString()} (+10)`);
    passedChecks++;
  } else if (liquidityUSD >= THRESHOLDS.MIN_LIQUIDITY_USD) {
    score += 5;
    breakdown['liquidityDepth'] = 0.3;
    reasons.push(`⚠️ Low liquidity: $${liquidityUSD.toLocaleString()} (+5)`);
  } else {
    rugRisk += 20;
    breakdown['liquidityDepth'] = 0.0;
    reasons.push(`🚨 Very low liquidity: $${liquidityUSD.toLocaleString()} (+20 risk)`);
    failedChecks++;
  }

  // ==================== SOCIAL & ACTIVITY ====================

  // 6. Organic Score (15 points max)
  totalChecks++;
  const organicScore = token.organicScore || 0;
  if (organicScore >= THRESHOLDS.EXCELLENT_ORGANIC_SCORE) {
    score += 15;
    breakdown['socialMomentum'] = 1.0;
    reasons.push(`✅ Excellent organic score: ${organicScore.toFixed(1)} (+15)`);
    passedChecks++;
  } else if (organicScore >= THRESHOLDS.GOOD_ORGANIC_SCORE) {
    score += 10;
    breakdown['socialMomentum'] = 0.7;
    reasons.push(`✅ Good organic score: ${organicScore.toFixed(1)} (+10)`);
    passedChecks++;
  } else if (organicScore >= THRESHOLDS.MIN_ORGANIC_SCORE) {
    score += 5;
    breakdown['socialMomentum'] = 0.3;
    reasons.push(`⚠️ Low organic score: ${organicScore.toFixed(1)} (+5)`);
  } else {
    rugRisk += 25;
    breakdown['socialMomentum'] = 0.0;
    reasons.push(`🚨 Very low organic score: ${organicScore.toFixed(1)} (+25 risk)`);
    failedChecks++;
  }

  // 7. Verification Status (10 points max)
  totalChecks++;
  if (token.isVerified) {
    score += 10;
    breakdown['verificationStatus'] = 1.0;
    reasons.push('✅ Jupiter verified (+10)');
    passedChecks++;
  } else {
    breakdown['verificationStatus'] = 0.0;
    reasons.push('⚠️ Not verified (0)');
  }

  // ==================== TRADING ACTIVITY (24H) ====================

  const stats24h = token.stats24h;
  
  if (stats24h) {
    // 8. Trader Activity (10 points max)
    totalChecks++;
    if (stats24h.numTraders >= THRESHOLDS.EXCELLENT_TRADERS_24H) {
      score += 10;
      breakdown['traderActivity'] = 1.0;
      reasons.push(`✅ Excellent trader count: ${stats24h.numTraders.toLocaleString()} (+10)`);
      passedChecks++;
    } else if (stats24h.numTraders >= THRESHOLDS.GOOD_TRADERS_24H) {
      score += 7;
      breakdown['traderActivity'] = 0.7;
      reasons.push(`✅ Good trader count: ${stats24h.numTraders.toLocaleString()} (+7)`);
      passedChecks++;
    } else if (stats24h.numTraders >= THRESHOLDS.MIN_TRADERS_24H) {
      score += 3;
      breakdown['traderActivity'] = 0.3;
      reasons.push(`⚠️ Low trader count: ${stats24h.numTraders.toLocaleString()} (+3)`);
    } else {
      breakdown['traderActivity'] = 0.0;
      reasons.push(`⚠️ Very low trader count: ${stats24h.numTraders.toLocaleString()} (0)`);
      failedChecks++;
    }

    // 9. Volume Analysis (10 points max)
    totalChecks++;
    const totalVolume24h = stats24h.buyVolume + stats24h.sellVolume;
    if (totalVolume24h >= THRESHOLDS.EXCELLENT_VOLUME_24H) {
      score += 10;
      breakdown['volume24h'] = 1.0;
      reasons.push(`✅ Excellent volume: $${totalVolume24h.toLocaleString()} (+10)`);
      passedChecks++;
    } else if (totalVolume24h >= THRESHOLDS.GOOD_VOLUME_24H) {
      score += 7;
      breakdown['volume24h'] = 0.7;
      reasons.push(`✅ Good volume: $${totalVolume24h.toLocaleString()} (+7)`);
      passedChecks++;
    } else if (totalVolume24h >= THRESHOLDS.MIN_VOLUME_24H) {
      score += 3;
      breakdown['volume24h'] = 0.3;
      reasons.push(`⚠️ Low volume: $${totalVolume24h.toLocaleString()} (+3)`);
    } else {
      breakdown['volume24h'] = 0.0;
      reasons.push(`⚠️ Very low volume: $${totalVolume24h.toLocaleString()} (0)`);
      failedChecks++;
    }

    // 10. Buy/Sell Pressure (5 points max)
    totalChecks++;
    const buyPressure = stats24h.buyVolume / (stats24h.buyVolume + stats24h.sellVolume);
    if (buyPressure >= 0.55) {
      score += 5;
      breakdown['buyPressure'] = 1.0;
      reasons.push(`✅ Strong buy pressure: ${(buyPressure * 100).toFixed(1)}% (+5)`);
      passedChecks++;
    } else if (buyPressure >= 0.45) {
      score += 2;
      breakdown['buyPressure'] = 0.5;
      reasons.push(`⚠️ Balanced buy/sell: ${(buyPressure * 100).toFixed(1)}% (+2)`);
    } else {
      rugRisk += 10;
      breakdown['buyPressure'] = 0.0;
      reasons.push(`🚨 Sell pressure dominant: ${(buyPressure * 100).toFixed(1)}% (+10 risk)`);
      failedChecks++;
    }

    // 11. Net Buyers (5 points max)
    totalChecks++;
    if (stats24h.numNetBuyers >= THRESHOLDS.GOOD_NET_BUYERS_24H) {
      score += 5;
      breakdown['netBuyers'] = 1.0;
      reasons.push(`✅ Strong net buyers: ${stats24h.numNetBuyers.toLocaleString()} (+5)`);
      passedChecks++;
    } else if (stats24h.numNetBuyers >= THRESHOLDS.MIN_NET_BUYERS_24H) {
      score += 2;
      breakdown['netBuyers'] = 0.5;
      reasons.push(`⚠️ Moderate net buyers: ${stats24h.numNetBuyers.toLocaleString()} (+2)`);
    } else if (stats24h.numNetBuyers < 0) {
      rugRisk += 15;
      breakdown['netBuyers'] = 0.0;
      reasons.push(`🚨 Net sellers: ${stats24h.numNetBuyers.toLocaleString()} (+15 risk)`);
      failedChecks++;
    } else {
      breakdown['netBuyers'] = 0.2;
      reasons.push(`⚠️ Low net buyers: ${stats24h.numNetBuyers.toLocaleString()} (0)`);
    }

    // 12. Price Action (5 points max)
    totalChecks++;
    const priceChange24h = stats24h.priceChange || 0;
    if (priceChange24h >= THRESHOLDS.MIN_POSITIVE_PRICE_CHANGE_24H) {
      score += 5;
      breakdown['priceAction'] = 1.0;
      reasons.push(`✅ Positive price action: +${priceChange24h.toFixed(1)}% (+5)`);
      passedChecks++;
    } else if (priceChange24h <= THRESHOLDS.MAX_NEGATIVE_PRICE_CHANGE_24H) {
      rugRisk += 20;
      breakdown['priceAction'] = 0.0;
      reasons.push(`🚨 Severe price drop: ${priceChange24h.toFixed(1)}% (+20 risk)`);
      failedChecks++;
    } else if (priceChange24h < 0) {
      rugRisk += 5;
      breakdown['priceAction'] = 0.3;
      reasons.push(`⚠️ Negative price action: ${priceChange24h.toFixed(1)}% (+5 risk)`);
    } else {
      breakdown['priceAction'] = 0.5;
      reasons.push(`⚠️ Sideways price action: ${priceChange24h.toFixed(1)}% (0)`);
    }

    // 13. Organic Buyer Ratio (5 points max)
    totalChecks++;
    const organicBuyerRatio = stats24h.numOrganicBuyers / stats24h.numBuys;
    if (organicBuyerRatio >= 0.05) {
      score += 5;
      breakdown['organicBuyerRatio'] = 1.0;
      reasons.push(`✅ High organic buyer ratio: ${(organicBuyerRatio * 100).toFixed(2)}% (+5)`);
      passedChecks++;
    } else if (organicBuyerRatio >= 0.02) {
      score += 2;
      breakdown['organicBuyerRatio'] = 0.5;
      reasons.push(`⚠️ Moderate organic buyer ratio: ${(organicBuyerRatio * 100).toFixed(2)}% (+2)`);
    } else {
      rugRisk += 10;
      breakdown['organicBuyerRatio'] = 0.0;
      reasons.push(`🚨 Low organic buyer ratio: ${(organicBuyerRatio * 100).toFixed(2)}% (+10 risk)`);
      failedChecks++;
    }
  } else {
    // No 24h stats available - neutral scoring
    breakdown['traderActivity'] = 0.5;
    breakdown['volume24h'] = 0.5;
    breakdown['buyPressure'] = 0.5;
    breakdown['netBuyers'] = 0.5;
    breakdown['priceAction'] = 0.5;
    breakdown['organicBuyerRatio'] = 0.5;
    reasons.push('⚠️ No 24h trading stats available');
  }

  // ==================== TOKEN AGE ====================

  // 14. Token Age (5 points max)
  totalChecks++;
  if (token.firstPool?.createdAt) {
    const ageHours = (Date.now() - new Date(token.firstPool.createdAt).getTime()) / 3600000;
    
    if (ageHours >= THRESHOLDS.GOOD_AGE_HOURS) {
      score += 5;
      breakdown['tokenAge'] = 1.0;
      reasons.push(`✅ Mature token: ${Math.floor(ageHours / 24)} days old (+5)`);
      passedChecks++;
    } else if (ageHours >= THRESHOLDS.MIN_AGE_HOURS) {
      score += 2;
      breakdown['tokenAge'] = 0.5;
      reasons.push(`⚠️ Young token: ${Math.floor(ageHours)} hours old (+2)`);
    } else {
      rugRisk += 10;
      breakdown['tokenAge'] = 0.0;
      reasons.push(`🚨 Brand new token: ${Math.floor(ageHours)} hours old (+10 risk)`);
      failedChecks++;
    }
  } else {
    breakdown['tokenAge'] = 0.5;
    reasons.push('⚠️ Token age unknown (0)');
  }

  // ==================== BONUS POINTS ====================

  // 15. CEX Listings (bonus 10 points max)
  if (token.cexes && token.cexes.length > 0) {
    const cexBonus = Math.min(10, token.cexes.length * 2);
    score += cexBonus;
    breakdown['cexListings'] = token.cexes.length / 5; // Normalize to 0-1
    reasons.push(`✅ CEX listings (${token.cexes.length}): ${token.cexes.join(', ')} (+${cexBonus})`);
  } else {
    breakdown['cexListings'] = 0.0;
  }

  // 16. Market Cap Check (bonus 5 points)
  if (token.mcap && token.mcap >= 1000000) {
    score += 5;
    breakdown['marketCap'] = 1.0;
    reasons.push(`✅ Market cap ≥ $1M: $${(token.mcap / 1000000).toFixed(2)}M (+5)`);
  } else {
    breakdown['marketCap'] = 0.0;
  }

  // ==================== FINALIZE SCORES ====================

  // Populate remaining breakdown keys with defaults
  const requiredKeys = [
    'liquidityLock', 'devReputation', 'taxForensics'
  ];
  requiredKeys.forEach(k => {
    if (breakdown[k] === undefined) breakdown[k] = 0.5;
  });

  // Cap scores
  const forensicScore = Math.min(100, Math.max(0, score));
  const finalRugRisk = Math.min(100, Math.max(0, rugRisk));

  // Determine confidence level
  const confidenceLevel: 'LOW' | 'MEDIUM' | 'HIGH' = 
    stats24h ? 'HIGH' : 
    token.holderCount > 100 ? 'MEDIUM' : 'LOW';

  // Generate recommendation
  const recommendation = generateRecommendation(forensicScore, finalRugRisk, passedChecks, totalChecks);

  logger.log(
    `📊 Scoring complete: ${token.symbol} | Score: ${forensicScore}/100 | Rug Risk: ${finalRugRisk}% | ${recommendation}`,
    'info',
    {
      symbol: token.symbol,
      score: forensicScore,
      rugRisk: finalRugRisk,
      passed: passedChecks,
      failed: failedChecks,
      total: totalChecks,
    },
    1,
    'jupiterScoring'
  );

  return {
    forensicScore,
    rugRisk: finalRugRisk,
    confidenceLevel,
    reasons,
    breakdown,
    totalChecks,
    passedChecks,
    failedChecks,
    recommendation,
  };
}

/**
 * Generate trading recommendation
 */
function generateRecommendation(
  score: number,
  rugRisk: number,
  passed: number,
  total: number
): 'STRONG_BUY' | 'BUY' | 'NEUTRAL' | 'AVOID' | 'STRONG_AVOID' {
  const passRate = passed / total;

  // Strong Buy: High score, low risk, high pass rate
  if (score >= 85 && rugRisk <= 20 && passRate >= 0.8) {
    return 'STRONG_BUY';
  }

  // Buy: Good score, acceptable risk
  if (score >= 70 && rugRisk <= 40 && passRate >= 0.6) {
    return 'BUY';
  }

  // Avoid: Low score or high risk
  if (score < 50 || rugRisk >= 60 || passRate < 0.4) {
    return 'AVOID';
  }

  // Strong Avoid: Very low score or very high risk
  if (score < 30 || rugRisk >= 80 || passRate < 0.3) {
    return 'STRONG_AVOID';
  }

  // Neutral: Everything else
  return 'NEUTRAL';
}

/**
 * Batch score multiple tokens
 */
export function batchScoreJupiterTokens(tokens: JupiterTokenV2[]): JupiterForensicScore[] {
  logger.log(
    `📊 Batch scoring ${tokens.length} tokens`,
    'info',
    { count: tokens.length },
    1,
    'jupiterScoring'
  );

  const scores = tokens.map(token => scoreJupiterToken(token));

  // Sort by forensic score (descending)
  scores.sort((a, b) => b.forensicScore - a.forensicScore);

  logger.log(
    `✅ Batch scoring complete`,
    'success',
    {
      count: scores.length,
      avgScore: (scores.reduce((sum, s) => sum + s.forensicScore, 0) / scores.length).toFixed(1),
      topScore: scores[0]?.forensicScore,
    },
    1,
    'jupiterScoring'
  );

  return scores;
}

export default scoreJupiterToken;
