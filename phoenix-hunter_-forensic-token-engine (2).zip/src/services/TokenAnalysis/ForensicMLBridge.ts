import { logger } from '../Infrastructure/observabilityService';
import { TokenMetadata } from '../../types';

/**
 * ML Prediction Result
 */
export interface MLPrediction {
  // Core Predictions
  rugProbability: number;
  confidence: number;
  suggestedAction: 'BUY' | 'HOLD' | 'AVOID';
  
  // Additional Predictions
  expectedROI?: number;
  volatilityScore?: number;
  liquidityRisk?: number;
  
  // Model Info
  modelVersion?: string;
  featuresUsed: string[];
  inferenceTime?: number;
  
  // Explanations
  reasoning?: string;
  keyFactors?: Array<{
    feature: string;
    impact: number;
    direction: 'positive' | 'negative';
  }>;
}

/**
 * ML Request Payload
 */
export interface MLRequestPayload {
  // Token Identification
  mint: string;
  symbol: string;
  name: string;
  
  // Market Data
  liquidity: number;
  marketCap: number;
  volume24h: number;
  priceUSD: number;
  priceChange24h?: number;
  
  // Token Metrics
  holders: number;
  holderConcentration?: number;
  topHolderPercent?: number;
  
  // Security
  is_verified: boolean;
  mintAuthority: boolean;
  freezeAuthority: boolean;
  lpLocked: boolean;
  lpLockDuration?: number;
  
  // Social
  socialScore?: number;
  twitterFollowers?: number;
  telegramMembers?: number;
  
  // Developer
  devWalletHistory?: number;
  previousRugs?: number;
  
  // Time
  age_hours: number;
  
  // Metadata
  timestamp: number;
  source: string;
}

/**
 * ML Service Configuration
 */
export interface MLServiceConfig {
  endpoint: string;
  timeout: number;
  retries: number;
  retryDelay: number;
  apiKey?: string;
  headers?: Record<string, string>;
}

/**
 * ML Service Health Status
 */
export interface MLServiceHealth {
  online: boolean;
  latency: number;
  modelVersion: string;
  lastCheck: number;
  errorRate: number;
  totalRequests: number;
}

/**
 * ForensicMLBridge - ML Model Integration Service
 * 
 * Connects Phoenix Hunter to external ML services:
 * - Custom Python models (FastAPI/Flask)
 * - Cloud ML endpoints (AWS SageMaker, GCP AI Platform)
 * - Local TensorFlow.js models
 * 
 * Features:
 * - Multiple endpoint support
 * - Automatic retry with exponential backoff
 * - Request/response caching
 * - Health monitoring
 * - Fallback predictions
 * - Performance tracking
 * - Error handling and recovery
 */
export class ForensicMLBridge {
  // Configuration
  private static endpoints: Map<string, MLServiceConfig> = new Map();
  private static activeEndpoint: string = 'default';
  
  // Default Configuration
  private static readonly DEFAULT_CONFIG: MLServiceConfig = {
    endpoint: "http://localhost:8000/predict",
    timeout: 10000, // 10 seconds
    retries: 3,
    retryDelay: 1000, // 1 second
  };
  
  // Cache
  private static predictionCache: Map<string, {
    prediction: MLPrediction;
    timestamp: number;
  }> = new Map();
  private static readonly CACHE_TTL = 300000; // 5 minutes
  
  // Health Monitoring
  private static health: Map<string, MLServiceHealth> = new Map();
  
  // Statistics
  private static stats = {
    totalRequests: 0,
    successfulRequests: 0,
    failedRequests: 0,
    cacheHits: 0,
    cacheMisses: 0,
    totalInferenceTime: 0,
    averageInferenceTime: 0,
  };

  /**
   * Initialize ML Bridge with default endpoint
   */
  static initialize(config?: Partial<MLServiceConfig>): void {
    const defaultConfig = { ...this.DEFAULT_CONFIG, ...config };
    this.endpoints.set('default', defaultConfig);
    
    logger.log(
      `🧠 ML Bridge initialized`,
      'info',
      { endpoint: defaultConfig.endpoint },
      1,
      'mlBridge'
    );
  }

  /**
   * Set primary ML endpoint
   */
  static setEndpoint(url: string, config?: Partial<MLServiceConfig>): void {
    const fullConfig: MLServiceConfig = {
      ...this.DEFAULT_CONFIG,
      ...config,
      endpoint: url,
    };
    
    this.endpoints.set('default', fullConfig);
    this.activeEndpoint = 'default';
    
    logger.log(
      `🔗 ML Bridge: Redirected to ${url}`,
      'info',
      { url, timeout: fullConfig.timeout },
      1,
      'mlBridge'
    );
  }

  /**
   * Register multiple ML endpoints (for load balancing/fallback)
   */
  static registerEndpoint(name: string, config: MLServiceConfig): void {
    this.endpoints.set(name, config);
    
    logger.log(
      `📡 ML endpoint registered: ${name}`,
      'info',
      { name, endpoint: config.endpoint },
      1,
      'mlBridge'
    );
  }

  /**
   * Switch active endpoint
   */
  static switchEndpoint(name: string): boolean {
    if (!this.endpoints.has(name)) {
      logger.log(
        `❌ ML endpoint not found: ${name}`,
        'error',
        { name },
        3,
        'mlBridge'
      );
      return false;
    }
    
    this.activeEndpoint = name;
    
    logger.log(
      `🔄 Switched to ML endpoint: ${name}`,
      'info',
      { name },
      1,
      'mlBridge'
    );
    
    return true;
  }

  /**
   * Get neural prediction from ML service
   */
  static async getNeuralPrediction(
    tokenData: TokenMetadata | any,
    useCache: boolean = true
  ): Promise<MLPrediction | null> {
    const startTime = performance.now();
    this.stats.totalRequests++;

    try {
      const cacheKey = this.getCacheKey(tokenData);

      // Check cache
      if (useCache) {
        const cached = this.checkCache(cacheKey);
        if (cached) {
          this.stats.cacheHits++;
          logger.log(
            `💾 ML Cache hit: ${tokenData.symbol || tokenData.mint?.slice(0, 8)}`,
            'info',
            { mint: tokenData.mint },
            1,
            'mlBridge'
          );
          return cached;
        }
        this.stats.cacheMisses++;
      }

      logger.startPerformanceMark(`ml_inference_${cacheKey}`);

      // Prepare request payload
      const payload = this.preparePayload(tokenData);

      // Get prediction with retry
      const prediction = await this.requestWithRetry(payload);

      if (!prediction) {
        this.stats.failedRequests++;
        return null;
      }

      // Update statistics
      const inferenceTime = logger.endPerformanceMark(`ml_inference_${cacheKey}`, false) || 0;
      this.stats.successfulRequests++;
      this.stats.totalInferenceTime += inferenceTime;
      this.stats.averageInferenceTime = this.stats.totalInferenceTime / this.stats.successfulRequests;

      // Cache result
      if (useCache) {
        this.cacheResult(cacheKey, prediction);
      }

      // Update health
      this.updateHealth(this.activeEndpoint, true, inferenceTime);

      // Log result
      logger.log(
        `🧠 ML Inference: ${tokenData.symbol || 'Token'} | Rug: ${(prediction.rugProbability * 100).toFixed(1)}% | Action: ${prediction.suggestedAction}`,
        'audit',
        {
          mint: tokenData.mint,
          rugProb: `${(prediction.rugProbability * 100).toFixed(1)}%`,
          confidence: `${(prediction.confidence * 100).toFixed(1)}%`,
          action: prediction.suggestedAction,
          inferenceTime: `${inferenceTime.toFixed(0)}ms`,
        },
        1,
        'mlBridge'
      );

      return prediction;
    } catch (err: any) {
      this.stats.failedRequests++;
      this.updateHealth(this.activeEndpoint, false, 0);
      
      logger.reportError(
        err,
        {
          mint: tokenData.mint,
          endpoint: this.activeEndpoint,
        },
        'mlBridge'
      );

      logger.log(
        `❌ ML Bridge: Downlink failed - ${err.message}`,
        'warning',
        {
          mint: tokenData.mint,
          error: err.message,
        },
        2,
        'mlBridge'
      );

      return this.getFallbackPrediction(tokenData);
    }
  }

  /**
   * Check ML service health
   */
  static async checkHealth(endpointName?: string): Promise<MLServiceHealth | null> {
    const name = endpointName || this.activeEndpoint;
    const config = this.endpoints.get(name);

    if (!config) {
      logger.log(
        `❌ Endpoint not found: ${name}`,
        'error',
        { name },
        3,
        'mlBridge'
      );
      return null;
    }

    try {
      const startTime = performance.now();
      
      const response = await fetch(`${config.endpoint}/health`, {
        method: 'GET',
        headers: this.buildHeaders(config),
        signal: AbortSignal.timeout(5000), // 5s timeout for health check
      });

      const latency = performance.now() - startTime;

      if (!response.ok) {
        throw new Error(`Health check failed: ${response.status}`);
      }

      const data = await response.json();

      const health: MLServiceHealth = {
        online: true,
        latency,
        modelVersion: data.modelVersion || 'unknown',
        lastCheck: Date.now(),
        errorRate: this.calculateErrorRate(name),
        totalRequests: this.stats.totalRequests,
      };

      this.health.set(name, health);

      logger.log(
        `✅ ML Service healthy: ${name} (${latency.toFixed(0)}ms)`,
        'success',
        { name, latency: `${latency.toFixed(0)}ms`, modelVersion: health.modelVersion },
        1,
        'mlBridge'
      );

      return health;
    } catch (err: any) {
      const health: MLServiceHealth = {
        online: false,
        latency: -1,
        modelVersion: 'unknown',
        lastCheck: Date.now(),
        errorRate: 1.0,
        totalRequests: this.stats.totalRequests,
      };

      this.health.set(name, health);

      logger.log(
        `⚠️ ML Service unhealthy: ${name} - ${err.message}`,
        'warning',
        { name, error: err.message },
        2,
        'mlBridge'
      );

      return health;
    }
  }

  /**
   * Get all registered endpoints
   */
  static getEndpoints(): Array<{ name: string; config: MLServiceConfig; health?: MLServiceHealth }> {
    return Array.from(this.endpoints.entries()).map(([name, config]) => ({
      name,
      config,
      health: this.health.get(name),
    }));
  }

  /**
   * Get bridge statistics
   */
  static getStats() {
    return {
      ...this.stats,
      successRate: this.stats.totalRequests > 0
        ? (this.stats.successfulRequests / this.stats.totalRequests) * 100
        : 0,
      cacheHitRate: (this.stats.cacheHits + this.stats.cacheMisses) > 0
        ? (this.stats.cacheHits / (this.stats.cacheHits + this.stats.cacheMisses)) * 100
        : 0,
    };
  }

  /**
   * Clear prediction cache
   */
  static clearCache(): void {
    this.predictionCache.clear();
    logger.log(
      `🧹 ML prediction cache cleared`,
      'info',
      {},
      1,
      'mlBridge'
    );
  }

  // ==================== PRIVATE METHODS ====================

  /**
   * Prepare ML request payload
   */
  private static preparePayload(tokenData: any): MLRequestPayload {
    const ageHours = tokenData.launchedAt
      ? (Date.now() - tokenData.launchedAt) / 3600000
      : 0;

    return {
      // Token Identification
      mint: tokenData.mint || '',
      symbol: tokenData.symbol || 'UNKNOWN',
      name: tokenData.name || 'Unknown Token',
      
      // Market Data
      liquidity: tokenData.liquidity || 0,
      marketCap: tokenData.marketCap || 0,
      volume24h: tokenData.volume24h || 0,
      priceUSD: tokenData.entry_price || tokenData.priceUSD || 0,
      priceChange24h: tokenData.priceChange24h,
      
      // Token Metrics
      holders: tokenData.holders || 0,
      holderConcentration: tokenData.holderConcentration,
      topHolderPercent: tokenData.topHolderPercent,
      
      // Security
      is_verified: tokenData.contractVerified || false,
      mintAuthority: tokenData.mintAuthority ?? true,
      freezeAuthority: tokenData.freezeAuthority ?? true,
      lpLocked: tokenData.lpLocked || false,
      lpLockDuration: tokenData.lpLockDuration,
      
      // Social
      socialScore: tokenData.socialScore || tokenData.platformQuality,
      twitterFollowers: tokenData.twitterFollowers,
      telegramMembers: tokenData.telegramMembers,
      
      // Developer
      devWalletHistory: tokenData.devHistory?.launches,
      previousRugs: tokenData.devHistory?.rugs,
      
      // Time
      age_hours: ageHours,
      
      // Metadata
      timestamp: Date.now(),
      source: tokenData.discoverySource || 'unknown',
    };
  }

  /**
   * Make ML request with retry logic
   */
  private static async requestWithRetry(
    payload: MLRequestPayload,
    attemptNumber: number = 1
  ): Promise<MLPrediction | null> {
    const config = this.endpoints.get(this.activeEndpoint);
    
    if (!config) {
      throw new Error(`Endpoint not configured: ${this.activeEndpoint}`);
    }

    try {
      const response = await fetch(config.endpoint, {
        method: 'POST',
        headers: this.buildHeaders(config),
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(config.timeout),
      });

      if (!response.ok) {
        throw new Error(`ML Service Error: ${response.status} ${response.statusText}`);
      }

      const prediction = await response.json();

      // Validate prediction
      if (!this.validatePrediction(prediction)) {
        throw new Error('Invalid prediction format from ML service');
      }

      return prediction;
    } catch (err: any) {
      // Retry logic
      if (attemptNumber < config.retries) {
        const delay = config.retryDelay * Math.pow(2, attemptNumber - 1); // Exponential backoff
        
        logger.log(
          `⚠️ ML request failed (attempt ${attemptNumber}/${config.retries}), retrying in ${delay}ms...`,
          'warning',
          { attempt: attemptNumber, error: err.message },
          2,
          'mlBridge'
        );

        await new Promise(r => setTimeout(r, delay));
        return this.requestWithRetry(payload, attemptNumber + 1);
      }

      throw err;
    }
  }

  /**
   * Build request headers
   */
  private static buildHeaders(config: MLServiceConfig): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'User-Agent': 'PhoenixHunter/2.0',
      ...config.headers,
    };

    if (config.apiKey) {
      headers['Authorization'] = `Bearer ${config.apiKey}`;
    }

    return headers;
  }

  /**
   * Validate prediction response
   */
  private static validatePrediction(prediction: any): boolean {
    return (
      typeof prediction.rugProbability === 'number' &&
      typeof prediction.confidence === 'number' &&
      typeof prediction.suggestedAction === 'string' &&
      Array.isArray(prediction.featuresUsed)
    );
  }

  /**
   * Get cache key for token
   */
  private static getCacheKey(tokenData: any): string {
    return `${tokenData.mint}_${Math.floor(Date.now() / this.CACHE_TTL)}`;
  }

  /**
   * Check cache for prediction
   */
  private static checkCache(cacheKey: string): MLPrediction | null {
    const cached = this.predictionCache.get(cacheKey);
    
    if (!cached) return null;

    // Check if cache is still valid
    if (Date.now() - cached.timestamp > this.CACHE_TTL) {
      this.predictionCache.delete(cacheKey);
      return null;
    }

    return cached.prediction;
  }

  /**
   * Cache prediction result
   */
  private static cacheResult(cacheKey: string, prediction: MLPrediction): void {
    this.predictionCache.set(cacheKey, {
      prediction,
      timestamp: Date.now(),
    });

    // Prune old cache entries
    if (this.predictionCache.size > 1000) {
      const oldestKey = this.predictionCache.keys().next().value;
      this.predictionCache.delete(oldestKey);
    }
  }

  /**
   * Update endpoint health
   */
  private static updateHealth(name: string, success: boolean, latency: number): void {
    const existing = this.health.get(name);
    
    const health: MLServiceHealth = {
      online: success,
      latency,
      modelVersion: existing?.modelVersion || 'unknown',
      lastCheck: Date.now(),
      errorRate: this.calculateErrorRate(name),
      totalRequests: this.stats.totalRequests,
    };

    this.health.set(name, health);
  }

  /**
   * Calculate error rate
   */
  private static calculateErrorRate(name: string): number {
    if (this.stats.totalRequests === 0) return 0;
    return this.stats.failedRequests / this.stats.totalRequests;
  }

  /**
   * Get fallback prediction when ML service fails
   */
  private static getFallbackPrediction(tokenData: any): MLPrediction | null {
    logger.log(
      `🔄 Using fallback prediction for ${tokenData.symbol || tokenData.mint?.slice(0, 8)}`,
      'warning',
      { mint: tokenData.mint },
      2,
      'mlBridge'
    );

    // Simple heuristic fallback
    const liquidity = tokenData.liquidity || 0;
    const holders = tokenData.holders || 0;
    const verified = tokenData.contractVerified || false;

    let rugProbability = 0.5; // Default medium risk

    // Adjust based on simple rules
    if (liquidity < 5000) rugProbability += 0.3;
    if (holders < 50) rugProbability += 0.2;
    if (!verified) rugProbability += 0.1;

    rugProbability = Math.min(1.0, rugProbability);

    const suggestedAction: 'BUY' | 'HOLD' | 'AVOID' =
      rugProbability < 0.3 ? 'BUY' :
      rugProbability < 0.6 ? 'HOLD' : 'AVOID';

    return {
      rugProbability,
      confidence: 0.4, // Low confidence for fallback
      suggestedAction,
      featuresUsed: ['liquidity', 'holders', 'verified'],
      reasoning: 'Fallback prediction (ML service unavailable)',
    };
  }
}

// Initialize with default config
ForensicMLBridge.initialize();

export default ForensicMLBridge;
