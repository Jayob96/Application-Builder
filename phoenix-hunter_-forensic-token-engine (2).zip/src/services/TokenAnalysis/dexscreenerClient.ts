
import type { LaunchEvent } from "../../types"
import { observabilityService } from "../Infrastructure/observabilityService"

// ═════════════════════════════════════════════════════════════════════════════
// TYPE DEFINITIONS
// ═════════════════════════════════════════════════════════════════════════════

export interface DexToken {
  address: string
  name: string
  symbol: string
}

export interface DexLiquidity {
  usd: number | null
  base: number | null
  quote: number | null
}

export interface DexVolume {
  h24: number | null
  h6: number | null
  h1: number | null
  m5: number | null
}

export interface DexPriceChange {
  m5: number | null
  h1: number | null
  h6: number | null
  h24: number | null
}

export interface DexPair {
  chainId: string
  dexId: string
  url: string
  pairAddress: string
  baseToken: DexToken
  quoteToken: DexToken
  priceNative: string
  priceUsd: string
  txns?: {
    m5: { buys: number; sells: number }
    h1: { buys: number; sells: number }
    h6: { buys: number; sells: number }
    h24: { buys: number; sells: number }
  }
  volume?: DexVolume
  priceChange?: DexPriceChange
  liquidity?: DexLiquidity
  fdv?: number
  marketCap?: number
  pairCreatedAt?: number
  info?: {
    imageUrl?: string
    websites?: { label: string; url: string }[]
    socials?: { type: string; url: string }[]
  }
  boosts?: {
    active: number
  }
}

export interface TokenProfile {
  url: string
  chainId: string
  tokenAddress: string
  icon?: string
  header?: string
  description?: string
  links?: {
    type?: string
    label?: string
    url: string
  }[]
}

export interface CommunityTakeover {
  url: string
  chainId: string
  tokenAddress: string
  icon: string
  header: string | null
  description: string | null
  links: { type: string | null; label: string | null; url: string }[] | null
  claimDate: string
}

export interface TokenBoost {
  url: string
  chainId: string
  tokenAddress: string
  icon?: string
  header?: string
  description?: string
  links?: { type?: string; label?: string; url: string }[]
  amount: number
  totalAmount: number
}

interface PairDataWithMetadata extends DexPair {
  fetchedAt: number
  dataQuality: "EXCELLENT" | "GOOD" | "FAIR" | "POOR" | "MISSING"
  riskFlags: string[]
}

interface CacheEntry<T> {
  data: T
  timestamp: number
  ttl: number
}

export interface PairAssessment {
  isHealthy: boolean
  overallScore: number
  liquidity: {
    totalLiquidity: number
    assessmentLevel: string
  }
  volume: {
    volumeH24: number
    buyPressure: number
  }
  priceHealth: {
    h24Change: number
    volatility: number
  }
  recommendations: string[]
  lastUpdated: number
}

type DexListCacheKey = 'latestProfilesCache' | 'boostsCache' | 'takeoversCache';

export class DexScreenerClient {
  private pairCache: Map<string, CacheEntry<PairDataWithMetadata>> = new Map()
  private latestProfilesCache: CacheEntry<TokenProfile[]> | null = null
  private boostsCache: CacheEntry<TokenBoost[]> | null = null
  private takeoversCache: CacheEntry<CommunityTakeover[]> | null = null
  private assessmentCache: Map<string, CacheEntry<PairAssessment>> = new Map()

  private readonly API_BASE = "https://api.dexscreener.com"
  private readonly CACHE_TTL = 15000 // Reduced from 60s to 15s for faster updates
  private readonly REQUEST_TIMEOUT = 5000 
  private readonly RATE_LIMIT_PER_MINUTE = 60
  private requestTimestamps: number[] = []

  constructor() {
    observabilityService.log("DexScreener V1 Node Online", "success", {}, 1, "dexscreenerClient");
  }

  async fetchPairData(mint: string): Promise<DexPair | null> {
    try {
      const cached = this.getFromCache(this.pairCache, mint);
      if (cached) return cached;

      const data = await this.fetchWithRetry(`${this.API_BASE}/tokens/v1/solana/${mint}`);
      if (!data || !Array.isArray(data) || data.length === 0) return null;

      const pairs = data as DexPair[];
      const pair = pairs.sort((a, b) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0))[0];

      const enriched = { ...pair, fetchedAt: Date.now(), dataQuality: "GOOD" as const, riskFlags: [] };
      this.setCache(this.pairCache, mint, enriched);
      return enriched;
    } catch (error) {
      return null;
    }
  }

  async getTokenProfiles(): Promise<TokenProfile[]> {
    return this.fetchAndCacheList<TokenProfile>(`${this.API_BASE}/token-profiles/latest/v1`, 'latestProfilesCache');
  }

  async getCommunityTakeovers(): Promise<CommunityTakeover[]> {
    return this.fetchAndCacheList<CommunityTakeover>(`${this.API_BASE}/community-takeovers/latest/v1`, 'takeoversCache');
  }

  async getLatestBoosts(): Promise<TokenBoost[]> {
    return this.fetchAndCacheList<TokenBoost>(`${this.API_BASE}/token-boosts/latest/v1`, 'boostsCache');
  }

  private async fetchAndCacheList<T>(url: string, cacheKey: DexListCacheKey): Promise<T[]> {
    const cacheEntry = (this as any)[cacheKey] as CacheEntry<T[]> | null;
    if (cacheEntry && Date.now() - cacheEntry.timestamp < cacheEntry.ttl) return cacheEntry.data;

    const data = await this.fetchWithRetry(url);
    const list = Array.isArray(data) ? data : [];
    const solanaList = list.filter((item: any) => item.chainId === 'solana');

    (this as any)[cacheKey] = { data: solanaList, timestamp: Date.now(), ttl: this.CACHE_TTL };
    return solanaList;
  }

  scorePairData(pair: DexPair | null): number {
    if (!pair) return 0;
    let score = 50;
    const liq = pair.liquidity?.usd || 0;
    if (liq > 50000) score += 20;
    if (pair.boosts && pair.boosts.active > 0) score += 15;
    return Math.min(100, score);
  }

  private async fetchWithRetry(url: string, retries: number = 2): Promise<any> {
    for (let i = 0; i <= retries; i++) {
      try {
        await this.enforceRateLimit();
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.REQUEST_TIMEOUT);
        // Removed User-Agent header to avoid CORS preflight issues in browsers
        const response = await fetch(url, { signal: controller.signal });
        clearTimeout(timeoutId);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        this.requestTimestamps.push(Date.now());
        return await response.json();
      } catch (error) {
        if (i === retries) throw error;
        await new Promise(r => setTimeout(r, 1000 * Math.pow(2, i)));
      }
    }
  }

  private async enforceRateLimit() {
    const now = Date.now();
    this.requestTimestamps = this.requestTimestamps.filter(t => t > now - 60000);
    if (this.requestTimestamps.length >= this.RATE_LIMIT_PER_MINUTE) {
      await new Promise(r => setTimeout(r, 60000 - (now - this.requestTimestamps[0]) + 100));
    }
  }

  private getFromCache<T>(cache: Map<string, CacheEntry<T>>, key: string): T | null {
    const entry = cache.get(key);
    if (!entry || Date.now() - entry.timestamp > entry.ttl) return null;
    return entry.data;
  }

  private setCache<T>(cache: Map<string, CacheEntry<T>>, key: string, value: T) {
    cache.set(key, { data: value, timestamp: Date.now(), ttl: this.CACHE_TTL });
  }
}

let clientInstance: DexScreenerClient | null = null;
export function getDexScreenerClient(): DexScreenerClient {
  if (!clientInstance) clientInstance = new DexScreenerClient();
  return clientInstance;
}

export const fetchDexscreenerData = (mint: string) => getDexScreenerClient().fetchPairData(mint);
export const getLatestSolanaTokens = async () => {
  const profiles = await getDexScreenerClient().getTokenProfiles();
  return profiles.map(p => ({ address: p.tokenAddress, ...p }));
};
export const scoreDexscreenerData = (pair: any) => getDexScreenerClient().scorePairData(pair);
export const getCommunityTakeovers = () => getDexScreenerClient().getCommunityTakeovers();
export const getLatestBoosts = () => getDexScreenerClient().getLatestBoosts();
