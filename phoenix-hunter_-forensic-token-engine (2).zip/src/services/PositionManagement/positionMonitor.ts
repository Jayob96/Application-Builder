
import { positionService } from '../TradeExecution/positionService';
import { ExecutionService } from '../TradeExecution/executionService';
import { TradeExecutor } from '../TradeExecution/tradeExecutor';
import { logger } from '../Infrastructure/observabilityService';
import { THRESHOLDS, INTERVALS, FEATURES } from '../Infrastructure/constants';
import { Position, TokenOutcome } from '../../types';
import { Keypair } from '@solana/web3.js';

/**
 * Position Exit Reason
 */
export enum ExitReason {
  STOP_LOSS = 'STOP_LOSS',
  TAKE_PROFIT = 'TAKE_PROFIT',
  TRAILING_STOP = 'TRAILING_STOP',
  TIME_EXPIRED = 'TIME_EXPIRED',
  EMERGENCY_EXIT = 'EMERGENCY_EXIT',
  MANUAL_EXIT = 'MANUAL_EXIT',
  RUG_DETECTED = 'RUG_DETECTED',
  LIQUIDITY_DRIED = 'LIQUIDITY_DRIED',
}

/**
 * Position Monitoring Statistics
 */
export interface MonitorStats {
  totalChecks: number;
  positionsMonitored: number;
  exitsTriggered: number;
  exitsByReason: Record<ExitReason, number>;
  averageHoldTime: number;
  averageROI: number;
  lastCheckTime: number;
  errors: number;
  uptime: number;
}

/**
 * Trailing Stop Configuration
 */
export interface TrailingStopConfig {
  enabled: boolean;
  activationPercent: number; // Activate after this % gain
  trailPercent: number; // Trail by this % from peak
}

/**
 * PositionMonitor - Real-time Position Management & Auto-Exit
 * 
 * Features:
 * - Real-time position monitoring
 * - Stop-loss and take-profit automation
 * - Trailing stop-loss
 * - Time-based exits
 * - Emergency exit conditions
 * - Rug detection
 * - Liquidity monitoring
 * - Performance tracking
 * - Error recovery
 * - Configurable thresholds
 */
export class PositionMonitor {
  // State
  private isRunning = false;
  private intervalId: NodeJS.Timeout | null = null;
  
  // Constants
  private readonly SOL_MINT = "So11111111111111111111111111111111111111112";
  
  // Configuration
  private stopLossPercent: number;
  private takeProfitPercent: number;
  private trailingStopPercent: number;
  private maxHoldHours: number;
  private emergencyStopPercent: number;
  private checkInterval: number;
  private minLiquidityUSD: number;
  
  // Trailing Stop Configuration
  private trailingStopConfig: TrailingStopConfig = {
    enabled: FEATURES.TRAILING_STOP_ENABLED,
    activationPercent: 20, // Activate after +20% gain
    trailPercent: 15, // Trail by 15% from peak
  };
  
  // Position Peak Tracking (for trailing stops)
  private positionPeaks: Map<string, {
    peakPrice: number;
    peakPnlPercent: number;
    peakTime: number;
  }> = new Map();
  
  // Statistics
  private stats: MonitorStats = {
    totalChecks: 0,
    positionsMonitored: 0,
    exitsTriggered: 0,
    exitsByReason: {
      [ExitReason.STOP_LOSS]: 0,
      [ExitReason.TAKE_PROFIT]: 0,
      [ExitReason.TRAILING_STOP]: 0,
      [ExitReason.TIME_EXPIRED]: 0,
      [ExitReason.EMERGENCY_EXIT]: 0,
      [ExitReason.MANUAL_EXIT]: 0,
      [ExitReason.RUG_DETECTED]: 0,
      [ExitReason.LIQUIDITY_DRIED]: 0,
    },
    averageHoldTime: 0,
    averageROI: 0,
    lastCheckTime: 0,
    errors: 0,
    uptime: Date.now(),
  };
  
  // Error Tracking
  private consecutiveErrors: Map<string, number> = new Map();
  private readonly MAX_CONSECUTIVE_ERRORS = 5;
  
  // Price History (for pattern detection)
  private priceHistory: Map<string, number[]> = new Map();
  private readonly MAX_PRICE_HISTORY = 20;

  constructor(
    private executionService: ExecutionService,
    private tradeExecutor: TradeExecutor,
    private wallet: Keypair
  ) {
    // Load configuration from constants
    this.stopLossPercent = THRESHOLDS.STOP_LOSS_PERCENT;
    this.takeProfitPercent = THRESHOLDS.TAKE_PROFIT_PERCENT;
    this.trailingStopPercent = THRESHOLDS.TRAILING_STOP_PERCENT;
    this.maxHoldHours = THRESHOLDS.MAX_HOLD_HOURS;
    this.emergencyStopPercent = THRESHOLDS.EMERGENCY_STOP_LOSS;
    this.checkInterval = INTERVALS.POSITION_MONITOR;
    this.minLiquidityUSD = THRESHOLDS.MIN_LIQUIDITY;

    logger.log(
      "🎯 PositionMonitor created",
      "info",
      {
        stopLoss: `${this.stopLossPercent}%`,
        takeProfit: `${this.takeProfitPercent}%`,
        trailingStop: `${this.trailingStopPercent}%`,
        maxHold: `${this.maxHoldHours}h`,
        checkInterval: `${this.checkInterval}ms`,
      },
      1,
      "positionMonitor"
    );
  }

  /**
   * Start monitoring positions
   */
  start(): void {
    if (this.isRunning) {
      logger.log(
        "⚠️ PositionMonitor already running",
        "warning",
        {},
        2,
        "positionMonitor"
      );
      return;
    }

    this.isRunning = true;
    this.stats.uptime = Date.now();
    
    // Run immediately on start
    this.monitor();
    
    // Then set up interval
    this.intervalId = setInterval(() => this.monitor(), this.checkInterval);

    logger.log(
      "✅ Position Monitor: ONLINE",
      "success",
      { interval: `${this.checkInterval}ms` },
      1,
      "positionMonitor"
    );
  }

  /**
   * Stop monitoring positions
   */
  stop(): void {
    if (!this.isRunning) return;

    this.isRunning = false;
    
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    logger.log(
      "🛑 Position Monitor: OFFLINE",
      "warning",
      {
        uptime: `${Math.round((Date.now() - this.stats.uptime) / 1000)}s`,
        totalChecks: this.stats.totalChecks,
        exitsTriggered: this.stats.exitsTriggered,
      },
      1,
      "positionMonitor"
    );
  }

  /**
   * Monitor all active positions
   */
  private async monitor(): Promise<void> {
    if (!this.isRunning) return;

    this.stats.totalChecks++;
    this.stats.lastCheckTime = Date.now();

    const positions = positionService.getActive();
    this.stats.positionsMonitored = positions.length;

    if (positions.length === 0) {
      return; // No positions to monitor
    }

    logger.debug(
      `🔍 Monitoring ${positions.length} active positions`,
      { count: positions.length },
      "positionMonitor"
    );

    // Monitor each position in parallel (with concurrency limit)
    const monitorPromises = positions.map(pos => 
      this.monitorPosition(pos).catch(err => {
        this.handleMonitorError(pos, err);
      })
    );

    await Promise.allSettled(monitorPromises);
  }

  /**
   * Monitor a single position
   */
  private async monitorPosition(pos: Position): Promise<void> {
    try {
      logger.startPerformanceMark(`monitor_${pos.id}`);

      // Get current price and value
      const priceData = await this.getCurrentPriceData(pos);

      if (!priceData) {
        // Could not fetch price - skip this tick
        this.incrementErrorCount(pos.id);
        return;
      }

      // Reset error count on success
      this.consecutiveErrors.delete(pos.id);

      const { currentValueSol, currentPriceSol, pnl, pnlPercent } = priceData;

      // Update price history
      this.updatePriceHistory(pos.id, currentPriceSol);

      // Update position state
      positionService.update(pos.id, {
        currentPrice: currentPriceSol,
        pnl,
        pnlPercent,
        lastUpdated: Date.now(),
      });

      // Track peak for trailing stop
      this.updatePositionPeak(pos.id, currentPriceSol, pnlPercent);

      // Check exit conditions
      const exitReason = this.checkExitConditions(pos, pnlPercent, currentValueSol);

      if (exitReason) {
        await this.triggerExit(pos, exitReason, pnlPercent);
      }

      logger.endPerformanceMark(`monitor_${pos.id}`, false);
    } catch (err: any) {
      this.handleMonitorError(pos, err);
    }
  }

  /**
   * Get current price data for position
   */
  private async getCurrentPriceData(pos: Position): Promise<{
    currentValueSol: number;
    currentPriceSol: number;
    pnl: number;
    pnlPercent: number;
  } | null> {
    try {
      // Determine decimals (with fallbacks)
      const decimals = pos.decimals || this.guessDecimals(pos.mint);
      const rawAmount = Math.floor(pos.amountTokens * Math.pow(10, decimals));

      // Get quote for selling entire position to SOL
      const quote = await this.executionService.estimateSwap(
        pos.mint,
        this.SOL_MINT,
        rawAmount
      );

      if (!quote || !quote.outputAmount) {
        logger.debug(
          `⚠️ No quote available for ${pos.symbol}`,
          { mint: pos.mint },
          "positionMonitor"
        );
        return null;
      }

      // Calculate current value in SOL
      const currentValueSol = parseInt(quote.outputAmount) / 1e9;
      const currentPriceSol = currentValueSol / pos.amountTokens;

      // Calculate P&L
      const pnl = currentValueSol - pos.costBasis;
      const pnlPercent = (pnl / pos.costBasis) * 100;

      return {
        currentValueSol,
        currentPriceSol,
        pnl,
        pnlPercent,
      };
    } catch (err: any) {
      logger.debug(
        `Failed to fetch price for ${pos.symbol}: ${err.message}`,
        { mint: pos.mint, error: err.message },
        "positionMonitor"
      );
      return null;
    }
  }

  /**
   * Check all exit conditions
   */
  private checkExitConditions(
    pos: Position,
    pnlPercent: number,
    currentValueSol: number
  ): ExitReason | null {
    const holdHours = (Date.now() - pos.entryTime) / 3600000;

    // 1. Emergency Stop Loss (highest priority)
    if (pnlPercent <= this.emergencyStopPercent) {
      logger.log(
        `🚨 EMERGENCY STOP TRIGGERED: ${pos.symbol} (${pnlPercent.toFixed(1)}%)`,
        "error",
        { position: pos.symbol, pnl: pnlPercent },
        4,
        "positionMonitor"
      );
      return ExitReason.EMERGENCY_EXIT;
    }

    // 2. Rug Detection (price crash > 80% in short time)
    if (this.detectRugPull(pos.id, pnlPercent)) {
      logger.log(
        `🚨 RUG PULL DETECTED: ${pos.symbol}`,
        "error",
        { position: pos.symbol, pnl: pnlPercent },
        4,
        "positionMonitor"
      );
      return ExitReason.RUG_DETECTED;
    }

    // 3. Liquidity Dried Up
    if (currentValueSol < this.minLiquidityUSD / 100) {
      logger.log(
        `💧 LIQUIDITY DRIED: ${pos.symbol}`,
        "warning",
        { position: pos.symbol, liquidity: currentValueSol },
        3,
        "positionMonitor"
      );
      return ExitReason.LIQUIDITY_DRIED;
    }

    // 4. Trailing Stop (if enabled and activated)
    if (this.trailingStopConfig.enabled) {
      const trailingStopTriggered = this.checkTrailingStop(pos.id, pnlPercent);
      if (trailingStopTriggered) {
        logger.log(
          `📉 Trailing stop triggered: ${pos.symbol} (${pnlPercent.toFixed(1)}%)`,
          "warning",
          { position: pos.symbol, pnl: pnlPercent },
          2,
          "positionMonitor"
        );
        return ExitReason.TRAILING_STOP;
      }
    }

    // 5. Stop Loss
    if (pnlPercent <= this.stopLossPercent) {
      logger.log(
        `🛑 Stop loss triggered: ${pos.symbol} (${pnlPercent.toFixed(1)}%)`,
        "warning",
        { position: pos.symbol, pnl: pnlPercent },
        2,
        "positionMonitor"
      );
      return ExitReason.STOP_LOSS;
    }

    // 6. Take Profit
    if (pnlPercent >= this.takeProfitPercent) {
      logger.log(
        `🎯 Take profit triggered: ${pos.symbol} (+${pnlPercent.toFixed(1)}%)`,
        "success",
        { position: pos.symbol, pnl: pnlPercent },
        2,
        "positionMonitor"
      );
      return ExitReason.TAKE_PROFIT;
    }

    // 7. Time Expired
    if (holdHours >= this.maxHoldHours) {
      logger.log(
        `⏰ Max hold time reached: ${pos.symbol} (${holdHours.toFixed(1)}h)`,
        "warning",
        { position: pos.symbol, holdHours },
        2,
        "positionMonitor"
      );
      return ExitReason.TIME_EXPIRED;
    }

    return null; // No exit conditions met
  }

  /**
   * Trigger position exit
   */
  private async triggerExit(
    pos: Position,
    reason: ExitReason,
    pnlPercent: number
  ): Promise<void> {
    logger.log(
      `🚪 Exiting ${pos.symbol}: ${reason} (${pnlPercent >= 0 ? '+' : ''}${pnlPercent.toFixed(2)}%)`,
      pnlPercent >= 0 ? 'success' : 'warning',
      {
        position: pos.symbol,
        reason,
        pnl: pnlPercent,
        costBasis: pos.costBasis,
      },
      2,
      "positionMonitor"
    );

    try {
      // Execute trade
      const result = await this.tradeExecutor.closePosition(pos, reason, this.wallet);

      if (result.status === 'SUCCESS') {
        // Close position in service
        positionService.close(pos.id, {
          exitReason: reason,
          exitPrice: result.price,
          exitTime: Date.now(),
          exitTxn: result.signature || result.orderId || 'unknown',
          finalPnl: pnlPercent,
        });

        // Update statistics
        this.stats.exitsTriggered++;
        this.stats.exitsByReason[reason]++;
        this.updateAverageStats(pos, pnlPercent);

        // Clean up tracking data
        this.positionPeaks.delete(pos.id);
        this.priceHistory.delete(pos.id);
        this.consecutiveErrors.delete(pos.id);

        logger.log(
          `✅ Position closed: ${pos.symbol} (${pnlPercent >= 0 ? '+' : ''}${pnlPercent.toFixed(2)}%)`,
          'success',
          {
            position: pos.symbol,
            roi: pnlPercent,
            reason,
            signature: result.signature,
          },
          2,
          "positionMonitor"
        );
      } else {
        logger.log(
          `❌ Failed to close ${pos.symbol}: ${result.error}`,
          'error',
          {
            position: pos.symbol,
            error: result.error,
            reason,
          },
          3,
          "positionMonitor"
        );
      }
    } catch (err: any) {
      logger.reportError(
        err,
        {
          position: pos.symbol,
          reason,
          pnl: pnlPercent,
        },
        "positionMonitor"
      );
    }
  }

  /**
   * Manually close a position
   */
  async manualExit(positionId: string): Promise<boolean> {
    const pos = positionService.getActive().find(p => p.id === positionId);

    if (!pos) {
      logger.log(
        `❌ Position not found: ${positionId}`,
        "error",
        { positionId },
        3,
        "positionMonitor"
      );
      return false;
    }

    const priceData = await this.getCurrentPriceData(pos);
    const pnlPercent = priceData?.pnlPercent || 0;

    await this.triggerExit(pos, ExitReason.MANUAL_EXIT, pnlPercent);
    return true;
  }

  /**
   * Update position peak (for trailing stop)
   */
  private updatePositionPeak(positionId: string, currentPrice: number, pnlPercent: number): void {
    const existing = this.positionPeaks.get(positionId);

    if (!existing || pnlPercent > existing.peakPnlPercent) {
      this.positionPeaks.set(positionId, {
        peakPrice: currentPrice,
        peakPnlPercent: pnlPercent,
        peakTime: Date.now(),
      });
    }
  }

  /**
   * Check trailing stop condition
   */
  private checkTrailingStop(positionId: string, currentPnlPercent: number): boolean {
    const peak = this.positionPeaks.get(positionId);

    if (!peak) return false;

    // Check if trailing stop is activated (after activation threshold)
    if (peak.peakPnlPercent < this.trailingStopConfig.activationPercent) {
      return false;
    }

    // Check if price dropped below trailing stop threshold
    const dropFromPeak = peak.peakPnlPercent - currentPnlPercent;
    return dropFromPeak >= this.trailingStopConfig.trailPercent;
  }

  /**
   * Detect rug pull (sudden price crash)
   */
  private detectRugPull(positionId: string, currentPnlPercent: number): boolean {
    const history = this.priceHistory.get(positionId);

    if (!history || history.length < 3) return false;

    // Check if price crashed > 80% in last 3 data points
    const recentHigh = Math.max(...history.slice(-3));
    const currentLow = history[history.length - 1];
    const crashPercent = ((recentHigh - currentLow) / recentHigh) * 100;

    return crashPercent > 80 && currentPnlPercent < -50;
  }

  /**
   * Update price history for pattern detection
   */
  private updatePriceHistory(positionId: string, price: number): void {
    let history = this.priceHistory.get(positionId) || [];
    history.push(price);

    // Keep only recent history
    if (history.length > this.MAX_PRICE_HISTORY) {
      history = history.slice(-this.MAX_PRICE_HISTORY);
    }

    this.priceHistory.set(positionId, history);
  }

  /**
   * Update average statistics
   */
  private updateAverageStats(pos: Position, pnlPercent: number): void {
    const holdTime = Date.now() - pos.entryTime;
    
    const totalExits = this.stats.exitsTriggered;
    
    this.stats.averageHoldTime = 
      ((this.stats.averageHoldTime * (totalExits - 1)) + holdTime) / totalExits;
    
    this.stats.averageROI = 
      ((this.stats.averageROI * (totalExits - 1)) + pnlPercent) / totalExits;
  }

  /**
   * Handle monitoring errors
   */
  private handleMonitorError(pos: Position, err: any): void {
    this.stats.errors++;
    this.incrementErrorCount(pos.id);

    const errorCount = this.consecutiveErrors.get(pos.id) || 0;

    if (errorCount >= this.MAX_CONSECUTIVE_ERRORS) {
      logger.log(
        `⚠️ Max errors reached for ${pos.symbol} - position may be stale`,
        "warning",
        { position: pos.symbol, errors: errorCount },
        3,
        "positionMonitor"
      );
    }

    logger.debug(
      `Monitor error for ${pos.symbol}: ${err.message}`,
      { position: pos.symbol, error: err.message },
      "positionMonitor"
    );
  }

  /**
   * Increment error count for position
   */
  private incrementErrorCount(positionId: string): void {
    const current = this.consecutiveErrors.get(positionId) || 0;
    this.consecutiveErrors.set(positionId, current + 1);
  }

  /**
   * Guess token decimals based on mint address patterns
   */
  private guessDecimals(mint: string): number {
    // Common token decimals: SOL=9, USDC=6, most SPL=6
    // This is a fallback - ideally decimals should be stored
    if (mint === this.SOL_MINT) return 9;
    return 6; // Default to USDC-like decimals
  }

  /**
   * Get monitoring statistics
   */
  getStats(): MonitorStats {
    return {
      ...this.stats,
      uptime: Date.now() - this.stats.uptime,
    };
  }

  /**
   * Configure monitoring thresholds
   */
  configure(config: {
    stopLossPercent?: number;
    takeProfitPercent?: number;
    trailingStopPercent?: number;
    maxHoldHours?: number;
    checkInterval?: number;
    trailingStopConfig?: Partial<TrailingStopConfig>;
  }): void {
    if (config.stopLossPercent !== undefined) this.stopLossPercent = config.stopLossPercent;
    if (config.takeProfitPercent !== undefined) this.takeProfitPercent = config.takeProfitPercent;
    if (config.trailingStopPercent !== undefined) this.trailingStopPercent = config.trailingStopPercent;
    if (config.maxHoldHours !== undefined) this.maxHoldHours = config.maxHoldHours;
    if (config.checkInterval !== undefined) this.checkInterval = config.checkInterval;
    if (config.trailingStopConfig) {
      this.trailingStopConfig = { ...this.trailingStopConfig, ...config.trailingStopConfig };
    }

    logger.log(
      "⚙️ PositionMonitor configured",
      "info",
      config,
      1,
      "positionMonitor"
    );
  }

  /**
   * Get monitoring status
   */
  isActive(): boolean {
    return this.isRunning;
  }
}

export default PositionMonitor;
