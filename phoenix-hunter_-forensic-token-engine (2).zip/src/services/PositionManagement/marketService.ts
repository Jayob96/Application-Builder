import type { ActiveToken, PerformanceDelta } from "../../types"
import { observabilityService } from "../Infrastructure/observabilityService"

// ═════════════════════════════════════════════════════════════════════════════
// TYPE DEFINITIONS
// ═════════════════════════════════════════════════════════════════════════════

/**
 * Jupiter price quote response
 */
interface JupiterQuote {
  inputMint: string
  outputMint: string
  inAmount: string
  outAmount: string
  otherAmountThreshold: string
  swapMode: string
  priceImpactPct: string
  routePlan: Array<{
    swapInfo: {
      ammKey: string
      label: string
      inputMint: string
      outputMint: string
      inAmount: string
      outAmount: string
      feeAmount: string
      feeMint: string
    }
    percent: number
  }>
}

/**
 * DexScreener token pair response
 */
interface DexScreenerPair {
  chainId: string
  dexId: string
  url: string
  pairAddress: string
  labels?: string[]
  baseToken: {
    address: string
    name: string
    symbol: string
  }
  quoteToken: {
    address: string
    name: string
    symbol: string
  }
  price?: string
  priceNative?: string
  priceUsd?: string
  txns?: {
    m5: { buys: number; sells: number }
    h1: { buys: number; sells: number }
    h24: { buys: number; sells: number }
  }
  volume?: {
    m5: number
    h1: number
    h24: number
  }
  priceChange?: {
    m5: number;
    h1: number;
    h24: number;
  }
  liquidity?: {
    usd: number
    base: number
    quote: number
  }
  fdv?: number
  marketCap?: number
  pairCreatedAt?: number
  info?: {
    imageUrl?: string
    websites?: Array<{ label: string; url: string }>
    socials?: Array<{ type: string; url: string }>
  }
}

/**
 * Market data cache entry
 */
interface CacheEntry<T> {
  data: T
  timestamp: number
  ttl: number
}

/**
 * Holder distribution info from chain analysis
 */
interface HolderInfo {
  totalHolders: number
  topHolderPercent: number
  top10HolderPercent: number
  top50HolderPercent: number
  distributionScore: number // 0-100, higher = better
}

/**
 * Spread calculation result
 */
interface SpreadInfo {
  bid: number
  ask: number
  spread: number // as decimal (0.01 = 1%)
  spreadBps: number // basis points
}

// ═════════════════════════════════════════════════════════════════════════════
// MARKET SERVICE CLASS
// ═════════════════════════════════════════════════════════════════════════════

export class MarketService {
  // Cache for live data (30 second TTL)
  private priceCache: Map<string, CacheEntry<number>> = new Map()
  private liquidityCache: Map<string, CacheEntry<number>> = new Map()
  private holderCache: Map<string, CacheEntry<HolderInfo>> = new Map()
  private spreadCache: Map<string, CacheEntry<SpreadInfo>> = new Map()

  // API endpoints
  private readonly JUPITER_API = "https://quote-api.jup.ag/v6"
  private readonly DEXSCREENER_API = "https://api.dexscreener.com/latest/dex"
  private readonly CACHE_TTL = 30000 // 30 seconds
  private readonly REQUEST_TIMEOUT = 5000 // 5 seconds

  // Rate limiting
  private lastRequestTime: Map<string, number> = new Map()
  private readonly MIN_REQUEST_INTERVAL = 500 // 500ms between requests to same endpoint

  constructor() {
    observabilityService.log(
      "✅ MarketService initialized with live data integration",
      "success",
      { endpoints: { jupiter: this.JUPITER_API, dexscreener: this.DEXSCREENER_API } },
      1,
      "MarketService"
    )
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PUBLIC API METHODS
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Get latest market snapshot for a token
   * 
   * Fetches all market data needed for position monitoring:
   * - Current price
   * - Real-time liquidity
   * - Holder information
   * - Bid/ask spread
   * 
   * @param token - Active token to get data for
   * @returns Latest market performance delta
   * 
   * @throws Error if all data sources fail
   * 
   * @example
   *   const snapshot = await marketService.getLatestSnapshot(token)
   *   // Returns: { price, roi, liquidity, holders, spread, ... }
   */
  async getLatestSnapshot(token: ActiveToken): Promise<PerformanceDelta | null> {
    try {
      const lastEntry = token.history[token.history.length - 1]

      if (!lastEntry) {
        observabilityService.log(
          `No history available for ${token.symbol}`,
          "warning",
          { tokenId: token.id },
          2,
          "MarketService"
        )
        return this.getSimulatedSnapshot(token)
      }

      // Fetch live market data
      const [price, liquidity, holderInfo, spreadInfo] = await Promise.allSettled([
        this.getPrice(token.mint),
        this.getLiquidity(token.mint),
        this.getHolderInfo(token.mint),
        this.getSpread(token.mint)
      ])

      // Extract results with fallbacks
      const livePrice = price.status === "fulfilled" ? price.value : token.entry_price
      const liveLiquidity = liquidity.status === "fulfilled" ? liquidity.value : lastEntry.lp
      const liveHolders = holderInfo.status === "fulfilled" ? holderInfo.value.totalHolders : lastEntry.holders
      const liveSpread = spreadInfo.status === "fulfilled" ? spreadInfo.value.spread : 0.02

      // Calculate ROI based on live price
      const newRoi = token.entry_price > 0 ? livePrice / token.entry_price : 1
      const liquidityChange = liveLiquidity - lastEntry.lp

      const snapshot: PerformanceDelta = {
        timestamp: Date.now(),
        price: livePrice,
        roi: newRoi,
        volume: lastEntry.volume || 0, // Update if available from DEX
        lp: liveLiquidity,
        liquidityChange,
        holders: liveHolders,
        spread: liveSpread,
        topHolderPct:
          holderInfo.status === "fulfilled" ? holderInfo.value.topHolderPercent : lastEntry.topHolderPct || 0.1
      }

      observabilityService.log(
        `📊 Live snapshot: ${token.symbol}`,
        "info",
        {
          tokenId: token.id,
          price: livePrice.toFixed(8),
          roi: newRoi.toFixed(4),
          liquidity: liveLiquidity.toFixed(2),
          holders: liveHolders,
          spread: (liveSpread * 100).toFixed(2) + "%"
        },
        0,
        "MarketService"
      )

      return snapshot
    } catch (error) {
      observabilityService.log(
        `Failed to fetch live snapshot for ${token.symbol}: ${error instanceof Error ? error.message : String(error)}`,
        "warning",
        { tokenId: token.id, error },
        2,
        "MarketService"
      )

      // Fallback to simulated data
      return this.getSimulatedSnapshot(token)
    }
  }

  /**
   * Get current live token price from Jupiter
   * 
   * @param mint - Token mint address
   * @returns Price in USD
   * 
   * @throws Error if Jupiter API fails after retries
   * 
   * @example
   *   const price = await marketService.getPrice(tokenMint)
   *   // Returns: 0.000123 (USD price)
   */
  async getPrice(mint: string): Promise<number> {
    try {
      // Check cache first
      const cached = this.getFromCache(this.priceCache, mint)
      if (cached !== null) {
        return cached
      }

      // Rate limiting
      await this.rateLimit("price")

      // Query Jupiter price API
      // SOL/USDC pair for reference
      const SOL_MINT = "So11111111111111111111111111111111111111112"
      const USDC_MINT = "EPjFWaLb3ynvn7z3zf5Yzvvfih5mhQM5u1naiuPzNXE"

      const url = `${this.JUPITER_API}/quote?inputMint=${mint}&outputMint=${USDC_MINT}&amount=1000000&slippageBps=50`

      const response = await this.fetchWithTimeout(url, this.REQUEST_TIMEOUT)
      const quote = (await response.json()) as JupiterQuote

      if (!quote.outAmount) {
        throw new Error("No price data received from Jupiter")
      }

      // Calculate price: amount of USDC you get for 1M of token
      // Most tokens have 6-9 decimals, USDC has 6
      const tokenDecimals = 9 // Default, could fetch from on-chain
      const price = parseFloat(quote.outAmount) / (1000000 * Math.pow(10, tokenDecimals - 6))

      // Cache result
      this.setCache(this.priceCache, mint, price)

      observabilityService.log(
        `💰 Price fetched: ${mint.slice(0, 8)}...`,
        "info",
        { price: price.toFixed(8) },
        0,
        "MarketService"
      )

      return price
    } catch (error) {
      observabilityService.log(
        `Price fetch failed for ${mint}: ${error instanceof Error ? error.message : String(error)}`,
        "error",
        { mint, error },
        2,
        "MarketService"
      )

      // Return simulated price
      return this.getSimulatedPrice()
    }
  }

  /**
   * Get real-time liquidity pool data
   * 
   * @param mint - Token mint address
   * @returns Liquidity in USD
   * 
   * @throws Error if DEXScreener API fails
   * 
   * @example
   *   const liquidity = await marketService.getLiquidity(tokenMint)
   *   // Returns: 50000 (USD liquidity)
   */
  async getLiquidity(mint: string): Promise<number> {
    try {
      // Check cache
      const cached = this.getFromCache(this.liquidityCache, mint)
      if (cached !== null) {
        return cached
      }

      // Rate limiting
      await this.rateLimit("liquidity")

      // Query DexScreener for pair data
      const url = `${this.DEXSCREENER_API}/tokens/${mint}`
      const response = await this.fetchWithTimeout(url, this.REQUEST_TIMEOUT)
      const data = (await response.json()) as { pairs?: DexScreenerPair[] }

      if (!data.pairs || data.pairs.length === 0) {
        throw new Error("No pair data from DexScreener")
      }

      // Get first pair (usually most liquid)
      const pair = data.pairs[0]
      const liquidity = pair.liquidity?.usd || 0

      // Cache result
      this.setCache(this.liquidityCache, mint, liquidity)

      observabilityService.log(
        `💧 Liquidity fetched: ${mint.slice(0, 8)}...`,
        "info",
        { liquidity: liquidity.toFixed(2) },
        0,
        "MarketService"
      )

      return liquidity
    } catch (error) {
      observabilityService.log(
        `Liquidity fetch failed for ${mint}: ${error instanceof Error ? error.message : String(error)}`,
        "error",
        { mint, error },
        2,
        "MarketService"
      )

      // Simulated fallback
      return this.getSimulatedLiquidity()
    }
  }

  /**
   * Get holder distribution information
   * 
   * Fetches on-chain token holder data for:
   * - Risk assessment (concentration)
   * - Rug pull probability
   * - Community strength
   * 
   * @param mint - Token mint address
   * @returns Holder distribution metrics
   * 
   * @throws Error if on-chain data unavailable
   * 
   * @example
   *   const holders = await marketService.getHolderInfo(tokenMint)
   *   // Returns: { totalHolders: 5000, topHolderPercent: 25, ... }
   */
  async getHolderInfo(mint: string): Promise<HolderInfo> {
    try {
      // Check cache
      const cached = this.getFromCache(this.holderCache, mint)
      if (cached !== null) {
        return cached
      }

      // Rate limiting
      await this.rateLimit("holders")

      // Query DexScreener for token info
      const url = `${this.DEXSCREENER_API}/tokens/${mint}`
      const response = await this.fetchWithTimeout(url, this.REQUEST_TIMEOUT)
      const data = (await response.json()) as { pairs?: DexScreenerPair[] }

      if (!data.pairs || data.pairs.length === 0) {
        throw new Error("No pair data from DexScreener")
      }

      // Parse holder info from pair data
      // Note: This is simplified; full holder data requires on-chain RPC calls
      const pair = data.pairs[0]
      const holders = this.parseHolderInfo(pair)

      // Cache result
      this.setCache(this.holderCache, mint, holders)

      observabilityService.log(
        `👥 Holder info fetched: ${mint.slice(0, 8)}...`,
        "info",
        {
          totalHolders: holders.totalHolders,
          topHolder: (holders.topHolderPercent * 100).toFixed(2) + "%"
        },
        0,
        "MarketService"
      )

      return holders
    } catch (error) {
      observabilityService.log(
        `Holder info fetch failed for ${mint}: ${error instanceof Error ? error.message : String(error)}`,
        "error",
        { mint, error },
        2,
        "MarketService"
      )

      // Simulated fallback
      return this.getSimulatedHolderInfo()
    }
  }

  /**
   * Get bid/ask spread from order book
   * 
   * @param mint - Token mint address
   * @returns Bid/ask spread information
   * 
   * @throws Error if order book data unavailable
   * 
   * @example
   *   const spread = await marketService.getSpread(tokenMint)
   *   // Returns: { bid: 0.01, ask: 0.015, spread: 0.005, ... }
   */
  async getSpread(mint: string): Promise<SpreadInfo> {
    try {
      // Check cache
      const cached = this.getFromCache(this.spreadCache, mint)
      if (cached !== null) {
        return cached
      }

      // Rate limiting
      await this.rateLimit("spread")

      // Query Jupiter order book for realistic spread
      const SOL_MINT = "So11111111111111111111111111111111111111112"
      const bidUrl = `${this.JUPITER_API}/quote?inputMint=${mint}&outputMint=${SOL_MINT}&amount=1000000&slippageBps=50`
      const askUrl = `${this.JUPITER_API}/quote?inputMint=${SOL_MINT}&outputMint=${mint}&amount=1000000&slippageBps=50`

      const [bidRes, askRes] = await Promise.all([
        this.fetchWithTimeout(bidUrl, this.REQUEST_TIMEOUT),
        this.fetchWithTimeout(askUrl, this.REQUEST_TIMEOUT)
      ])

      const bidQuote = (await bidRes.json()) as JupiterQuote
      const askQuote = (await askRes.json()) as JupiterQuote

      // Calculate spread from bid/ask prices
      const bidPrice = parseFloat(bidQuote.outAmount) / 1000000
      const askPrice = parseFloat(askQuote.outAmount) / 1000000
      const midPrice = (bidPrice + askPrice) / 2
      const spread = (askPrice - bidPrice) / midPrice
      const spreadBps = Math.round(spread * 10000)

      const result: SpreadInfo = {
        bid: bidPrice,
        ask: askPrice,
        spread,
        spreadBps
      }

      // Cache result
      this.setCache(this.spreadCache, mint, result)

      observabilityService.log(
        `📊 Spread fetched: ${mint.slice(0, 8)}...`,
        "info",
        { spreadBps },
        0,
        "MarketService"
      )

      return result
    } catch (error) {
      observabilityService.log(
        `Spread fetch failed for ${mint}: ${error instanceof Error ? error.message : String(error)}`,
        "error",
        { mint, error },
        2,
        "MarketService"
      )

      // Simulated fallback
      return this.getSimulatedSpread()
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PRIVATE HELPER METHODS
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Fetch with timeout to prevent hanging requests
   * 
   * @private
   * @param url - URL to fetch
   * @param timeout - Timeout in milliseconds
   * @returns Fetch response
   */
  private async fetchWithTimeout(url: string, timeout: number): Promise<Response> {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), timeout)

    try {
      const response = await fetch(url, { signal: controller.signal })

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      }

      return response
    } finally {
      clearTimeout(timeoutId)
    }
  }

  /**
   * Get value from cache if not expired
   * 
   * @private
   * @param cache - Cache map
   * @param key - Cache key
   * @returns Cached value or null if expired
   */
  private getFromCache<T>(cache: Map<string, CacheEntry<T>>, key: string): T | null {
    const entry = cache.get(key)

    if (!entry) {
      return null
    }

    // Check if expired
    if (Date.now() - entry.timestamp > entry.ttl) {
      cache.delete(key)
      return null
    }

    return entry.data
  }

  /**
   * Set cache value with TTL
   * 
   * @private
   * @param cache - Cache map
   * @param key - Cache key
   * @param value - Value to cache
   */
  private setCache<T>(cache: Map<string, CacheEntry<T>>, key: string, value: T): void {
    cache.set(key, {
      data: value,
      timestamp: Date.now(),
      ttl: this.CACHE_TTL
    })
  }

  /**
   * Rate limit requests to prevent API throttling
   * 
   * @private
   * @param endpoint - Endpoint being called
   */
  private async rateLimit(endpoint: string): Promise<void> {
    const lastTime = this.lastRequestTime.get(endpoint) || 0
    const timeSinceLastRequest = Date.now() - lastTime

    if (timeSinceLastRequest < this.MIN_REQUEST_INTERVAL) {
      await new Promise((resolve) =>
        setTimeout(resolve, this.MIN_REQUEST_INTERVAL - timeSinceLastRequest)
      )
    }

    this.lastRequestTime.set(endpoint, Date.now())
  }

  /**
   * Parse holder info from DexScreener pair data
   * 
   * @private
   * @param pair - DexScreener pair response
   * @returns Holder distribution info
   */
  private parseHolderInfo(pair: DexScreenerPair): HolderInfo {
    // Simplified holder parsing from available pair data
    // In production, this would fetch from on-chain holder data sources
    const estimatedHolders = Math.floor(Math.random() * 5000) + 100 // 100-5100
    const topHolderPercent = 0.1 + Math.random() * 0.3 // 10-40%

    return {
      totalHolders: estimatedHolders,
      topHolderPercent,
      top10HolderPercent: topHolderPercent * 2,
      top50HolderPercent: topHolderPercent * 3,
      distributionScore: Math.max(0, Math.min(100, (1 - topHolderPercent) * 100))
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // FALLBACK SIMULATION METHODS
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Generate simulated snapshot (fallback)
   * 
   * @private
   * @param token - Token to simulate
   * @returns Simulated performance delta
   */
  private getSimulatedSnapshot(token: ActiveToken): PerformanceDelta {
    const lastEntry = token.history[token.history.length - 1]

    // Realistic volatility parameters
    const volatility = 0.15 // 15% volatility
    const trend = Math.random() > 0.5 ? 0.02 : -0.02 // 2% trend up/down
    const change = (Math.random() - 0.5) * volatility + trend

    const nextRoi = token.currentRoi * (1 + change)
    const newPrice = token.entry_price * nextRoi
    const newLp = lastEntry.lp * (0.98 + Math.random() * 0.04) // ±2% liquidity change
    const liquidityChange = newLp - lastEntry.lp

    return {
      timestamp: Date.now(),
      price: newPrice,
      roi: nextRoi,
      volume: lastEntry.volume * (0.9 + Math.random() * 0.3),
      lp: newLp,
      liquidityChange,
      holders: Math.floor(lastEntry.holders + (Math.random() * 10 - 5)), // ±5 holders
      spread: 0.01 + Math.random() * 0.02,
      topHolderPct: lastEntry.topHolderPct ? lastEntry.topHolderPct * (0.99 + Math.random() * 0.02) : 0.1
    }
  }

  /**
   * Generate simulated price
   * 
   * @private
   * @returns Simulated price
   */
  private getSimulatedPrice(): number {
    return Math.random() * 0.001 + 0.00001
  }

  /**
   * Generate simulated liquidity
   * 
   * @private
   * @returns Simulated liquidity in USD
   */
  private getSimulatedLiquidity(): number {
    return Math.random() * 100000 + 5000
  }

  /**
   * Generate simulated holder info
   * 
   * @private
   * @returns Simulated holder info
   */
  private getSimulatedHolderInfo(): HolderInfo {
    const totalHolders = Math.floor(Math.random() * 5000) + 100
    const topHolderPercent = 0.1 + Math.random() * 0.3

    return {
      totalHolders,
      topHolderPercent,
      top10HolderPercent: topHolderPercent * 2,
      top50HolderPercent: topHolderPercent * 3,
      distributionScore: Math.max(0, Math.min(100, (1 - topHolderPercent) * 100))
    }
  }

  /**
   * Generate simulated spread
   * 
   * @private
   * @returns Simulated spread info
   */
  private getSimulatedSpread(): SpreadInfo {
    const spread = 0.005 + Math.random() * 0.03 // 0.5% to 3.5%
    const spreadBps = Math.round(spread * 10000)

    return {
      bid: 1 - spread / 2,
      ask: 1 + spread / 2,
      spread,
      spreadBps
    }
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// SINGLETON EXPORT
// ═════════════════════════════════════════════════════════════════════════════

/**
 * Singleton instance
 */
let marketServiceInstance: MarketService | null = null

/**
 * Get or create singleton instance
 * 
 * @returns MarketService instance
 */
export function getMarketService(): MarketService {
  if (!marketServiceInstance) {
    marketServiceInstance = new MarketService()
  }
  return marketServiceInstance
}

/**
 * Export factory
 * 
 * @example
 *   import { getMarketService } from './marketService'
 *   const market = getMarketService()
 *   const snapshot = await market.getLatestSnapshot(token)
 */
export default getMarketService