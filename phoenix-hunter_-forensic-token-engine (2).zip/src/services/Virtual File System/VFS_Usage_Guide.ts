
// ============================================================================
// VIRTUAL FILE SYSTEM - COMPLETE USAGE GUIDE
// ============================================================================

import { vfs, VFSEvent, SearchResult } from './VirtualFileSystem'

// ============================================================================
// 1. BASIC FILE OPERATIONS
// ============================================================================
{
  // CREATE FILE
  const file = vfs.createFile('/src/utils/helpers.ts', 'export const add = (a, b) => a + b')

  // READ FILE
  const content = vfs.getFileContent('/src/utils/helpers.ts')
  console.log(content) // 'export const add = (a, b) => a + b'

  // UPDATE FILE
  vfs.updateFile('/src/utils/helpers.ts', 'export const add = (a, b) => a + b\nexport const subtract = (a, b) => a - b')

  // DELETE FILE
  vfs.deleteNode('/src/utils/helpers.ts')
}

// ============================================================================
// 2. FOLDER OPERATIONS
// ============================================================================
{
  // CREATE FOLDER
  vfs.createFolder('/src/new-feature')

  // GET FOLDER CONTENTS
  const children = vfs.getFolderChildren('/src')
  console.log(children) // [FileNode, FileNode, ...]

  // TOGGLE FOLDER (expand/collapse in UI)
  vfs.toggleFolder('/src/components')
}

// ============================================================================
// 3. BATCH OPERATIONS
// ============================================================================
{
  // CREATE MULTIPLE FILES AT ONCE
  vfs.createMultiple([
    { path: '/src/types/user.ts', content: 'export interface User { id: string }' },
    { path: '/src/types/token.ts', content: 'export interface Token { mint: string }' },
    { path: '/src/types/trade.ts', content: 'export interface Trade { id: string }' },
  ])

  // DELETE MULTIPLE FILES
  vfs.deleteMultiple([
    '/src/types/user.ts',
    '/src/types/token.ts',
  ])
}

// ============================================================================
// 4. RENAME & MOVE
// ============================================================================
{
  // RENAME FILE
  vfs.renameNode('/src/utils/helpers.ts', 'math.ts')

  // MOVE FILE TO DIFFERENT FOLDER
  vfs.moveNode('/src/utils/math.ts', '/src/services')
}

// ============================================================================
// 5. DUPLICATE FILES
// ============================================================================
{
  // DUPLICATE WITH AUTO NAME
  vfs.duplicateNode('/src/components/Button.tsx')
  // Creates: /src/components/Button_copy.tsx

  // DUPLICATE WITH CUSTOM NAME
  vfs.duplicateNode('/src/components/Button.tsx', 'LargeButton.tsx')
  // Creates: /src/components/LargeButton.tsx
}

// ============================================================================
// 6. SEARCH & FIND
// ============================================================================
{
  // SEARCH BY NAME
  const results = vfs.search('Button')
  console.log(results)
  // [
  //   { path: '/src/components/Button.tsx', node: {...}, matchType: 'name' },
  //   { path: '/src/components/ButtonGroup.tsx', node: {...}, matchType: 'name' }
  // ]

  // SEARCH BY CONTENT (case-insensitive)
  const imports = vfs.search('import React', {
    searchContent: true,
    matchCase: false,
  })

  // SEARCH BY FILE TYPE
  const tsFiles = vfs.search('.ts', {
    fileType: '.ts'
  })

  // SEARCH WITH CASE SENSITIVITY
  const exact = vfs.search('ExactMatch', {
    matchCase: true
  })
}

// ============================================================================
// 7. FILTER FILES
// ============================================================================
{
  // FILTER BY PREDICATE
  const allTypeScriptFiles = vfs.filter((node, path) => {
    return path.endsWith('.ts') || path.endsWith('.tsx')
  })

  // FILTER FOR SPECIFIC PATTERN
  const modifiedFiles = vfs.filter((node) => {
    return node.isModified === true
  })

  // FILTER NESTED - ALL FILES UNDER A FOLDER
  const srcFiles = vfs.filter((node, path) => {
    return path.startsWith('/src') && node.type === 'file'
  })
}

// ============================================================================
// 8. SUBSCRIBE TO CHANGES
// ============================================================================
{
  // LISTEN TO ALL VFS CHANGES
  const unsubscribe = vfs.subscribe((tree, event) => {
    console.log(`Event: ${event.type}`)
    console.log(`Path: ${event.path}`)
    console.log(`Timestamp: ${event.timestamp}`)
    console.log(`Source: ${event.source}`) // 'user' | 'system' | 'import'
    
    // Handle different event types
    if (event.type === 'create') {
      console.log('New file created:', event.newValue)
    } else if (event.type === 'update') {
      console.log('File updated')
      console.log('Previous:', event.previousValue)
      console.log('New:', event.newValue)
    } else if (event.type === 'delete') {
      console.log('File deleted:', event.previousValue)
    } else if (event.type === 'rename') {
      console.log('Renamed from:', event.previousValue.name)
      console.log('Renamed to:', event.newValue.name)
    } else if (event.type === 'move') {
      console.log('Moved:', event.previousValue, '→', event.newValue)
    }
  })

  // Later, stop listening
  // unsubscribe()
}

// ============================================================================
// 9. UNDO/REDO
// ============================================================================
{
  // CHECK IF UNDO IS AVAILABLE
  if (vfs.canUndo()) {
    vfs.undo()
    console.log('Undone!')
  }

  // CHECK IF REDO IS AVAILABLE
  if (vfs.canRedo()) {
    vfs.redo()
    console.log('Redone!')
  }

  // GET UNDO/REDO STATE
  console.log(vfs.getHistoryIndex()) // Current position in history

  // GET FULL HISTORY
  const history = vfs.getHistory()
  console.log(history)
}

// ============================================================================
// 10. IMPORT/EXPORT
// ============================================================================
{
  // EXPORT VFS AS JSON STRING
  const vfsJson = vfs.export()
  console.log(vfsJson) // JSON string of entire file tree

  // EXPORT VFS TO FILE (downloads to user's computer)
  vfs.exportToFile('my_project_structure.json')

  // IMPORT VFS FROM JSON STRING
  const importedJson = '{"name":"project","type":"folder","children":[...]}'
  vfs.import(importedJson)

  // IMPORT VFS FROM FILE UPLOAD
  const handleFileUpload = async (file: File) => {
    try {
      await vfs.importFromFile(file)
      console.log('Import successful!')
    } catch (error) {
      console.error('Import failed:', error)
    }
  }
}

// ============================================================================
// 11. STATISTICS & MONITORING
// ============================================================================
{
  // GET VFS STATISTICS
  const stats = vfs.getStats()
  console.log(stats)

  // GET MEMORY USAGE
  const memory = vfs.getMemoryUsage()
  console.log(memory)

  // GET TREE SIZE
  const treeSize = vfs.getTreeSize()
  console.log(`VFS takes ${treeSize} bytes in storage`)
}

// ============================================================================
// 12. VALIDATION & CONSTRAINTS
// ============================================================================
{
  // REGISTER CUSTOM VALIDATOR
  vfs.registerValidator('typescript-only', (path, node) => {
    if (node.type === 'file' && !path.endsWith('.ts') && !path.endsWith('.tsx')) {
      return 'Only TypeScript files allowed!'
    }
    return true
  })

  // NOW THIS WILL THROW AN ERROR
  try {
    vfs.createFile('/src/test.js', 'console.log("hi")')
    // Error: Only TypeScript files allowed!
  } catch (error: any) {
    console.error(error.message)
  }
}

// ============================================================================
// 13. FIND NODES
// ============================================================================
{
  // FIND A SPECIFIC NODE BY PATH
  const node = vfs.findNode('/src/components/Button.tsx')
  console.log(node)
  // { name: 'Button.tsx', type: 'file', content: '...', ... }

  // CHECK IF NODE EXISTS
  if (vfs.findNode('/src/components/Button.tsx')) {
    console.log('File exists!')
  }
}

// ============================================================================
// 14. LIST ALL FILES
// ============================================================================
{
  // LIST ALL FILES RECURSIVELY
  const allFiles = vfs.listFilesRecursive('/')
  console.log(allFiles)

  // LIST FILES IN SPECIFIC FOLDER
  const srcFiles = vfs.listFilesRecursive('/src')

  // COUNT FILES
  const fileCount = vfs.listFilesRecursive('/').filter(r => r.node.type === 'file').length
}

// ============================================================================
// 15. RESET & CLEAR
// ============================================================================
{
  // FACTORY RESET (back to initial state)
  vfs.factoryReset()

  // CLEAR CACHE (usually not needed)
  vfs.clearCache()
}

// ============================================================================
// 16. REACT COMPONENT EXAMPLE (COMMENTED OUT TO PREVENT TSX ERRORS)
// ============================================================================

/*
import React, { useEffect, useState } from 'react'

export const FileExplorer: React.FC = () => {
  const [tree, setTree] = useState(vfs.getTree())
  const [stats, setStats] = useState(vfs.getStats())
  const [history, setHistory] = useState(vfs.getHistory())

  // Subscribe to changes
  useEffect(() => {
    const unsubscribe = vfs.subscribe((newTree, event) => {
      setTree(newTree)
      setStats(vfs.getStats())
      setHistory(vfs.getHistory())
      
      // Optional: Log event
      console.log(`VFS Event: ${event.type} at ${event.path}`)
    })

    return () => unsubscribe()
  }, [])

  // Create new file
  const handleCreateFile = (path: string) => {
    try {
      vfs.createFile(path, '')
    } catch (error) {
      console.error('Error creating file:', error)
    }
  }

  // Delete file
  const handleDelete = (path: string) => {
    vfs.deleteNode(path)
  }

  // Update file
  const handleUpdate = (path: string, content: string) => {
    vfs.updateFile(path, content)
  }

  return (
    <div>
      <h1>File Explorer</h1>
      
      {stats && (
        <div>
          <p>Files: {stats.totalFiles}</p>
          <p>Folders: {stats.totalFolders}</p>
          <p>Size: {(stats.totalSize / 1024).toFixed(2)} KB</p>
        </div>
      )}

      <div>
        <button onClick={() => vfs.canUndo() && vfs.undo()}>
          Undo {vfs.canUndo() ? '✓' : '✗'}
        </button>
        <button onClick={() => vfs.canRedo() && vfs.redo()}>
          Redo {vfs.canRedo() ? '✓' : '✗'}
        </button>
      </div>

      {renderTree(tree, handleDelete, handleUpdate)}
    </div>
  )
}

function renderTree(nodes: any[], onDelete: (path: string) => void, onUpdate: any) {
  return (
    <ul>
      {nodes.map(node => (
        <li key={node.name}>
          <span>{node.name}</span>
          <button onClick={() => onDelete(`/${node.name}`)}>Delete</button>
        </li>
      ))}
    </ul>
  )
}
*/

// ============================================================================
// 17. ADVANCED: SEARCH & REPLACE IN FILES
// ============================================================================
{
  const searchAndReplace = (searchTerm: string, replaceTerm: string) => {
    // Find all files containing search term
    const results = vfs.search(searchTerm, { searchContent: true })

    // Replace in each file
    results.forEach(result => {
      if (result.node.type === 'file' && result.node.content) {
        const updated = result.node.content.split(searchTerm).join(replaceTerm)
        vfs.updateFile(result.path, updated)
      }
    })

    console.log(`Replaced ${results.length} occurrences`)
  }

  // Usage
  searchAndReplace('oldFunction', 'newFunction')
}

// ============================================================================
// 18. ADVANCED: EXPORT SPECIFIC FOLDER
// ============================================================================
{
  const exportFolder = (folderPath: string, filename: string = 'export.json') => {
    const files = vfs.listFilesRecursive(folderPath)
    const data = JSON.stringify(files, null, 2)
    const blob = new Blob([data], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = filename
    link.click()
    URL.revokeObjectURL(url)
  }

  // Usage
  exportFolder('/src', 'src_backup.json')
}

// ============================================================================
// 19. ADVANCED: FILE METADATA
// ============================================================================
{
  // CREATE FILE WITH METADATA
  const fileWithMeta = vfs.createFile('/src/utils/math.ts', 'export const add = (a, b) => a + b', {
    tags: ['utility', 'math'],
    description: 'Math helper functions',
  })

  // Find node and check metadata
  const node = vfs.findNode('/src/utils/math.ts')
  console.log(node?.tags) // ['utility', 'math']
  console.log(node?.createdAt) // timestamp
  console.log(node?.modifiedAt) // timestamp
}
