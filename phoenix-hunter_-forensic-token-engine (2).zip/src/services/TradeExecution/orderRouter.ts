import { BackpackClient } from './backpackClient';
import { ExecutionService } from './executionService';
import { searchByMint } from './jupiterClient';
import { logger } from '../Infrastructure/observabilityService';
import { BackpackMarket } from './backpackTypes';

export interface RouteDecision {
  venue: 'backpack' | 'jupiter';
  reason: string;
  estimatedOutput: number;
  slippageBps: number;
  priceImpactPct: number;
  marketSymbol?: string;
  side?: 'Bid' | 'Ask';
  executeParams?: any;
}

interface TokenInfo {
  symbol: string;
  decimals: number;
}

export class OrderRouter {
  private backpack: BackpackClient;
  private jupiter: ExecutionService;
  private marketsCache: BackpackMarket[] | null = null;
  private tokenCache: Map<string, TokenInfo> = new Map([
    ['So11111111111111111111111111111111111111112', { symbol: 'SOL', decimals: 9 }],
    ['EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', { symbol: 'USDC', decimals: 6 }],
    ['Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB', { symbol: 'USDT', decimals: 6 }]
  ]);

  constructor(backpack: BackpackClient, jupiter: ExecutionService) {
    this.backpack = backpack;
    this.jupiter = jupiter;
  }

  async routeOrder(
    inputMint: string,
    outputMint: string,
    amountLamports: number, // Raw integer amount
    slippageBps: number = 50
  ): Promise<RouteDecision> {
    const startTime = Date.now();
    
    // 1. Get Jupiter Quote (Baseline)
    let jupiterQuote = null;
    let bestJupiterOutput = 0;
    try {
      jupiterQuote = await this.jupiter.estimateSwap(inputMint, outputMint, amountLamports);
      if (jupiterQuote && jupiterQuote.outputAmount) {
        bestJupiterOutput = parseInt(jupiterQuote.outputAmount);
      }
    } catch (e) {
      logger.log('Jupiter Quote Failed', 'warning', { error: e }, 1, 'orderRouter');
    }

    // 2. Check Backpack
    let backpackOutputRaw = 0;
    let backpackMarket: BackpackMarket | null = null;
    let backpackSide: 'Bid' | 'Ask' | undefined;
    let backpackError = '';

    try {
      const inputInfo = await this.resolveToken(inputMint);
      const outputInfo = await this.resolveToken(outputMint);

      if (inputInfo && outputInfo) {
        // Try to find market: BASE_QUOTE or QUOTE_BASE
        backpackMarket = await this.findBackpackMarket(inputInfo.symbol, outputInfo.symbol);
        
        if (backpackMarket) {
          const depth = await this.backpack.getDepth(backpackMarket.symbol);
          
          if (backpackMarket.baseSymbol === inputInfo.symbol) {
            // SELLING BASE (e.g. SOL -> USDC). We Sell to Bids.
            // Input is raw amount of Base.
            const inputAmountFloat = amountLamports / Math.pow(10, inputInfo.decimals);
            const quoteOutputFloat = this.simulateMarketSell(depth.bids, inputAmountFloat);
            
            // Output is Quote. Convert to integer.
            backpackOutputRaw = Math.floor(quoteOutputFloat * Math.pow(10, outputInfo.decimals));
            backpackSide = 'Ask';
            
          } else {
            // BUYING BASE (e.g. USDC -> SOL). We Buy from Asks.
            // Input is raw amount of Quote.
            const inputAmountFloat = amountLamports / Math.pow(10, inputInfo.decimals);
            const baseOutputFloat = this.simulateMarketBuy(depth.asks, inputAmountFloat);
            
            // Output is Base. Convert to integer.
            backpackOutputRaw = Math.floor(baseOutputFloat * Math.pow(10, outputInfo.decimals));
            backpackSide = 'Bid';
          }
        } else {
          backpackError = 'Pair not found';
        }
      } else {
        backpackError = 'Token info unresolved';
      }
    } catch (e: any) {
      backpackError = e.message;
    }

    // 3. Compare & Decide
    // Net output after estimated fees (Backpack ~0.1% Taker)
    const backpackNet = backpackOutputRaw * 0.999;
    
    // Logic: 
    // - If Backpack output is viable (>0) AND (Jupiter failed OR Backpack is better OR Backpack is close enough)
    // - "Close enough" defined as > 99.5% of Jupiter (sacrificing 0.5% for speed/centralization benefits on major pairs)
    const isBackpackCompetitive = bestJupiterOutput === 0 || (backpackNet >= bestJupiterOutput * 0.995);

    if (backpackMarket && backpackNet > 0 && isBackpackCompetitive) {
      const routeInfo: RouteDecision = {
        venue: 'backpack',
        reason: bestJupiterOutput === 0 ? 'Jupiter unavailable' : 'Backpack competitive execution',
        estimatedOutput: backpackNet,
        slippageBps: 10,
        priceImpactPct: 0,
        marketSymbol: backpackMarket.symbol,
        side: backpackSide
      };

      // Construct execution params for BackpackClient
      if (backpackSide === 'Ask') {
        // Selling Base: Quantity = Input Amount (Base)
        // Need to normalize to string float for API
        const inputInfo = await this.resolveToken(inputMint);
        routeInfo.executeParams = {
          symbol: backpackMarket.symbol,
          side: 'Ask',
          orderType: 'Market',
          quantity: (amountLamports / Math.pow(10, inputInfo!.decimals)).toString()
        };
      } else {
        // Buying Base: We have Input Amount (Quote).
        // Backpack Market Buy usually takes `quantity` (Base) OR `quoteQuantity` (Quote).
        // We will prefer `quoteQuantity` if supported, else estimate quantity.
        const inputInfo = await this.resolveToken(inputMint);
        routeInfo.executeParams = {
          symbol: backpackMarket.symbol,
          side: 'Bid',
          orderType: 'Market',
          quoteQuantity: (amountLamports / Math.pow(10, inputInfo!.decimals)).toString()
        };
      }
      
      logger.log(`Routing Result: BACKPACK [${backpackMarket.symbol}] vs JUPITER [Est: ${bestJupiterOutput}]`, 'info', {}, 1, 'orderRouter');
      return routeInfo;
    }

    // Default to Jupiter
    if (bestJupiterOutput > 0) {
      return {
        venue: 'jupiter',
        reason: backpackMarket ? 'Jupiter offers better price' : `Backpack unavailable (${backpackError})`,
        estimatedOutput: bestJupiterOutput,
        slippageBps,
        priceImpactPct: jupiterQuote?.priceImpactPct || 0
      };
    }

    throw new Error(`Routing failed: No liquidity on Backpack or Jupiter.`);
  }

  // --- Helpers ---

  private async resolveToken(mint: string): Promise<TokenInfo | null> {
    if (this.tokenCache.has(mint)) return this.tokenCache.get(mint)!;

    try {
      const token = await searchByMint(mint);
      if (token) {
        const info = { symbol: token.symbol.toUpperCase(), decimals: token.decimals };
        this.tokenCache.set(mint, info);
        return info;
      }
    } catch (e) { /* ignore */ }
    return null;
  }

  private async findBackpackMarket(symA: string, symB: string): Promise<BackpackMarket | undefined> {
    if (!this.marketsCache) {
      try {
        this.marketsCache = await this.backpack.getMarkets();
      } catch (e) { return undefined; }
    }
    
    // Check A_B or B_A
    return this.marketsCache.find(m => 
      (m.baseSymbol === symA && m.quoteSymbol === symB) || 
      (m.baseSymbol === symB && m.quoteSymbol === symA)
    );
  }

  private simulateMarketSell(bids: [string, string][], amountBase: number): number {
    let remaining = amountBase;
    let totalQuote = 0;
    
    for (const [priceStr, sizeStr] of bids) {
      const price = parseFloat(priceStr);
      const size = parseFloat(sizeStr);
      
      const fill = Math.min(remaining, size);
      totalQuote += fill * price;
      remaining -= fill;
      
      if (remaining <= 0) break;
    }
    return totalQuote;
  }

  private simulateMarketBuy(asks: [string, string][], amountQuote: number): number {
    let remainingQuote = amountQuote;
    let totalBase = 0;
    
    for (const [priceStr, sizeStr] of asks) {
      const price = parseFloat(priceStr);
      const size = parseFloat(sizeStr); // Base size
      
      const cost = size * price;
      if (cost <= remainingQuote) {
        totalBase += size;
        remainingQuote -= cost;
      } else {
        // Partial fill
        const fillSize = remainingQuote / price;
        totalBase += fillSize;
        remainingQuote = 0;
      }
      
      if (remainingQuote <= 0) break;
    }
    return totalBase;
  }
}