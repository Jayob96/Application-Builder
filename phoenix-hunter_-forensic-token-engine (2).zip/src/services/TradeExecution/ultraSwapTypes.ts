
export interface UltraSearchResponse {
  tokens: Array<{
    address: string;
    decimals: number;
    name: string;
    symbol: string;
    logoURI?: string;
    tags?: string[];
    daily_volume?: string;
    freezeAuthority?: string | null;
    mintAuthority?: string | null;
    permanent_delegate?: string | null;
    minted_at?: string;
    created_at?: string;
  }>;
}

export interface ShieldWarning {
  type:
    | 'NOT_VERIFIED'
    | 'LOW_ORGANIC_ACTIVITY'
    | 'NEW_LISTING'
    | 'HAS_FREEZE_AUTHORITY'
    | 'HAS_MINT_AUTHORITY'
    | 'PERMANENT_DELEGATE'
    | 'HONEYPOT'
    | 'BLACKLISTED';
  message: string;
  severity: 'info' | 'warning' | 'error';
}

export interface ShieldResponse {
  warnings: {
    [mint: string]: ShieldWarning[];
  };
}

export interface HoldingsToken {
  account: string;
  amount: string;
  uiAmount: number;
  uiAmountString: string;
  isFrozen: boolean;
  isAssociatedTokenAccount: boolean;
  decimals: number;
  programId: string;
}

export interface HoldingsResponse {
  amount: string; // Native SOL in lamports
  uiAmount: number;
  uiAmountString: string;
  tokens: {
    [mint: string]: HoldingsToken[];
  };
}

export interface OrderRequest {
  inputMint: string;
  outputMint: string;
  amount: number; // In smallest units
  taker: string;
  referralAccount?: string;
  referralFee?: number; // In basis points
}

export interface OrderResponse {
  transaction: string; // Base64 encoded
  requestId: string;
  swapType: string;
  slippageBps: number;
  inputAmount: string;
  outputAmount: string;
  priceImpactPct: number;
}

export interface ExecuteRequest {
  signedTransaction: string; // Base64 encoded
  requestId: string;
}

export interface ExecuteResponse {
  status: 'Success' | 'Failed' | 'Processing' | 'PartiallySucceeded';
  signature: string;
  inputAmount?: string;
  outputAmount?: string;
  timestamp?: number;
  error?: string;
}

export interface TradeExecution {
  requestId: string;
  inputMint: string;
  outputMint: string;
  inputAmount: number;
  expectedOutput: number;
  actualOutput?: number;
  status: 'PENDING' | 'SUCCESS' | 'FAILED' | 'EXPIRED';
  signature?: string;
  timestamp: number;
  completedAt?: number;
}
