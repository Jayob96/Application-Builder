
import { Keypair, PublicKey, VersionedTransaction } from '@solana/web3.js';
import { UltraSwapClient } from './ultraSwapClient';
import { logger } from '../Infrastructure/observabilityService';
import type { TradeExecution } from './ultraSwapTypes';

export class UltraSwapOrchestrator {
  private client: UltraSwapClient;
  private wallet: Keypair;
  private onTradeComplete: (trade: TradeExecution) => Promise<void>;

  constructor(
    apiKey: string,
    keypair: Keypair,
    callback: (trade: TradeExecution) => Promise<void>
  ) {
    this.client = new UltraSwapClient(apiKey);
    this.wallet = keypair;
    this.onTradeComplete = callback;
  }

  async executeSwap(params: {
    inputMint: string;
    outputMint: string;
    amountLamports: number;
  }): Promise<TradeExecution> {
    try {
      logger.log(`[Ultra] Initiating swap for ${params.outputMint}`, 'info', {}, 1, 'ultraSwap');

      // Security check
      const shield = await this.client.getShield([params.outputMint]);
      const warnings = shield.warnings[params.outputMint] || [];
      if (warnings.some(w => w.severity === 'error')) {
        throw new Error('Critical shield warning detected');
      }

      // Order
      const order = await this.client.getOrder({
        inputMint: params.inputMint,
        outputMint: params.outputMint,
        amount: params.amountLamports,
        taker: this.wallet.publicKey.toBase58(),
      });

      const trade: TradeExecution = {
        requestId: order.requestId,
        inputMint: params.inputMint,
        outputMint: params.outputMint,
        inputAmount: params.amountLamports,
        expectedOutput: parseInt(order.outputAmount),
        status: 'PENDING',
        timestamp: Date.now(),
      };

      // Sign
      const txBuffer = Uint8Array.from(atob(order.transaction), c => c.charCodeAt(0));
      const tx = VersionedTransaction.deserialize(txBuffer);
      tx.sign([this.wallet]);
      const signedTx = btoa(String.fromCharCode.apply(null, Array.from(tx.serialize())));

      // Execute & Poll
      const result = await this.client.pollExecutionStatus(signedTx, order.requestId);

      trade.actualOutput = parseInt(result.outputAmount || '0');
      trade.signature = result.signature;
      trade.status = result.status === 'Success' ? 'SUCCESS' : 'FAILED';
      trade.completedAt = Date.now();

      await this.onTradeComplete(trade);
      return trade;
    } catch (err: any) {
      logger.log(`[Ultra] Swap failed: ${err.message}`, 'error', { err }, 4, 'ultraSwap');
      throw err;
    }
  }

  recordVolume(volumeUsd: number) {
    this.client.updateQuotaFromVolume(volumeUsd);
  }

  getQuotaStatus() {
    return this.client.getQuotaStatus();
  }
}
