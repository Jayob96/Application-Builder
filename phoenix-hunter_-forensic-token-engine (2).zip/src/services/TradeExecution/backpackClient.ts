import nacl from "tweetnacl";
import { logger } from "../Infrastructure/observabilityService";

/**
 * Order types supported by Backpack
 */
export type OrderType = "Limit" | "Market";
export type OrderSide = "Bid" | "Ask";
export type TimeInForce = "GTC" | "IOC" | "FOK" | "PO";

/**
 * Order response from Backpack
 */
export interface Order {
  orderId: string;
  clientId?: string;
  symbol: string;
  side: OrderSide;
  orderType: OrderType;
  price?: string;
  quantity: string;
  filledQuantity: string;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
}

/**
 * Order status enum
 */
export enum OrderStatus {
  New = "New",
  PartiallyFilled = "PartiallyFilled",
  Filled = "Filled",
  Cancelled = "Cancelled",
  Expired = "Expired",
  Rejected = "Rejected"
}

/**
 * Account information
 */
export interface AccountInfo {
  username: string;
  email?: string;
  balances: Balance[];
  borrowLimit: string;
  positionLimit: number;
  spotMakerFee: string;
  spotTakerFee: string;
}

/**
 * Balance entry
 */
export interface Balance {
  asset: string;
  total: string;
  available: string;
  locked: string;
}

/**
 * Fill/Trade record
 */
export interface Fill {
  tradeId: string;
  orderId: string;
  symbol: string;
  side: OrderSide;
  price: string;
  quantity: string;
  fee: string;
  feeSymbol: string;
  timestamp: string;
  executedQuantity: string;
  id: string;
}

/**
 * Backpack API Client
 */
export class BackpackClient {
  private static readonly BASE_URL = "https://api.backpack.exchange";
  private publicKey: string = ""; 
  private privateKey: Uint8Array = new Uint8Array(64); 
  private apiKey: string = ""; 
  private isConfigured: boolean = false;

  constructor(privateKeyBase64: string) {
    if (!privateKeyBase64 || privateKeyBase64.trim() === "") {
      logger.log(
        "[Backpack] No Private Key configured. Execution disabled.",
        "warning",
        {},
        1,
        "backpackClient"
      );
      return;
    }

    try {
      // Decode the base64 private key
      this.privateKey = this.decodeBase64(privateKeyBase64);

      if (this.privateKey.length !== 64) {
        throw new Error(`Invalid key size: ${this.privateKey.length} bytes (expected 64). Check if Base64.`);
      }

      // Derive the public key from the private key
      const keypair = nacl.sign.keyPair.fromSecretKey(this.privateKey);
      this.publicKey = this.encodeBase64(keypair.publicKey);
      this.apiKey = this.publicKey;
      this.isConfigured = true;

      logger.log(
        "[Backpack] Core: ED25519 Engine Initialized",
        "success",
        { publicKey: this.publicKey.slice(0, 12) + "..." },
        1,
        "backpackClient"
      );
    } catch (e: any) {
      this.isConfigured = false;
      this.privateKey = new Uint8Array(64);
      this.publicKey = "";
      this.apiKey = "";
      logger.log(`[Backpack] Key Init Failed: ${e.message}`, "error", {}, 2, "backpackClient");
    }
  }

  private decodeBase64(base64: string): Uint8Array {
    try {
      const binaryString = atob(base64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      return bytes;
    } catch (e) {
      throw new Error("Failed to decode Base64 string");
    }
  }

  private encodeBase64(bytes: Uint8Array): string {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  /**
   * Generate signature for a request
   */
  private generateSignature(
    instruction: string,
    params: Record<string, any>,
    timestamp: number,
    window: number = 5000
  ): string {
    if (!this.isConfigured) return "";

    // Alphabetical param sorting for canonical signature string
    const sortedParams = Object.keys(params)
      .sort()
      .map((key) => `${key}${params[key]}`)
      .join("");

    const signingString = `instruction=${instruction}${sortedParams ? '&' + sortedParams : ''}&timestamp=${timestamp}&window=${window}`;
    const messageBytes = new TextEncoder().encode(signingString);
    const signatureBytes = nacl.sign.detached(messageBytes, this.privateKey);
    return this.encodeBase64(signatureBytes);
  }

  /**
   * Make an authenticated API request
   */
  private async request<T>(
    endpoint: string,
    method: "GET" | "POST" | "PATCH" | "DELETE",
    instruction: string,
    params: Record<string, any> = {}
  ): Promise<T | null> {
    if (!this.isConfigured) {
      // Fail silently or log once? Logging might be spammy if polling.
      return null;
    }

    const timestamp = Date.now();
    const window = 5000;

    const signature = this.generateSignature(
      instruction,
      params,
      timestamp,
      window
    );

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      "X-API-Key": this.apiKey,
      "X-Signature": signature,
      "X-Timestamp": timestamp.toString(),
      "X-Window": window.toString()
    };

    let url = `${BackpackClient.BASE_URL}${endpoint}`;
    
    try {
      const fetchOptions: RequestInit = {
        method,
        headers
      };

      if (method !== "GET") {
        fetchOptions.body = JSON.stringify(params);
      } else if (Object.keys(params).length > 0) {
        const query = new URLSearchParams(params as any).toString();
        url = `${url}?${query}`;
      }

      const response = await fetch(url, fetchOptions);

      if (!response.ok) {
        const error = await response.json();
        logger.log(`[Backpack] Error ${response.status}: ${error.message || 'Unknown'}`, "error", { endpoint }, 3, "backpackClient");
        return null;
      }

      return (await response.json()) as T;
    } catch (error: any) {
      logger.log(`[Backpack] Critical Failure: ${error.message}`, "error", { endpoint }, 4, "backpackClient");
      return null;
    }
  }

  async getAccount(): Promise<AccountInfo | null> {
    return this.request<AccountInfo>("/api/v1/account", "GET", "accountQuery");
  }

  async buyOrder(symbol: string, quantity: string, price?: string): Promise<Order | null> {
    const params: Record<string, any> = {
      symbol,
      side: "Bid",
      orderType: price ? "Limit" : "Market",
      quantity
    };
    if (price) params.price = price;

    return this.request<Order>("/api/v1/order", "POST", "orderExecute", params);
  }

  async sellOrder(symbol: string, quantity: string, price?: string): Promise<Order | null> {
    const params: Record<string, any> = {
      symbol,
      side: "Ask",
      orderType: price ? "Limit" : "Market",
      quantity
    };
    if (price) params.price = price;

    return this.request<Order>("/api/v1/order", "POST", "orderExecute", params);
  }

  async getOrder(orderId: string, symbol: string): Promise<Order | null> {
    return this.request<Order>("/api/v1/order", "GET", "orderQuery", { orderId, symbol });
  }

  async cancelOrder(orderId: string, symbol: string): Promise<boolean> {
    const result = await this.request<{ status: string }>("/api/v1/order", "DELETE", "orderCancel", { orderId, symbol });
    return result?.status === "Cancelled";
  }

  async pollOrderUntilFilled(orderId: string, symbol: string, maxPolls: number = 20): Promise<Order | null> {
    for (let i = 0; i < maxPolls; i++) {
      const order = await this.getOrder(orderId, symbol);
      if (!order) return null;
      if ([OrderStatus.Filled, OrderStatus.Cancelled, OrderStatus.Expired].includes(order.status)) return order;
      await new Promise(r => setTimeout(r, 1500));
    }
    return null;
  }

  // Missing methods for OrderRouter and TradeExecutor
  async getDepth(symbol: string): Promise<{ asks: [string, string][], bids: [string, string][] }> {
    // Public endpoint, does not require auth
    try {
      const res = await fetch(`${BackpackClient.BASE_URL}/api/v1/depth?symbol=${symbol}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (e: any) {
      throw new Error(`Depth fetch failed: ${e.message}`);
    }
  }

  async getMarkets(): Promise<any[]> {
    // Public endpoint
    try {
      const res = await fetch(`${BackpackClient.BASE_URL}/api/v1/markets`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (e: any) {
      throw new Error(`Markets fetch failed: ${e.message}`);
    }
  }

  async executeOrder(params: any): Promise<Order> {
    const result = await this.request<Order>("/api/v1/order", "POST", "orderExecute", params);
    if (!result) throw new Error("Order execution failed");
    return result;
  }

  async pollOrder(orderId: string, symbol: string): Promise<Fill> {
    const order = await this.pollOrderUntilFilled(orderId, symbol);
    if (!order) throw new Error("Order not found during poll");
    return {
      id: order.orderId,
      tradeId: order.orderId,
      orderId: order.orderId,
      symbol: order.symbol,
      side: order.side,
      price: order.price || "0",
      quantity: order.quantity,
      executedQuantity: order.filledQuantity,
      fee: "0",
      feeSymbol: "USDC",
      timestamp: order.createdAt
    };
  }
}

// Singleton Instance
const BACKPACK_PRIVATE_KEY = (import.meta as any).env?.VITE_BACKPACK_PRIVATE_KEY || process.env.BACKPACK_PRIVATE_KEY;
export const backpackClient = new BackpackClient(BACKPACK_PRIVATE_KEY || "");