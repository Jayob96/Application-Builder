
// services/jupiterClient.ts
// Complete Jupiter Tokens API V2 (Beta) client with circuit breaker, caching, and forensic integration

import { logger } from "../Infrastructure/observabilityService";

/**
 * JupiterTokenV2 - Complete token metadata structure from Jupiter API
 */
export interface JupiterTokenV2 {
  id: string;
  name: string;
  symbol: string;
  icon: string;
  decimals: number;
  circSupply: number;
  totalSupply: number;
  tokenProgram: string;
  firstPool: { id: string; createdAt: string };
  holderCount: number;
  audit: {
    mintAuthorityDisabled: boolean;
    freezeAuthorityDisabled: boolean;
    topHoldersPercentage: number;
  };
  organicScore: number;
  organicScoreLabel: "low" | "medium" | "high" | "very high";
  isVerified: boolean;
  cexes: string[];
  tags: string[];
  fdv: number;
  mcap: number;
  usdPrice: number;
  liquidity: number;
  stats5m: TokenStats;
  stats1h: TokenStats;
  stats6h: TokenStats;
  stats24h: TokenStats;
  updatedAt: string;
}

/**
 * TokenStats - Temporal price/volume metrics
 */
export interface TokenStats {
  priceChange: number;
  liquidityChange: number;
  volumeChange: number;
  buyVolume: number;
  sellVolume: number;
  buyOrganicVolume: number;
  sellOrganicVolume: number;
  numBuys: number;
  numSells: number;
  numTraders: number;
  numOrganicBuyers: number;
  numNetBuyers: number;
}

/**
 * JupiterSearchResult - Paginated search response
 */
export interface JupiterSearchResult {
  data: JupiterTokenV2[];
  pageNumber: number;
  pageSize: number;
  totalResults: number;
}

/**
 * JupiterTagResponse - Tag-based token query response
 */
export interface JupiterTagResponse {
  data: JupiterTokenV2[];
  tag: string;
}

/**
 * JupiterCategoryResponse - Category-based token query response
 */
export interface JupiterCategoryResponse {
  data: JupiterTokenV2[];
  category: string;
  interval: string;
}

/**
 * Circuit breaker configuration
 */
interface CircuitBreakerState {
  isOpen: boolean;
  resetTime: number;
  failureCount: number;
  successCount: number;
}

/**
 * Cache entry with TTL
 */
interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number;
}

// ============================================================================
// CIRCUIT BREAKER & RATE LIMITING
// ============================================================================

class JupiterCircuitBreaker {
  private state: CircuitBreakerState = {
    isOpen: false,
    resetTime: 0,
    failureCount: 0,
    successCount: 0
  };

  private readonly FAILURE_THRESHOLD = 5;
  private readonly SUCCESS_THRESHOLD = 3;
  private readonly BACKOFF_DURATION = 30000; // Reduced from 2m to 30s for faster recovery
  private readonly HALF_OPEN_TIMEOUT = 10000; // Reduced from 30s to 10s

  isAvailable(): boolean {
    if (!this.state.isOpen) return true;

    if (Date.now() > this.state.resetTime) {
      this.state.isOpen = false;
      this.state.failureCount = 0;
      this.state.successCount = 0;
      logger.log(
        "[Jupiter] Circuit breaker reset. Resuming API calls.",
        "info",
        {},
        1,
        "jupiterClient"
      );
      return true;
    }

    return false;
  }

  recordSuccess(): void {
    this.state.successCount++;
    if (this.state.successCount >= this.SUCCESS_THRESHOLD && this.state.isOpen) {
      this.state.isOpen = false;
      this.state.failureCount = 0;
      this.state.successCount = 0;
      logger.log(
        "[Jupiter] Circuit breaker recovered after successful requests.",
        "info",
        { recoveryCount: this.state.successCount },
        1,
        "jupiterClient"
      );
    }
  }

  recordFailure(statusCode?: number): void {
    this.state.failureCount++;

    if (statusCode === 401) {
      // Unauthorized - permanent circuit open
      this.state.isOpen = true;
      this.state.resetTime = Date.now() + this.BACKOFF_DURATION;
      logger.log(
        `[Jupiter] 401 Unauthorized detected. Circuit open for ${this.BACKOFF_DURATION / 1000}s.`,
        "error",
        { statusCode },
        3,
        "jupiterClient"
      );
      return;
    }

    if (this.state.failureCount >= this.FAILURE_THRESHOLD) {
      this.state.isOpen = true;
      this.state.resetTime = Date.now() + this.HALF_OPEN_TIMEOUT;
      logger.log(
        `[Jupiter] Failure threshold reached (${this.state.failureCount}/${this.FAILURE_THRESHOLD}). Circuit open for ${this.HALF_OPEN_TIMEOUT / 1000}s.`,
        "warning",
        { failureCount: this.state.failureCount, statusCode },
        2,
        "jupiterClient"
      );
    }
  }

  getState() {
    return { ...this.state };
  }
}

// ============================================================================
// RESPONSE CACHING
// ============================================================================

class JupiterCache {
  private cache: Map<string, CacheEntry<any>> = new Map();
  private readonly DEFAULT_TTL = 15000; // Reduced from 60s to 15s for live data

  get<T>(key: string): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;

    if (Date.now() - entry.timestamp > entry.ttl) {
      this.cache.delete(key);
      return null;
    }

    return entry.data as T;
  }

  set<T>(key: string, data: T, ttl: number = this.DEFAULT_TTL): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
  }

  clear(): void {
    this.cache.clear();
  }

  size(): number {
    return this.cache.size;
  }
}

// ============================================================================
// JUPITER CLIENT
// ============================================================================

export class JupiterClient {
  private static BASE_URL = "https://api.jup.ag/tokens/v2";
  private static REQUEST_TIMEOUT = 60000; // 60 seconds

  private circuitBreaker: JupiterCircuitBreaker;
  private cache: JupiterCache;
  private apiKey?: string;
  private requestQueue: Promise<void> = Promise.resolve();
  private rateLimitDelay = 200; // ms between requests

  constructor(apiKey?: string) {
    this.apiKey = apiKey;
    this.circuitBreaker = new JupiterCircuitBreaker();
    this.cache = new JupiterCache();

    logger.log(
      "[Jupiter] Client initialized",
      "info",
      { hasApiKey: !!apiKey, baseUrl: JupiterClient.BASE_URL },
      1,
      "jupiterClient"
    );
  }

  /**
   * Rate limit with async queue
   */
  private async rateLimit(): Promise<void> {
    return new Promise((resolve) => {
      this.requestQueue = this.requestQueue.then(
        () =>
          new Promise((res) => {
            setTimeout(res, this.rateLimitDelay);
          })
      );
      this.requestQueue.then(resolve);
    });
  }

  /**
   * Fetch wrapper with circuit breaker, timeout, retry, and error handling
   */
  private async fetch(
    url: string,
    options: RequestInit = {},
    retries = 2
  ): Promise<Response | null> {
    if (!this.circuitBreaker.isAvailable()) {
      logger.log(
        "[Jupiter] Circuit breaker open, request blocked",
        "warning",
        { url },
        2,
        "jupiterClient"
      );
      return null;
    }

    await this.rateLimit();

    const headers: Record<string, string> = {
      Accept: "application/json",
      ...((options.headers as Record<string, string>) || {})
    };

    if (this.apiKey) {
      headers["x-api-key"] = this.apiKey;
    }

    for (let attempt = 0; attempt <= retries; attempt++) {
        const controller = new AbortController();
        const timeoutId = setTimeout(
          () => controller.abort(),
          JupiterClient.REQUEST_TIMEOUT
        );

        try {
            const res = await fetch(url, {
                ...options,
                headers,
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (res.ok) {
                this.circuitBreaker.recordSuccess();
                return res;
            } else if (res.status === 401) {
                this.circuitBreaker.recordFailure(401);
                return null;
            } else if (res.status < 500 && res.status !== 429) {
                // Client errors (4xx) - usually no point retrying (except 429)
                this.circuitBreaker.recordFailure(res.status);
                logger.log(`[Jupiter] API Error ${res.status}`, "warning", { url }, 2, "jupiterClient");
                return res; 
            }

            // Retry on 5xx or 429
            if (attempt === retries) {
                this.circuitBreaker.recordFailure(res.status);
                logger.log(`[Jupiter] Failed after ${retries + 1} attempts: ${res.status}`, "error", { url }, 3, "jupiterClient");
                return res;
            }

            // Backoff before retry
            const backoff = 1000 * Math.pow(2, attempt);
            await new Promise(r => setTimeout(r, backoff));

        } catch (error: any) {
            clearTimeout(timeoutId);
            const isAbort = error.name === "AbortError";
            
            if (attempt === retries) {
                this.circuitBreaker.recordFailure();
                const errorMsg = isAbort ? "Request timeout" : (error?.message || String(error));
                logger.log(
                    `[Jupiter] Fetch error: ${errorMsg}`,
                    "error",
                    { url, error: errorMsg },
                    3,
                    "jupiterClient"
                );
                return null;
            }

            const backoff = 1000 * Math.pow(2, attempt);
            await new Promise(r => setTimeout(r, backoff));
        }
    }
    return null;
  }

  /**
   * Search for tokens by mint, symbol, or name
   * Supports pagination
   */
  async search(
    query: string,
    pageNumber: number = 1,
    pageSize: number = 10
  ): Promise<JupiterSearchResult | null> {
    const cacheKey = `search:${query}:${pageNumber}:${pageSize}`;
    const cached = this.cache.get<JupiterSearchResult>(cacheKey);
    if (cached) {
      logger.log(
        "[Jupiter] Search cache hit",
        "info",
        { query, cacheKey },
        0,
        "jupiterClient"
      );
      return cached;
    }

    const url = new URL(`${JupiterClient.BASE_URL}/search`);
    url.searchParams.append("query", query);
    url.searchParams.append("pageNumber", pageNumber.toString());
    url.searchParams.append("pageSize", pageSize.toString());

    const res = await this.fetch(url.toString());
    if (!res || !res.ok) return null;

    try {
      const data = await res.json();
      this.cache.set(cacheKey, data, 15000); // 15 second TTL for search
      return data as JupiterSearchResult;
    } catch (error) {
      logger.log(
        "[Jupiter] Search parse error",
        "error",
        { query, error: (error as Error).message },
        3,
        "jupiterClient"
      );
      return null;
    }
  }

  /**
   * Get a single token by mint (convenience method)
   */
  async getByMint(mint: string): Promise<JupiterTokenV2 | null> {
    const cacheKey = `mint:${mint}`;
    const cached = this.cache.get<JupiterTokenV2>(cacheKey);
    if (cached) {
      return cached;
    }

    const result = await this.search(mint, 1, 1);
    if (!result || result.data.length === 0) {
      logger.log(
        "[Jupiter] Token not found",
        "warning",
        { mint },
        2,
        "jupiterClient"
      );
      return null;
    }

    const token = result.data[0];
    this.cache.set(cacheKey, token, 30000); // 30 second TTL for individual tokens
    return token;
  }

  /**
   * Get recently created tokens
   */
  async getRecent(limit: number = 30): Promise<JupiterTokenV2[]> {
    const cacheKey = `recent:${limit}`;
    const cached = this.cache.get<JupiterTokenV2[]>(cacheKey);
    if (cached) {
      logger.log(
        "[Jupiter] Recent tokens cache hit",
        "info",
        { limit, cacheKey },
        0,
        "jupiterClient"
      );
      return cached;
    }

    const url = new URL(`${JupiterClient.BASE_URL}/recent`);
    url.searchParams.append("limit", limit.toString());

    const res = await this.fetch(url.toString());
    if (!res || !res.ok) return [];

    try {
      const data = await res.json();
      const tokens = Array.isArray(data) ? data : data.data || [];
      this.cache.set(cacheKey, tokens, 10000); // Reduced to 10s for live ingestion
      return tokens as JupiterTokenV2[];
    } catch (error) {
      logger.log(
        "[Jupiter] Recent tokens parse error",
        "error",
        { limit, error: (error as Error).message },
        3,
        "jupiterClient"
      );
      return [];
    }
  }

  /**
   * Get tokens by tag (e.g., "pump-fun", "meme")
   */
  async getByTag(tag: string): Promise<JupiterTokenV2[]> {
    const cacheKey = `tag:${tag}`;
    const cached = this.cache.get<JupiterTokenV2[]>(cacheKey);
    if (cached) {
      return cached;
    }

    const url = new URL(`${JupiterClient.BASE_URL}/tag`);
    url.searchParams.append("tag", tag);

    const res = await this.fetch(url.toString());
    if (!res || !res.ok) return [];

    try {
      const data = await res.json();
      const tokens = Array.isArray(data) ? data : data.data || [];
      this.cache.set(cacheKey, tokens, 30000); // 30s TTL
      return tokens as JupiterTokenV2[];
    } catch (error) {
      logger.log(
        "[Jupiter] Tag query parse error",
        "error",
        { tag, error: (error as Error).message },
        3,
        "jupiterClient"
      );
      return [];
    }
  }

  /**
   * Get tokens by category and interval
   */
  async getByCategory(
    category: string,
    interval: string = "1h"
  ): Promise<JupiterTokenV2[]> {
    const cacheKey = `category:${category}:${interval}`;
    const cached = this.cache.get<JupiterTokenV2[]>(cacheKey);
    if (cached) {
      return cached;
    }

    const url = new URL(`${JupiterClient.BASE_URL}/category`);
    url.searchParams.append("category", category);
    url.searchParams.append("interval", interval);

    const res = await this.fetch(url.toString());
    if (!res || !res.ok) return [];

    try {
      const data = await res.json();
      const tokens = Array.isArray(data) ? data : data.data || [];
      this.cache.set(cacheKey, tokens, 30000); // 30s TTL
      return tokens as JupiterTokenV2[];
    } catch (error) {
      logger.log(
        "[Jupiter] Category query parse error",
        "error",
        { category, interval, error: (error as Error).message },
        3,
        "jupiterClient"
      );
      return [];
    }
  }

  async getTrending(): Promise<JupiterTokenV2[]> {
    return this.getByCategory("trending", "1h");
  }

  async getTopGainers(): Promise<JupiterTokenV2[]> {
    return this.getByCategory("top-gainers", "1h");
  }

  async getTopLosers(): Promise<JupiterTokenV2[]> {
    return this.getByCategory("top-losers", "1h");
  }

  static toForensicToken(token: JupiterTokenV2) {
    return {
      mint: token.id,
      symbol: token.symbol,
      name: token.name,
      liquidity: token.liquidity,
      marketCap: token.mcap,
      holders: token.holderCount,
      contractVerified: token.isVerified,
      discoverySource: "jupiter" as const,
      mintAuthority: !token.audit.mintAuthorityDisabled,
      freezeAuthority: !token.audit.freezeAuthorityDisabled,
      holderConcentration: token.audit.topHoldersPercentage / 100,
      devKYC: token.isVerified,
      isOrganic: token.organicScore >= 0.7,
      buyTax: 0,
      sellTax: 0,
      organicScore: token.organicScore,
      price: token.usdPrice,
      fdv: token.fdv,
      audit: token.audit,
      stats24h: token.stats24h,
      icon: token.icon
    };
  }

  getCircuitBreakerStatus() {
    return this.circuitBreaker.getState();
  }

  getCacheStats() {
    return {
      size: this.cache.size(),
      hitRate: "N/A"
    };
  }

  clearCache(): void {
    this.cache.clear();
    logger.log("[Jupiter] Cache cleared", "info", {}, 1, "jupiterClient");
  }
}

const env = (import.meta as any).env || {};
const apiKey = env.VITE_JUPITER_API_KEY || process.env.JUPITER_API_KEY || "982b8f12-e54f-47dc-b632-06b00361943e";

export const jupiterClient = new JupiterClient(apiKey);
export const searchByMint = (mint: string) => jupiterClient.getByMint(mint);
export const getRecent = (limit: number = 30) => jupiterClient.getRecent(limit);
