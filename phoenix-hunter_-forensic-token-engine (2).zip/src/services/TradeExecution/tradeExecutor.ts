import { Keypair } from '@solana/web3.js';
import { BackpackClient } from './backpackClient';
import { ExecutionService } from './executionService';
import { OrderRouter, RouteDecision } from './orderRouter';
import { TradeHistoryService } from './tradeHistoryService';
import { logger } from '../Infrastructure/observabilityService';
import { Position } from '../../types';
import { storageService } from '../Infrastructure/storageService';

export interface TradeRequest {
  inputMint: string;
  outputMint: string;
  amountLamports: number;
  maxSlippageBps: number;
  wallet: Keypair;
  symbol: string; 
}

export interface TradeConfirmation {
  venue: 'backpack' | 'jupiter';
  signature?: string;
  orderId?: string;
  inputAmount: number;
  outputAmount: number;
  price: number;
  status: 'SUCCESS' | 'FAILED';
  error?: string;
}

export class TradeExecutor {
  constructor(
    private router: OrderRouter,
    private backpack: BackpackClient,
    private jupiter: ExecutionService,
    private history: TradeHistoryService
  ) {}

  async executeTrade(request: TradeRequest): Promise<TradeConfirmation> {
    logger.log(`Initiating Trade Sequence for ${request.symbol}...`, 'info', { amount: request.amountLamports }, 1, 'tradeExecutor');

    let route: RouteDecision;
    try {
      route = await this.router.routeOrder(
        request.inputMint,
        request.outputMint,
        request.amountLamports,
        request.maxSlippageBps
      );
    } catch (e: any) {
      logger.log(`Routing failed: ${e.message}`, 'error', {}, 3, 'tradeExecutor');
      return { 
        venue: 'jupiter', 
        status: 'FAILED', 
        inputAmount: request.amountLamports, 
        outputAmount: 0, 
        price: 0, 
        error: `Routing Error: ${e.message}` 
      };
    }

    let confirmation: TradeConfirmation;
    if (route.venue === 'backpack') {
      confirmation = await this.executeOnBackpack(route, request);
    } else {
      confirmation = await this.executeOnJupiter(route, request);
    }

    if (confirmation.status === 'SUCCESS') {
      const loggedTrade = {
        id: confirmation.signature || confirmation.orderId || 'unknown',
        symbol: request.symbol,
        side: (request.inputMint === "So11111111111111111111111111111111111111112" ? 'Buy' : 'Sell') as 'Buy' | 'Sell',
        price: confirmation.price,
        quantity: confirmation.outputAmount,
        fee: 0,
        timestamp: Date.now(),
        venue: (route.venue === 'backpack' ? 'Backpack' : 'Jupiter') as 'Backpack' | 'Jupiter'
      };

      this.history.logManualTrade(loggedTrade);
      
      // SYNC TO SPREADSHEET
      storageService.syncTrade(loggedTrade, 0); 

      logger.log(`Trade Finalized via ${route.venue.toUpperCase()}`, 'success', { ...confirmation }, 2, 'tradeExecutor');
    }

    return confirmation;
  }

  async closePosition(position: Position, reason: string, wallet: Keypair): Promise<TradeConfirmation> {
    const SOL_MINT = "So11111111111111111111111111111111111111112";
    const amountLamports = Math.floor(position.amountTokens * Math.pow(10, position.decimals));

    logger.log(`Closing position ${position.symbol}: ${reason}`, 'warning', {}, 1, 'tradeExecutor');

    const request: TradeRequest = {
        inputMint: position.mint,
        outputMint: SOL_MINT,
        amountLamports: amountLamports,
        maxSlippageBps: 100, 
        wallet: wallet,
        symbol: position.symbol
    };

    const result = await this.executeTrade(request);
    
    if (result.status === 'SUCCESS') {
        const loggedTrade = {
            id: result.signature || result.orderId || 'unknown',
            symbol: position.symbol,
            side: 'Sell' as 'Sell',
            price: result.price,
            quantity: position.amountTokens,
            fee: 0,
            timestamp: Date.now(),
            venue: (result.venue === 'backpack' ? 'Backpack' : 'Jupiter') as 'Backpack' | 'Jupiter'
        };

        this.history.logManualTrade(loggedTrade);

        // SYNC TO SPREADSHEET WITH FINAL PNL
        storageService.syncTrade(loggedTrade, position.pnl);
    }

    return result;
  }

  private async executeOnBackpack(route: RouteDecision, request: TradeRequest): Promise<TradeConfirmation> {
    try {
      if (!route.executeParams) throw new Error("Invalid route params for Backpack");
      logger.log(`Submitting Order to Backpack Exchange...`, 'info', {}, 1, 'tradeExecutor');
      const order = await this.backpack.executeOrder(route.executeParams);
      // Fix: order.id -> order.orderId based on BackpackClient definition
      logger.log(`Polling for fill (Order: ${order.orderId})...`, 'info', {}, 1, 'tradeExecutor');
      const fill = await this.backpack.pollOrder(order.orderId, order.symbol);

      const outputQty = parseFloat(fill.executedQuantity);
      const price = fill.price ? parseFloat(fill.price) : (outputQty > 0 ? (request.amountLamports / 1e9) / outputQty : 0);

      return {
        venue: 'backpack',
        status: 'SUCCESS',
        orderId: fill.id,
        inputAmount: request.amountLamports,
        outputAmount: outputQty,
        price: price
      };
    } catch (e: any) {
      logger.log(`Backpack Execution Error: ${e.message}`, 'error', {}, 3, 'tradeExecutor');
      return {
        venue: 'backpack',
        status: 'FAILED',
        inputAmount: request.amountLamports,
        outputAmount: 0,
        price: 0,
        error: e.message
      };
    }
  }

  private async executeOnJupiter(route: RouteDecision, request: TradeRequest): Promise<TradeConfirmation> {
    try {
      logger.log(`Swapping on Jupiter...`, 'info', {}, 1, 'tradeExecutor');
      const res = await this.jupiter.executeBuySwap({
        inputMint: request.inputMint,
        outputMint: request.outputMint,
        amountLamports: request.amountLamports,
        slippageBps: request.maxSlippageBps,
        userPublicKey: request.wallet.publicKey,
        userKeypair: request.wallet
      });
      if (!res.success) throw new Error(res.error);
      return {
        venue: 'jupiter',
        status: 'SUCCESS',
        signature: res.signature,
        inputAmount: request.amountLamports,
        outputAmount: res.amountOut || route.estimatedOutput,
        price: res.estimatedPrice || 0
      };
    } catch (e: any) {
      logger.log(`Jupiter Execution Error: ${e.message}`, 'error', {}, 3, 'tradeExecutor');
      return {
        venue: 'jupiter',
        status: 'FAILED',
        inputAmount: request.amountLamports,
        outputAmount: 0,
        price: 0,
        error: e.message
      };
    }
  }
}