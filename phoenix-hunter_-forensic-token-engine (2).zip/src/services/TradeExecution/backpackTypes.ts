
export type Side = 'Bid' | 'Ask';
export type OrderType = 'Limit' | 'Market';
export type TimeInForce = 'GTC' | 'IOC' | 'FOK';
export type SelfTradePrevention = 'RejectTaker' | 'RejectMaker' | 'RejectBoth' | 'Allow';

export interface BackpackMarket {
  symbol: string;
  baseSymbol: string;
  quoteSymbol: string;
  filters: {
    quantity: {
      min: string;
      max: string;
      step: string;
    };
    price: {
      min: string;
      max: string;
      tickSize: string;
    };
  };
}

export interface BackpackTicker {
  symbol: string;
  firstPrice: string;
  lastPrice: string;
  priceChange: string;
  priceChangePercent: string;
  high: string;
  low: string;
  volume: string;
  quoteVolume: string;
  trades: number;
}

export interface BackpackBalance {
  available: string;
  locked: string;
  staked: string;
}

export interface BackpackAccount {
  balances: Record<string, BackpackBalance>;
}

export interface BackpackCapital {
  balances: Record<string, BackpackBalance>;
  collateral: string;
  leverage: string;
}

export interface ExecuteOrderParams {
  symbol: string;
  side: Side;
  orderType: OrderType;
  price?: string;
  quantity?: string;
  quoteQuantity?: string;
  executedQuantity?: string;
  timeInForce?: TimeInForce;
  selfTradePrevention?: SelfTradePrevention;
  clientId?: number;
  postOnly?: boolean;
}

export interface BackpackOrder {
  id: string;
  clientId?: number;
  symbol: string;
  side: Side;
  orderType: OrderType;
  price?: string;
  quantity: string;
  executedQuantity: string;
  quoteQuantity?: string;
  executedQuoteQuantity?: string;
  timeInForce: TimeInForce;
  selfTradePrevention: SelfTradePrevention;
  status: 'New' | 'PartiallyFilled' | 'Filled' | 'Canceled' | 'Expired';
  createdAt: number;
}

export interface BackpackFill {
  id: string;
  tradeId: string;
  orderId: string;
  symbol: string;
  price: string;
  quantity: string;
  fee: string;
  feeSymbol: string;
  isMaker: boolean;
  side: Side;
  timestamp: number;
}

export interface BackpackDepth {
  asks: [string, string][]; // [price, quantity]
  bids: [string, string][];
  lastUpdateId: string;
}

export interface BackpackKLine {
  start: string;
  open: string;
  high: string;
  low: string;
  close: string;
  volume: string;
  end: string;
  trades: string;
}

export interface PnLMetrics {
  realizedPnL: number;
  unrealizedPnL: number;
  volume: number;
  trades: number;
  winRate: number;
}