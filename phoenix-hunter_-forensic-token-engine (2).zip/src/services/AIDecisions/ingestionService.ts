
import { LaunchEvent } from "../../types";
import { 
  getLatestSolanaTokens, 
  fetchDexscreenerData, 
  getCommunityTakeovers, 
  getLatestBoosts 
} from "../TokenAnalysis/dexscreenerClient";
import { jupiterClient, getRecent as getRecentJupiter } from "../TradeExecution/jupiterClient";
import { logger } from "../Infrastructure/observabilityService";
import { INTERVALS, RATE_LIMITS, VALIDATION } from "../Infrastructure/constants";

const USER_AGENT = 'Phoenix-Hunter/2.0 (+https://github.com/yourusername/phoenix-hunter)';

export class IngestionService {
  private seen = new Map<string, { timestamp: number; sources: Set<string> }>();
  private isRunning = false;
  private timeouts: Map<string, NodeJS.Timeout> = new Map();
  private eventQueue: LaunchEvent[] = [];
  private queueProcessing = false;
  private jupiterRateLimiter = new RateLimiter(RATE_LIMITS.JUPITER_RPM, 'Jupiter');
  private dexscreenerRateLimiter = new RateLimiter(60, 'DexScreener');

  constructor() {
    logger.log("Ingestion Core initialized", "info", {}, 1, "ingestionService");
  }

  async start(onEvent: (event: LaunchEvent) => void): Promise<void> {
    if (this.isRunning) return;
    this.isRunning = true;
    this.pollJupiterRecursive(onEvent);
    this.pollDexDiscoveryRecursive(onEvent);
    this.startQueueProcessor(onEvent);
  }

  stop(): void {
    this.isRunning = false;
    this.timeouts.forEach(clearTimeout);
    this.timeouts.clear();
  }

  async fetchJupiterFeed(type: 'recent' | 'trending' | 'organic'): Promise<LaunchEvent[]> {
    try {
      let tokens: any[] = [];
      if (type === 'trending') {
        tokens = await jupiterClient.getTrending();
      } else {
        tokens = await jupiterClient.getRecent(30);
      }
      
      const events: LaunchEvent[] = [];
      for (const t of tokens) {
        if (!this.seen.has(t.id)) {
          const event = this.normalizeJupiter(t);
          if (event && this.validateLaunchEvent(event)) {
            events.push(event);
            this.markSeen(event.mint, `JUPITER_${type.toUpperCase()}`);
          }
        }
      }
      return events;
    } catch (error: any) {
      logger.log(`Failed to fetch Jupiter feed ${type}: ${error.message}`, "error");
      return [];
    }
  }

  async fetchJupiterByMint(mint: string): Promise<LaunchEvent | null> {
    try {
      const token = await jupiterClient.getByMint(mint);
      if (!token) return null;
      
      const event = this.normalizeJupiter(token);
      if (this.validateLaunchEvent(event)) {
        return event;
      }
      return null;
    } catch (error: any) {
      logger.log(`Failed to fetch Jupiter token ${mint}: ${error.message}`, "error");
      return null;
    }
  }

  private async pollJupiterRecursive(onEvent: (event: LaunchEvent) => void) {
    if (!this.isRunning) return;
    
    try {
      await this.jupiterRateLimiter.waitForSlot();
      const tokens = await getRecentJupiter(30);
      
      if (tokens) {
        for (const t of tokens) {
          if (!this.seen.has(t.id)) {
            const event = this.normalizeJupiter(t);
            if (event && this.validateLaunchEvent(event)) {
              this.enqueue(event);
              this.markSeen(t.id, 'JUPITER');
            }
          }
        }
      }
    } catch (err: any) {
      logger.log(`Jupiter Poll Warning: ${err.message}`, "warning", {}, 2, "ingestionService");
    } finally {
      if (this.isRunning) {
        // Schedule next poll only after current one finishes
        const timeout = setTimeout(
          () => this.pollJupiterRecursive(onEvent), 
          INTERVALS.INGEST_JUPITER
        );
        this.timeouts.set('jupiter', timeout);
      }
    }
  }

  private async pollDexDiscoveryRecursive(onEvent: (event: LaunchEvent) => void) {
    if (!this.isRunning) return;

    try {
      await this.dexscreenerRateLimiter.waitForSlot();
      const [profiles, takeovers, boosts] = await Promise.all([
        getLatestSolanaTokens(),
        getCommunityTakeovers(),
        getLatestBoosts()
      ]);

      const candidates = [
        ...profiles.map(p => ({ mint: p.address, src: 'DEX_PROFILE', bonus: 0 })),
        ...takeovers.map(t => ({ mint: t.tokenAddress, src: 'DEX_TAKEOVER', bonus: 15 })),
        ...boosts.map(b => ({ mint: b.tokenAddress, src: 'DEX_BOOST', bonus: 25 }))
      ];

      for (const c of candidates) {
        if (!this.isRunning) break;
        if (!this.seen.has(c.mint)) {
          const pair = await fetchDexscreenerData(c.mint);
          if (pair) {
            const event = this.normalizeDexscreener(pair, c.mint, c.src);
            event.socialScore += c.bonus;
            if (this.validateLaunchEvent(event)) {
              this.enqueue(event);
              this.markSeen(c.mint, 'DEXSCREENER');
            }
          }
        }
      }
    } catch (err: any) {
      logger.log(`Dex Poll Warning: ${err.message}`, "warning", {}, 2, "ingestionService");
    } finally {
      if (this.isRunning) {
        const timeout = setTimeout(
          () => this.pollDexDiscoveryRecursive(onEvent), 
          INTERVALS.INGEST_DEXSCREENER
        );
        this.timeouts.set('dex', timeout);
      }
    }
  }

  private enqueue(event: LaunchEvent) {
    if (this.eventQueue.length < 1000) this.eventQueue.push(event);
  }

  private markSeen(mint: string, source: string) {
    const entry = this.seen.get(mint) || { timestamp: Date.now(), sources: new Set() };
    entry.sources.add(source);
    this.seen.set(mint, entry);
  }

  private startQueueProcessor(onEvent: (event: LaunchEvent) => void) {
    // Process queue with setInterval is fine as it's just in-memory array manipulation
    const interval = setInterval(async () => {
      if (this.queueProcessing || this.eventQueue.length === 0) return;
      this.queueProcessing = true;
      while (this.eventQueue.length > 0 && this.isRunning) {
        const event = this.eventQueue.shift();
        if (event) onEvent(event);
        await new Promise(r => setTimeout(r, 50));
      }
      this.queueProcessing = false;
    }, 100);
    this.timeouts.set('queue', interval);
  }

  private normalizeJupiter(t: any): LaunchEvent {
    return {
      id: t.id, name: t.name, symbol: t.symbol, mint: t.id,
      liquidity: Number(t.liquidity) || 0, marketCap: Number(t.mcap) || 0,
      devHistory: { launches: 1, rugs: 0, avgRoi: 1 },
      socialScore: Number(t.organicScore) || 50, holders: Number(t.holderCount) || 0,
      launchedAt: Date.now(), contractVerified: !!t.isVerified,
      source: 'RAYDIUM', discoverySource: 'JUP_V2', first_seen: Date.now(),
      entry_price: Number(t.usdPrice) || 0, stage: 'IDENTIFIED', platformQuality: Number(t.organicScore) || 0
    };
  }

  private normalizeDexscreener(pair: any, mint: string, src: string): LaunchEvent {
    const liq = Number(pair.liquidity?.usd) || 0;
    return {
      id: pair.pairAddress || mint, name: pair.baseToken?.name || "Unknown",
      symbol: (pair.baseToken?.symbol || "UNK").toUpperCase(), mint: pair.baseToken?.address || mint,
      liquidity: liq, marketCap: Number(pair.fdv) || 0,
      devHistory: { launches: 1, rugs: 0, avgRoi: 1 },
      socialScore: 50, holders: 0, launchedAt: pair.pairCreatedAt || Date.now(),
      contractVerified: true, source: 'DEXSCREENER', discoverySource: src,
      first_seen: Date.now(), entry_price: Number(pair.priceUsd) || 0,
      stage: 'IDENTIFIED', platformQuality: Math.min(100, (liq / 1000) * 5)
    };
  }

  private validateLaunchEvent(e: LaunchEvent): boolean {
    return !!(e.mint && e.symbol && e.liquidity >= VALIDATION.MIN_LIQUIDITY_USD && /^[1-9A-HJ-NP-Z]{44}$/.test(e.mint));
  }
}

class RateLimiter {
  private reqs: number[] = [];
  constructor(private rpm: number, private name: string) {}
  async waitForSlot(): Promise<void> {
    const now = Date.now();
    this.reqs = this.reqs.filter(t => t > now - 60000);
    if (this.reqs.length >= this.rpm) {
      await new Promise(r => setTimeout(r, 60000 - (now - this.reqs[0]) + 100));
      return this.waitForSlot();
    }
    this.reqs.push(now);
  }
}
