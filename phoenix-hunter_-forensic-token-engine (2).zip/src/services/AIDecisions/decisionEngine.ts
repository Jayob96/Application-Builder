
import { Keypair } from "@solana/web3.js"
import { GeminiQuotaService } from "../PositionManagement/geminiQuotaService"
import { IngestionService } from "./ingestionService"
import { VerificationService } from "../TokenAnalysis/verificationService"
import { ExecutionService } from "../TradeExecution/executionService"
import { BackpackClient } from "../TradeExecution/backpackClient"
import { OrderRouter } from "../TradeExecution/orderRouter"
import { TradeExecutor, TradeRequest, TradeConfirmation } from "../TradeExecution/tradeExecutor"
import { TradeHistoryService } from "../TradeExecution/tradeHistoryService"
import { positionService } from "../TradeExecution/positionService"
import { MarketService } from "../PositionManagement/marketService"
import { PositionMonitor } from "../PositionManagement/positionMonitor"
import { analyzeNewToken } from "../TokenAnalysis/analyzeToken"
import { ForensicMLBridge } from "../TokenAnalysis/ForensicMLBridge"
import { observabilityService } from "../Infrastructure/observabilityService"
import { storageService } from "../Infrastructure/storageService"
import { vfs } from "../Infrastructure/VirtualFileSystem"
import { THRESHOLDS, INITIAL_WEIGHTS } from "../Infrastructure/constants"
import type { ActiveToken, LaunchEvent, ScoringWeights, TokenRisk, LifecycleStage, PerformanceDelta, Position } from "../../types"
import { TokenRisk as TokenRiskEnum } from "../../types"

export class DecisionEngine {
  private forensicService: GeminiQuotaService
  private ingestion: IngestionService
  private tokens: Map<string, ActiveToken>
  private onUpdate: (tokens: ActiveToken[]) => void
  private currentWeights: ScoringWeights
  private sessionKeypair: Keypair
  private isRunning: boolean
  private tradeExecutor: TradeExecutor
  private positionMonitor: PositionMonitor
  private heartbeatInterval: ReturnType<typeof setInterval> | null

  constructor(
    forensicService: GeminiQuotaService,
    onUpdate: (tokens: ActiveToken[]) => void
  ) {
    this.forensicService = forensicService
    this.onUpdate = onUpdate
    this.currentWeights = { ...INITIAL_WEIGHTS }
    this.tokens = new Map()
    this.isRunning = false
    this.ingestion = new IngestionService()
    
    try {
      this.sessionKeypair = Keypair.generate()
      const execution = new ExecutionService()
      const backpack = new BackpackClient("")
      const router = new OrderRouter(backpack, execution)
      this.tradeExecutor = new TradeExecutor(router, backpack, execution, TradeHistoryService.getInstance())
      this.positionMonitor = new PositionMonitor(execution, this.tradeExecutor, this.sessionKeypair)
    } catch (e) {
      this.sessionKeypair = Keypair.fromSeed(new Uint8Array(32).fill(1))
    }
  }

  async start(weights: ScoringWeights): Promise<void> {
    if (this.isRunning) return
    this.currentWeights = { ...weights }
    this.isRunning = true
    this.positionMonitor.start()
    this.ingestion.start(async (event: LaunchEvent) => {
      await this.processLaunch(event)
    })
    this.heartbeatInterval = setInterval(() => this.heartbeat(), 2000)
  }

  async ingestToken(event: LaunchEvent): Promise<void> {
    await this.processLaunch(event)
  }

  async manualSnipe(tokenId: string): Promise<void> {
    const token = this.tokens.get(tokenId)
    if (!token) return

    observabilityService.log(`Manual snipe initiated for ${token.symbol}`, "info", { tokenId }, 1, "DecisionEngine")
    
    token.stage = "CANDIDATE" 
    token.verdict = "SNIPE"
    this.broadcast()
  }

  private async processLaunch(event: LaunchEvent): Promise<void> {
    try {
      if (this.tokens.has(event.id)) return

      const active: ActiveToken = {
        ...event,
        status: "active",
        stage: "AUDITING",
        history: [{ timestamp: Date.now(), price: event.entry_price, roi: 1, volume: 0, lp: event.liquidity, holders: event.holders }],
        currentRoi: 1
      }

      this.tokens.set(active.id, active)
      this.broadcast()

      // Perform deep forensic audit
      const audit = await analyzeNewToken(active.mint, this.forensicService)

      if (audit && audit.aiVerdict) {
        this.applyAnalysisResults(active, audit)
      }

      // INGESTION: Append Live Data to test.csv in VFS for training
      this.updateMLTrainingCsv(active, audit);

      await this.makeEntryDecision(active)
    } catch (error) {
      observabilityService.log(`Pipeline failure`, "error", { error }, 4, "DecisionEngine")
    }
    this.broadcast()
  }

  private updateMLTrainingCsv(token: ActiveToken, audit: any): void {
    try {
      const CSV_PATH = "/test.csv";
      const timestamp = new Date().toISOString();
      const score = audit?.heuristicScore?.toFixed(2) || "0";
      const risk = token.analysis?.riskLevel || "UNKNOWN";
      const rugProb = token.analysis?.rugProbability?.toFixed(4) || "0.5";
      
      const row = [
        timestamp,
        token.symbol,
        score,
        risk,
        token.stage,
        token.liquidity.toFixed(0),
        token.holders.toFixed(0),
        rugProb
      ].join(",");

      const currentContent = vfs.getFileContent(CSV_PATH) || "Timestamp,Token,ForensicScore,RiskLevel,Status,Liquidity,Holders,RugProb\n";
      vfs.updateFile(CSV_PATH, currentContent.trimEnd() + "\n" + row);
      
      // Also sync to persistent Cloud Audit Record
      storageService.syncTokenAudit(token);
    } catch (e) {
      console.error("ML CSV Sync Failure", e);
    }
  }

  private applyAnalysisResults(token: ActiveToken, audit: any): void {
    const v = audit.aiVerdict
    token.analysis = {
      forensicScore: v.confidence,
      confidence: v.confidence,
      riskLevel: (v.riskLevel as TokenRisk) || TokenRiskEnum.MEDIUM,
      predictedHoldTime: v.predictedHoldTime || 10,
      reasoning: v.summary || v.reasoning || "No reasoning provided",
      rugProbability: v.rugProbability || 0.5
    }
    token.verdict = v.verdict === "ENTER" ? "ENTER" : "WATCH"
  }

  private async makeEntryDecision(token: ActiveToken): Promise<void> {
    if (token.verdict === "ENTER" && (token.analysis?.forensicScore || 0) >= 80) {
      this.transitionStage(token, "CANDIDATE")
    }
  }

  private transitionStage(token: ActiveToken, newStage: LifecycleStage): void {
    token.stage = newStage
  }

  private async heartbeat(): Promise<void> {
    if (!this.isRunning) return
    this.broadcast()
  }

  private broadcast(): void {
    this.onUpdate(Array.from(this.tokens.values()))
  }

  stop(): void {
    this.isRunning = false
    if (this.heartbeatInterval) clearInterval(this.heartbeatInterval)
    this.ingestion.stop()
    this.positionMonitor.stop()
  }
}
export default DecisionEngine
