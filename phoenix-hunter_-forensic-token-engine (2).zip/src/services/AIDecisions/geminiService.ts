import { GoogleGenAI, Type } from "@google/genai";
import { 
  TokenMetadata, 
  AnalysisResult, 
  ScoringWeights, 
  TokenRisk, 
  TokenOutcome,
  FilterAttribution,
  EvolutionReport
} from "../../types";
import { SYSTEM_PROMPT, INITIAL_WEIGHTS } from "../Infrastructure/constants";
import { logger } from "../Infrastructure/observabilityService";

const sleep = (ms: number) => new Promise(res => setTimeout(res, ms));

export class ForensicEngine {
  private ai: GoogleGenAI;
  private currentWeights: ScoringWeights = { ...INITIAL_WEIGHTS };
  private evolutionHistory: EvolutionReport[] = [];
  private analysisCache: Map<string, AnalysisResult> = new Map();
  private requestQueue: Promise<any> = Promise.resolve();
  private globalCooldownUntil: number = 0;
  private consecutiveRateLimits: number = 0;
  
  private outcomesTable: Array<{
    tokenId: string, 
    symbol: string,
    outcome: TokenOutcome, 
    roi: number, 
    peakRoi: number,
    timeToPeak: number,
    initialLiquidity: number,
    socialScore: number,
    score_breakdown: any,
    timestamp: number 
  }> = [];

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
  }

  getWeights(): ScoringWeights {
    return this.currentWeights;
  }

  private async enqueueRequest<T>(requestFn: () => Promise<T>): Promise<T> {
    const result = this.requestQueue.then(async () => {
      let now = Date.now();
      if (now < this.globalCooldownUntil) {
        const waitTime = this.globalCooldownUntil - now;
        logger.log(`Rate limit protection active. Waiting ${Math.ceil(waitTime / 1000)}s...`, 'warning', {}, 1, 'forensicNode');
        await sleep(waitTime);
      }

      let retries = 0;
      const maxRetries = 4; 
      let retryDelay = 10000;

      while (retries <= maxRetries) {
        try {
          const res = await requestFn();
          this.consecutiveRateLimits = 0;
          await sleep(2000); 
          return res;
        } catch (error: any) {
          const errorMessage = error?.message?.toLowerCase() || "";
          const isRateLimit = errorMessage.includes('429') || 
                            error?.status === 429 || 
                            errorMessage.includes('quota') || 
                            errorMessage.includes('exhausted');
          
          if (isRateLimit) {
            this.consecutiveRateLimits++;
            retries++;
            const backoff = retryDelay * Math.pow(2, retries - 1) + (Math.random() * 2000);
            this.globalCooldownUntil = Date.now() + backoff;
            
            logger.log(`Quota hit (${this.consecutiveRateLimits}x). Entering cool-down: ${Math.round(backoff/1000)}s.`, 'warning', { retries }, 2, 'forensicNode');
            
            if (retries <= maxRetries) {
              await sleep(backoff);
              continue;
            } else {
              this.globalCooldownUntil = Date.now() + 120000;
              logger.log("Neural Kernel suspended: Persistent Quota Exhaustion.", "error", {}, 4, "forensicNode");
              throw new Error("Gemini API Quota Exhausted.");
            }
          }
          throw error;
        }
      }
    });
    
    this.requestQueue = result.catch(() => {}); 
    return result as Promise<T>;
  }

  async runSelfEvolutionCycle(): Promise<EvolutionReport | null> {
    if (this.outcomesTable.length < 5) {
      for(let i=0; i<5; i++) {
        this.outcomesTable.push({
          tokenId: 'sim-' + i + '-' + Date.now(),
          symbol: 'SIM' + i,
          outcome: Math.random() > 0.5 ? TokenOutcome.GAIN_2X : TokenOutcome.RUG,
          roi: Math.random() * 2,
          peakRoi: Math.random() * 5,
          timeToPeak: 10,
          initialLiquidity: 20000,
          socialScore: 70,
          score_breakdown: { 
            liquidityDepth: 0.1, liquidityLock: 0.1, devReputation: 0.1, 
            holderConcentration: 0.1, mintAuthority: 0.1, freezeAuthority: 0.1, 
            socialMomentum: 0.1, taxForensics: 0.1, verificationStatus: 0.2 
          },
          timestamp: Date.now()
        });
      }
    }

    const attribution = this.analyzeFilterAttribution();
    
    return this.enqueueRequest(async () => {
      const reweightResult = await this.reweightFilters(attribution);
      if (!reweightResult) return null;

      const report: EvolutionReport = {
        timestamp: Date.now(),
        attribution,
        adjustmentReasoning: reweightResult.reasoning,
        previousWeights: { ...this.currentWeights },
        newWeights: reweightResult.weights
      };

      this.currentWeights = { ...report.newWeights };
      this.evolutionHistory.push(report);
      return report;
    });
  }

  private analyzeFilterAttribution(): FilterAttribution[] {
    const filters: (keyof ScoringWeights)[] = [
      'liquidityDepth', 'liquidityLock', 'devReputation', 
      'holderConcentration', 'mintAuthority', 'freezeAuthority', 
      'socialMomentum', 'taxForensics', 'verificationStatus'
    ];
    return filters.map(filter => {
      const highThreshold = 0.15;
      const items = this.outcomesTable.filter(o => o.score_breakdown && o.score_breakdown[filter]);
      const truePositives = items.filter(o => (o.score_breakdown[filter] > highThreshold) && (o.outcome !== TokenOutcome.LOSS && o.outcome !== TokenOutcome.RUG)).length;
      const falsePositives = items.filter(o => (o.score_breakdown[filter] > highThreshold) && (o.outcome === TokenOutcome.LOSS || o.outcome === TokenOutcome.RUG)).length;
      const falseNegatives = items.filter(o => (o.score_breakdown[filter] <= highThreshold) && (o.outcome !== TokenOutcome.LOSS && o.outcome !== TokenOutcome.RUG)).length;
      const precision = truePositives / (truePositives + falsePositives) || 0.5;
      const recall = truePositives / (truePositives + falseNegatives) || 0.5;
      const highFilterTokens = items.filter(o => o.score_breakdown[filter] > highThreshold);
      const avgRoiHigh = highFilterTokens.reduce((sum, o) => sum + o.roi, 0) / (highFilterTokens.length || 1);
      const avgRoiTotal = items.reduce((sum, o) => sum + o.roi, 0) / (items.length || 1);
      return { filterName: filter, precision, recall, roiDelta: avgRoiHigh - avgRoiTotal };
    });
  }

  private async reweightFilters(attribution: FilterAttribution[]): Promise<{ weights: ScoringWeights, reasoning: string } | null> {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Reweight Phoenix Hunter Forensic filters. Current: ${JSON.stringify(this.currentWeights)}. Perf: ${JSON.stringify(attribution)}. Maximize ROI.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              weights: {
                type: Type.OBJECT,
                properties: {
                  liquidityDepth: { type: Type.NUMBER },
                  liquidityLock: { type: Type.NUMBER },
                  devReputation: { type: Type.NUMBER },
                  holderConcentration: { type: Type.NUMBER },
                  mintAuthority: { type: Type.NUMBER },
                  freezeAuthority: { type: Type.NUMBER },
                  socialMomentum: { type: Type.NUMBER },
                  taxForensics: { type: Type.NUMBER },
                  verificationStatus: { type: Type.NUMBER }
                },
                required: [
                  "liquidityDepth", "liquidityLock", "devReputation", 
                  "holderConcentration", "mintAuthority", "freezeAuthority", 
                  "socialMomentum", "taxForensics", "verificationStatus"
                ]
              },
              reasoning: { type: Type.STRING }
            },
            required: ["weights", "reasoning"]
          }
        }
      });
      return JSON.parse(response.text || "{}");
    } catch (err) {
      logger.log("Topology calibration bypass: Quota/Model failure.", "warning");
      return null;
    }
  }

  async analyzeToken(token: TokenMetadata, weights: ScoringWeights): Promise<AnalysisResult> {
    if (this.analysisCache.has(token.mint)) {
      return this.analysisCache.get(token.mint)!;
    }

    const prompt = `
Perform forensic audit on Solana token:
Symbol: ${token.symbol}
Mint: ${token.mint}
Liq: $${token.liquidity}
MCap: $${token.marketCap}
Verified: ${token.contractVerified}
Source: ${token.discoverySource}

Assess risk of rug-pull and potential for 10x+ growth.
    `.trim();

    return this.enqueueRequest(async () => {
      try {
        const response = await this.ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: prompt,
          config: {
            systemInstruction: SYSTEM_PROMPT,
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                forensicScore: { type: Type.NUMBER },
                confidence: { type: Type.NUMBER },
                riskLevel: { type: Type.STRING, description: "LOW, MEDIUM, HIGH, CRITICAL" },
                predictedHoldTime: { type: Type.NUMBER },
                reasoning: { type: Type.STRING },
                rugProbability: { type: Type.NUMBER }
              },
              required: ["forensicScore", "confidence", "riskLevel", "predictedHoldTime", "reasoning", "rugProbability"]
            }
          }
        });
        
        const parsed = JSON.parse(response.text || "{}");
        const result: AnalysisResult = {
          forensicScore: parsed.forensicScore || 50,
          confidence: parsed.confidence || 50,
          riskLevel: (parsed.riskLevel as TokenRisk) || TokenRisk.MEDIUM,
          predictedHoldTime: parsed.predictedHoldTime || 5,
          reasoning: parsed.reasoning || "Forensic sequence complete.",
          rugProbability: parsed.rugProbability || 0.5
        };

        this.analysisCache.set(token.mint, result);
        return result;
      } catch (error: any) {
        throw error;
      }
    }).catch(err => {
      return { 
        forensicScore: 50, 
        confidence: 10, 
        riskLevel: TokenRisk.MEDIUM, 
        predictedHoldTime: 5, 
        reasoning: "Neural downlink failed. Manual verification required.", 
        rugProbability: 0.5 
      };
    });
  }
}