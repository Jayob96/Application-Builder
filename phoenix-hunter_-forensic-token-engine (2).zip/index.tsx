import React, { Component, ErrorInfo, ReactNode } from 'react';
import ReactDOM from 'react-dom/client';
import App from './src/App';
import { AlertOctagon, Terminal } from 'lucide-react';
import { observabilityService } from './src/services/Infrastructure/observabilityService';

interface ErrorBoundaryProps {
  children?: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

// Setup Global Exception Handlers
const setupGlobalErrorHandling = () => {
  window.addEventListener('error', (event) => {
    observabilityService.reportError(
      event.error || event.message, 
      { 
        filename: event.filename, 
        lineno: event.lineno, 
        colno: event.colno 
      }, 
      'Window::OnError'
    );
  });

  window.addEventListener('unhandledrejection', (event) => {
    observabilityService.reportError(
      event.reason, 
      { type: 'Unhandled Promise Rejection' }, 
      'Window::Promise'
    );
  });
};

setupGlobalErrorHandling();

// Global Error Boundary to catch neural kernel panics
class GlobalErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  // FIXED: Standardize state initialization for TypeScript Component
  state: ErrorBoundaryState = {
    hasError: false,
    error: null,
    errorInfo: null
  };

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error, errorInfo: null };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("PHX_KERNEL_PANIC:", error, errorInfo);
    this.setState({ errorInfo });
    
    // Report to internal logger
    observabilityService.reportError(
      error, 
      { componentStack: errorInfo.componentStack }, 
      'React::ErrorBoundary'
    );
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#050505] flex items-center justify-center p-6 font-mono text-white">
          <div className="max-w-2xl w-full glass-panel border-red-500/50 p-8 rounded-2xl shadow-2xl bg-black/80 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-red-500 animate-pulse" />
            
            <div className="flex items-center gap-4 text-red-500 mb-6">
              <AlertOctagon size={48} className="animate-pulse" />
              <div>
                <h1 className="text-2xl font-black uppercase tracking-tighter italic">Neural Ash Detected</h1>
                <p className="text-xs opacity-60 uppercase font-bold tracking-[0.2em]">Execution Loop Halted</p>
              </div>
            </div>
            
            <div className="bg-red-500/5 border border-red-500/20 p-4 rounded-lg mb-6 max-h-64 overflow-y-auto">
              <div className="text-[10px] text-red-400 font-bold mb-2 uppercase tracking-widest">Error Trace</div>
              <pre className="text-xs text-red-300 whitespace-pre-wrap font-mono">
                {this.state.error?.toString() || "SYNAPSE_FAILURE"}
              </pre>
              {this.state.errorInfo && (
                <div className="mt-4 pt-4 border-t border-red-500/20">
                   <div className="text-[10px] text-red-400 font-bold mb-2 uppercase tracking-widest">Component Stack</div>
                   <pre className="text-[10px] text-red-300/70 whitespace-pre-wrap">
                     {this.state.errorInfo.componentStack}
                   </pre>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button 
                onClick={() => window.location.reload()}
                className="py-3 bg-red-500/20 hover:bg-red-500/40 text-red-500 text-[10px] font-black uppercase tracking-[0.2em] rounded-lg border border-red-500/30 transition-all flex items-center justify-center gap-2"
              >
                <Terminal size={14} /> Re-Ignite Core
              </button>
              <button 
                onClick={() => {
                  // Hard reset local storage in case of corrupt state
                  localStorage.clear();
                  window.location.reload();
                }}
                className="py-3 bg-zinc-800/50 hover:bg-zinc-800 text-zinc-400 text-[10px] font-black uppercase tracking-[0.2em] rounded-lg border border-zinc-700/50 transition-all"
              >
                Factory Reset
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <GlobalErrorBoundary>
      <App />
    </GlobalErrorBoundary>
  );
}