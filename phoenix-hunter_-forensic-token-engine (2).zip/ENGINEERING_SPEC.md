
# Phoenix Hunter: Forensic Token Analysis & Autonomous Trading Engine
## Engineering Specification & Architectural Reference v2.1

---

## 1. Abstract

**Phoenix Hunter** is a high-fidelity, autonomous trading terminal architected for the Solana blockchain. It functions as a "Forensic Node," capable of ingesting high-velocity token launch data, performing real-time security auditing via on-chain heuristics and Large Language Model (LLM) inference, and executing trades with millisecond-precision.

Unlike standard trading bots that rely solely on technical indicators, Phoenix Hunter employs a **hybrid neuro-symbolic architecture**. It combines deterministic rule-based validation (Symbolic AI) with probabilistic risk assessment provided by Google's Gemini 3 Flash model (Neural AI). The system features a novel **Virtual File System (VFS)** layer that bridges React application state with an embedded Python (Pyodide) runtime, allowing for dynamic script execution, self-calibration, and persistent state management within the browser execution environment.

---

## 2. System Architecture

The application follows a **Service-Oriented Architecture (SOA)** implemented as a Single Page Application (SPA). It relies on a singleton pattern for service instantiation to maintain state consistency across the React component lifecycle without the overhead of Redux or Context API for high-frequency data.

### 2.1 Core Layers

1.  **Presentation Layer (React 19):**
    *   High-performance UI rendering using direct service subscriptions.
    *   Cyberpunk aesthetic via Tailwind CSS.
    *   Components act as "View" controllers, delegating logic to the Service layer.

2.  **Orchestration Layer (Decision Engine):**
    *   Central nervous system of the app.
    *   Manages the lifecycle of a token from `Discovery` -> `Audit` -> `Candidacy` -> `Execution` -> `Monitoring` -> `Exit`.

3.  **Cognitive Layer (Forensic Engine):**
    *   Interfaces with `GeminiQuotaService`.
    *   Translates raw token metadata into semantic risk assessments.
    *   Implements "Self-Evolution" via `ForensicMLBridge`.

4.  **Infrastructure Layer:**
    *   **VFS (Virtual File System):** A JSON-based file system abstracting `localStorage` into a directory structure (`/src`, `/logs`, `/data`).
    *   **Observability:** Structured logging, error telemetry, and performance profiling.
    *   **Python Runtime:** WASM-based Python 3.11 environment for data science tasks on the client side.

5.  **Execution Layer:**
    *   **Router:** Determines optimal execution venue (Jupiter Aggregator vs. Backpack Exchange).
    *   **Wallet:** Non-custodial key management (Ed25519).

---

## 3. Data Pipelines & Logic Flow

### 3.1 Token Ingestion Pipeline
**Source:** `src/services/AIDecisions/ingestionService.ts`

The ingestion pipeline operates on two parallel threads to maximize coverage:
1.  **Jupiter V2 Stream:** Polls `https://api.jup.ag/tokens/v2/recent` to identify newly created mints.
2.  **DexScreener Discovery:** Polls `token-profiles`, `boosts`, and `community-takeovers` endpoints.

**Logic:**
*   **Normalization:** Data from divergent sources is mapped to a unified `LaunchEvent` interface.
*   **Deduplication:** A `Set<string>` tracks seen mint addresses to prevent re-processing.
*   **Rate Limiting:** Implements token-bucket rate limiting to respect API quotas.

### 3.2 The Forensic Audit Sequence
**Source:** `src/services/TokenAnalysis/analyzeToken.ts`

Upon ingestion, a token enters the `AUDITING` stage. The `analyzeNewToken` function orchestrates a multi-step verification:

1.  **Parallel Data Fetch:** Simultaneously requests data from Jupiter V2 and DexScreener.
2.  **Heuristic Scoring (`jupiterScoring.ts`):**
    *   Calculates a deterministic score (0-100) based on hard metrics: Liquidity > $10k, Mint Auth Disabled, Top 10 Holders < 30%.
3.  **On-Chain Verification (`verificationService.ts`):**
    *   Queries Solana RPC to parse the Mint Account and Token Program data.
    *   Verifies Freeze Authority status and LP Token burning/locking.
4.  **Neural Inference (`geminiService.ts`):**
    *   If the Heuristic Score > `minScoreForAI` (70), the metadata is serialized into a prompt for Gemini 3 Flash.
    *   The LLM returns a JSON object containing `rugProbability`, `confidence`, and `reasoning`.
5.  **Fusion:** The Heuristic Score and AI Score are weighted (default 60/40) to produce a `FinalForensicScore`.

### 3.3 Decision & Execution
**Source:** `src/services/AIDecisions/decisionEngine.ts`

*   **Entry:** If `FinalForensicScore` > `THRESHOLDS.SNIPE_SCORE` (85), the engine triggers an automatic snipe.
*   **Routing (`orderRouter.ts`):** The router compares the estimated output of a swap via Jupiter vs. Backpack. It selects the venue with the highest expected output, accounting for slippage and fees.
*   **Signing:** The transaction is constructed and signed using the session `Keypair` or connected wallet.

### 3.4 Position Lifecycle & Self-Healing
**Source:** `src/services/PositionManagement/positionMonitor.ts` & `SelfHealingService.ts`

*   **Monitoring:** An interval loop fetches live prices every 2 seconds.
*   **Exit Logic:**
    *   **Stop Loss:** Fixed % drop (e.g., -15%).
    *   **Take Profit:** Fixed % gain (e.g., +50%).
    *   **Trailing Stop:** Dynamic floor that rises with price peaks (e.g., 15% below ATH).
    *   **Rug Detection:** If price drops >80% within 3 ticks, emergency exit is triggered.
*   **Self-Healing:** If the VFS encounters write collisions (e.g., `troubleshoot_db.json` exists), the `SelfHealingService` catches the error, switches from `createFile` to `updateFile`, and logs the incident for future optimization.

---

## 4. Virtual File System (VFS) Internals
**Source:** `src/services/Infrastructure/VirtualFileSystem.ts`

The VFS is a critical infrastructure component that simulates a hierarchical file system in the browser.

*   **Data Structure:** `FileNode` tree serialized to JSON in `localStorage`.
*   **Capabilities:**
    *   **CRUD:** Create, Read, Update, Delete files/folders.
    *   **Versioning:** Maintains an undo/redo history stack.
    *   **Search:** Recursive tree traversal for content/name matching.
    *   **Persistence:** Auto-saves to browser storage.
*   **Integration:**
    *   **Python Bridge:** The `PythonKernelService` injects a `phx_vfs` module into the Python WASM runtime, allowing Python scripts to read/write VFS files directly (e.g., reading `data/test.csv` to train a model).

---

## 5. Detailed File & Folder Breakdown

### `/src` - Application Source Code

#### `/src/components` - UI Components
*   **`App.tsx`:** Root controller. Manages navigation (`dashboard`, `trading`, `logs`) and system boot sequence.
*   **`TerminalHeader.tsx`:** Displays system vitals (CPU/Mem simulation, uptime, health score).
*   **`TokenTable.tsx`:** Complex data grid for displaying tokens. Supports sorting, filtering (Risk/Stage), and bulk actions.
*   **`SystemLogs.tsx`:** Real-time log viewer with color-coded severity, filtering, and JSON expansion.
*   **`ForensicRadar.tsx`:** Visualizes the scoring weights (Liquidity vs. Dev Rep vs. Social) using a progress bar interface.
*   **`CodeTerminal.tsx`:** An IDE-like component. Integrates the VFS file tree sidebar with a code editor and a CLI terminal for executing "npm" or "python" commands.
*   **`CodeTerminal-NPM-Integration.tsx`:** Simulates npm commands (`install`, `audit`) within the virtual terminal.
*   **`TroubleshootPanel.tsx`:** Visualization of the `SelfHealingService` database, showing active incidents and system health.

#### `/src/services` - Business Logic Core

**`/src/services/AIDecisions`** (Brain)
*   **`decisionEngine.ts`:** The central loop. Ingests tokens, calls analysis, triggers trades, maintains the `tokens` state map.
*   **`geminiService.ts` (ForensicEngine):** Manages Gemini API interactions. Handles prompt engineering and JSON response parsing.
*   **`ingestionService.ts`:** Manages the polling loops for Jupiter and DexScreener. Handles rate limiting and normalization.

**`/src/services/Infrastructure`** (Plumbing)
*   **`VirtualFileSystem.ts`:** The implementation of the VFS logic (tree traversal, persistence, events).
*   **`fileRegistry.ts`:** Defines the *default* file structure (initial config, default Python scripts) loaded on a fresh boot.
*   **`PackageManagerService.ts`:** Simulates a package manager, fetching metadata from the real npm registry but "installing" to VFS.
*   **`PythonKernelService.ts`:** Manages the Pyodide WASM runtime. Handles package installation (`micropip`) and script execution.
*   **`SelfHealingService.ts`:** Autonomous error handling. Monitors logs for patterns (e.g., 429 errors) and applies fixes (adjusting backoff). Stores incident history in VFS.
*   **`observabilityService.ts`:** Centralized pub/sub logger. Distributes logs to the UI, console, and VFS.
*   **`storageService.ts`:** Handles syncing data to Google Sheets (if configured).
*   **`constants.ts`:** System-wide configuration (weights, thresholds, API limits).
*   **`troubleshootReporter.ts`:** Generates diagnostic reports on system environment and connectivity.

**`/src/services/PositionManagement`** (Portfolio)
*   **`marketService.ts`:** Fetches live price/liquidity data. Implements simulation fallbacks if APIs fail.
*   **`positionMonitor.ts`:** The "Guard Dog." Checks active positions against exit criteria every tick.
*   **`geminiQuotaService.ts`:** Tracks API usage for Gemini to prevent rate limiting. Switches to heuristic fallback if quota is exceeded.

**`/src/services/TokenAnalysis`** (Forensics)
*   **`analyzeToken.ts`:** The master workflow for auditing a token. Aggregates data and scores.
*   **`verificationService.ts`:** Performs RPC calls to verify on-chain security parameters (Mint/Freeze authority).
*   **`jupiterScoring.ts`:** Contains the specific heuristic logic for scoring based on Jupiter V2 data.
*   **`dexscreenerClient.ts`:** Client for interacting with DexScreener API.
*   **`ForensicMLBridge.ts`:** An abstraction layer to connect to external ML endpoints (Python/TensorFlow) for advanced inference.

**`/src/services/TradeExecution`** (Action)
*   **`executionService.ts`:** Handles Solana transaction construction and signing via Jupiter Swap API.
*   **`tradeExecutor.ts`:** High-level abstraction for executing trades. Calls the router and logs results.
*   **`orderRouter.ts`:** Smart routing logic to choose between execution venues.
*   **`backpackClient.ts`:** Client for Backpack Exchange execution (Ed25519 signing).
*   **`ultraSwapOrchestrator.ts` & `ultraSwapClient.ts`:** Implementation for Jupiter's "Ultra" swap mode (beta).
*   **`positionService.ts`:** In-memory store for active positions.
*   **`tradeHistoryService.ts`:** Logs completed trades to LocalStorage/VFS.

**`/src/types.ts`:** Shared TypeScript interfaces defining the data models (Token, Position, Log, Weights).

---

## 6. Key Algorithmic Concepts

### 6.1 The "Forensic Score"
The score (0-100) is a weighted sum of normalized vectors:

$$ Score = \sum (Vector_i \times Weight_i) $$

Where vectors include:
1.  **Liquidity Depth ($15\%):** Normalized log scale of liquidity USD.
2.  **Dev Reputation ($15\%):** Based on history of previous deployments (if available).
3.  **Holder Lock ($15\%):** Binary check on LP burning/locking.
4.  **Mint/Freeze Auth ($20\%):** Immediate penalty if enabled.
5.  **Social/Organic ($10\%):** Based on Jupiter's "Organic Score".

### 6.2 Self-Healing Mechanism
The `SelfHealingService` subscribes to the log stream.
*   **Input:** Stream of `SystemLog` objects.
*   **Pattern Matching:** Regex matching on error messages (e.g., "Entry already exists", "429 Too Many Requests").
*   **Action:**
    *   *Rate Limits:* Triggers a global backoff in `constants.ts` (runtime modification).
    *   *VFS Conflicts:* Switches strategies (Create -> Update).
    *   *Storage Full:* Triggers log rotation/pruning.

### 6.3 Python-JS Interop
The application uses a shared memory model via the VFS.
1.  **JS** writes token data to `/data/test.csv`.
2.  **JS** calls `pythonKernel.runScript('/scripts/ml_calibrate.py')`.
3.  **Python (WASM)** reads `/data/test.csv` via the injected `phx_vfs` bridge.
4.  **Python** calculates statistics (e.g., standard deviation of ROI).
5.  **Python** writes results to `/reports/calibration_latest.json`.
6.  **JS** detects file change via VFS subscription and updates the UI.

---

## 7. Conclusion

Phoenix Hunter represents a sophisticated convergence of web technologies, cryptography, and artificial intelligence. By bringing the runtime environment (Python), the database (VFS), and the decision engine (Gemini) directly into the client, it eliminates backend latency and creates a fully autonomous, self-contained trading singularity.
